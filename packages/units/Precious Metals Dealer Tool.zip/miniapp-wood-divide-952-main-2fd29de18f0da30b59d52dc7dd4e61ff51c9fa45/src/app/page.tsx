'use client'
import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Switch } from '@/components/ui/switch';
import { PriceChart } from '@/components/PriceChart';
import { PresetTemplates } from '@/components/PresetTemplates';
import { CustomerTracker, type Customer } from '@/components/CustomerTracker';
import { ProfitLossDashboard } from '@/components/ProfitLossDashboard';
import { PrintReceipt } from '@/components/PrintReceipt';
import { PriceAlerts, type PriceAlert } from '@/components/PriceAlerts';
import type { MetalCode, UnitType, SpotMap } from '@/lib/melt';
import { calcMeltValue, calcSpreadAndPremiums, getMetalName } from '@/lib/melt';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type QuoteRow = {
  id: string;
  metal: MetalCode;
  label: string;
  weightValue: number;
  unit: UnitType;
  purity: number;
  meltValue: number;
  buyPrice: number;
  sellPrice: number;
  spreadPct: number;
  marginPerUnit: number;
  buyOverMeltPct: number;
  sellOverMeltPct: number;
  createdAt: number;
  customerId?: string | null;
};

type SpotData = SpotMap & {
  currency: string;
  timestamp: number;
};

type PricePoint = {
  time: string;
  price: number;
};

type PriceHistory = {
  [key in MetalCode]: PricePoint[];
};

export default function MeltSpreadEngine() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  // Spot prices state
  const [spotData, setSpotData] = useState<SpotData | null>(null);
  const [spotLoading, setSpotLoading] = useState<boolean>(false);
  const [spotError, setSpotError] = useState<string>("");
  const [autoRefresh, setAutoRefresh] = useState<boolean>(false);
  const [priceHistory, setPriceHistory] = useState<PriceHistory>({
    AU: [],
    AG: [],
    PT: [],
    PD: [],
    RH: []
  });

  // Form state
  const [label, setLabel] = useState<string>("");
  const [metal, setMetal] = useState<MetalCode>("AU");
  const [weightValue, setWeightValue] = useState<string>("");
  const [unit, setUnit] = useState<UnitType>("oz");
  const [purity, setPurity] = useState<string>(".999");
  const [buyPrice, setBuyPrice] = useState<string>("");
  const [sellPrice, setSellPrice] = useState<string>("");

  // Calculated values for preview
  const [previewCalc, setPreviewCalc] = useState<{
    melt: number;
    spread: number;
    margin: number;
    buyOverMelt: number;
    sellOverMelt: number;
  } | null>(null);

  // Quotes table
  const [quotes, setQuotes] = useState<QuoteRow[]>([]);

  // Chart display
  const [showCharts, setShowCharts] = useState<boolean>(false);

  // Customer tracking
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [selectedCustomerId, setSelectedCustomerId] = useState<string | null>(null);

  // Price alerts
  const [priceAlerts, setPriceAlerts] = useState<PriceAlert[]>([]);

  // Fetch spot prices
  const fetchSpotPrices = useCallback(async () => {
    setSpotLoading(true);
    setSpotError("");

    try {
      const res = await fetch('/api/spot');
      if (!res.ok) {
        const errorData = await res.json();
        throw new Error(errorData.hint || errorData.error || 'Failed to fetch spot prices');
      }
      const data = await res.json();
      setSpotData(data);

      // Update price history
      const now = new Date();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      
      setPriceHistory((prev: PriceHistory) => {
        const updated: PriceHistory = { ...prev };
        const metals: MetalCode[] = ['AU', 'AG', 'PT', 'PD', 'RH'];
        
        metals.forEach((m: MetalCode) => {
          const key = m.toLowerCase() as 'gold' | 'silver' | 'platinum' | 'palladium' | 'rhodium';
          const metalKey: keyof SpotMap = key === 'gold' ? 'gold' : 
                                           key === 'silver' ? 'silver' : 
                                           key === 'platinum' ? 'platinum' : 
                                           key === 'palladium' ? 'palladium' : 'rhodium';
          const price = data[metalKey];
          const history = [...prev[m]];
          history.push({ time: timeStr, price });
          // Keep last 24 points (1 per minute for 24 minutes, or adjust as needed)
          if (history.length > 24) {
            history.shift();
          }
          updated[m] = history;
        });
        
        return updated;
      });
    } catch (err) {
      setSpotError(err instanceof Error ? err.message : 'Unknown error');
    } finally {
      setSpotLoading(false);
    }
  }, []);

  // Load spot prices on mount
  useEffect(() => {
    fetchSpotPrices();
  }, [fetchSpotPrices]);

  // Auto-refresh every 60 seconds
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchSpotPrices();
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, [autoRefresh, fetchSpotPrices]);

  // Recalculate preview when form changes
  useEffect(() => {
    if (!spotData) return;

    const weight = parseFloat(weightValue);
    const purityVal = parseFloat(purity);
    const buy = parseFloat(buyPrice);
    const sell = parseFloat(sellPrice);

    if (isNaN(weight) || isNaN(purityVal) || isNaN(buy) || isNaN(sell)) {
      setPreviewCalc(null);
      return;
    }

    const melt = calcMeltValue(metal, weight, unit, purityVal, spotData);
    const { marginPerUnit, spreadPct, buyOverMeltPct, sellOverMeltPct } = calcSpreadAndPremiums(melt, buy, sell);

    setPreviewCalc({
      melt,
      spread: spreadPct,
      margin: marginPerUnit,
      buyOverMelt: buyOverMeltPct,
      sellOverMelt: sellOverMeltPct
    });
  }, [spotData, metal, weightValue, unit, purity, buyPrice, sellPrice]);

  const handleAddQuote = () => {
    if (!spotData) {
      alert('No spot data available. Please refresh spot prices.');
      return;
    }

    const weight = parseFloat(weightValue);
    const purityVal = parseFloat(purity);
    const buy = parseFloat(buyPrice);
    const sell = parseFloat(sellPrice);

    if (!label.trim()) {
      alert('Please enter a label');
      return;
    }

    if (isNaN(weight) || weight <= 0) {
      alert('Please enter a valid weight');
      return;
    }

    if (isNaN(purityVal) || purityVal <= 0 || purityVal > 1) {
      alert('Please enter a valid purity (0 to 1)');
      return;
    }

    if (isNaN(buy) || buy < 0) {
      alert('Please enter a valid buy price');
      return;
    }

    if (isNaN(sell) || sell < 0) {
      alert('Please enter a valid sell price');
      return;
    }

    const melt = calcMeltValue(metal, weight, unit, purityVal, spotData);
    const { marginPerUnit, spreadPct, buyOverMeltPct, sellOverMeltPct } = calcSpreadAndPremiums(melt, buy, sell);

    const newQuote: QuoteRow = {
      id: Date.now().toString(),
      metal,
      label,
      weightValue: weight,
      unit,
      purity: purityVal,
      meltValue: melt,
      buyPrice: buy,
      sellPrice: sell,
      spreadPct,
      marginPerUnit,
      buyOverMeltPct,
      sellOverMeltPct,
      createdAt: Date.now(),
      customerId: selectedCustomerId
    };

    setQuotes([newQuote, ...quotes]);

    // Update customer stats if a customer is selected
    if (selectedCustomerId) {
      setCustomers(customers.map((c: Customer) => {
        if (c.id === selectedCustomerId) {
          return {
            ...c,
            totalQuotes: c.totalQuotes + 1,
            totalValue: c.totalValue + sell,
            lastVisit: Date.now()
          };
        }
        return c;
      }));
    }

    // Clear form
    setLabel("");
    setWeightValue("");
    setBuyPrice("");
    setSellPrice("");
  };

  const handleDeleteQuote = (id: string) => {
    setQuotes(quotes.filter((q: QuoteRow) => q.id !== id));
  };

  const handleDuplicateQuote = (quote: QuoteRow) => {
    // Populate form with the quote's values for quick repricing
    setLabel(quote.label);
    setMetal(quote.metal);
    setWeightValue(quote.weightValue.toString());
    setUnit(quote.unit);
    setPurity(quote.purity.toString());
    setBuyPrice(quote.buyPrice.toString());
    setSellPrice(quote.sellPrice.toString());

    // Scroll to top so user can see the form
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handlePresetSelect = (preset: { label: string; metal: MetalCode; weightValue: number; unit: UnitType; purity: number }) => {
    setLabel(preset.label);
    setMetal(preset.metal);
    setWeightValue(preset.weightValue.toString());
    setUnit(preset.unit);
    setPurity(preset.purity.toString());
    // Leave buy/sell prices empty for user to fill
    setBuyPrice("");
    setSellPrice("");
  };

  const handleAddCustomer = (customerData: Omit<Customer, 'id' | 'totalQuotes' | 'totalValue' | 'lastVisit'>) => {
    const newCustomer: Customer = {
      id: Date.now().toString(),
      ...customerData,
      totalQuotes: 0,
      totalValue: 0,
      lastVisit: Date.now()
    };
    setCustomers([...customers, newCustomer]);
    setSelectedCustomerId(newCustomer.id);
  };

  const handleAddPriceAlert = (alertData: Omit<PriceAlert, 'id' | 'active' | 'createdAt'>) => {
    const newAlert: PriceAlert = {
      id: Date.now().toString(),
      ...alertData,
      active: true,
      createdAt: Date.now()
    };
    setPriceAlerts([...priceAlerts, newAlert]);
  };

  const handleTogglePriceAlert = (id: string) => {
    setPriceAlerts(priceAlerts.map((alert: PriceAlert) => 
      alert.id === id ? { ...alert, active: !alert.active } : alert
    ));
  };

  const handleDeletePriceAlert = (id: string) => {
    setPriceAlerts(priceAlerts.filter((alert: PriceAlert) => alert.id !== id));
  };

  const handleExportCSV = () => {
    if (quotes.length === 0) {
      alert('No quotes to export');
      return;
    }

    const headers = [
      'Label', 'Metal', 'Weight', 'Unit', 'Purity', 
      'Melt Value', 'Buy Price', 'Sell Price', 
      'Spread %', 'Margin', 'Buy/Melt %', 'Sell/Melt %', 
      'Created Time'
    ];

    const rows = quotes.map((q: QuoteRow) => [
      q.label,
      q.metal,
      q.weightValue.toString(),
      q.unit,
      q.purity.toString(),
      q.meltValue.toFixed(2),
      q.buyPrice.toFixed(2),
      q.sellPrice.toFixed(2),
      q.spreadPct.toFixed(2),
      q.marginPerUnit.toFixed(2),
      q.buyOverMeltPct.toFixed(2),
      q.sellOverMeltPct.toFixed(2),
      new Date(q.createdAt).toLocaleString()
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row: string[]) => row.map((cell: string) => `"${cell}"`).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `melt-spread-quotes-${Date.now()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const getSpreadColor = (spreadPct: number): string => {
    if (spreadPct < 1) return 'text-red-500';
    if (spreadPct >= 1 && spreadPct < 3) return 'text-yellow-500';
    if (spreadPct >= 3 && spreadPct <= 10) return 'text-green-500';
    return 'text-cyan-400';
  };

  const getSellOverMeltColor = (sellOverMeltPct: number): string => {
    if (sellOverMeltPct > 30) return 'text-yellow-500';
    if (sellOverMeltPct >= 5 && sellOverMeltPct <= 20) return 'text-green-400';
    return 'text-gray-400';
  };

  const getSpreadAlert = (spreadPct: number): string => {
    if (spreadPct < 1) return '🔴 Too Tight';
    if (spreadPct >= 1 && spreadPct < 3) return '🟡 Thin';
    if (spreadPct >= 3 && spreadPct <= 10) return '🟢 Good';
    return '🔵 Wide';
  };

  return (
    <div className="min-h-screen bg-[#020617] text-white p-4 pt-12 md:pt-4">
      <div className="max-w-[1400px] mx-auto space-y-6">
        {/* Header */}
        <div className="text-center py-6">
          <h1 className="text-3xl font-bold text-cyan-400">⚡ Melt & Spread Engine</h1>
          <p className="text-gray-400 mt-2">Live Precious Metals Dealer Desk</p>
        </div>

        {/* Spot Bar */}
        <Card className="bg-[#050816] border-[#1e293b]">
          <CardHeader className="pb-3">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <CardTitle className="text-cyan-400 text-lg">📊 Live Spot Prices</CardTitle>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-2">
                  <Label htmlFor="auto-refresh" className="text-sm text-gray-400">Auto-refresh (60s)</Label>
                  <Switch
                    id="auto-refresh"
                    checked={autoRefresh}
                    onCheckedChange={setAutoRefresh}
                  />
                </div>
                <Button 
                  onClick={fetchSpotPrices} 
                  disabled={spotLoading}
                  className="bg-cyan-600 hover:bg-cyan-700"
                  size="sm"
                >
                  {spotLoading ? 'Loading...' : '🔄 Refresh Spot'}
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            {spotError && (
              <div className="bg-red-500/10 border border-red-500 rounded p-3 mb-4">
                <div className="text-red-400 font-semibold mb-1">⚠️ {spotError}</div>
                <div className="text-xs text-gray-400 mt-2">
                  💡 Get a free API key at <a href="https://metals-api.com" target="_blank" rel="noopener noreferrer" className="text-cyan-400 underline">metals-api.com</a> and set it as METALS_API_KEY environment variable.
                </div>
              </div>
            )}
            {spotData && (
              <div className="space-y-3">
                <div className="flex flex-wrap gap-3">
                  <Badge variant="outline" className="border-cyan-500 text-cyan-400 px-4 py-2 text-base">
                    🥇 AU: ${spotData.gold.toFixed(2)} / oz
                  </Badge>
                  <Badge variant="outline" className="border-green-500 text-green-400 px-4 py-2 text-base">
                    🥈 AG: ${spotData.silver.toFixed(2)} / oz
                  </Badge>
                  <Badge variant="outline" className="border-gray-400 text-gray-300 px-4 py-2 text-base">
                    ⚪ PT: ${spotData.platinum.toFixed(2)} / oz
                  </Badge>
                  <Badge variant="outline" className="border-blue-400 text-blue-300 px-4 py-2 text-base">
                    🔵 PD: ${spotData.palladium.toFixed(2)} / oz
                  </Badge>
                  <Badge variant="outline" className="border-purple-400 text-purple-300 px-4 py-2 text-base">
                    🟣 RH: ${spotData.rhodium.toFixed(2)} / oz
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <div className="text-xs text-gray-500">
                    Last updated: {new Date(spotData.timestamp).toLocaleString()} ({spotData.currency})
                  </div>
                  <Button
                    onClick={() => setShowCharts(!showCharts)}
                    variant="outline"
                    size="sm"
                    className="border-[#1e293b] text-xs"
                  >
                    {showCharts ? '📉 Hide Charts' : '📈 Show 24h Charts'}
                  </Button>
                </div>
              </div>
            )}
            {!spotData && !spotLoading && (
              <div className="text-gray-400">Click "Refresh Spot" to load live prices</div>
            )}
          </CardContent>
        </Card>

        {/* Price Charts */}
        {showCharts && spotData && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            <PriceChart metal="AU" data={priceHistory.AU} />
            <PriceChart metal="AG" data={priceHistory.AG} />
            <PriceChart metal="PT" data={priceHistory.PT} />
            <PriceChart metal="PD" data={priceHistory.PD} />
            <PriceChart metal="RH" data={priceHistory.RH} />
          </div>
        )}

        {/* Customer Tracker and Price Alerts */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <CustomerTracker 
            customers={customers}
            selectedCustomerId={selectedCustomerId}
            onSelectCustomer={setSelectedCustomerId}
            onAddCustomer={handleAddCustomer}
          />
          <PriceAlerts
            alerts={priceAlerts}
            onAddAlert={handleAddPriceAlert}
            onToggleAlert={handleTogglePriceAlert}
            onDeleteAlert={handleDeletePriceAlert}
          />
        </div>

        {/* Profit/Loss Dashboard */}
        <ProfitLossDashboard quotes={quotes} />

        {/* Preset Templates */}
        <PresetTemplates onSelect={handlePresetSelect} />

        {/* Quote Input Card */}
        <Card className="bg-[#050816] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-cyan-400">➕ Add Quote</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="label" className="text-yellow-300 font-semibold">Label</Label>
                <Input
                  id="label"
                  placeholder="e.g., 1oz Gold Eagle"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  className="bg-[#0a0f1e] border-[#1e293b] text-white placeholder:text-yellow-600"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="metal" className="text-yellow-300 font-semibold">Metal</Label>
                <Select value={metal} onValueChange={(val) => setMetal(val as MetalCode)}>
                  <SelectTrigger className="bg-[#0a0f1e] border-[#1e293b] text-yellow-300 font-semibold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                    <SelectItem value="AU" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🥇 Gold (AU)</SelectItem>
                    <SelectItem value="AG" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🥈 Silver (AG)</SelectItem>
                    <SelectItem value="PT" className="text-yellow-300 hover:text-green-300 focus:text-green-300">⚪ Platinum (PT)</SelectItem>
                    <SelectItem value="PD" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🔵 Palladium (PD)</SelectItem>
                    <SelectItem value="RH" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🟣 Rhodium (RH)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="weight" className="text-yellow-300 font-semibold">Weight</Label>
                <div className="flex gap-2">
                  <Input
                    id="weight"
                    type="number"
                    step="0.001"
                    placeholder="0.00"
                    value={weightValue}
                    onChange={(e) => setWeightValue(e.target.value)}
                    className="bg-[#0a0f1e] border-[#1e293b] text-yellow-300 font-semibold placeholder:text-yellow-600"
                  />
                  <Select value={unit} onValueChange={(val) => setUnit(val as UnitType)}>
                    <SelectTrigger className="bg-[#0a0f1e] border-[#1e293b] w-24 text-yellow-300 font-semibold">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                      <SelectItem value="oz" className="text-yellow-300 hover:text-green-300 focus:text-green-300">oz</SelectItem>
                      <SelectItem value="g" className="text-yellow-300 hover:text-green-300 focus:text-green-300">g</SelectItem>
                      <SelectItem value="kg" className="text-yellow-300 hover:text-green-300 focus:text-green-300">kg</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="purity" className="text-yellow-300 font-semibold">Purity</Label>
                <Select value={purity} onValueChange={setPurity}>
                  <SelectTrigger className="bg-[#0a0f1e] border-[#1e293b] text-yellow-300 font-semibold">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                    <SelectItem value=".999" className="text-yellow-300 hover:text-green-300 focus:text-green-300">.999 (Fine)</SelectItem>
                    <SelectItem value=".995" className="text-yellow-300 hover:text-green-300 focus:text-green-300">.995</SelectItem>
                    <SelectItem value=".9167" className="text-yellow-300 hover:text-green-300 focus:text-green-300">.9167 (22k)</SelectItem>
                    <SelectItem value=".900" className="text-yellow-300 hover:text-green-300 focus:text-green-300">.900 (90%)</SelectItem>
                    <SelectItem value="custom" className="text-yellow-300 hover:text-green-300 focus:text-green-300">Custom</SelectItem>
                  </SelectContent>
                </Select>
                {purity === 'custom' && (
                  <Input
                    type="number"
                    step="0.0001"
                    placeholder="Enter purity (e.g., 0.925)"
                    onChange={(e) => setPurity(e.target.value)}
                    className="bg-[#0a0f1e] border-[#1e293b] mt-2 text-yellow-300 font-semibold placeholder:text-yellow-600"
                  />
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="buyPrice" className="text-yellow-300 font-semibold">Buy Price (Dealer Paying)</Label>
                <Input
                  id="buyPrice"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={buyPrice}
                  onChange={(e) => setBuyPrice(e.target.value)}
                  className="bg-[#0a0f1e] border-[#1e293b] text-yellow-300 font-semibold placeholder:text-yellow-600"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="sellPrice" className="text-yellow-300 font-semibold">Sell Price (Dealer Asking)</Label>
                <Input
                  id="sellPrice"
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={sellPrice}
                  onChange={(e) => setSellPrice(e.target.value)}
                  className="bg-[#0a0f1e] border-[#1e293b] text-yellow-300 font-semibold placeholder:text-yellow-600"
                />
              </div>
            </div>

            {/* Preview Calculation */}
            {previewCalc && (
              <div className="mt-6 p-4 bg-[#0a0f1e] border border-[#1e293b] rounded-lg">
                <div className="flex justify-between items-center mb-3">
                  <h3 className="text-sm font-semibold text-cyan-400">👁️ Preview</h3>
                  <Badge className={getSpreadColor(previewCalc.spread)}>
                    {getSpreadAlert(previewCalc.spread)}
                  </Badge>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-3 text-sm">
                  <div>
                    <div className="text-yellow-300 font-semibold">Melt</div>
                    <div className="font-mono text-white text-lg">${previewCalc.melt.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-yellow-300 font-semibold">Spread</div>
                    <div className={`font-mono text-lg ${getSpreadColor(previewCalc.spread)}`}>
                      {previewCalc.spread.toFixed(2)}%
                    </div>
                  </div>
                  <div>
                    <div className="text-yellow-300 font-semibold">Margin</div>
                    <div className="font-mono text-white text-lg">${previewCalc.margin.toFixed(2)}</div>
                  </div>
                  <div>
                    <div className="text-yellow-300 font-semibold">Buy/Melt</div>
                    <div className="font-mono text-white">{previewCalc.buyOverMelt.toFixed(2)}%</div>
                  </div>
                  <div>
                    <div className="text-yellow-300 font-semibold">Sell/Melt</div>
                    <div className={`font-mono ${getSellOverMeltColor(previewCalc.sellOverMelt)}`}>
                      {previewCalc.sellOverMelt.toFixed(2)}%
                    </div>
                  </div>
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="mt-6 flex gap-3">
              <Button
                onClick={handleAddQuote}
                disabled={!spotData}
                className="bg-green-600 hover:bg-green-700"
              >
                ✅ Calculate & Add Quote
              </Button>
              <Button
                onClick={() => {
                  setLabel("");
                  setWeightValue("");
                  setBuyPrice("");
                  setSellPrice("");
                }}
                variant="outline"
                className="border-[#1e293b]"
              >
                🗑️ Clear
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Quotes Table */}
        {quotes.length > 0 && (
          <Card className="bg-[#050816] border-[#1e293b]">
            <CardHeader>
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                <CardTitle className="text-cyan-400">📋 Quotes ({quotes.length})</CardTitle>
                <div className="flex gap-2">
                  <Button
                    onClick={handleExportCSV}
                    variant="outline"
                    size="sm"
                    className="border-green-500 text-green-400 hover:bg-green-500/10"
                  >
                    📥 Export CSV
                  </Button>
                  <Button
                    onClick={() => setQuotes([])}
                    variant="outline"
                    size="sm"
                    className="border-red-500 text-red-400 hover:bg-red-500/10"
                  >
                    🗑️ Clear All
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-[#1e293b]">
                      <TableHead className="text-gray-400">Label</TableHead>
                      <TableHead className="text-gray-400">Metal</TableHead>
                      <TableHead className="text-gray-400">Weight</TableHead>
                      <TableHead className="text-gray-400">Purity</TableHead>
                      <TableHead className="text-gray-400 text-right">Melt</TableHead>
                      <TableHead className="text-gray-400 text-right">Buy</TableHead>
                      <TableHead className="text-gray-400 text-right">Sell</TableHead>
                      <TableHead className="text-gray-400 text-right">Spread %</TableHead>
                      <TableHead className="text-gray-400 text-right">Margin</TableHead>
                      <TableHead className="text-gray-400 text-right">Buy/Melt %</TableHead>
                      <TableHead className="text-gray-400 text-right">Sell/Melt %</TableHead>
                      <TableHead className="text-gray-400">Time</TableHead>
                      <TableHead className="text-gray-400">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {quotes.map((quote: QuoteRow) => (
                      <TableRow key={quote.id} className="border-[#1e293b]">
                        <TableCell className="font-medium">{quote.label}</TableCell>
                        <TableCell>
                          <Badge variant="outline" className="border-cyan-500 text-cyan-400">
                            {quote.metal}
                          </Badge>
                        </TableCell>
                        <TableCell className="font-mono">
                          {quote.weightValue} {quote.unit}
                        </TableCell>
                        <TableCell className="font-mono">{quote.purity}</TableCell>
                        <TableCell className="font-mono text-right">${quote.meltValue.toFixed(2)}</TableCell>
                        <TableCell className="font-mono text-right">${quote.buyPrice.toFixed(2)}</TableCell>
                        <TableCell className="font-mono text-right">${quote.sellPrice.toFixed(2)}</TableCell>
                        <TableCell className={`font-mono text-right ${getSpreadColor(quote.spreadPct)}`}>
                          {quote.spreadPct.toFixed(2)}%
                        </TableCell>
                        <TableCell className="font-mono text-right">${quote.marginPerUnit.toFixed(2)}</TableCell>
                        <TableCell className="font-mono text-right">{quote.buyOverMeltPct.toFixed(2)}%</TableCell>
                        <TableCell className={`font-mono text-right ${getSellOverMeltColor(quote.sellOverMeltPct)}`}>
                          {quote.sellOverMeltPct.toFixed(2)}%
                        </TableCell>
                        <TableCell className="text-xs text-gray-500">
                          {new Date(quote.createdAt).toLocaleTimeString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-1">
                            <PrintReceipt 
                              quote={quote}
                              customer={customers.find((c: Customer) => c.id === quote.customerId) || null}
                            />
                            <Button
                              onClick={() => handleDuplicateQuote(quote)}
                              variant="ghost"
                              size="sm"
                              className="text-cyan-400 hover:text-cyan-300 px-2"
                              title="Duplicate for repricing"
                            >
                              📋
                            </Button>
                            <Button
                              onClick={() => handleDeleteQuote(quote.id)}
                              variant="ghost"
                              size="sm"
                              className="text-red-500 hover:text-red-400 px-2"
                            >
                              🗑️
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Footer Info */}
        <Card className="bg-[#050816] border-[#1e293b]">
          <CardContent className="pt-6">
            <div className="text-xs text-gray-500 space-y-2">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">💡 Pro Tip:</span>
                <span>Use Quick Presets to load common items instantly, then adjust buy/sell prices.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">🔄 Auto-Refresh:</span>
                <span>Enable to automatically update spot prices every 60 seconds.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">📋 Duplicate:</span>
                <span>Click the clipboard icon to quickly reprice an existing quote.</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">📊 Spread Guide:</span>
                <span>🔴 &lt;1% Too Tight • 🟡 1-3% Thin • 🟢 3-10% Good • 🔵 &gt;10% Wide</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
