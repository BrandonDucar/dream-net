'use client'

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

export type Customer = {
  id: string;
  name: string;
  email: string;
  phone: string;
  totalQuotes: number;
  totalValue: number;
  lastVisit: number;
};

type CustomerTrackerProps = {
  customers: Customer[];
  selectedCustomerId: string | null;
  onSelectCustomer: (customerId: string | null) => void;
  onAddCustomer: (customer: Omit<Customer, 'id' | 'totalQuotes' | 'totalValue' | 'lastVisit'>) => void;
};

export function CustomerTracker({ 
  customers, 
  selectedCustomerId, 
  onSelectCustomer,
  onAddCustomer 
}: CustomerTrackerProps) {
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [newName, setNewName] = useState<string>('');
  const [newEmail, setNewEmail] = useState<string>('');
  const [newPhone, setNewPhone] = useState<string>('');

  const handleSubmit = () => {
    if (!newName.trim()) {
      alert('Please enter customer name');
      return;
    }

    onAddCustomer({
      name: newName,
      email: newEmail,
      phone: newPhone
    });

    setNewName('');
    setNewEmail('');
    setNewPhone('');
    setShowAddForm(false);
  };

  const selectedCustomer = customers.find((c: Customer) => c.id === selectedCustomerId);

  return (
    <Card className="bg-[#050816] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-yellow-300 font-bold">👤 Customer Tracker</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label className="text-yellow-300 font-semibold">Select Customer</Label>
          <div className="flex gap-2">
            <Select 
              value={selectedCustomerId || 'none'} 
              onValueChange={(val) => onSelectCustomer(val === 'none' ? null : val)}
            >
              <SelectTrigger className="bg-[#0a0f1e] border-[#1e293b] flex-1 text-yellow-300 font-semibold">
                <SelectValue placeholder="Select customer or walk-in" className="text-yellow-300" />
              </SelectTrigger>
              <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                <SelectItem value="none" className="text-yellow-300 hover:text-green-300 focus:text-green-300">Walk-in (No customer)</SelectItem>
                {customers.map((customer: Customer) => (
                  <SelectItem key={customer.id} value={customer.id} className="text-yellow-300 hover:text-green-300 focus:text-green-300">
                    {customer.name} {customer.email && `(${customer.email})`}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              onClick={() => setShowAddForm(!showAddForm)}
              variant="outline"
              className="border-cyan-500 text-cyan-400"
            >
              {showAddForm ? '✕' : '➕ New'}
            </Button>
          </div>
        </div>

        {showAddForm && (
          <div className="space-y-3 p-4 bg-[#0a0f1e] border border-[#1e293b] rounded-lg">
            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Customer Name *</Label>
              <Input
                placeholder="John Doe"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                className="bg-[#020617] border-[#1e293b]"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Email</Label>
              <Input
                type="email"
                placeholder="john@example.com"
                value={newEmail}
                onChange={(e) => setNewEmail(e.target.value)}
                className="bg-[#020617] border-[#1e293b]"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Phone</Label>
              <Input
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={newPhone}
                onChange={(e) => setNewPhone(e.target.value)}
                className="bg-[#020617] border-[#1e293b]"
              />
            </div>
            <Button
              onClick={handleSubmit}
              className="bg-green-600 hover:bg-green-700 w-full"
            >
              ✅ Add Customer
            </Button>
          </div>
        )}

        {selectedCustomer && (
          <div className="p-4 bg-[#0a0f1e] border border-cyan-500/30 rounded-lg space-y-2">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-cyan-400">Customer Info</h4>
              <Badge className="bg-green-600">Active</Badge>
            </div>
            <div className="text-sm space-y-1">
              <div className="flex justify-between">
                <span className="text-yellow-300">Name:</span>
                <span className="text-white font-medium">{selectedCustomer.name}</span>
              </div>
              {selectedCustomer.email && (
                <div className="flex justify-between">
                  <span className="text-yellow-300">Email:</span>
                  <span className="text-white">{selectedCustomer.email}</span>
                </div>
              )}
              {selectedCustomer.phone && (
                <div className="flex justify-between">
                  <span className="text-yellow-300">Phone:</span>
                  <span className="text-white">{selectedCustomer.phone}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-yellow-300">Total Quotes:</span>
                <span className="text-white font-mono">{selectedCustomer.totalQuotes}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-yellow-300">Total Value:</span>
                <span className="text-green-400 font-mono">${selectedCustomer.totalValue.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-yellow-300">Last Visit:</span>
                <span className="text-white text-xs">
                  {new Date(selectedCustomer.lastVisit).toLocaleDateString()}
                </span>
              </div>
            </div>
          </div>
        )}

        {customers.length > 0 && (
          <div className="text-xs text-gray-400">
            📊 Total Customers: {customers.length}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
