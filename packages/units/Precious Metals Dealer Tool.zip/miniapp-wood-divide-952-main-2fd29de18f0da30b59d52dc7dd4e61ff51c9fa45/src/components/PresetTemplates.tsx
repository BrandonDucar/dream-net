'use client'
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { MetalCode, UnitType } from '@/lib/melt';

type PresetTemplate = {
  label: string;
  metal: MetalCode;
  weightValue: number;
  unit: UnitType;
  purity: number;
  icon: string;
};

const PRESETS: PresetTemplate[] = [
  { label: "1oz Gold Eagle", metal: "AU", weightValue: 1, unit: "oz", purity: 0.9167, icon: "🦅" },
  { label: "1oz Gold Maple", metal: "AU", weightValue: 1, unit: "oz", purity: 0.9999, icon: "🍁" },
  { label: "1oz Gold Buffalo", metal: "AU", weightValue: 1, unit: "oz", purity: 0.9999, icon: "🦬" },
  { label: "1oz Silver Eagle", metal: "AG", weightValue: 1, unit: "oz", purity: 0.999, icon: "🦅" },
  { label: "1oz Silver Maple", metal: "AG", weightValue: 1, unit: "oz", purity: 0.9999, icon: "🍁" },
  { label: "$1 Face Junk Silver (90%)", metal: "AG", weightValue: 0.715, unit: "oz", purity: 0.900, icon: "💰" },
  { label: "100oz Silver Bar", metal: "AG", weightValue: 100, unit: "oz", purity: 0.999, icon: "📊" },
  { label: "1oz Platinum Eagle", metal: "PT", weightValue: 1, unit: "oz", purity: 0.9995, icon: "🦅" },
  { label: "1oz Palladium Maple", metal: "PD", weightValue: 1, unit: "oz", purity: 0.9995, icon: "🍁" },
  { label: "10oz Gold Bar", metal: "AU", weightValue: 10, unit: "oz", purity: 0.9999, icon: "📊" },
  { label: "1kg Gold Bar", metal: "AU", weightValue: 1, unit: "kg", purity: 0.9999, icon: "🧱" },
  { label: "1kg Silver Bar", metal: "AG", weightValue: 1, unit: "kg", purity: 0.999, icon: "🧱" },
];

type PresetTemplatesProps = {
  onSelect: (preset: PresetTemplate) => void;
};

export function PresetTemplates({ onSelect }: PresetTemplatesProps) {
  return (
    <Card className="bg-[#050816] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-cyan-400">Quick Presets</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-2">
          {PRESETS.map((preset: PresetTemplate, index: number) => (
            <Button
              key={index}
              onClick={() => onSelect(preset)}
              variant="outline"
              className="border-[#1e293b] bg-[#0a0f1e] hover:bg-[#1e293b] text-left justify-start h-auto py-3 px-3 text-yellow-300 hover:text-green-300 font-semibold"
            >
              <div className="flex flex-col items-start gap-1 w-full">
                <span className="text-lg">{preset.icon}</span>
                <span className="text-xs font-medium break-words">{preset.label}</span>
              </div>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
