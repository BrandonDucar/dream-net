'use client'

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import type { MetalCode } from '@/lib/melt';
import { getMetalName } from '@/lib/melt';

export type PriceAlert = {
  id: string;
  metal: MetalCode;
  condition: 'above' | 'below';
  targetPrice: number;
  phone: string;
  active: boolean;
  createdAt: number;
};

type PriceAlertsProps = {
  alerts: PriceAlert[];
  onAddAlert: (alert: Omit<PriceAlert, 'id' | 'active' | 'createdAt'>) => void;
  onToggleAlert: (id: string) => void;
  onDeleteAlert: (id: string) => void;
};

export function PriceAlerts({ alerts, onAddAlert, onToggleAlert, onDeleteAlert }: PriceAlertsProps) {
  const [showAddForm, setShowAddForm] = useState<boolean>(false);
  const [metal, setMetal] = useState<MetalCode>('AU');
  const [condition, setCondition] = useState<'above' | 'below'>('above');
  const [targetPrice, setTargetPrice] = useState<string>('');
  const [phone, setPhone] = useState<string>('');

  const handleSubmit = () => {
    const price = parseFloat(targetPrice);
    
    if (isNaN(price) || price <= 0) {
      alert('Please enter a valid target price');
      return;
    }

    if (!phone.trim()) {
      alert('Please enter a phone number for SMS alerts');
      return;
    }

    onAddAlert({
      metal,
      condition,
      targetPrice: price,
      phone: phone.trim()
    });

    setTargetPrice('');
    setPhone('');
    setShowAddForm(false);
  };

  return (
    <Card className="bg-[#050816] border-[#1e293b]">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle className="text-cyan-400">🔔 Price Alerts</CardTitle>
          <Button
            onClick={() => setShowAddForm(!showAddForm)}
            variant="outline"
            size="sm"
            className="border-cyan-500 text-cyan-400"
          >
            {showAddForm ? '✕ Cancel' : '➕ New Alert'}
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {showAddForm && (
          <div className="space-y-3 p-4 bg-[#0a0f1e] border border-[#1e293b] rounded-lg">
            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Metal</Label>
              <Select value={metal} onValueChange={(val) => setMetal(val as MetalCode)}>
                <SelectTrigger className="bg-[#020617] border-[#1e293b] text-yellow-300 font-semibold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                  <SelectItem value="AU" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🥇 Gold</SelectItem>
                  <SelectItem value="AG" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🥈 Silver</SelectItem>
                  <SelectItem value="PT" className="text-yellow-300 hover:text-green-300 focus:text-green-300">⚪ Platinum</SelectItem>
                  <SelectItem value="PD" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🔵 Palladium</SelectItem>
                  <SelectItem value="RH" className="text-yellow-300 hover:text-green-300 focus:text-green-300">🟣 Rhodium</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Alert When Price</Label>
              <Select value={condition} onValueChange={(val) => setCondition(val as 'above' | 'below')}>
                <SelectTrigger className="bg-[#020617] border-[#1e293b] text-yellow-300 font-semibold">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-[#0a0f1e] border-[#1e293b]">
                  <SelectItem value="above" className="text-yellow-300 hover:text-green-300 focus:text-green-300">Goes Above</SelectItem>
                  <SelectItem value="below" className="text-yellow-300 hover:text-green-300 focus:text-green-300">Goes Below</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">Target Price ($/oz)</Label>
              <Input
                type="number"
                step="0.01"
                placeholder="2400.00"
                value={targetPrice}
                onChange={(e) => setTargetPrice(e.target.value)}
                className="bg-[#020617] border-[#1e293b]"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-yellow-300 font-semibold">SMS Phone Number</Label>
              <Input
                type="tel"
                placeholder="+1 (555) 123-4567"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                className="bg-[#020617] border-[#1e293b]"
              />
              <p className="text-xs text-yellow-300 font-semibold">
                💡 Note: SMS functionality requires integration with Twilio or similar service
              </p>
            </div>

            <Button
              onClick={handleSubmit}
              className="bg-green-600 hover:bg-green-700 w-full"
            >
              ✅ Create Alert
            </Button>
          </div>
        )}

        {alerts.length > 0 ? (
          <div className="space-y-2">
            {alerts.map((alert: PriceAlert) => (
              <div
                key={alert.id}
                className="p-3 bg-[#0a0f1e] border border-[#1e293b] rounded-lg flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="text-white font-medium">{getMetalName(alert.metal)}</span>
                    <Badge variant="outline" className={alert.active ? 'border-green-500 text-green-400' : 'border-gray-500 text-gray-400'}>
                      {alert.active ? '🟢 Active' : '⚫ Paused'}
                    </Badge>
                  </div>
                  <div className="text-sm text-yellow-300 font-semibold">
                    Alert when price goes {alert.condition} ${alert.targetPrice.toFixed(2)}/oz
                  </div>
                  <div className="text-xs text-yellow-300 font-semibold mt-1">
                    📱 SMS: {alert.phone}
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    onClick={() => onToggleAlert(alert.id)}
                    variant="ghost"
                    size="sm"
                    className="text-cyan-400 hover:text-cyan-300 px-2"
                    title={alert.active ? 'Pause alert' : 'Activate alert'}
                  >
                    {alert.active ? '⏸️' : '▶️'}
                  </Button>
                  <Button
                    onClick={() => onDeleteAlert(alert.id)}
                    variant="ghost"
                    size="sm"
                    className="text-red-500 hover:text-red-400 px-2"
                    title="Delete alert"
                  >
                    🗑️
                  </Button>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-yellow-300 font-semibold text-sm">
            No price alerts set. Create one to get notified when metals hit your target prices.
          </div>
        )}

        <div className="p-3 bg-yellow-500/10 border border-yellow-500/30 rounded-lg">
          <div className="text-xs text-yellow-400">
            <span className="font-semibold">⚠️ Setup Required:</span> To enable SMS alerts, configure Twilio credentials
            (TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_PHONE_NUMBER) in your environment variables.
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
