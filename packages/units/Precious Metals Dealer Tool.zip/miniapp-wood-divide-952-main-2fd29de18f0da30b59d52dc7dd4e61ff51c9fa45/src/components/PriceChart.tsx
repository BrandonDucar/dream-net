'use client'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import type { MetalCode } from '@/lib/melt';

type PricePoint = {
  time: string;
  price: number;
};

type PriceChartProps = {
  metal: MetalCode;
  data: PricePoint[];
};

export function PriceChart({ metal, data }: PriceChartProps) {
  if (data.length === 0) {
    return (
      <Card className="bg-[#050816] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-cyan-400 text-sm">24h Price Trend - {metal}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-gray-400 text-sm">No historical data available</div>
        </CardContent>
      </Card>
    );
  }

  const prices = data.map((d: PricePoint) => d.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const range = maxPrice - minPrice;
  const padding = range * 0.1;

  const chartHeight = 120;
  const chartWidth = 100; // percentage

  // Create SVG path
  const points = data.map((point: PricePoint, index: number) => {
    const x = (index / (data.length - 1)) * chartWidth;
    const y = chartHeight - ((point.price - minPrice + padding) / (range + padding * 2)) * chartHeight;
    return `${x},${y}`;
  }).join(' ');

  const currentPrice = prices[prices.length - 1];
  const firstPrice = prices[0];
  const priceChange = currentPrice - firstPrice;
  const priceChangePct = (priceChange / firstPrice) * 100;
  const isPositive = priceChange >= 0;

  return (
    <Card className="bg-[#050816] border-[#1e293b]">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-cyan-400 text-sm">24h Price Trend - {metal}</CardTitle>
          <div className="text-right">
            <div className="text-lg font-mono text-white">${currentPrice.toFixed(2)}</div>
            <div className={`text-xs font-mono ${isPositive ? 'text-green-400' : 'text-red-400'}`}>
              {isPositive ? '+' : ''}{priceChange.toFixed(2)} ({isPositive ? '+' : ''}{priceChangePct.toFixed(2)}%)
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="relative" style={{ height: `${chartHeight}px` }}>
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            preserveAspectRatio="none"
            className="w-full h-full"
          >
            {/* Grid lines */}
            <line x1="0" y1="0" x2={chartWidth} y2="0" stroke="#1e293b" strokeWidth="0.5" />
            <line x1="0" y1={chartHeight / 2} x2={chartWidth} y2={chartHeight / 2} stroke="#1e293b" strokeWidth="0.5" />
            <line x1="0" y1={chartHeight} x2={chartWidth} y2={chartHeight} stroke="#1e293b" strokeWidth="0.5" />

            {/* Price line */}
            <polyline
              points={points}
              fill="none"
              stroke={isPositive ? '#22c55e' : '#ef4444'}
              strokeWidth="2"
              vectorEffect="non-scaling-stroke"
            />

            {/* Area under line */}
            <polygon
              points={`0,${chartHeight} ${points} ${chartWidth},${chartHeight}`}
              fill={isPositive ? 'rgba(34, 197, 94, 0.1)' : 'rgba(239, 68, 68, 0.1)'}
            />
          </svg>
        </div>
        <div className="flex justify-between mt-2 text-xs text-gray-500">
          <span>{data[0].time}</span>
          <span>Now</span>
        </div>
      </CardContent>
    </Card>
  );
}
