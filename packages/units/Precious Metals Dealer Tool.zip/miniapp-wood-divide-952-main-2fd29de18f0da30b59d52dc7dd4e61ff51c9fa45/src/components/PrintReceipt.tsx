'use client'

import { Button } from '@/components/ui/button';
import type { MetalCode, UnitType } from '@/lib/melt';
import { getMetalName } from '@/lib/melt';

type QuoteRow = {
  id: string;
  metal: MetalCode;
  label: string;
  weightValue: number;
  unit: UnitType;
  purity: number;
  meltValue: number;
  buyPrice: number;
  sellPrice: number;
  spreadPct: number;
  marginPerUnit: number;
  buyOverMeltPct: number;
  sellOverMeltPct: number;
  createdAt: number;
};

type Customer = {
  name: string;
  email: string;
  phone: string;
} | null;

type PrintReceiptProps = {
  quote: QuoteRow;
  customer?: Customer;
  dealerName?: string;
};

export function PrintReceipt({ quote, customer, dealerName = 'Precious Metals Dealer' }: PrintReceiptProps) {
  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Please allow popups to print receipts');
      return;
    }

    const receiptHTML = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>Quote Receipt - ${quote.label}</title>
          <style>
            body {
              font-family: 'Courier New', monospace;
              max-width: 400px;
              margin: 20px auto;
              padding: 20px;
              background: white;
              color: black;
            }
            .header {
              text-align: center;
              border-bottom: 2px solid black;
              padding-bottom: 10px;
              margin-bottom: 15px;
            }
            .header h1 {
              margin: 0;
              font-size: 18px;
            }
            .header p {
              margin: 5px 0 0 0;
              font-size: 12px;
            }
            .section {
              margin: 15px 0;
              border-bottom: 1px dashed #666;
              padding-bottom: 10px;
            }
            .row {
              display: flex;
              justify-content: space-between;
              margin: 5px 0;
              font-size: 14px;
            }
            .label {
              font-weight: bold;
            }
            .value {
              text-align: right;
            }
            .total {
              font-size: 16px;
              font-weight: bold;
              margin-top: 10px;
            }
            .footer {
              text-align: center;
              margin-top: 20px;
              font-size: 11px;
              color: #666;
            }
            @media print {
              body {
                margin: 0;
              }
            }
          </style>
        </head>
        <body>
          <div class="header">
            <h1>${dealerName}</h1>
            <p>Precious Metals Quote</p>
            <p>${new Date(quote.createdAt).toLocaleString()}</p>
          </div>

          ${customer ? `
            <div class="section">
              <div class="row">
                <span class="label">Customer:</span>
                <span class="value">${customer.name}</span>
              </div>
              ${customer.email ? `
                <div class="row">
                  <span class="label">Email:</span>
                  <span class="value">${customer.email}</span>
                </div>
              ` : ''}
              ${customer.phone ? `
                <div class="row">
                  <span class="label">Phone:</span>
                  <span class="value">${customer.phone}</span>
                </div>
              ` : ''}
            </div>
          ` : ''}

          <div class="section">
            <div class="row">
              <span class="label">Item:</span>
              <span class="value">${quote.label}</span>
            </div>
            <div class="row">
              <span class="label">Metal:</span>
              <span class="value">${getMetalName(quote.metal)}</span>
            </div>
            <div class="row">
              <span class="label">Weight:</span>
              <span class="value">${quote.weightValue} ${quote.unit}</span>
            </div>
            <div class="row">
              <span class="label">Purity:</span>
              <span class="value">${(quote.purity * 100).toFixed(2)}%</span>
            </div>
          </div>

          <div class="section">
            <div class="row">
              <span class="label">Melt Value:</span>
              <span class="value">$${quote.meltValue.toFixed(2)}</span>
            </div>
            <div class="row">
              <span class="label">Premium over Melt:</span>
              <span class="value">${quote.sellOverMeltPct.toFixed(2)}%</span>
            </div>
          </div>

          <div class="section">
            <div class="row total">
              <span class="label">Dealer Buy Price:</span>
              <span class="value">$${quote.buyPrice.toFixed(2)}</span>
            </div>
            <div class="row total">
              <span class="label">Dealer Sell Price:</span>
              <span class="value">$${quote.sellPrice.toFixed(2)}</span>
            </div>
          </div>

          <div class="section">
            <div class="row">
              <span class="label">Spread:</span>
              <span class="value">${quote.spreadPct.toFixed(2)}%</span>
            </div>
            <div class="row">
              <span class="label">Margin:</span>
              <span class="value">$${quote.marginPerUnit.toFixed(2)}</span>
            </div>
          </div>

          <div class="footer">
            <p>This quote is valid for current market conditions.</p>
            <p>Prices subject to change based on spot market.</p>
            <p>Thank you for your business!</p>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(receiptHTML);
    printWindow.document.close();
    
    // Wait for content to load, then print
    printWindow.onload = () => {
      printWindow.print();
      // Close after printing or canceling
      printWindow.onafterprint = () => {
        printWindow.close();
      };
    };
  };

  return (
    <Button
      onClick={handlePrint}
      variant="ghost"
      size="sm"
      className="text-purple-400 hover:text-purple-300 px-2"
      title="Print receipt"
    >
      🖨️
    </Button>
  );
}
