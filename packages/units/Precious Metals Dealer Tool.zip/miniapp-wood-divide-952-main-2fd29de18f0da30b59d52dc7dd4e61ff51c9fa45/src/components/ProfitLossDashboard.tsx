'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

type QuoteRow = {
  id: string;
  marginPerUnit: number;
  spreadPct: number;
  sellPrice: number;
  buyPrice: number;
  createdAt: number;
};

type ProfitLossDashboardProps = {
  quotes: QuoteRow[];
};

export function ProfitLossDashboard({ quotes }: ProfitLossDashboardProps) {
  const now = Date.now();
  const oneDayAgo = now - (24 * 60 * 60 * 1000);
  const oneWeekAgo = now - (7 * 24 * 60 * 60 * 1000);

  const todayQuotes = quotes.filter((q: QuoteRow) => q.createdAt >= oneDayAgo);
  const weekQuotes = quotes.filter((q: QuoteRow) => q.createdAt >= oneWeekAgo);

  const calcStats = (quoteList: QuoteRow[]) => {
    if (quoteList.length === 0) {
      return {
        totalMargin: 0,
        avgSpread: 0,
        totalBuyVolume: 0,
        totalSellVolume: 0,
        count: 0
      };
    }

    const totalMargin = quoteList.reduce((sum: number, q: QuoteRow) => sum + q.marginPerUnit, 0);
    const avgSpread = quoteList.reduce((sum: number, q: QuoteRow) => sum + q.spreadPct, 0) / quoteList.length;
    const totalBuyVolume = quoteList.reduce((sum: number, q: QuoteRow) => sum + q.buyPrice, 0);
    const totalSellVolume = quoteList.reduce((sum: number, q: QuoteRow) => sum + q.sellPrice, 0);

    return {
      totalMargin,
      avgSpread,
      totalBuyVolume,
      totalSellVolume,
      count: quoteList.length
    };
  };

  const todayStats = calcStats(todayQuotes);
  const weekStats = calcStats(weekQuotes);

  return (
    <Card className="bg-[#050816] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-cyan-400">💰 Profit & Loss Dashboard</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Today's Stats */}
          <div className="p-4 bg-[#0a0f1e] border border-green-500/30 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-green-400">📅 Today (24h)</h4>
              <Badge className="bg-green-600">{todayStats.count} quotes</Badge>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Margin:</span>
                <span className="text-green-400 font-mono text-lg font-bold">
                  ${todayStats.totalMargin.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Spread:</span>
                <span className="text-white font-mono">{todayStats.avgSpread.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Buy Volume:</span>
                <span className="text-cyan-400 font-mono">${todayStats.totalBuyVolume.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Sell Volume:</span>
                <span className="text-purple-400 font-mono">${todayStats.totalSellVolume.toFixed(2)}</span>
              </div>
            </div>
          </div>

          {/* Week Stats */}
          <div className="p-4 bg-[#0a0f1e] border border-cyan-500/30 rounded-lg space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-cyan-400">📆 This Week (7d)</h4>
              <Badge className="bg-cyan-600">{weekStats.count} quotes</Badge>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-400">Total Margin:</span>
                <span className="text-green-400 font-mono text-lg font-bold">
                  ${weekStats.totalMargin.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Avg Spread:</span>
                <span className="text-white font-mono">{weekStats.avgSpread.toFixed(2)}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Buy Volume:</span>
                <span className="text-cyan-400 font-mono">${weekStats.totalBuyVolume.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-400">Sell Volume:</span>
                <span className="text-purple-400 font-mono">${weekStats.totalSellVolume.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Performance Indicators */}
        {quotes.length > 0 && (
          <div className="mt-4 p-3 bg-[#0a0f1e] rounded-lg">
            <div className="text-xs text-gray-400 space-y-1">
              <div className="flex items-center gap-2">
                <span className="text-cyan-400">💡</span>
                <span>
                  {todayStats.avgSpread >= 5 
                    ? '🟢 Strong spreads today - excellent margins!' 
                    : todayStats.avgSpread >= 3 
                    ? '🟡 Good spreads - solid performance' 
                    : '🔴 Thin spreads - watch your margins'}
                </span>
              </div>
              {weekStats.count > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-cyan-400">📊</span>
                  <span>
                    Weekly average: {(weekStats.totalMargin / weekStats.count).toFixed(2)} margin per quote
                  </span>
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
