export type MetalCode = "AU" | "AG" | "PT" | "PD" | "RH";
export type UnitType = "oz" | "g" | "kg";

export type SpotMap = {
  gold: number;
  silver: number;
  platinum: number;
  palladium: number;
  rhodium: number;
};

export function toOz(value: number, unit: UnitType): number {
  if (unit === "oz") return value;
  if (unit === "g") return value / 31.1034768;
  if (unit === "kg") return (value * 1000) / 31.1034768;
  return value;
}

export function getSpotForMetal(metal: MetalCode, spots: SpotMap): number {
  switch (metal) {
    case "AU": return spots.gold;
    case "AG": return spots.silver;
    case "PT": return spots.platinum;
    case "PD": return spots.palladium;
    case "RH": return spots.rhodium;
  }
}

export function getMetalName(metal: MetalCode): string {
  switch (metal) {
    case "AU": return "Gold";
    case "AG": return "Silver";
    case "PT": return "Platinum";
    case "PD": return "Palladium";
    case "RH": return "Rhodium";
  }
}

export function calcMeltValue(
  metal: MetalCode,
  weightValue: number,
  unit: UnitType,
  purity: number,
  spots: SpotMap
): number {
  const spot = getSpotForMetal(metal, spots);
  const oz = toOz(weightValue, unit);
  return oz * purity * spot;
}

export function calcSpreadAndPremiums(
  meltValue: number,
  buyPrice: number,
  sellPrice: number
) {
  const marginPerUnit = sellPrice - buyPrice;

  const spreadPct = sellPrice > 0
    ? ((sellPrice - buyPrice) / sellPrice) * 100
    : 0;

  const buyOverMeltPct = meltValue > 0
    ? ((buyPrice - meltValue) / meltValue) * 100
    : 0;

  const sellOverMeltPct = meltValue > 0
    ? ((sellPrice - meltValue) / meltValue) * 100
    : 0;

  return {
    marginPerUnit,
    spreadPct,
    buyOverMeltPct,
    sellOverMeltPct
  };
}
