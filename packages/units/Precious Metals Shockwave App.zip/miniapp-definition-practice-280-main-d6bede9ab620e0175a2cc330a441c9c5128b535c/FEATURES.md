# Spot Shockwave Monitor - Enhanced Features

## 🎉 What's New

Your metals volatility dashboard now includes three major upgrades:

### 1. 📡 Real Metals API Integration
- **Live data from Metals.Dev API** for Gold, Silver, Platinum, and Palladium
- Automatic fallback to simulated data if API is unavailable
- Rhodium pricing via simulation (not available in free APIs)
- To use real API: Replace `YOUR_API_KEY` in `src/app/api/spot/route.ts` with your Metals.Dev API key

### 2. 💾 SpacetimeDB Persistent Storage
- **Real-time database** for historical price tracking
- All price snapshots automatically saved to the cloud
- Shockwave alerts stored with full context
- Data persists across sessions and syncs across all clients
- Visual database connection status in the top bar
- Access historical data from the last 7 days (price snapshots) and 24 hours (alerts)

**How it works:**
- Green "Connected" status = database is live and syncing
- All price updates automatically save to SpacetimeDB
- All shockwave events are recorded with timestamp, metal, price, and severity

### 3. 🔔 Browser Notifications
- **Desktop notifications** for major shockwaves
- Click the "Alerts" button to enable/disable notifications
- Browser will request permission on first use
- Only major shockwaves (2%+ moves) trigger notifications
- Persistent notifications that require acknowledgment
- Settings saved locally per device

**How to enable:**
1. Click the "Alerts" button in the top bar
2. Allow notifications when prompted by your browser
3. You'll receive a test notification confirming it's working
4. Major shockwaves will now trigger desktop alerts

## 🎯 Key Features

### Real-time Monitoring
- Live spot prices for 5 precious metals
- Auto-refresh every 60 seconds (toggle on/off)
- Manual refresh button for instant updates

### Shockwave Detection
- Configurable thresholds (Minor 0.5%, Moderate 1.0%, Major 2.0%)
- Color-coded severity badges
- Real-time alerts feed with filtering
- Automatic database persistence

### Volatility Indicators
- Each metal panel shows volatility status (Calm/Choppy/Wild)
- Session change tracking
- Mini sparkline charts for visual trends

### Data Persistence
- Historical price snapshots
- Shockwave event log
- Cross-device synchronization via SpacetimeDB

## 🔧 Configuration

### Environment Variables
`.env.local`:
```
NEXT_PUBLIC_SPACETIME_MODULE_NAME=metals-shockwave-monitor
```

### API Integration
To use real Metals.Dev API:
1. Get your free API key from https://metals.dev
2. Edit `src/app/api/spot/route.ts`
3. Replace `YOUR_API_KEY` with your actual key

### Notification Settings
- Stored in browser localStorage
- Toggle on/off via "Alerts" button
- Permission managed by browser settings

## 📊 Database Schema

SpacetimeDB stores:
- **Price Snapshots**: timestamp, gold, silver, platinum, palladium, rhodium
- **Shockwave Alerts**: timestamp, metal, price, percentage move, direction, band, message

## 🚀 Next Steps

Consider adding:
- Historical price charts with more data points
- Email/SMS notifications via integration
- Custom alert thresholds per metal
- Export functionality for alerts
- Price prediction models
- Multi-currency support
- Webhook integration for trading bots

## 🎨 UI Features

- Dark, lean dashboard optimized for quick scanning
- Responsive design for desktop and mobile
- Real-time database connection status
- Visual notification toggle
- Color-coded price movements (green up, red down)
- Filterable shockwave feed by metal and severity

## 🔐 Privacy & Security

- All database connections secured via WSS
- No personal data collected
- Notification preferences stored locally
- SpacetimeDB handles data encryption
