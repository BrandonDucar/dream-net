// SpacetimeDB imports must be at the top
use spacetimedb::{table, reducer, ReducerContext, Table, Timestamp, SpacetimeType, TimeDuration};
use std::time::Duration;

// --- Domain Types ---

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum MetalCode {
    Au, // Gold
    Ag, // Silver
    Pt, // Platinum
    Pd, // Palladium
    Rh, // Rhodium
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum Direction {
    Up,
    Down,
}

#[derive(SpacetimeType, Clone, Debug, PartialEq)]
pub enum ShockwaveBand {
    Minor,
    Moderate,
    Major,
}

// --- Tables ---

#[table(name = price_snapshot, public)]
#[derive(Clone)]
pub struct PriceSnapshot {
    #[primary_key]
    #[auto_inc]
    id: u64,
    #[index(btree)]
    timestamp: Timestamp,
    gold: f64,
    silver: f64,
    platinum: f64,
    palladium: f64,
    rhodium: f64,
}

#[table(name = shockwave_alert, public)]
#[derive(Clone)]
pub struct ShockwaveAlert {
    #[primary_key]
    #[auto_inc]
    alert_id: u64,
    #[index(btree)]
    timestamp: Timestamp,
    #[index(btree)]
    metal: MetalCode,
    price: f64,
    percentage_move: f64,
    direction: Direction,
    band: ShockwaveBand,
    message: String,
}

// "View" tables to materialize recent selections for clients that subscribe to a concise feed.
// These are optional but helpful to match "get_recent_*" reducers without returning data.
#[table(name = recent_price_snapshot, public)]
#[derive(Clone)]
pub struct RecentPriceSnapshot {
    #[primary_key]
    // Keep the original snapshot id as the primary key to avoid duplicates
    snapshot_id: u64,
    #[index(btree)]
    timestamp: Timestamp,
    gold: f64,
    silver: f64,
    platinum: f64,
    palladium: f64,
    rhodium: f64,
}

#[table(name = recent_shockwave_alert, public)]
#[derive(Clone)]
pub struct RecentShockwaveAlert {
    #[primary_key]
    // Keep the original alert id as the primary key to avoid duplicates
    alert_id: u64,
    #[index(btree)]
    timestamp: Timestamp,
    #[index(btree)]
    metal: MetalCode,
    price: f64,
    percentage_move: f64,
    direction: Direction,
    band: ShockwaveBand,
    message: String,
}

// --- Reducers ---

#[reducer]
pub fn add_price_snapshot(
    ctx: &ReducerContext,
    timestamp: Timestamp,
    gold: f64,
    silver: f64,
    platinum: f64,
    palladium: f64,
    rhodium: f64,
) -> Result<(), String> {
    let snap = PriceSnapshot {
        id: 0, // auto_inc
        timestamp,
        gold,
        silver,
        platinum,
        palladium,
        rhodium,
    };

    match ctx.db.price_snapshot().try_insert(snap) {
        Ok(row) => {
            spacetimedb::log::info!("Inserted price snapshot id={} at {}", row.id, row.timestamp.to_micros_since_unix_epoch());
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert price snapshot: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn add_shockwave_alert(
    ctx: &ReducerContext,
    timestamp: Timestamp,
    metal: MetalCode,
    price: f64,
    percentage_move: f64,
    direction: Direction,
    band: ShockwaveBand,
    message: String,
) -> Result<(), String> {
    let alert = ShockwaveAlert {
        alert_id: 0, // auto_inc
        timestamp,
        metal: metal.clone(),
        price,
        percentage_move,
        direction: direction.clone(),
        band: band.clone(),
        message: message.clone(),
    };

    match ctx.db.shockwave_alert().try_insert(alert) {
        Ok(row) => {
            spacetimedb::log::info!(
                "Inserted shockwave alert id={} metal={:?} band={:?}",
                row.alert_id,
                row.metal,
                row.band
            );
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to insert shockwave alert: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn get_recent_snapshots(ctx: &ReducerContext) -> Result<(), String> {
    // Calculate cutoff timestamp: last 7 days
    let seven_days = Duration::from_secs(7 * 24 * 60 * 60);
    let cutoff_opt = ctx.timestamp.checked_sub(TimeDuration::from_duration(seven_days));
    let cutoff = match cutoff_opt {
        Some(ts) => ts,
        None => {
            let msg = "Timestamp underflow while computing 7-day cutoff".to_string();
            spacetimedb::log::error!("{}", msg);
            return Err(msg);
        }
    };

    let cutoff_micros = cutoff.to_micros_since_unix_epoch();

    // Clear the recent table
    let mut to_delete: Vec<u64> = Vec::new();
    for row in ctx.db.recent_price_snapshot().iter() {
        to_delete.push(row.snapshot_id);
    }
    for id in &to_delete {
        ctx.db.recent_price_snapshot().snapshot_id().delete(id);
    }

    // Populate with snapshots from the last 7 days
    let mut inserted = 0usize;
    for snap in ctx.db.price_snapshot().iter() {
        if snap.timestamp.to_micros_since_unix_epoch() >= cutoff_micros {
            let recent = RecentPriceSnapshot {
                snapshot_id: snap.id,
                timestamp: snap.timestamp,
                gold: snap.gold,
                silver: snap.silver,
                platinum: snap.platinum,
                palladium: snap.palladium,
                rhodium: snap.rhodium,
            };
            // Use insert (panic on constraint) or try_insert; try_insert allows logging if duplicates happen
            if let Err(e) = ctx.db.recent_price_snapshot().try_insert(recent) {
                spacetimedb::log::warn!("Skipping duplicate recent snapshot id {}: {}", snap.id, e);
            } else {
                inserted += 1;
            }
        }
    }

    spacetimedb::log::info!("Refreshed recent_price_snapshot with {} rows", inserted);
    Ok(())
}

#[reducer]
pub fn get_recent_alerts(ctx: &ReducerContext) -> Result<(), String> {
    // Calculate cutoff timestamp: last 24 hours
    let day = Duration::from_secs(24 * 60 * 60);
    let cutoff_opt = ctx.timestamp.checked_sub(TimeDuration::from_duration(day));
    let cutoff = match cutoff_opt {
        Some(ts) => ts,
        None => {
            let msg = "Timestamp underflow while computing 24-hour cutoff".to_string();
            spacetimedb::log::error!("{}", msg);
            return Err(msg);
        }
    };

    let cutoff_micros = cutoff.to_micros_since_unix_epoch();

    // Clear the recent table
    let mut to_delete: Vec<u64> = Vec::new();
    for row in ctx.db.recent_shockwave_alert().iter() {
        to_delete.push(row.alert_id);
    }
    for id in &to_delete {
        ctx.db.recent_shockwave_alert().alert_id().delete(id);
    }

    // Populate with alerts from the last 24 hours
    let mut inserted = 0usize;
    for alert in ctx.db.shockwave_alert().iter() {
        if alert.timestamp.to_micros_since_unix_epoch() >= cutoff_micros {
            let recent = RecentShockwaveAlert {
                alert_id: alert.alert_id,
                timestamp: alert.timestamp,
                metal: alert.metal.clone(),
                price: alert.price,
                percentage_move: alert.percentage_move,
                direction: alert.direction.clone(),
                band: alert.band.clone(),
                message: alert.message.clone(),
            };
            if let Err(e) = ctx.db.recent_shockwave_alert().try_insert(recent) {
                spacetimedb::log::warn!("Skipping duplicate recent alert id {}: {}", alert.alert_id, e);
            } else {
                inserted += 1;
            }
        }
    }

    spacetimedb::log::info!("Refreshed recent_shockwave_alert with {} rows", inserted);
    Ok(())
}