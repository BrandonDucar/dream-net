'use client'
import { useState, useEffect, useCallback } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent } from "@/components/ui/card";
import { MetalPanel } from "@/components/MetalPanel";
import { ShockwaveFeed } from "@/components/ShockwaveFeed";
import { useSpacetimeDB } from "@/hooks/useSpacetimeDB";
import { useNotifications } from "@/hooks/useNotifications";
import type {
  SpotSnapshot,
  MetalHistoryMap,
  ShockwaveEvent,
  Thresholds,
  MetalCode,
  MetalInfo,
} from "@/lib/types";
import {
  snapshotToHistoryUpdate,
  detectShockwaves,
} from "@/lib/shockwave";
import { RefreshCw, Bell, BellOff, Database } from "lucide-react";
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

const METALS: MetalInfo[] = [
  { code: "AU", name: "Gold", symbol: "$" },
  { code: "AG", name: "Silver", symbol: "$" },
  { code: "PT", name: "Platinum", symbol: "$" },
  { code: "PD", name: "Palladium", symbol: "$" },
  { code: "RH", name: "Rhodium", symbol: "$" },
];

export default function ShockwaveMonitor(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    
    // SpacetimeDB integration
    const {
      connected: dbConnected,
      statusMessage: dbStatusMessage,
      savePriceSnapshot,
      saveShockwaveAlert,
      loadRecentData,
    } = useSpacetimeDB();
    
    // Notifications integration
    const {
      permission: notificationPermission,
      enabled: notificationsEnabled,
      showNotification,
      toggleNotifications,
    } = useNotifications();
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [spots, setSpots] = useState<SpotSnapshot | null>(null);
  const [prevSnapshot, setPrevSnapshot] = useState<SpotSnapshot | null>(null);
  const [sessionOpen, setSessionOpen] = useState<SpotSnapshot | null>(null);
  const [history, setHistory] = useState<MetalHistoryMap>({
    AU: [],
    AG: [],
    PT: [],
    PD: [],
    RH: [],
  });
  const [events, setEvents] = useState<ShockwaveEvent[]>([]);
  const [thresholds, setThresholds] = useState<Thresholds>({
    minor: 0.5,
    moderate: 1.0,
    major: 2.0,
  });
  const [autoRefresh, setAutoRefresh] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [filterMetal, setFilterMetal] = useState<MetalCode | "ALL">("ALL");
  const [filterBand, setFilterBand] = useState<"all" | "minor" | "moderate" | "major">(
    "all"
  );

  const fetchSpotData = useCallback(async (): Promise<void> => {
    setLoading(true);
    try {
      const response = await fetch("/api/spot");
      const data: SpotSnapshot = await response.json();

      // If this is the first fetch, set as session open
      if (!sessionOpen) {
        setSessionOpen(data);
        setSpots(data);
        setPrevSnapshot(data);
        setHistory(snapshotToHistoryUpdate(data, history));
      } else {
        // Move current to previous
        if (spots) {
          setPrevSnapshot(spots);
        }

        // Set new data
        setSpots(data);
        setHistory((prev: MetalHistoryMap) => snapshotToHistoryUpdate(data, prev));

        // Detect shockwaves
        if (spots) {
          const newEvents = detectShockwaves(spots, data, thresholds);
          if (newEvents.length > 0) {
            setEvents((prev: ShockwaveEvent[]) => {
              const combined = [...newEvents, ...prev];
              // Keep only last 200 events
              return combined.slice(0, 200);
            });
            
            // Save shockwaves to database and trigger notifications
            newEvents.forEach((event: ShockwaveEvent) => {
              saveShockwaveAlert(event);
              
              // Show notification for major shockwaves
              if (event.band === "major") {
                showNotification(
                  `Major Shockwave: ${event.metal}`,
                  `${event.message} at $${event.price.toFixed(2)}`,
                  `shockwave-${event.id}`
                );
              }
            });
          }
        }
        
        // Save price snapshot to database
        savePriceSnapshot(data);
      }
    } catch (error) {
      console.error("Failed to fetch spot data:", error);
    } finally {
      setLoading(false);
    }
  }, [spots, sessionOpen, history, thresholds, savePriceSnapshot, saveShockwaveAlert, showNotification]);

  // Initial fetch on mount
  useEffect(() => {
    fetchSpotData();
  }, []);
  
  // Load historical data when DB connects
  useEffect(() => {
    if (dbConnected) {
      loadRecentData();
    }
  }, [dbConnected, loadRecentData]);

  // Auto-refresh timer
  useEffect(() => {
    if (!autoRefresh) return;

    const interval = setInterval(() => {
      fetchSpotData();
    }, 60000); // 60 seconds

    return () => clearInterval(interval);
  }, [autoRefresh, fetchSpotData]);

  const handleRefresh = (): void => {
    fetchSpotData();
  };

  const formatTimestamp = (timestamp: number): string => {
    return new Date(timestamp).toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const getPriceForMetal = (
    snapshot: SpotSnapshot | null,
    code: MetalCode
  ): number => {
    if (!snapshot) return 0;
    const mapping: Record<MetalCode, keyof SpotSnapshot> = {
      AU: "gold",
      AG: "silver",
      PT: "platinum",
      PD: "palladium",
      RH: "rhodium",
    };
    return snapshot[mapping[code]] as number;
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white p-6">
      <div className="max-w-[1800px] mx-auto space-y-6">
        {/* Top Bar - Controls & Current Spots */}
        <Card className="bg-slate-900 border-slate-800">
          <CardContent className="pt-6">
            <div className="space-y-6">
              {/* Title & Refresh */}
              <div className="flex items-center justify-between flex-wrap gap-4">
                <h1 className="text-3xl font-bold text-cyan-400">
                  Spot Shockwave Monitor
                </h1>
                <div className="flex items-center gap-4">
                  <Button
                    onClick={handleRefresh}
                    disabled={loading}
                    className="bg-cyan-600 hover:bg-cyan-700"
                  >
                    <RefreshCw
                      className={`w-4 h-4 mr-2 ${loading ? "animate-spin" : ""}`}
                    />
                    Refresh Now
                  </Button>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-2">
                      <Switch
                        id="auto-refresh"
                        checked={autoRefresh}
                        onCheckedChange={setAutoRefresh}
                      />
                      <Label htmlFor="auto-refresh" className="text-sm text-slate-300">
                        Auto-refresh (60s)
                      </Label>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={toggleNotifications}
                        className="border-slate-700 hover:bg-slate-800"
                      >
                        {notificationsEnabled ? (
                          <Bell className="w-4 h-4 mr-2" />
                        ) : (
                          <BellOff className="w-4 h-4 mr-2" />
                        )}
                        Alerts
                      </Button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Current Spots Display */}
              {spots && (
                <div className="grid grid-cols-2 md:grid-cols-6 gap-4 p-4 bg-slate-950 rounded-lg border border-slate-800">
                  {METALS.map((metal: MetalInfo) => (
                    <div key={metal.code} className="text-center">
                      <div className="text-xs text-slate-400 mb-1">{metal.code}</div>
                      <div className="text-lg font-bold text-white">
                        {metal.symbol}
                        {getPriceForMetal(spots, metal.code).toLocaleString("en-US", {
                          minimumFractionDigits: 2,
                          maximumFractionDigits: 2,
                        })}
                      </div>
                    </div>
                  ))}
                  <div className="text-center">
                    <div className="text-xs text-slate-400 mb-1">Last Update</div>
                    <div className="text-sm font-medium text-slate-300">
                      {formatTimestamp(spots.timestamp)}
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-xs text-slate-400 mb-1 flex items-center justify-center gap-1">
                      <Database className="w-3 h-3" />
                      Database
                    </div>
                    <div className={`text-sm font-medium ${
                      dbConnected ? "text-green-400" : "text-amber-400"
                    }`}>
                      {dbConnected ? "Connected" : "Connecting..."}
                    </div>
                  </div>
                </div>
              )}

              {/* Threshold Controls */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-slate-950 rounded-lg border border-slate-800">
                <div className="space-y-2">
                  <Label htmlFor="minor" className="text-sm text-cyan-400">
                    Minor Threshold (%)
                  </Label>
                  <Input
                    id="minor"
                    type="number"
                    step="0.1"
                    value={thresholds.minor}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setThresholds((prev: Thresholds) => ({
                        ...prev,
                        minor: parseFloat(e.target.value) || 0,
                      }))
                    }
                    className="bg-slate-900 border-slate-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="moderate" className="text-sm text-cyan-400">
                    Moderate Threshold (%)
                  </Label>
                  <Input
                    id="moderate"
                    type="number"
                    step="0.1"
                    value={thresholds.moderate}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setThresholds((prev: Thresholds) => ({
                        ...prev,
                        moderate: parseFloat(e.target.value) || 0,
                      }))
                    }
                    className="bg-slate-900 border-slate-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="major" className="text-sm text-cyan-400">
                    Major Threshold (%)
                  </Label>
                  <Input
                    id="major"
                    type="number"
                    step="0.1"
                    value={thresholds.major}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      setThresholds((prev: Thresholds) => ({
                        ...prev,
                        major: parseFloat(e.target.value) || 0,
                      }))
                    }
                    className="bg-slate-900 border-slate-700 text-white"
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
          {/* Metal Panels - Left Side (2 columns) */}
          <div className="xl:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-4">
            {METALS.map((metal: MetalInfo) => (
              <MetalPanel
                key={metal.code}
                code={metal.code}
                name={metal.name}
                symbol={metal.symbol}
                currentPrice={getPriceForMetal(spots, metal.code)}
                sessionOpen={getPriceForMetal(sessionOpen, metal.code)}
                previousPrice={getPriceForMetal(prevSnapshot, metal.code)}
                history={history[metal.code]}
              />
            ))}
          </div>

          {/* Shockwave Feed - Right Side (1 column) */}
          <div className="xl:col-span-1">
            <ShockwaveFeed
              events={events}
              filterMetal={filterMetal}
              filterBand={filterBand}
              onFilterMetal={setFilterMetal}
              onFilterBand={setFilterBand}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
