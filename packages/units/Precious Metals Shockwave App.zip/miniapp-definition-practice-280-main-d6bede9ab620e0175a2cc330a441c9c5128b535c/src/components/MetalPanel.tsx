import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Sparkline } from "./Sparkline";
import type { MetalCode, MetalHistoryPoint } from "@/lib/types";
import { calculateVolatility, pctChange } from "@/lib/shockwave";

type MetalPanelProps = {
  code: MetalCode;
  name: string;
  symbol: string;
  currentPrice: number;
  sessionOpen: number;
  previousPrice: number;
  history: MetalHistoryPoint[];
};

export function MetalPanel({
  code,
  name,
  symbol,
  currentPrice,
  sessionOpen,
  previousPrice,
  history,
}: MetalPanelProps): JSX.Element {
  const sessionChange = pctChange(currentPrice, sessionOpen);
  const lastChange = pctChange(currentPrice, previousPrice);

  const volatility = calculateVolatility(history.map((h: MetalHistoryPoint) => h.price));

  const getChangeColor = (change: number): string => {
    if (change > 0) return "text-green-500";
    if (change < 0) return "text-red-400";
    return "text-gray-400";
  };

  const getSparklineColor = (change: number): string => {
    if (change > 0) return "#22c55e";
    if (change < 0) return "#f87171";
    return "#94a3b8";
  };

  const getVolatilityBadge = (): JSX.Element => {
    const config: Record<string, { label: string; className: string }> = {
      calm: { label: "Calm", className: "bg-slate-700 text-slate-300" },
      choppy: { label: "Choppy", className: "bg-amber-900/50 text-amber-300" },
      wild: { label: "Wild", className: "bg-red-900/50 text-red-300" },
    };

    const { label, className } = config[volatility];
    return (
      <Badge variant="outline" className={className}>
        {label}
      </Badge>
    );
  };

  return (
    <Card className="bg-slate-950 border-slate-800">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold text-cyan-400">
            {code} · {name}
          </CardTitle>
          {getVolatilityBadge()}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="text-2xl font-bold text-white">
            {symbol}
            {currentPrice.toLocaleString("en-US", {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            })}
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <div className="text-slate-400 text-xs mb-1">Session</div>
            <div className={`font-semibold ${getChangeColor(sessionChange)}`}>
              {sessionChange >= 0 ? "+" : ""}
              {sessionChange.toFixed(2)}%
            </div>
          </div>
          <div>
            <div className="text-slate-400 text-xs mb-1">Last Tick</div>
            <div className={`font-semibold ${getChangeColor(lastChange)}`}>
              {lastChange >= 0 ? "+" : ""}
              {lastChange.toFixed(2)}%
            </div>
          </div>
        </div>

        <div className="pt-2">
          <div className="text-slate-400 text-xs mb-2">Price History</div>
          <div className="flex justify-center">
            <Sparkline
              data={history}
              color={getSparklineColor(sessionChange)}
              width={200}
              height={50}
            />
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
