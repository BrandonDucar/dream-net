import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import type { ShockwaveEvent, MetalCode } from "@/lib/types";
import { TrendingUp, TrendingDown } from "lucide-react";

type ShockwaveFeedProps = {
  events: ShockwaveEvent[];
  filterMetal: MetalCode | "ALL";
  filterBand: "all" | "minor" | "moderate" | "major";
  onFilterMetal: (metal: MetalCode | "ALL") => void;
  onFilterBand: (band: "all" | "minor" | "moderate" | "major") => void;
};

export function ShockwaveFeed({
  events,
  filterMetal,
  filterBand,
  onFilterMetal,
  onFilterBand,
}: ShockwaveFeedProps): JSX.Element {
  const filteredEvents = events.filter((event: ShockwaveEvent) => {
    const metalMatch = filterMetal === "ALL" || event.metal === filterMetal;
    const bandMatch = filterBand === "all" || event.band === filterBand;
    return metalMatch && bandMatch;
  });

  const getBandBadge = (band: "minor" | "moderate" | "major"): JSX.Element => {
    const config: Record<string, { label: string; className: string }> = {
      minor: { label: "Minor", className: "bg-slate-700 text-slate-300" },
      moderate: { label: "Moderate", className: "bg-amber-900/50 text-amber-300" },
      major: { label: "Major", className: "bg-red-900/50 text-red-300" },
    };

    const { label, className } = config[band];
    return (
      <Badge variant="outline" className={className}>
        {label}
      </Badge>
    );
  };

  const formatTime = (timestamp: number): string => {
    const date = new Date(timestamp);
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    });
  };

  const metals: Array<MetalCode | "ALL"> = ["ALL", "AU", "AG", "PT", "PD", "RH"];
  const bands: Array<"all" | "minor" | "moderate" | "major"> = [
    "all",
    "minor",
    "moderate",
    "major",
  ];

  return (
    <Card className="bg-slate-950 border-slate-800 h-full flex flex-col">
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-cyan-400">
          Shockwave Feed
        </CardTitle>

        <div className="flex flex-wrap gap-2 mt-4">
          <div className="text-xs text-slate-400 w-full mb-1">Filter by Metal:</div>
          {metals.map((metal: MetalCode | "ALL") => (
            <Button
              key={metal}
              size="sm"
              variant={filterMetal === metal ? "default" : "outline"}
              onClick={() => onFilterMetal(metal)}
              className={
                filterMetal === metal
                  ? "bg-cyan-600 hover:bg-cyan-700 text-white"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
              }
            >
              {metal}
            </Button>
          ))}
        </div>

        <div className="flex flex-wrap gap-2 mt-3">
          <div className="text-xs text-slate-400 w-full mb-1">Filter by Band:</div>
          {bands.map((band: "all" | "minor" | "moderate" | "major") => (
            <Button
              key={band}
              size="sm"
              variant={filterBand === band ? "default" : "outline"}
              onClick={() => onFilterBand(band)}
              className={
                filterBand === band
                  ? "bg-cyan-600 hover:bg-cyan-700 text-white"
                  : "bg-slate-800 hover:bg-slate-700 text-slate-300 border-slate-700"
              }
            >
              {band.charAt(0).toUpperCase() + band.slice(1)}
            </Button>
          ))}
        </div>
      </CardHeader>

      <CardContent className="flex-1 overflow-y-auto space-y-2">
        {filteredEvents.length === 0 ? (
          <div className="text-center text-slate-500 py-8">
            No shockwave events detected yet.
            <br />
            <span className="text-sm">Markets are calm.</span>
          </div>
        ) : (
          filteredEvents.map((event: ShockwaveEvent) => (
            <div
              key={event.id}
              className="bg-slate-900 border border-slate-800 rounded-lg p-3 hover:border-slate-700 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <span className="font-bold text-white">{event.metal}</span>
                  {getBandBadge(event.band)}
                  {event.direction === "up" ? (
                    <TrendingUp className="w-4 h-4 text-green-500" />
                  ) : (
                    <TrendingDown className="w-4 h-4 text-red-400" />
                  )}
                </div>
                <span className="text-xs text-slate-400">
                  {formatTime(event.timestamp)}
                </span>
              </div>

              <div className="text-sm text-slate-300 mb-1">{event.message}</div>

              <div className="text-xs text-slate-500">
                ${event.price.toLocaleString("en-US", {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 2,
                })}{" "}
                <span
                  className={
                    event.direction === "up" ? "text-green-500" : "text-red-400"
                  }
                >
                  {event.pctMove >= 0 ? "+" : ""}
                  {event.pctMove.toFixed(2)}%
                </span>
              </div>
            </div>
          ))
        )}
      </CardContent>
    </Card>
  );
}
