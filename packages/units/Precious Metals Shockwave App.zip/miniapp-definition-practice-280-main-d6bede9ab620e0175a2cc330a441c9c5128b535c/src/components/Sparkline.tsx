import type { MetalHistoryPoint } from "@/lib/types";

type SparklineProps = {
  data: MetalHistoryPoint[];
  color: string;
  width?: number;
  height?: number;
};

export function Sparkline({
  data,
  color,
  width = 120,
  height = 40,
}: SparklineProps): JSX.Element {
  if (data.length < 2) {
    return (
      <svg width={width} height={height} className="opacity-30">
        <line
          x1="0"
          y1={height / 2}
          x2={width}
          y2={height / 2}
          stroke={color}
          strokeWidth="1"
          strokeDasharray="2,2"
        />
      </svg>
    );
  }

  const prices = data.map((d: MetalHistoryPoint) => d.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const priceRange = maxPrice - minPrice || 1;

  const points = data
    .map((d: MetalHistoryPoint, i: number) => {
      const x = (i / (data.length - 1)) * width;
      const y = height - ((d.price - minPrice) / priceRange) * height;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");

  return (
    <svg width={width} height={height} className="overflow-visible">
      <polyline
        points={points}
        fill="none"
        stroke={color}
        strokeWidth="1.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
