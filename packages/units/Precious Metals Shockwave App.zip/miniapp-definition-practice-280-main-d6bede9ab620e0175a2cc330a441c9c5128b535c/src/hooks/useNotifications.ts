'use client'

import { useState, useEffect, useCallback } from "react";

export interface NotificationState {
  permission: NotificationPermission;
  enabled: boolean;
}

export interface NotificationActions {
  requestPermission: () => Promise<void>;
  showNotification: (title: string, body: string, tag?: string) => void;
  toggleNotifications: () => void;
}

export function useNotifications(): NotificationState & NotificationActions {
  const [permission, setPermission] = useState<NotificationPermission>("default");
  const [enabled, setEnabled] = useState<boolean>(false);

  useEffect(() => {
    if (typeof window !== "undefined" && "Notification" in window) {
      setPermission(Notification.permission);
      
      // Load saved preference
      const savedEnabled = localStorage.getItem("notificationsEnabled");
      if (savedEnabled !== null) {
        setEnabled(savedEnabled === "true" && Notification.permission === "granted");
      }
    }
  }, []);

  const requestPermission = useCallback(async (): Promise<void> => {
    if (!("Notification" in window)) {
      console.log("Browser does not support notifications");
      return;
    }

    if (Notification.permission === "granted") {
      setPermission("granted");
      setEnabled(true);
      localStorage.setItem("notificationsEnabled", "true");
      return;
    }

    if (Notification.permission !== "denied") {
      try {
        const result = await Notification.requestPermission();
        setPermission(result);
        
        if (result === "granted") {
          setEnabled(true);
          localStorage.setItem("notificationsEnabled", "true");
          
          // Show test notification
          new Notification("Notifications Enabled", {
            body: "You'll now receive alerts for major shockwaves",
            icon: "/icon.png",
            tag: "test-notification"
          });
        }
      } catch (error) {
        console.error("Failed to request notification permission:", error);
      }
    }
  }, []);

  const showNotification = useCallback((title: string, body: string, tag?: string): void => {
    if (!enabled || permission !== "granted") {
      console.log("Notifications not enabled or permitted");
      return;
    }

    try {
      new Notification(title, {
        body,
        icon: "/icon.png",
        tag: tag || `notification-${Date.now()}`,
        requireInteraction: true,
      });
    } catch (error) {
      console.error("Failed to show notification:", error);
    }
  }, [enabled, permission]);

  const toggleNotifications = useCallback((): void => {
    if (permission !== "granted") {
      requestPermission();
    } else {
      const newEnabled = !enabled;
      setEnabled(newEnabled);
      localStorage.setItem("notificationsEnabled", newEnabled.toString());
    }
  }, [enabled, permission, requestPermission]);

  return {
    permission,
    enabled,
    requestPermission,
    showNotification,
    toggleNotifications,
  };
}
