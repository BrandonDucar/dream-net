'use client'

import { useState, useEffect, useRef, useCallback } from "react";
import { Identity, Timestamp } from "spacetimedb";
import * as moduleBindings from "../spacetime_module_bindings";
import type { SpotSnapshot, ShockwaveEvent } from "@/lib/types";

type DbConnection = moduleBindings.DbConnection;
type EventContext = moduleBindings.EventContext;
type ErrorContext = moduleBindings.ErrorContext;
type PriceSnapshot = moduleBindings.PriceSnapshot;
type ShockwaveAlert = moduleBindings.ShockwaveAlert;
type MetalCode = moduleBindings.MetalCode;
type Direction = moduleBindings.Direction;
type ShockwaveBand = moduleBindings.ShockwaveBand;

export interface SpacetimeDBState {
  connected: boolean;
  identity: Identity | null;
  statusMessage: string;
  connection: DbConnection | null;
  historicalSnapshots: PriceSnapshot[];
  historicalAlerts: ShockwaveAlert[];
}

export interface SpacetimeDBActions {
  savePriceSnapshot: (snapshot: SpotSnapshot) => void;
  saveShockwaveAlert: (event: ShockwaveEvent) => void;
  loadRecentData: () => void;
}

export function useSpacetimeDB(): SpacetimeDBState & SpacetimeDBActions {
  const [connected, setConnected] = useState<boolean>(false);
  const [identity, setIdentity] = useState<Identity | null>(null);
  const [statusMessage, setStatusMessage] = useState<string>("Initializing database...");
  const [historicalSnapshots, setHistoricalSnapshots] = useState<PriceSnapshot[]>([]);
  const [historicalAlerts, setHistoricalAlerts] = useState<ShockwaveAlert[]>([]);
  
  const connectionRef = useRef<DbConnection | null>(null);

  const subscribeToTables = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log("Subscribing to SpacetimeDB tables...");
    
    const queries = [
      "SELECT * FROM recent_price_snapshot",
      "SELECT * FROM recent_shockwave_alert"
    ];
    
    connectionRef.current
      .subscriptionBuilder()
      .onApplied(() => {
        console.log("Subscription applied - loading historical data");
        processInitialCache();
      })
      .onError((error: Error) => {
        console.error("Subscription error:", error);
        setStatusMessage(`Subscription Error: ${error.message}`);
      })
      .subscribe(queries);
  }, []);

  const processInitialCache = useCallback(() => {
    if (!connectionRef.current) return;
    
    console.log("Processing initial cache...");
    
    // Load recent snapshots
    const snapshots: PriceSnapshot[] = [];
    for (const snap of connectionRef.current.db.recentPriceSnapshot.iter()) {
      snapshots.push(snap);
    }
    setHistoricalSnapshots(snapshots.sort((a: PriceSnapshot, b: PriceSnapshot) => 
      Number(b.timestamp.toDate().getTime() - a.timestamp.toDate().getTime())
    ));
    
    // Load recent alerts
    const alerts: ShockwaveAlert[] = [];
    for (const alert of connectionRef.current.db.recentShockwaveAlert.iter()) {
      alerts.push(alert);
    }
    setHistoricalAlerts(alerts.sort((a: ShockwaveAlert, b: ShockwaveAlert) => 
      Number(b.timestamp.toDate().getTime() - a.timestamp.toDate().getTime())
    ));
    
    setStatusMessage(`Loaded ${snapshots.length} snapshots and ${alerts.length} alerts`);
  }, []);

  const registerTableCallbacks = useCallback((currentIdentity: Identity) => {
    if (!connectionRef.current) return;
    
    console.log("Registering table callbacks...");

    // Recent price snapshot callbacks
    connectionRef.current.db.recentPriceSnapshot.onInsert((_ctx: EventContext | undefined, snap: PriceSnapshot) => {
      setHistoricalSnapshots((prev: PriceSnapshot[]) => {
        const newList = [snap, ...prev];
        return newList.slice(0, 200); // Keep last 200
      });
    });

    // Recent shockwave alert callbacks
    connectionRef.current.db.recentShockwaveAlert.onInsert((_ctx: EventContext | undefined, alert: ShockwaveAlert) => {
      setHistoricalAlerts((prev: ShockwaveAlert[]) => {
        const newList = [alert, ...prev];
        return newList.slice(0, 200); // Keep last 200
      });
    });
  }, []);

  useEffect(() => {
    if (connectionRef.current) {
      console.log("Connection already established, skipping setup.");
      return;
    }

    const dbHost = "wss://maincloud.spacetimedb.com";
    const dbName = process.env.NEXT_PUBLIC_SPACETIME_MODULE_NAME || "metals-shockwave-monitor";

    const onConnect = (connection: DbConnection, id: Identity, _token: string) => {
      console.log("Connected to SpacetimeDB!");
      connectionRef.current = connection;
      setIdentity(id);
      setConnected(true);
      setStatusMessage("Connected to database");
      
      subscribeToTables();
      registerTableCallbacks(id);
    };

    const onDisconnect = (_ctx: ErrorContext, reason?: Error | null) => {
      const reasonStr = reason ? reason.message : "No reason given";
      console.log("Disconnected from SpacetimeDB:", reasonStr);
      setStatusMessage(`Database disconnected: ${reasonStr}`);
      connectionRef.current = null;
      setIdentity(null);
      setConnected(false);
    };

    moduleBindings.DbConnection.builder()
      .withUri(dbHost)
      .withModuleName(dbName)
      .onConnect(onConnect)
      .onDisconnect(onDisconnect)
      .build();
  }, [subscribeToTables, registerTableCallbacks]);

  const savePriceSnapshot = useCallback((snapshot: SpotSnapshot): void => {
    if (!connectionRef.current || !connected) {
      console.log("Cannot save snapshot - not connected to database");
      return;
    }
    
    try {
      const timestamp = Timestamp.fromDate(new Date(snapshot.timestamp));
      connectionRef.current.reducers.addPriceSnapshot(
        timestamp,
        snapshot.gold,
        snapshot.silver,
        snapshot.platinum,
        snapshot.palladium,
        snapshot.rhodium
      );
      console.log("Price snapshot saved to database");
    } catch (error) {
      console.error("Failed to save price snapshot:", error);
    }
  }, [connected]);

  const saveShockwaveAlert = useCallback((event: ShockwaveEvent): void => {
    if (!connectionRef.current || !connected) {
      console.log("Cannot save alert - not connected to database");
      return;
    }
    
    try {
      const timestamp = Timestamp.fromDate(new Date(event.timestamp));
      
      // Map metal code
      const metalMapping: Record<string, MetalCode> = {
        AU: moduleBindings.MetalCode.Au,
        AG: moduleBindings.MetalCode.Ag,
        PT: moduleBindings.MetalCode.Pt,
        PD: moduleBindings.MetalCode.Pd,
        RH: moduleBindings.MetalCode.Rh,
      };
      const metal = metalMapping[event.metal as keyof typeof metalMapping];
      
      // Map direction
      const direction: Direction = event.direction === "up" 
        ? moduleBindings.Direction.Up 
        : moduleBindings.Direction.Down;
      
      // Map band
      const bandMapping: Record<string, ShockwaveBand> = {
        minor: moduleBindings.ShockwaveBand.Minor,
        moderate: moduleBindings.ShockwaveBand.Moderate,
        major: moduleBindings.ShockwaveBand.Major,
      };
      const band = bandMapping[event.band as keyof typeof bandMapping];
      
      connectionRef.current.reducers.addShockwaveAlert(
        timestamp,
        metal,
        event.price,
        event.pctMove,
        direction,
        band,
        event.message
      );
      console.log("Shockwave alert saved to database");
    } catch (error) {
      console.error("Failed to save shockwave alert:", error);
    }
  }, [connected]);

  const loadRecentData = useCallback((): void => {
    if (!connectionRef.current || !connected) {
      console.log("Cannot load recent data - not connected to database");
      return;
    }
    
    try {
      connectionRef.current.reducers.getRecentSnapshots();
      connectionRef.current.reducers.getRecentAlerts();
      console.log("Requested recent data refresh");
    } catch (error) {
      console.error("Failed to load recent data:", error);
    }
  }, [connected]);

  return {
    connected,
    identity,
    statusMessage,
    connection: connectionRef.current,
    historicalSnapshots,
    historicalAlerts,
    savePriceSnapshot,
    saveShockwaveAlert,
    loadRecentData,
  };
}
