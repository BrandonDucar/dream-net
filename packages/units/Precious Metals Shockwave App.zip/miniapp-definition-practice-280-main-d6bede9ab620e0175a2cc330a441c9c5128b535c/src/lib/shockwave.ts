import type {
  MetalCode,
  SpotSnapshot,
  MetalHistoryMap,
  ShockwaveEvent,
  Thresholds,
} from "./types";

export function snapshotToHistoryUpdate(
  snapshot: SpotSnapshot,
  history: MetalHistoryMap
): MetalHistoryMap {
  const next: MetalHistoryMap = { ...history };

  const entries: [MetalCode, number][] = [
    ["AU", snapshot.gold],
    ["AG", snapshot.silver],
    ["PT", snapshot.platinum],
    ["PD", snapshot.palladium],
    ["RH", snapshot.rhodium],
  ];

  for (const [metal, price] of entries) {
    const arr = next[metal] ? [...next[metal]] : [];
    arr.push({ timestamp: snapshot.timestamp, price });
    // Keep history manageable (last 200 points)
    if (arr.length > 200) arr.shift();
    next[metal] = arr;
  }

  return next;
}

export function pctChange(current: number, previous: number): number {
  if (previous === 0) return 0;
  return ((current - previous) / previous) * 100;
}

export function classifyBand(
  pctMove: number,
  thresholds: Thresholds
): "minor" | "moderate" | "major" | null {
  const abs = Math.abs(pctMove);
  if (abs >= thresholds.major) return "major";
  if (abs >= thresholds.moderate) return "moderate";
  if (abs >= thresholds.minor) return "minor";
  return null;
}

export function detectShockwaves(
  prevSnapshot: SpotSnapshot | null,
  currentSnapshot: SpotSnapshot,
  thresholds: Thresholds
): ShockwaveEvent[] {
  if (!prevSnapshot) return [];

  const events: ShockwaveEvent[] = [];

  const pairs: [MetalCode, number, number][] = [
    ["AU", prevSnapshot.gold, currentSnapshot.gold],
    ["AG", prevSnapshot.silver, currentSnapshot.silver],
    ["PT", prevSnapshot.platinum, currentSnapshot.platinum],
    ["PD", prevSnapshot.palladium, currentSnapshot.palladium],
    ["RH", prevSnapshot.rhodium, currentSnapshot.rhodium],
  ];

  for (const [metal, prev, curr] of pairs) {
    const move = pctChange(curr, prev);
    const band = classifyBand(move, thresholds);
    if (!band) continue;

    const direction: "up" | "down" = move >= 0 ? "up" : "down";

    const message = (() => {
      const rounded = move.toFixed(2);
      if (band === "major") return `${metal} major move ${direction} ${rounded}%`;
      if (band === "moderate")
        return `${metal} moderate move ${direction} ${rounded}%`;
      return `${metal} minor move ${direction} ${rounded}%`;
    })();

    events.push({
      id: `${metal}-${currentSnapshot.timestamp}`,
      metal,
      timestamp: currentSnapshot.timestamp,
      price: curr,
      pctMove: move,
      direction,
      band,
      message,
    });
  }

  return events;
}

export function calculateVolatility(
  prices: number[],
  windowSize: number = 10
): "calm" | "choppy" | "wild" {
  if (prices.length < 2) return "calm";

  const recentPrices = prices.slice(-windowSize);
  if (recentPrices.length < 2) return "calm";

  // Calculate standard deviation
  const mean =
    recentPrices.reduce((sum: number, p: number) => sum + p, 0) /
    recentPrices.length;
  const variance =
    recentPrices.reduce((sum: number, p: number) => sum + Math.pow(p - mean, 2), 0) /
    recentPrices.length;
  const stdDev = Math.sqrt(variance);

  // Calculate coefficient of variation (CV)
  const cv = mean !== 0 ? (stdDev / mean) * 100 : 0;

  if (cv > 1.5) return "wild";
  if (cv > 0.5) return "choppy";
  return "calm";
}
