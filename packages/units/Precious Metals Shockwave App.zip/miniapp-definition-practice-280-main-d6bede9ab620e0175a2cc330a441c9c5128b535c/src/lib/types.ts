export type MetalCode = "AU" | "AG" | "PT" | "PD" | "RH";

export type SpotSnapshot = {
  timestamp: number;
  gold: number;
  silver: number;
  platinum: number;
  palladium: number;
  rhodium: number;
};

export type MetalHistoryPoint = {
  timestamp: number;
  price: number;
};

export type MetalHistoryMap = {
  AU: MetalHistoryPoint[];
  AG: MetalHistoryPoint[];
  PT: MetalHistoryPoint[];
  PD: MetalHistoryPoint[];
  RH: MetalHistoryPoint[];
};

export type ShockwaveEvent = {
  id: string;
  metal: MetalCode;
  timestamp: number;
  price: number;
  pctMove: number;
  direction: "up" | "down";
  band: "minor" | "moderate" | "major";
  message: string;
};

export type Thresholds = {
  minor: number;
  moderate: number;
  major: number;
};

export type MetalInfo = {
  code: MetalCode;
  name: string;
  symbol: string;
};
