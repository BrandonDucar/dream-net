use spacetimedb::{table, reducer, ReducerContext, Identity, Table, Timestamp, SpacetimeType};

#[derive(SpacetimeType, Clone, Debug, PartialEq, Eq)]
pub enum PostStatus {
    Pending,
    Published,
    Failed,
}

#[table(name = content_transformations, public)]
#[derive(Clone)]
pub struct ContentTransformations {
    #[primary_key]
    #[auto_inc]
    id: u64,
    core_text: String,
    platforms: Vec<String>,
    audience_region: String,
    tone: String,
    // Store JSON as a string
    platform_text: String,
    hashtags: String,
    short_hook: String,
    long_version: String,
    created_at: Timestamp,
    user_id: Identity,
}

#[table(name = brand_voices, public)]
#[derive(Clone)]
pub struct BrandVoices {
    #[primary_key]
    #[auto_inc]
    id: u64,
    name: String,
    description: String,
    tone: String,
    sample_text: String,
    keywords: Vec<String>,
    created_at: Timestamp,
    user_id: Identity,
}

#[table(name = scheduled_posts, public)]
#[derive(Clone)]
pub struct ScheduledPosts {
    #[primary_key]
    #[auto_inc]
    id: u64,
    transformation_id: u64,
    platform: String,
    scheduled_for: Timestamp,
    status: PostStatus,
    published_at: Option<Timestamp>,
    user_id: Identity,
}

#[table(name = analytics, public)]
#[derive(Clone)]
pub struct Analytics {
    #[primary_key]
    #[auto_inc]
    id: u64,
    transformation_id: u64,
    platform: String,
    views: u64,
    likes: u64,
    shares: u64,
    comments: u64,
    engagement_rate: f32,
    created_at: Timestamp,
}

#[table(name = asset_library, public)]
#[derive(Clone)]
pub struct AssetLibrary {
    #[primary_key]
    #[auto_inc]
    id: u64,
    url: String,
    name: String,
    prompt: String,
    platform: String,
    created_at: Timestamp,
    user_id: Identity,
}

#[reducer]
pub fn save_transformation(
    ctx: &ReducerContext,
    core_text: String,
    platforms: Vec<String>,
    audience_region: String,
    tone: String,
    platform_text: String,
    hashtags: String,
    short_hook: String,
    long_version: String,
) -> Result<(), String> {
    let row = ContentTransformations {
        id: 0,
        core_text,
        platforms,
        audience_region,
        tone,
        platform_text,
        hashtags,
        short_hook,
        long_version,
        created_at: ctx.timestamp,
        user_id: ctx.sender,
    };

    match ctx.db.content_transformations().try_insert(row) {
        Ok(inserted) => {
            spacetimedb::log::info!(
                "Saved transformation id={} user={}",
                inserted.id,
                inserted.user_id
            );
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to save transformation: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn get_user_transformations(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!(
        "get_user_transformations called by user={}. Clients should subscribe to content_transformations filtered by user_id.",
        ctx.sender
    );
    Ok(())
}

#[reducer]
pub fn save_brand_voice(
    ctx: &ReducerContext,
    name: String,
    description: String,
    tone: String,
    sample_text: String,
    keywords: Vec<String>,
) -> Result<(), String> {
    // Try to find existing brand voice for this user by name
    let mut existing_id: Option<u64> = None;
    for bv in ctx.db.brand_voices().iter() {
        if bv.user_id == ctx.sender && bv.name == name {
            existing_id = Some(bv.id);
            break;
        }
    }

    if let Some(id) = existing_id {
        if let Some(mut existing) = ctx.db.brand_voices().id().find(&id) {
            existing.description = description;
            existing.tone = tone;
            existing.sample_text = sample_text;
            existing.keywords = keywords;
            // Keep original created_at
            let updated_name = existing.name.clone();
            let updated_id = existing.id;
            ctx.db.brand_voices().id().update(existing);
            spacetimedb::log::info!(
                "Updated brand voice id={} name={} for user={}",
                updated_id,
                updated_name,
                ctx.sender
            );
            Ok(())
        } else {
            Err("Brand voice found during scan but missing on update fetch".to_string())
        }
    } else {
        let row = BrandVoices {
            id: 0,
            name,
            description,
            tone,
            sample_text,
            keywords,
            created_at: ctx.timestamp,
            user_id: ctx.sender,
        };
        match ctx.db.brand_voices().try_insert(row) {
            Ok(inserted) => {
                spacetimedb::log::info!(
                    "Created brand voice id={} name={} for user={}",
                    inserted.id,
                    inserted.name,
                    inserted.user_id
                );
                Ok(())
            }
            Err(e) => {
                let msg = format!("Failed to save brand voice: {}", e);
                spacetimedb::log::error!("{}", msg);
                Err(msg)
            }
        }
    }
}

#[reducer]
pub fn get_brand_voices(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!(
        "get_brand_voices called by user={}. Clients should subscribe to brand_voices filtered by user_id.",
        ctx.sender
    );
    Ok(())
}

#[reducer]
pub fn schedule_post(
    ctx: &ReducerContext,
    transformation_id: u64,
    platform: String,
    scheduled_for: Timestamp,
) -> Result<(), String> {
    let row = ScheduledPosts {
        id: 0,
        transformation_id,
        platform,
        scheduled_for,
        status: PostStatus::Pending,
        published_at: None,
        user_id: ctx.sender,
    };
    match ctx.db.scheduled_posts().try_insert(row) {
        Ok(inserted) => {
            spacetimedb::log::info!(
                "Scheduled post id={} for transformation_id={} user={}",
                inserted.id,
                inserted.transformation_id,
                inserted.user_id
            );
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to schedule post: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn get_scheduled_posts(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!(
        "get_scheduled_posts called by user={}. Clients should subscribe to scheduled_posts filtered by user_id.",
        ctx.sender
    );
    Ok(())
}

#[reducer]
pub fn save_analytics(
    ctx: &ReducerContext,
    transformation_id: u64,
    platform: String,
    views: u64,
    likes: u64,
    shares: u64,
    comments: u64,
    engagement_rate: f32,
) -> Result<(), String> {
    let row = Analytics {
        id: 0,
        transformation_id,
        platform,
        views,
        likes,
        shares,
        comments,
        engagement_rate,
        created_at: ctx.timestamp,
    };
    match ctx.db.analytics().try_insert(row) {
        Ok(inserted) => {
            spacetimedb::log::info!(
                "Saved analytics id={} for transformation_id={}",
                inserted.id,
                inserted.transformation_id
            );
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to save analytics: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn get_analytics(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!(
        "get_analytics called by user={}. Clients should subscribe to analytics and filter by transformation_id/platform as needed.",
        ctx.sender
    );
    Ok(())
}

#[reducer]
pub fn save_asset(
    ctx: &ReducerContext,
    url: String,
    name: String,
    prompt: String,
    platform: String,
) -> Result<(), String> {
    let row = AssetLibrary {
        id: 0,
        url,
        name,
        prompt,
        platform,
        created_at: ctx.timestamp,
        user_id: ctx.sender,
    };
    match ctx.db.asset_library().try_insert(row) {
        Ok(inserted) => {
            spacetimedb::log::info!(
                "Saved asset id={} for user={}",
                inserted.id,
                inserted.user_id
            );
            Ok(())
        }
        Err(e) => {
            let msg = format!("Failed to save asset: {}", e);
            spacetimedb::log::error!("{}", msg);
            Err(msg)
        }
    }
}

#[reducer]
pub fn get_assets(ctx: &ReducerContext) -> Result<(), String> {
    spacetimedb::log::info!(
        "get_assets called by user={}. Clients should subscribe to asset_library filtered by user_id.",
        ctx.sender
    );
    Ok(())
}

#[reducer]
pub fn delete_transformation(ctx: &ReducerContext, id: u64) -> Result<(), String> {
    if let Some(row) = ctx.db.content_transformations().id().find(&id) {
        if row.user_id != ctx.sender {
            return Err("Not authorized to delete this transformation".to_string());
        }
        ctx.db.content_transformations().id().delete(&id);
        spacetimedb::log::info!("Deleted transformation id={} by user={}", id, ctx.sender);
        Ok(())
    } else {
        Err("Transformation not found".to_string())
    }
}

#[reducer]
pub fn update_transformation(
    ctx: &ReducerContext,
    id: u64,
    core_text: String,
    platforms: Vec<String>,
    audience_region: String,
    tone: String,
    platform_text: String,
    hashtags: String,
    short_hook: String,
    long_version: String,
) -> Result<(), String> {
    if let Some(mut row) = ctx.db.content_transformations().id().find(&id) {
        if row.user_id != ctx.sender {
            return Err("Not authorized to update this transformation".to_string());
        }

        row.core_text = core_text;
        row.platforms = platforms;
        row.audience_region = audience_region;
        row.tone = tone;
        row.platform_text = platform_text;
        row.hashtags = hashtags;
        row.short_hook = short_hook;
        row.long_version = long_version;

        let updated_id = row.id;
        ctx.db.content_transformations().id().update(row);
        spacetimedb::log::info!("Updated transformation id={} by user={}", updated_id, ctx.sender);
        Ok(())
    } else {
        Err("Transformation not found".to_string())
    }
}