import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { fluxproSubmit, fluxproPollStatus, fluxproFetchImages } from '@/fluxpro-api'

interface GenerateImageRequest {
  prompt: string
  platform?: string
  aspect_ratio?: '21:9' | '16:9' | '4:3' | '3:2' | '1:1' | '2:3' | '3:4' | '9:16' | '9:21'
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: GenerateImageRequest = await request.json()

    const { prompt, platform, aspect_ratio } = body

    if (!prompt || !prompt.trim()) {
      return NextResponse.json(
        { error: 'prompt is required' },
        { status: 400 }
      )
    }

    let aspectRatio = aspect_ratio

    if (!aspectRatio && platform) {
      const platformRatios: Record<string, typeof aspectRatio> = {
        'X': '16:9',
        'Farcaster': '16:9',
        'Instagram': '1:1',
        'TikTok': '9:16',
        'Base': '16:9',
      }
      aspectRatio = platformRatios[platform] || '16:9'
    }

    const requestId = await fluxproSubmit({
      prompt,
      aspect_ratio: aspectRatio || '16:9',
      num_images: 1,
      output_format: 'png',
      safety_tolerance: '3',
    })

    await fluxproPollStatus(requestId)
    const images = await fluxproFetchImages(requestId)

    if (!images || images.length === 0) {
      return NextResponse.json(
        { error: 'No images generated' },
        { status: 500 }
      )
    }

    return NextResponse.json({
      url: images[0].url,
      width: images[0].width,
      height: images[0].height,
    })
  } catch (error) {
    console.error('Error in image generation:', error)
    return NextResponse.json(
      { error: 'Failed to generate image' },
      { status: 500 }
    )
  }
}
