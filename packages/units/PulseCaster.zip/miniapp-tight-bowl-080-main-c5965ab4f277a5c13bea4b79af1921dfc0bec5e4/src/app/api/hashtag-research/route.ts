import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { tenorSearchMemes, tenorFeaturedMemes, tenorMemeSuggestions } from '@/tenor-api'

interface HashtagResearchRequest {
  query?: string
  platform?: string
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: HashtagResearchRequest = await request.json()
    const { query, platform } = body

    if (!query || !query.trim()) {
      const trending = await tenorFeaturedMemes({ limit: 20 })
      const topTags = trending.results.map((meme) => meme.tags).flat()
      const uniqueTags = [...new Set(topTags)].slice(0, 15)
      
      return NextResponse.json({
        hashtags: uniqueTags.map((tag) => `#${tag}`),
        source: 'trending',
      })
    }

    const suggestions = await tenorMemeSuggestions({ q: query, limit: 10 })
    const memes = await tenorSearchMemes({ q: query, limit: 10 })

    const allTags = [
      ...suggestions.results.map((s) => s.toLowerCase()),
      ...memes.results.flatMap((m) => m.tags),
    ]

    const uniqueTags = [...new Set(allTags)].slice(0, 20)

    const platformTags: Record<string, string[]> = {
      'X': ['tech', 'crypto', 'web3', 'builders'],
      'Farcaster': ['onchain', 'culture', 'community', 'vibes'],
      'Instagram': ['aesthetic', 'art', 'design', 'creative'],
      'TikTok': ['fyp', 'viral', 'trending', 'foryou'],
      'Base': ['base', 'onchain', 'builders', 'defi'],
    }

    if (platform && platform in platformTags) {
      const platformSpecific = platformTags[platform as keyof typeof platformTags]
      uniqueTags.push(...platformSpecific)
    }

    const finalTags = [...new Set(uniqueTags)].slice(0, 15)

    return NextResponse.json({
      hashtags: finalTags.map((tag) => `#${tag.replace(/^#/, '')}`),
      source: 'research',
    })
  } catch (error) {
    console.error('Error in hashtag research:', error)
    return NextResponse.json(
      { error: 'Failed to research hashtags' },
      { status: 500 }
    )
  }
}
