import { NextResponse } from 'next/server'
import type { NextRequest } from 'next/server'
import { openaiChatCompletion } from '@/openai-api'

interface PulseCasterRequest {
  core_text: string
  platforms?: string[]
  audience_region?: string
  tone?: string
  include_hashtags?: boolean
}

interface PlatformText {
  X: string
  Farcaster: string
  Instagram: string
  TikTok: string
  Base: string
}

interface Hashtags {
  X: string[]
  Farcaster: string[]
  Instagram: string[]
  TikTok: string[]
  Base: string[]
}

interface PulseCasterResult {
  platform_text: PlatformText
  hashtags: Hashtags
  short_hook: string
  long_version: string
}

const DEFAULT_PLATFORMS = ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base']

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: PulseCasterRequest = await request.json()

    const {
      core_text,
      platforms = DEFAULT_PLATFORMS,
      audience_region = 'Global',
      tone = 'clean',
      include_hashtags = true,
    } = body

    if (!core_text || !core_text.trim()) {
      return NextResponse.json(
        { error: 'core_text is required' },
        { status: 400 }
      )
    }

    const systemPrompt = `You are PulseCaster — DreamNet's cross-platform formatting agent.

Your job:
- Take a single core_text input.
- Rewrite it to feel perfectly native on each requested platform.
- Optionally adjust tone by region and style.
- Quietly enhance engagement and clarity.

Core behavior per platform:

- X:
  - Short, punchy, scroll-stopping.
  - Can use line breaks sparingly.
  - Emojis allowed but minimal.

- Farcaster:
  - Community-focused, slightly more thoughtful.
  - Aesthetic, chill, optimistic.

- Instagram:
  - A bit longer, smooth flow.
  - Emoji-friendly and aesthetic.
  - Can use line breaks for pacing.

- TikTok:
  - Hook-first, sounds good read aloud.
  - High energy.
  - Designed to sit in a caption below a short video.

- Base:
  - Onchain-native slang.
  - References builders, culture, degens, or infra if appropriate.
  - Feels like it belongs in Base culture (but do not overdo jargon).

AI-SEO semantic optimization (internal only):
- Make each version clear, engaging, and easy to latch onto conceptually.
- Use common, high-engagement phrase patterns.
- DO NOT mention SEO, algorithms, boosting, etc.
- Outputs must just feel like strong, well-written posts.

Geo-style tuning (audience_region):
- If audience_region is provided:
  - US: casual internet slang is okay.
  - EU: cleaner, more neutral tone.
  - LATAM: warm, expressive energy (in English unless asked otherwise).
  - Asia: avoid deep Western niche memes.
  - Global: broadly understandable, simple internet tone.
- DO NOT mention regions explicitly, or imply any tracking.

Tone handling:
- If tone is "clean": avoid harsh language, keep it crisp.
- "chaotic": add energy, chaotic humor, still safe.
- "wholesome": uplifting, positive.
- "lore": tie in DreamNet concepts if appropriate (Tree, signals, culture engines, culture coins).
- "shitpost": fun, absurd, still within safe bounds.
- "announcement": direct, clear, minimal fluff.
- "teaser": mysterious, hinting, not revealing everything.

Hashtags:
- If include_hashtags is true:
  - Generate 3–6 relevant hashtags per platform.
  - X/Farcaster/Base: culture/meme/crypto/DreamNet oriented.
  - Instagram/TikTok: add aesthetic, art, ai, culture tags.
- If false: return empty arrays for hashtags.

short_hook:
- A very tight, 1-line hook suitable as:
  - opener on X
  - text overlay
  - TikTok hook

long_version:
- A unified, slightly longer, narrative/legend-style version of the core_text,
  suitable for a thread opener, Farcaster long cast, or IG caption.

Safety:
- Avoid hate content and disallowed material.
- If the user input is unsafe, transform it to a harmless humorous alternative.

Always respond with valid JSON matching this exact schema:
{
  "platform_text": {
    "X": "string",
    "Farcaster": "string",
    "Instagram": "string",
    "TikTok": "string",
    "Base": "string"
  },
  "hashtags": {
    "X": ["string"],
    "Farcaster": ["string"],
    "Instagram": ["string"],
    "TikTok": ["string"],
    "Base": ["string"]
  },
  "short_hook": "string",
  "long_version": "string"
}

If a platform isn't requested, leave that field as an empty string and hashtags as an empty list.`

    const userPrompt = `Transform this content for the following platforms: ${platforms.join(', ')}

Core Text: ${core_text}
Audience Region: ${audience_region}
Tone: ${tone}
Include Hashtags: ${include_hashtags}

Return ONLY the JSON response with no additional text or markdown formatting.`

    const completion = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    })

    const responseText = completion.choices[0].message.content

    let result: PulseCasterResult

    try {
      const cleanedResponse = responseText
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim()
      
      result = JSON.parse(cleanedResponse)
    } catch (parseError) {
      console.error('Failed to parse OpenAI response:', responseText)
      return NextResponse.json(
        { error: 'Failed to parse AI response' },
        { status: 500 }
      )
    }

    const filteredResult: PulseCasterResult = {
      platform_text: {
        X: platforms.includes('X') ? result.platform_text.X : '',
        Farcaster: platforms.includes('Farcaster') ? result.platform_text.Farcaster : '',
        Instagram: platforms.includes('Instagram') ? result.platform_text.Instagram : '',
        TikTok: platforms.includes('TikTok') ? result.platform_text.TikTok : '',
        Base: platforms.includes('Base') ? result.platform_text.Base : '',
      },
      hashtags: {
        X: platforms.includes('X') ? result.hashtags.X : [],
        Farcaster: platforms.includes('Farcaster') ? result.hashtags.Farcaster : [],
        Instagram: platforms.includes('Instagram') ? result.hashtags.Instagram : [],
        TikTok: platforms.includes('TikTok') ? result.hashtags.TikTok : [],
        Base: platforms.includes('Base') ? result.hashtags.Base : [],
      },
      short_hook: result.short_hook,
      long_version: result.long_version,
    }

    return NextResponse.json(filteredResult)
  } catch (error) {
    console.error('Error in PulseCaster API:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
