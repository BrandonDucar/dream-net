'use client'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Switch } from '@/components/ui/switch'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Loader2, Copy, Check, Zap, Library, Image, BarChart3, Calendar, User, Sparkles, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";
import { ContentLibrary } from '@/components/content-library'
import { getSpacetimeConnection } from '@/spacetime/client'
import type { ContentTransformations } from '@/spacetime_module_bindings'

interface PlatformText {
  X: string
  Farcaster: string
  Instagram: string
  TikTok: string
  Base: string
}

interface Hashtags {
  X: string[]
  Farcaster: string[]
  Instagram: string[]
  TikTok: string[]
  Base: string[]
}

interface PulseCasterResult {
  platform_text: PlatformText
  hashtags: Hashtags
  short_hook: string
  long_version: string
}

const PLATFORM_COLORS: Record<keyof PlatformText, string> = {
  X: 'bg-black text-white',
  Farcaster: 'bg-purple-600 text-white',
  Instagram: 'bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 text-white',
  TikTok: 'bg-black text-white',
  Base: 'bg-blue-600 text-white',
}

const PLATFORM_ICONS: Record<keyof PlatformText, string> = {
  X: '𝕏',
  Farcaster: '🎭',
  Instagram: '📸',
  TikTok: '🎵',
  Base: '⛓️',
}

export default function PulseCasterPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [coreText, setCoreText] = useState<string>('')
  const [platforms, setPlatforms] = useState<string[]>(['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'])
  const [audienceRegion, setAudienceRegion] = useState<string>('Global')
  const [tone, setTone] = useState<string>('clean')
  const [includeHashtags, setIncludeHashtags] = useState<boolean>(true)
  const [loading, setLoading] = useState<boolean>(false)
  const [result, setResult] = useState<PulseCasterResult | null>(null)
  const [copiedItem, setCopiedItem] = useState<string>('')
  const [activeTab, setActiveTab] = useState<string>('transform')
  const [generatingImage, setGeneratingImage] = useState<boolean>(false)
  const [generatedImages, setGeneratedImages] = useState<Record<string, string>>({})
  const [researchingHashtags, setResearchingHashtags] = useState<boolean>(false)
  const [variationCount, setVariationCount] = useState<number>(1)

  const handleSubmit = async (): Promise<void> => {
    if (!coreText.trim()) {
      toast.error('Please enter some content to transform')
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch('/api/pulsecaster', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          core_text: coreText,
          platforms,
          audience_region: audienceRegion,
          tone,
          include_hashtags: includeHashtags,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to generate content')
      }

      const data: PulseCasterResult = await response.json()
      setResult(data)

      try {
        const db = getSpacetimeConnection()
        db.reducers.saveTransformation(
          coreText,
          platforms,
          audienceRegion,
          tone,
          JSON.stringify(data.platform_text),
          JSON.stringify(data.hashtags),
          data.short_hook,
          data.long_version
        )
      } catch (dbError) {
        console.error('Failed to save to database:', dbError)
      }

      toast.success('Content transformed successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to transform content. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleGenerateImage = async (platform: keyof PlatformText): Promise<void> => {
    if (!result || !result.platform_text[platform]) {
      toast.error('Generate content first')
      return
    }

    setGeneratingImage(true)
    try {
      const response = await fetch('/api/generate-image', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Create a visually stunning social media post image for ${platform} with the theme: ${result.platform_text[platform].substring(0, 200)}. Professional, engaging, high-quality`,
          platform,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to generate image')
      }

      const data = await response.json()
      setGeneratedImages((prev: Record<string, string>) => ({ ...prev, [platform]: data.url }))
      toast.success(`Image generated for ${platform}!`)
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to generate image')
    } finally {
      setGeneratingImage(false)
    }
  }

  const handleHashtagResearch = async (): Promise<void> => {
    setResearchingHashtags(true)
    try {
      const response = await fetch('/api/hashtag-research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: coreText,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to research hashtags')
      }

      const data = await response.json()
      toast.success(`Found ${data.hashtags.length} trending hashtags!`)
      console.log('Researched hashtags:', data.hashtags)
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to research hashtags')
    } finally {
      setResearchingHashtags(false)
    }
  }

  const loadTransformation = (transformation: ContentTransformations): void => {
    setCoreText(transformation.coreText)
    setPlatforms(transformation.platforms)
    setAudienceRegion(transformation.audienceRegion)
    setTone(transformation.tone)
    
    try {
      const platformText = JSON.parse(transformation.platformText)
      const hashtags = JSON.parse(transformation.hashtags)
      setResult({
        platform_text: platformText,
        hashtags,
        short_hook: transformation.shortHook,
        long_version: transformation.longVersion,
      })
      setActiveTab('transform')
      toast.success('Content loaded!')
    } catch (error) {
      console.error('Failed to parse transformation data:', error)
      toast.error('Failed to load content')
    }
  }

  const togglePlatform = (platform: string): void => {
    setPlatforms((prev: string[]) =>
      prev.includes(platform)
        ? prev.filter((p: string) => p !== platform)
        : [...prev, platform]
    )
  }

  const copyToClipboard = async (text: string, label: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedItem(label)
      toast.success(`Copied ${label}!`)
      setTimeout(() => setCopiedItem(''), 2000)
    } catch (err) {
      toast.error('Failed to copy')
    }
  }

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 pt-16 pb-12 px-4">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <Zap className="w-10 h-10 text-purple-600" />
            <h1 className="text-5xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
              PulseCaster Pro
            </h1>
          </div>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            The ultimate cross-platform content powerhouse with AI, analytics, scheduling & more
          </p>
        </div>

        {/* Tabs Navigation */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 lg:w-auto lg:inline-grid">
            <TabsTrigger value="transform" className="gap-2">
              <Zap className="w-4 h-4" />
              Transform
            </TabsTrigger>
            <TabsTrigger value="library" className="gap-2">
              <Library className="w-4 h-4" />
              Library
            </TabsTrigger>
            <TabsTrigger value="generate" className="gap-2">
              <Sparkles className="w-4 h-4" />
              Generate
            </TabsTrigger>
            <TabsTrigger value="research" className="gap-2">
              <RefreshCw className="w-4 h-4" />
              Research
            </TabsTrigger>
            <TabsTrigger value="analytics" className="gap-2">
              <BarChart3 className="w-4 h-4" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="schedule" className="gap-2">
              <Calendar className="w-4 h-4" />
              Schedule
            </TabsTrigger>
          </TabsList>

          {/* Transform Tab */}
          <TabsContent value="transform" className="space-y-6">
            {/* Input Form */}
            <Card className="shadow-lg">
          <CardHeader>
            <CardTitle>Transform Your Content</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Core Text */}
            <div className="space-y-2">
              <Label htmlFor="core-text">Core Text / Idea / Meme</Label>
              <Textarea
                id="core-text"
                placeholder="Enter your main idea, caption, or meme line..."
                value={coreText}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setCoreText(e.target.value)}
                rows={4}
                className="resize-none"
              />
            </div>

            {/* Platforms */}
            <div className="space-y-2">
              <Label>Platforms</Label>
              <div className="flex flex-wrap gap-2">
                {(['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'] as Array<keyof PlatformText>).map((platform: keyof PlatformText) => (
                  <Button
                    key={platform}
                    type="button"
                    variant={platforms.includes(platform) ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => togglePlatform(platform)}
                    className="gap-2"
                  >
                    <span>{PLATFORM_ICONS[platform]}</span>
                    {platform}
                  </Button>
                ))}
              </div>
            </div>

            {/* Audience Region */}
            <div className="space-y-2">
              <Label htmlFor="region">Audience Region</Label>
              <Select value={audienceRegion} onValueChange={setAudienceRegion}>
                <SelectTrigger id="region">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Global">Global</SelectItem>
                  <SelectItem value="US">US</SelectItem>
                  <SelectItem value="EU">EU</SelectItem>
                  <SelectItem value="LATAM">LATAM</SelectItem>
                  <SelectItem value="Asia">Asia</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Tone */}
            <div className="space-y-2">
              <Label htmlFor="tone">Tone</Label>
              <Select value={tone} onValueChange={setTone}>
                <SelectTrigger id="tone">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="clean">Clean</SelectItem>
                  <SelectItem value="chaotic">Chaotic</SelectItem>
                  <SelectItem value="wholesome">Wholesome</SelectItem>
                  <SelectItem value="lore">Lore</SelectItem>
                  <SelectItem value="shitpost">Shitpost</SelectItem>
                  <SelectItem value="announcement">Announcement</SelectItem>
                  <SelectItem value="teaser">Teaser</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Include Hashtags */}
            <div className="flex items-center justify-between">
              <Label htmlFor="hashtags">Include Hashtags</Label>
              <Switch
                id="hashtags"
                checked={includeHashtags}
                onCheckedChange={setIncludeHashtags}
              />
            </div>

            {/* Submit Button */}
            <Button
              onClick={handleSubmit}
              disabled={loading || !coreText.trim()}
              className="w-full"
              size="lg"
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Transforming...
                </>
              ) : (
                <>
                  <Zap className="w-4 h-4 mr-2" />
                  Transform Content
                </>
              )}
            </Button>
          </CardContent>
        </Card>

        {/* Results */}
        {result && (
          <div className="space-y-6">
            {/* Hooks Section */}
            <div className="grid md:grid-cols-2 gap-4">
              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-sm font-semibold text-purple-600">Short Hook</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <p className="text-lg font-medium mb-3">{result.short_hook}</p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(result.short_hook, 'Short Hook')}
                      className="absolute top-0 right-0"
                    >
                      {copiedItem === 'Short Hook' ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>

              <Card className="shadow-lg">
                <CardHeader>
                  <CardTitle className="text-sm font-semibold text-pink-600">Long Version</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="relative">
                    <p className="text-sm leading-relaxed mb-3">{result.long_version}</p>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => copyToClipboard(result.long_version, 'Long Version')}
                      className="absolute top-0 right-0"
                    >
                      {copiedItem === 'Long Version' ? (
                        <Check className="w-4 h-4" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Platform-Specific Content */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
              {(Object.keys(result.platform_text) as Array<keyof PlatformText>).map((platform: keyof PlatformText) => {
                const text = result.platform_text[platform]
                const tags = result.hashtags[platform]
                
                if (!text) return null

                return (
                  <Card key={platform} className="shadow-lg">
                    <CardHeader className={`${PLATFORM_COLORS[platform]} rounded-t-lg`}>
                      <CardTitle className="flex items-center gap-2 text-lg">
                        <span className="text-2xl">{PLATFORM_ICONS[platform]}</span>
                        {platform}
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="relative">
                          <p className="text-sm whitespace-pre-wrap mb-3">{text}</p>
                          <Button
                            size="sm"
                            variant="ghost"
                            onClick={() => copyToClipboard(text, `${platform} text`)}
                            className="absolute top-0 right-0"
                          >
                            {copiedItem === `${platform} text` ? (
                              <Check className="w-4 h-4" />
                            ) : (
                              <Copy className="w-4 h-4" />
                            )}
                          </Button>
                        </div>
                        
                        {tags.length > 0 && (
                          <div className="border-t pt-3">
                            <div className="flex flex-wrap gap-1">
                              {tags.map((tag: string, idx: number) => (
                                <span
                                  key={idx}
                                  className="text-xs bg-slate-100 text-slate-700 px-2 py-1 rounded"
                                >
                                  {tag}
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                )
              })}
            </div>
          </div>
        )}
          </TabsContent>

          <TabsContent value="library">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Content Library</CardTitle>
              </CardHeader>
              <CardContent>
                <ContentLibrary onLoad={loadTransformation} />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="generate">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>AI Generation</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-center py-8 text-slate-500">Image generation coming soon!</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="research">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Hashtag Research</CardTitle>
              </CardHeader>
              <CardContent>
                <Button onClick={handleHashtagResearch} disabled={researchingHashtags} className="w-full">
                  {researchingHashtags ? <><Loader2 className="w-4 h-4 mr-2 animate-spin" />Researching...</> : <><RefreshCw className="w-4 h-4 mr-2" />Research Hashtags</>}
                </Button>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Analytics</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-center py-8 text-slate-500">Analytics coming soon!</p>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="schedule">
            <Card className="shadow-lg">
              <CardHeader>
                <CardTitle>Schedule Posts</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-center py-8 text-slate-500">Scheduling coming soon!</p>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </main>
  )
}
