'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Trash2, Search, Calendar } from 'lucide-react'
import { getSpacetimeConnection } from '@/spacetime/client'
import type { ContentTransformations } from '@/spacetime_module_bindings'
import { toast } from 'sonner'

interface ContentLibraryProps {
  onLoad: (transformation: ContentTransformations) => void
}

export function ContentLibrary({ onLoad }: ContentLibraryProps): JSX.Element {
  const [transformations, setTransformations] = useState<ContentTransformations[]>([])
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const db = getSpacetimeConnection()
    
    const unsubscribe = db.db.contentTransformations.onInsert((ctx, row) => {
      setTransformations((prev: ContentTransformations[]) => [row, ...prev])
    })

    const unsubscribeDelete = db.db.contentTransformations.onDelete((ctx, row) => {
      setTransformations((prev: ContentTransformations[]) => 
        prev.filter((t) => t.id !== row.id)
      )
    })

    const items = Array.from(db.db.contentTransformations.iter())
    setTransformations(items.sort((a, b) => 
      Number(b.createdAt.micros - a.createdAt.micros)
    ))
    setLoading(false)

    return () => {
      unsubscribe()
      unsubscribeDelete()
    }
  }, [])

  const filteredTransformations = transformations.filter((t: ContentTransformations) =>
    t.coreText.toLowerCase().includes(searchQuery.toLowerCase()) ||
    t.platforms.some((p: string) => p.toLowerCase().includes(searchQuery.toLowerCase())) ||
    t.tone.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleDelete = async (id: bigint): Promise<void> => {
    try {
      const db = getSpacetimeConnection()
      db.reducers.deleteTransformation(id)
      toast.success('Content deleted')
    } catch (error) {
      console.error('Delete error:', error)
      toast.error('Failed to delete content')
    }
  }

  const formatDate = (timestamp: { micros: bigint }): string => {
    const date = new Date(Number(timestamp.micros) / 1000)
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-purple-600"></div>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-400 w-4 h-4" />
        <Input
          placeholder="Search your content..."
          value={searchQuery}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
          className="pl-10"
        />
      </div>

      {filteredTransformations.length === 0 ? (
        <div className="text-center py-12 text-slate-500">
          {searchQuery ? 'No matching content found' : 'No saved content yet. Create your first transformation!'}
        </div>
      ) : (
        <div className="grid gap-4">
          {filteredTransformations.map((transformation: ContentTransformations) => (
            <Card key={String(transformation.id)} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="text-base mb-2">{transformation.coreText}</CardTitle>
                    <div className="flex items-center gap-2 text-sm text-slate-500">
                      <Calendar className="w-3 h-3" />
                      {formatDate(transformation.createdAt)}
                      <span>•</span>
                      <span className="capitalize">{transformation.tone}</span>
                      <span>•</span>
                      <span>{transformation.platforms.length} platforms</span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => onLoad(transformation)}
                    >
                      Load
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDelete(transformation.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="pt-0">
                <div className="flex flex-wrap gap-2">
                  {transformation.platforms.map((platform: string) => (
                    <span
                      key={platform}
                      className="text-xs px-2 py-1 bg-purple-100 text-purple-700 rounded"
                    >
                      {platform}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
