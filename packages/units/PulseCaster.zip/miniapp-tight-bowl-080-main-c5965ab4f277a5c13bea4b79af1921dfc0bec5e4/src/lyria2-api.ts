/**
 * ================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 *
 * FAL Lyria 2 Music Generation API — Strict, Explicit, and Typed Agent Contract
 *
 * ALL USAGE MUST:
 * - Call only via the documented POST/GET endpoints and proxy structure.
 * - Always provide a non-empty prompt.
 * - Use the provided API key as Authorization: Key ...
 * - Strictly poll for status (see `lyria2PollStatus`) and handle all error/edge cases.
 * - Throw/halt on any missing/null required field.
 * - Never change input/output schemas or flow.
 * ================================================================================
 */

export type Lyria2Prompt = {
  /** Music prompt (required, non-empty) */
  prompt: string;
  /** Negative prompt (optional) */
  negative_prompt?: string;
  /** Integer seed (optional) */
  seed?: number;
};

/** Internal request/response types for FAL API */
export type Lyria2SubmitResponse = {
  request_id: string;
};

export type Lyria2StatusResponse =
  | { status: 'IN_QUEUE'; request_id: string; queue_position?: number }
  | { status: 'IN_PROGRESS'; request_id: string }
  | { status: 'COMPLETED'; request_id: string }
  | { status: string; request_id: string; [k: string]: any }; // For error/unknown

export type Lyria2AudioResult = {
  audio: {
    url: string; // CRITICAL: Always check presence, must be valid WAV URL
    content_type?: string;
    file_name?: string;
    file_size?: number;
    file_data?: string;
  };
};

/** Internal: Throws if any required property is missing/null/empty */
function _throwIfInvalid(res: any, keys: string[]) {
  for (const k of keys) {
    if (res == null || res[k] == null || (typeof res[k] === 'string' && !res[k].trim()))
      throw new Error(`Lyria2: Required property "${k}" missing in response.`);
  }
}

/** Internal: All FAL API calls must go through this proxy utility. */
async function _proxyLyria2(options: {
  path: string;
  method?: 'GET' | 'POST';
  body?: any;
}): Promise<any> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: `Key secret_cmbs48sfw0000356ncjyg7qiw`,
  };
  const payload: any = {
    protocol: 'https',
    origin: 'queue.fal.run',
    path: options.path,
    method: options.method || 'POST',
    headers,
  };
  if (options.body) payload.body = JSON.stringify(options.body);
  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  return res.json();
}

/**
 * Submit a new Lyria 2 music generation job.
 * @param input { prompt: string; negative_prompt?: string; seed?: number }
 * @returns request_id (string)
 * @throws if prompt is missing/empty, or request_id missing in response
 */
export async function lyria2Submit(input: Lyria2Prompt): Promise<string> {
  if (!input?.prompt || typeof input.prompt !== 'string' || !input.prompt.trim())
    throw new Error('Prompt is required and must be a non-empty string.');
  const body: any = { prompt: input.prompt };
  if (input.negative_prompt) body.negative_prompt = input.negative_prompt;
  if (typeof input.seed === 'number') body.seed = input.seed;

  const res = await _proxyLyria2({ path: '/fal-ai/lyria2', method: 'POST', body });
  _throwIfInvalid(res, ['request_id']);
  return res.request_id;
}

/**
 * Poll for Lyria 2 job status. Halts on error or unexpected status.
 * Cycles every 5 seconds until status is "COMPLETED" (max 20 min).
 * @param request_id (string)
 * @throws if request_id is missing, or API returns error/missing fields.
 */
export async function lyria2PollStatus(
  request_id: string,
  maxAttempts = 240, // 20 min (5s x 240)
  intervalMs = 5000
): Promise<void> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res: Lyria2StatusResponse = await _proxyLyria2({
      path: `/fal-ai/lyria2/requests/${request_id}/status`,
      method: 'GET',
    });
    _throwIfInvalid(res, ['status', 'request_id']);
    if (res.status === 'COMPLETED') return;
    if (res.status === 'IN_QUEUE' || res.status === 'IN_PROGRESS') {
      // Optional: you may log or display queue position/progress here.
      await new Promise((r) => setTimeout(r, intervalMs));
      attempts++;
      if (attempts > maxAttempts)
        throw new Error('Lyria2: Timeout waiting for music generation');
    } else {
      throw new Error(`Lyria2: Unexpected status "${res.status}" in polling`);
    }
  }
}

/**
 * Fetch Lyria 2 result (audio WAV URL). Always checks presence of valid audio.url.
 * Polls every 5s until present or throws on error/missing data.
 * @param request_id (string)
 * @returns audio.url (string, always .wav)
 * @throws if missing/invalid.
 */
export async function lyria2FetchAudioUrl(
  request_id: string,
  maxAttempts = 240,
  intervalMs = 5000
): Promise<string> {
  if (!request_id || typeof request_id !== 'string')
    throw new Error('Missing request_id');
  let attempts = 0;
  while (true) {
    const res: Lyria2AudioResult = await _proxyLyria2({
      path: `/fal-ai/lyria2/requests/${request_id}`,
      method: 'GET',
    });
    if (res?.audio?.url) return res.audio.url;
    await new Promise((r) => setTimeout(r, intervalMs));
    attempts++;
    if (attempts > maxAttempts)
      throw new Error('Lyria2: Timeout waiting for audio result');
  }
}