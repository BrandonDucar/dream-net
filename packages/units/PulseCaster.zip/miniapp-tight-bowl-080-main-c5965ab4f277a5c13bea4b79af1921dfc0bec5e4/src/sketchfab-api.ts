/**
 * ===================================================================================================
 * DO NOT MODIFY THIS FILE. This file is READ ONLY and is DETERMINISTIC.
 * Sketchfab API Service — Typed, Explicit, and Safe 3D Model Discovery & Download
 * All requests are securely relayed via /api/proxy; no API key is ever exposed client-side.
 *
 * CRITICAL REQUIREMENTS:
 * - All response fields are optional due to API inconsistencies
 * - Download URLs expire after 300 seconds - use immediately
 * - Creative Commons models require proper attribution
 * - Rate limiting applies - implement exponential backoff for production
 * - Large file sizes (10MB+) require proper loading states
 * ===================================================================================================
 */

// ================================================================================================
// SEARCH & DISCOVERY TYPES
// ================================================================================================

export type SketchfabSearchInput = {
  query?: string;
  categories?: string;
  tags?: string;
  downloadable?: boolean;
  license?: 'cc' | 'all';
  count?: number;
  offset?: number;
  sort?: 'relevance' | 'recent' | 'popular' | 'likes';
};

export type SketchfabModelInput = {
  uid: string;
};

export type SketchfabDownloadInput = {
  uid: string;
};

export type SketchfabCollectionsInput = {
  user?: string;
  count?: number;
  offset?: number;
};

// ================================================================================================
// RESPONSE TYPES (ALL OPTIONAL FOR DEFENSIVE PROGRAMMING)
// ================================================================================================

export type SketchfabCategory = {
  name?: string;
  slug?: string;
};

export type SketchfabTag = {
  name?: string;
  slug?: string;
};

export type SketchfabUser = {
  uid?: string;
  username?: string;
  displayName?: string;
  profileUrl?: string;
  avatar?: {
    uri?: string;
  };
};

export type SketchfabLicense = {
  uid?: string;
  label?: string;
  slug?: string;
  url?: string;
  requirements?: string;
};

export type SketchfabCollection = {
  uid?: string;
  name?: string;
  slug?: string;
  description?: string;
  embedUrl?: string;
};

export type SketchfabModel = {
  uid?: string;
  name?: string;
  description?: string;
  embedUrl?: string;
  uri?: string;
  viewerUrl?: string;

  // Metadata
  user?: SketchfabUser;
  license?: SketchfabLicense;
  categories?: SketchfabCategory[];
  tags?: SketchfabTag[];
  collections?: SketchfabCollection[];

  // Statistics
  viewCount?: number;
  likeCount?: number;
  commentCount?: number;
  downloadCount?: number;

  // Media
  thumbnails?: {
    images?: Array<{
      uid?: string;
      url?: string;
      width?: number;
      height?: number;
    }>;
  };

  // Technical
  vertexCount?: number;
  faceCount?: number;
  animationCount?: number;
  materialCount?: number;
  textureCount?: number;

  // Dates
  createdAt?: string;
  publishedAt?: string;

  // Flags
  isDownloadable?: boolean;
  isProtected?: boolean;
  isAgeRestricted?: boolean;

  // Extra metadata
  extras?: Record<string, any>;
};

export type SketchfabSearchResponse = {
  results?:
    | SketchfabModel[]
    | {
        models?: SketchfabModel[];
        users?: SketchfabUser[];
        collections?: SketchfabCollection[];
      };
  next?: string;
  previous?: string;
  count?: number;
  cursors?: {
    next?: string;
    previous?: string;
  };
};

export type SketchfabModelResponse = SketchfabModel;

export type SketchfabDownloadFormat = {
  url?: string;
  size?: number;
  textureWidth?: number;
  textureHeight?: number;
  expires?: number;
};

export type SketchfabDownloadResponse = {
  gltf?: SketchfabDownloadFormat;
  glb?: SketchfabDownloadFormat;
  usdz?: SketchfabDownloadFormat;
  source?: SketchfabDownloadFormat;
};

export type SketchfabCollectionsResponse = {
  results?: SketchfabCollection[];
  next?: string;
  previous?: string;
  count?: number;
};

// ================================================================================================
// PROXY FUNCTION
// ================================================================================================

const BASE_URL = 'api.sketchfab.com';

async function proxySketchfab<T = any>({
  path,
  method = 'GET',
  query = {},
  body,
}: {
  path: string;
  method?: 'GET' | 'POST';
  query?: Record<string, any>;
  body?: any;
}): Promise<T> {
  // Query string handling for GET requests
  const queryString =
    query && Object.keys(query).length
      ? '?' + new URLSearchParams(query).toString()
      : '';

  const payload = {
    protocol: 'https',
    origin: BASE_URL,
    path: path + queryString,
    method,
    headers: {
      accept: 'application/json',
      authorization: `Token secret_cmcvlbiho00002v6lkh2r2mrq`,
      'content-type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  };

  const res = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  try {
    const result = await res.json();

    // Handle API error responses
    if (result?.error) {
      console.warn('Sketchfab API error:', result.error);
      return {} as T;
    }

    return result && typeof result === 'object' ? result : ({} as T);
  } catch (error) {
    console.warn('Sketchfab API response parsing failed:', error);
    return {} as T;
  }
}

// ================================================================================================
// CORE FUNCTIONS
// ================================================================================================

/**
 * Search for 3D models on Sketchfab with comprehensive filtering options.
 * Supports text search, category filtering, license filtering, and pagination.
 *
 * CRITICAL: Always provides query parameter to avoid "Empty search" API error.
 * Uses wildcard "*" for popular models when no specific query provided.
 *
 * IMPLEMENTATION CRITICAL: Empty results (results: []) require state-aware UI handling:
 * - Initial load: "Enter a search term to discover 3D models"
 * - After search: "No models found. Try different search terms"
 * MUST track hasSearched state to display correct message.
 *
 * @param input - Search parameters including query, categories, tags, and filters
 * @returns Promise<SketchfabSearchResponse> - Search results with models and pagination
 */
export async function sketchfabSearch(
  input: SketchfabSearchInput = {}
): Promise<SketchfabSearchResponse> {
  const query: Record<string, any> = {};

  // Build query parameters
  // CRITICAL: Always provide query parameter to avoid "Empty search" error
  if (input.query) {
    query.q = input.query;
  } else {
    // Use wildcard for popular models when no specific query provided
    query.q = '*';
  }

  if (input.categories) query.categories = input.categories;
  if (input.tags) query.tags = input.tags;
  if (input.downloadable !== undefined) query.downloadable = input.downloadable;
  if (input.count) query.count = Math.min(input.count, 100); // API limit
  if (input.offset) query.offset = input.offset;
  if (input.sort) query.sort_by = input.sort;

  // Default to downloadable Creative Commons models
  if (query.downloadable === undefined) query.downloadable = true;

  const result = await proxySketchfab<SketchfabSearchResponse>({
    path: '/v3/search',
    method: 'GET',
    query,
  });

  // Handle the actual Sketchfab API response structure
  // API returns: { results: { models: [], users: [], collections: [] } }
  // We need to extract the models array
  let models: SketchfabModel[] = [];

  if (result?.results) {
    if (Array.isArray(result.results)) {
      // Direct array format (legacy or different endpoint)
      models = result.results;
    } else if (result.results.models && Array.isArray(result.results.models)) {
      // Nested format with models/users/collections (current API format)
      models = result.results.models;
    }
  }

  // Apply client-side Creative Commons filtering if requested
  if (input.license === 'cc' && models.length > 0) {
    models = models.filter(model => isCreativeCommonsModel(model));
  }

  return {
    results: models,
    // Preserve pagination info if available
    next: result?.next,
    previous: result?.previous,
    count: result?.count,
  };
}

/**
 * Get detailed information about a specific 3D model by its UID.
 *
 * @param input - Model identifier with UID
 * @returns Promise<SketchfabModelResponse> - Complete model information
 */
export async function sketchfabGetModelInfo(
  input: SketchfabModelInput
): Promise<SketchfabModelResponse> {
  if (!input?.uid) {
    console.warn('sketchfabGetModelInfo: uid is required');
    return {};
  }

  const result = await proxySketchfab<SketchfabModelResponse>({
    path: `/v3/models/${input.uid}`,
    method: 'GET',
  });

  return result || {};
}

/**
 * Get download URLs for a 3D model in various formats (glTF, GLB, USDZ).
 * CRITICAL: Download URLs expire after 300 seconds - use immediately!
 *
 * @param input - Model identifier with UID
 * @returns Promise<SketchfabDownloadResponse> - Download URLs and metadata
 */
export async function sketchfabDownloadModel(
  input: SketchfabDownloadInput
): Promise<SketchfabDownloadResponse> {
  if (!input?.uid) {
    console.warn('sketchfabDownloadModel: uid is required');
    return {};
  }

  const result = await proxySketchfab<SketchfabDownloadResponse>({
    path: `/v3/models/${input.uid}/download`,
    method: 'GET',
  });

  return result || {};
}

/**
 * Get collections from a specific user or public collections.
 *
 * @param input - Collection search parameters
 * @returns Promise<SketchfabCollectionsResponse> - User collections
 */
export async function sketchfabGetCollections(
  input: SketchfabCollectionsInput = {}
): Promise<SketchfabCollectionsResponse> {
  const query: Record<string, any> = {};

  if (input.count) query.count = Math.min(input.count, 100);
  if (input.offset) query.offset = input.offset;

  const path = input.user
    ? `/v3/users/${input.user}/collections`
    : '/v3/collections';

  const result = await proxySketchfab<SketchfabCollectionsResponse>({
    path,
    method: 'GET',
    query,
  });

  return result || { results: [] };
}

/**
 * Convenience function that combines search and model info retrieval.
 * Returns the first model found with complete information.
 *
 * @param input - Search parameters
 * @returns Promise<SketchfabModelResponse> - First model with complete info
 */
export async function sketchfabGetModel(
  input: SketchfabSearchInput
): Promise<SketchfabModelResponse> {
  const searchResults = await sketchfabSearch({ ...input, count: 1 });

  if (
    !searchResults.results ||
    !Array.isArray(searchResults.results) ||
    searchResults.results.length === 0
  ) {
    return {};
  }

  const firstModel = searchResults.results[0];
  if (!firstModel.uid) {
    return firstModel;
  }

  // Get complete model information
  return sketchfabGetModelInfo({ uid: firstModel.uid });
}

// ================================================================================================
// UTILITY FUNCTIONS
// ================================================================================================

/**
 * Helper function to map Sketchfab models to Duke's Asset interface.
 * Enables seamless integration with existing 3D Environment Loader.
 *
 * @param model - Sketchfab model object
 * @returns Asset - Duke-compatible asset object
 */
export function mapSketchfabToAsset(model: SketchfabModel): {
  category: string;
  name: string;
  url: string;
  pack?: string;
  tags?: string[];
} {
  return {
    category: model.categories?.[0]?.name || 'Unknown',
    name: model.name || 'Unnamed Model',
    url: model.uid || '',
    pack: model.collections?.[0]?.name,
    tags:
      model.tags
        ?.map(tag => tag.name)
        .filter((name): name is string => Boolean(name)) || [],
  };
}

/**
 * Helper function to extract proper Creative Commons attribution text.
 * Use this to display required attribution for downloaded models.
 *
 * @param model - Sketchfab model object
 * @returns string - Attribution text
 */
export function getSketchfabAttribution(model: SketchfabModel): string {
  const title = model.name || 'Unnamed Model';
  const author = model.user?.displayName || 'Unknown Author';
  const license = model.license?.label || 'Unknown License';
  const url = model.viewerUrl || '';

  return `"${title}" by ${author} (${license}) ${url}`;
}

/**
 * Helper function to check if a model is downloadable and has proper licensing.
 *
 * @param model - Sketchfab model object
 * @returns boolean - Whether model can be safely downloaded
 */
export function isSketchfabModelDownloadable(model: SketchfabModel): boolean {
  return Boolean(
    model.isDownloadable &&
      model.license?.slug &&
      !model.isProtected &&
      !model.isAgeRestricted
  );
}

/**
 * Helper function to check if a model has a Creative Commons license.
 * Used for client-side filtering since API license parameter is problematic.
 *
 * CRITICAL: Checks both licenseSlug AND licenseLabel since API often returns
 * licenseSlug: undefined while licenseLabel contains valid CC information.
 *
 * @param model - Sketchfab model object
 * @returns boolean - Whether model has Creative Commons license
 */
function isCreativeCommonsModel(model: SketchfabModel): boolean {
  const license = model.license;
  if (!license) return false;

  // Check both slug and label since slug is often undefined
  const slug = license.slug?.toLowerCase() || '';
  const label = license.label?.toLowerCase() || '';

  // Comprehensive CC keywords matching
  const ccKeywords = [
    'cc',
    'creative',
    'commons',
    'attribution',
    'by',
    'sa',
    'nc',
    'nd',
  ];

  return ccKeywords.some(
    keyword => slug.includes(keyword) || label.includes(keyword)
  );
}
