import { DbConnection } from '@/spacetime_module_bindings'

let dbConnection: DbConnection | null = null

export function getSpacetimeConnection(): DbConnection {
  if (!dbConnection) {
    dbConnection = DbConnection.builder()
      .withUri('wss://pulsecaster.spacetimedb.com')
      .withModuleName('pulsecaster')
      .onConnect(() => {
        console.log('Connected to SpacetimeDB')
      })
      .onConnectError((error: Error) => {
        console.error('SpacetimeDB connection error:', error)
      })
      .build()
  }
  return dbConnection
}
