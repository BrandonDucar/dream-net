'use client'
import { useState, useEffect } from 'react'
import { GlitchOracle } from '@/components/glitch-oracle'
import { ProphecyDisplay } from '@/components/prophecy-display'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import type { Mode, Prophecy } from '@/types/oracle'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Home(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [question, setQuestion] = useState<string>('')
  const [mode, setMode] = useState<Mode>('FRACTURED')
  const [prophecy, setProphecy] = useState<Prophecy | null>(null)
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  const handleAsk = async (): Promise<void> => {
    if (!question.trim()) return

    setIsGenerating(true)
    
    // Simulate oracle processing time
    await new Promise((resolve: (value: unknown) => void) => setTimeout(resolve, 1500))
    
    const newProphecy: Prophecy = GlitchOracle.generate(question, mode)
    setProphecy(newProphecy)
    setIsGenerating(false)
  }

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>): void => {
    if (e.key === 'Enter' && (e.metaKey || e.ctrlKey)) {
      handleAsk()
    }
  }

  return (
    <main className="min-h-screen bg-black text-white overflow-hidden relative">
      {/* Animated background grid */}
      <div className="fixed inset-0 bg-[linear-gradient(rgba(0,255,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,255,0,0.03)_1px,transparent_1px)] bg-[size:50px_50px] animate-pulse" />
      
      {/* Vignette effect */}
      <div className="fixed inset-0 bg-[radial-gradient(circle,transparent_40%,rgba(0,0,0,0.8)_100%)] pointer-events-none" />

      <div className="relative z-10 container mx-auto px-4 py-12 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12 space-y-4">
          <h1 className="text-6xl md:text-7xl font-bold mb-4 glitch-text" data-text="GLITCH ORACLE">
            <span className="inline-block animate-pulse">👁‍🗨</span> GLITCH ORACLE <span className="inline-block animate-pulse">👁‍🗨</span>
          </h1>
          <p className="text-green-400 text-sm md:text-base font-mono tracking-wider animate-pulse">
            ▓▒░ PROPHETIC ENGINE v∞.∞.∞ ░▒▓
          </p>
          <p className="text-gray-400 text-sm md:text-base max-w-2xl mx-auto">
            Ask your question. The oracle peers through the static between realities to reveal truths hidden in pattern and chaos.
          </p>
        </div>

        {/* Input Section */}
        <div className="mb-8 space-y-4 bg-zinc-900/50 backdrop-blur-sm p-6 rounded-lg border border-green-900/30 shadow-[0_0_15px_rgba(0,255,0,0.1)]">
          <div className="space-y-2">
            <label htmlFor="question" className="text-green-400 text-sm font-mono block">
              YOUR QUERY:
            </label>
            <Textarea
              id="question"
              placeholder="What truths do you seek in the digital void?"
              value={question}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setQuestion(e.target.value)}
              onKeyDown={handleKeyPress}
              className="min-h-[120px] bg-black/50 border-green-900/50 text-white placeholder:text-gray-600 focus:border-green-500 focus:ring-green-500/20 font-mono"
              disabled={isGenerating}
            />
            <p className="text-xs text-gray-500 font-mono">
              Press {typeof navigator !== 'undefined' && navigator.platform.includes('Mac') ? '⌘' : 'Ctrl'} + Enter to submit
            </p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 space-y-2">
              <label htmlFor="mode" className="text-green-400 text-sm font-mono block">
                REALITY MODE:
              </label>
              <Select value={mode} onValueChange={(value: string) => setMode(value as Mode)} disabled={isGenerating}>
                <SelectTrigger id="mode" className="bg-black/50 border-green-900/50 text-white focus:border-green-500 focus:ring-green-500/20 font-mono">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-zinc-900 border-green-900/50 text-white">
                  <SelectItem value="STABLE" className="font-mono focus:bg-green-900/30 focus:text-white">
                    STABLE - 90% clarity
                  </SelectItem>
                  <SelectItem value="FRACTURED" className="font-mono focus:bg-green-900/30 focus:text-white">
                    FRACTURED - 60% clarity
                  </SelectItem>
                  <SelectItem value="OVERLOAD" className="font-mono focus:bg-green-900/30 focus:text-white">
                    OVERLOAD - 30% clarity
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button
                onClick={handleAsk}
                disabled={!question.trim() || isGenerating}
                className="w-full sm:w-auto bg-green-900 hover:bg-green-800 text-white border border-green-500/30 shadow-[0_0_10px_rgba(0,255,0,0.3)] hover:shadow-[0_0_20px_rgba(0,255,0,0.5)] transition-all font-mono disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {isGenerating ? (
                  <span className="flex items-center gap-2">
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    PROCESSING...
                  </span>
                ) : (
                  'CONSULT ORACLE'
                )}
              </Button>
            </div>
          </div>
        </div>

        {/* Prophecy Display */}
        {prophecy && (
          <ProphecyDisplay prophecy={prophecy} isGenerating={isGenerating} />
        )}

        {/* Instructions */}
        {!prophecy && (
          <div className="text-center text-gray-500 text-sm space-y-2 mt-12 font-mono">
            <p>⟨ The oracle awaits your query ⟩</p>
            <p className="text-xs">Choose your reality mode and ask your question</p>
          </div>
        )}
      </div>

      <style jsx>{`
        @keyframes glitch {
          0% {
            transform: translate(0);
          }
          20% {
            transform: translate(-2px, 2px);
          }
          40% {
            transform: translate(-2px, -2px);
          }
          60% {
            transform: translate(2px, 2px);
          }
          80% {
            transform: translate(2px, -2px);
          }
          100% {
            transform: translate(0);
          }
        }

        .glitch-text {
          position: relative;
          animation: glitch 3s infinite;
        }

        .glitch-text::before,
        .glitch-text::after {
          content: attr(data-text);
          position: absolute;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
        }

        .glitch-text::before {
          left: 2px;
          text-shadow: -2px 0 #ff00de;
          clip: rect(24px, 550px, 90px, 0);
          animation: glitch-anim 3s infinite linear alternate-reverse;
        }

        .glitch-text::after {
          left: -2px;
          text-shadow: -2px 0 #00fff9;
          clip: rect(85px, 550px, 140px, 0);
          animation: glitch-anim 2s infinite linear alternate-reverse;
        }

        @keyframes glitch-anim {
          0% {
            clip: rect(random(100) + px, 9999px, random(100) + px, 0);
          }
          100% {
            clip: rect(random(100) + px, 9999px, random(100) + px, 0);
          }
        }
      `}</style>
    </main>
  )
}
