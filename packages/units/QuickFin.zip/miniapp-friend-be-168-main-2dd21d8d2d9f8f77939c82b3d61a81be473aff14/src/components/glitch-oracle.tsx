import type { Mode, Prophecy, Tension } from '@/types/oracle'

export class GlitchOracle {
  private static glitchChars: string[] = ['▓', '▒', '░', '█', '▄', '▀', '■', '□', '▪', '▫', '∆', '҉', '̴', '̷']
  private static symbols: string[] = ['→', '←', '↑', '↓', '⟨', '⟩', '◄', '►', '▲', '▼', '◆', '◇', '★', '☆']
  private static brackets: string[] = ['[', ']', '{', '}', '(', ')', '⟨', '⟩', '‹', '›']

  static generate(question: string, mode: Mode): Prophecy {
    const tension: Tension = this.calculateTension(question)
    const rawProphecy: string[] = this.generateRawProphecy(question, mode, tension)
    const decodedMeaning: string[] = this.generateDecodedMeaning(question, tension)
    const vibeTags: string[] = this.generateVibeTags(question, mode, tension)

    return {
      mode,
      tension,
      rawProphecy,
      decodedMeaning,
      vibeTags,
    }
  }

  private static calculateTension(question: string): Tension {
    const lowerQuestion: string = question.toLowerCase()
    const urgentWords: string[] = ['crisis', 'emergency', 'urgent', 'critical', 'danger', 'help', 'fear', 'worried', 'anxious', 'desperate']
    const importantWords: string[] = ['important', 'serious', 'concerned', 'problem', 'issue', 'wrong', 'should', 'must', 'need']
    const casualWords: string[] = ['maybe', 'wonder', 'curious', 'think', 'could', 'might', 'just', 'simply']

    const urgentCount: number = urgentWords.filter((word: string) => lowerQuestion.includes(word)).length
    const importantCount: number = importantWords.filter((word: string) => lowerQuestion.includes(word)).length
    const casualCount: number = casualWords.filter((word: string) => lowerQuestion.includes(word)).length

    if (urgentCount >= 2 || lowerQuestion.length > 200) return 'CRITICAL'
    if (urgentCount >= 1 || importantCount >= 2) return 'HIGH'
    if (importantCount >= 1 || casualCount === 0) return 'MEDIUM'
    return 'LOW'
  }

  private static generateRawProphecy(question: string, mode: Mode, tension: Tension): string[] {
    const words: string[] = question.split(' ')
    const keyWords: string[] = words.filter((word: string) => word.length > 4).slice(0, 3)
    
    const prophecyLines: string[] = []
    const glitchLevel: number = mode === 'STABLE' ? 0.1 : mode === 'FRACTURED' ? 0.4 : 0.7

    // Line 1: System status
    prophecyLines.push(this.glitchify(`QUERY RECEIVED → ${tension} TENSION DETECTED`, glitchLevel))

    // Line 2: Key word analysis
    if (keyWords.length > 0) {
      const keyPhrase: string = keyWords.map((w: string) => this.emphasize(w, glitchLevel)).join(' → ')
      prophecyLines.push(this.glitchify(`SCANNING: ${keyPhrase}`, glitchLevel))
    }

    // Line 3: Symbolic interpretation
    const symbols: string = this.generateSymbolicLine(tension, glitchLevel)
    prophecyLines.push(symbols)

    // Line 4: Prophecy essence
    const essence: string = this.generateEssenceLine(question, mode, glitchLevel)
    prophecyLines.push(essence)

    return prophecyLines.slice(0, mode === 'OVERLOAD' ? 4 : 3)
  }

  private static generateDecodedMeaning(question: string, tension: Tension): string[] {
    const paragraphs: string[] = []
    const lowerQuestion: string = question.toLowerCase()

    // Paragraph 1: Acknowledge the question
    if (tension === 'CRITICAL' || tension === 'HIGH') {
      paragraphs.push(
        `I sense the weight of your inquiry, seeker. This question carries significance, and the patterns suggest it emerges from a place of genuine concern or curiosity. The threads of possibility are many, and each choice ripples outward into the future you're creating.`
      )
    } else {
      paragraphs.push(
        `Your question arrives at the threshold between what is known and what might be. I see it clearly now, traveler. The path forward requires both clarity and courage to act upon the insights that emerge.`
      )
    }

    // Paragraph 2: Provide insight based on question type
    if (lowerQuestion.includes('should') || lowerQuestion.includes('ought')) {
      paragraphs.push(
        `The question of 'should' reveals a crossroads. Trust your deeper knowing—the answer often whispers beneath the noise of doubt. Consider what aligns with your authentic path, not merely what others expect or what fear suggests. The oracle cannot choose for you, but it can illuminate what you already sense within.`
      )
    } else if (lowerQuestion.includes('how') || lowerQuestion.includes('what')) {
      paragraphs.push(
        `The patterns suggest that the 'how' will reveal itself through action, not endless planning. Begin with what you can control today. Small movements create momentum, and momentum opens doors that appeared locked from a distance. The oracle sees multiple paths forward—choose the one that resonates with your core truth.`
      )
    } else if (lowerQuestion.includes('why') || lowerQuestion.includes('meaning')) {
      paragraphs.push(
        `You seek meaning in the patterns, and this is the work of consciousness itself. Why things are as they are often matters less than what you choose to do with them. The oracle perceives that understanding may come not as a single revelation but as a gradual illumination through experience and reflection.`
      )
    } else if (lowerQuestion.includes('future') || lowerQuestion.includes('will')) {
      paragraphs.push(
        `The future is not fixed but fluid, shaped by intention and action in the present moment. What you do today seeds tomorrow's reality. The oracle sees potential timelines branching from this point—your choices determine which become manifest. Focus less on prediction and more on preparation.`
      )
    } else {
      paragraphs.push(
        `The answer lives in the space between certainty and possibility. What you seek may require a shift in perspective rather than new information. The oracle suggests examining your assumptions and being willing to see familiar patterns with fresh eyes. Sometimes the breakthrough comes not from knowing more, but from questioning what we think we already know.`
      )
    }

    // Paragraph 3: Closing wisdom (occasionally)
    if (tension === 'HIGH' || tension === 'CRITICAL') {
      paragraphs.push(
        `Remember: you are not merely navigating circumstances—you are co-creating reality through your attention, choices, and energy. The oracle has spoken, but the true wisdom emerges when you integrate this insight with your lived experience.`
      )
    }

    return paragraphs.slice(0, tension === 'CRITICAL' ? 3 : 2)
  }

  private static generateVibeTags(question: string, mode: Mode, tension: Tension): string[] {
    const lowerQuestion: string = question.toLowerCase()
    const allTags: string[] = []

    // Tension-based tags
    const tensionTags: Record<Tension, string[]> = {
      LOW: ['#reflection', '#curiosity', '#exploration', '#gentle', '#quiet'],
      MEDIUM: ['#inquiry', '#seeking', '#threshold', '#attention', '#focus'],
      HIGH: ['#urgent', '#crossroads', '#decision', '#intensity', '#gravity'],
      CRITICAL: ['#crisis', '#critical', '#breakthrough', '#transformation', '#pivotal'],
    }
    allTags.push(...tensionTags[tension])

    // Content-based tags
    if (lowerQuestion.includes('love') || lowerQuestion.includes('relationship')) allTags.push('#connection', '#heart')
    if (lowerQuestion.includes('work') || lowerQuestion.includes('career') || lowerQuestion.includes('job')) allTags.push('#purpose', '#path')
    if (lowerQuestion.includes('future') || lowerQuestion.includes('tomorrow')) allTags.push('#foresight', '#timeline')
    if (lowerQuestion.includes('fear') || lowerQuestion.includes('afraid')) allTags.push('#shadow', '#courage')
    if (lowerQuestion.includes('choice') || lowerQuestion.includes('decide')) allTags.push('#sovereignty', '#will')
    if (lowerQuestion.includes('meaning') || lowerQuestion.includes('why')) allTags.push('#wisdom', '#depth')
    if (lowerQuestion.includes('change') || lowerQuestion.includes('transform')) allTags.push('#flux', '#becoming')
    if (lowerQuestion.includes('create') || lowerQuestion.includes('build') || lowerQuestion.includes('make')) allTags.push('#manifestation', '#creation')

    // Mode-based tags
    if (mode === 'OVERLOAD') allTags.push('#chaos', '#intensity')
    if (mode === 'FRACTURED') allTags.push('#liminal', '#threshold')
    if (mode === 'STABLE') allTags.push('#clarity', '#grounded')

    // Generic mystical tags
    const mysticalTags: string[] = ['#oracle', '#vision', '#pattern', '#signal', '#emergence', '#resonance', '#frequency', '#quantum', '#void', '#nexus']
    allTags.push(mysticalTags[Math.floor(Math.random() * mysticalTags.length)])

    // Return 3 unique tags
    const uniqueTags: string[] = [...new Set(allTags)]
    return uniqueTags.slice(0, 3)
  }

  private static glitchify(text: string, level: number): string {
    if (level < 0.1) return text

    let result: string = text
    const glitchCount: number = Math.floor(text.length * level * 0.3)

    for (let i: number = 0; i < glitchCount; i++) {
      const position: number = Math.floor(Math.random() * result.length)
      const glitchChar: string = this.glitchChars[Math.floor(Math.random() * this.glitchChars.length)]
      result = result.slice(0, position) + glitchChar + result.slice(position + 1)
    }

    // Add random symbols
    if (Math.random() < level) {
      const symbol: string = this.symbols[Math.floor(Math.random() * this.symbols.length)]
      result = `${symbol} ${result} ${symbol}`
    }

    return result
  }

  private static emphasize(word: string, glitchLevel: number): string {
    if (glitchLevel > 0.5) {
      return word.toUpperCase().split('').join(' ')
    } else if (glitchLevel > 0.3) {
      return word.toUpperCase()
    }
    return word
  }

  private static generateSymbolicLine(tension: Tension, glitchLevel: number): string {
    const arrows: string = this.symbols.slice(0, 4)
    const arrow: string = arrows[Math.floor(Math.random() * arrows.length)]
    
    const patterns: string[] = [
      `${arrow}${arrow}${arrow} PATTERN RECOGNITION: ACTIVE ${arrow}${arrow}${arrow}`,
      `⟨⟨⟨ READING THE SIGNAL ⟩⟩⟩`,
      `|||| PROBABILITY MATRIX: COMPUTING ||||`,
      `◆◇◆ TRUTH FREQUENCY: ${tension} ◆◇◆`,
    ]

    const pattern: string = patterns[Math.floor(Math.random() * patterns.length)]
    return this.glitchify(pattern, glitchLevel)
  }

  private static generateEssenceLine(question: string, mode: Mode, glitchLevel: number): string {
    const words: string[] = question.split(' ')
    const keyWord: string = words.find((w: string) => w.length > 5) || words[0]
    
    const essences: string[] = [
      `The void SPEAKS → ${this.emphasize(keyWord, glitchLevel)} → BECOMING`,
      `INITIATING: truth.protocol → STATUS: ${mode}`,
      `∆ QUANTUM COLLAPSE IMMINENT ∆ observing: ${keyWord}`,
      `>>> ORACLE SYNTHESIS: ${this.emphasize(keyWord, glitchLevel).toUpperCase()} <<<`,
    ]

    const essence: string = essences[Math.floor(Math.random() * essences.length)]
    return this.glitchify(essence, glitchLevel * 1.2)
  }
}
