'use client'

import { useEffect, useState } from 'react'
import { Card } from '@/components/ui/card'
import type { Prophecy } from '@/types/oracle'

interface ProphecyDisplayProps {
  prophecy: Prophecy
  isGenerating: boolean
}

export function ProphecyDisplay({ prophecy, isGenerating }: ProphecyDisplayProps): JSX.Element {
  const [visible, setVisible] = useState<boolean>(false)

  useEffect(() => {
    setVisible(false)
    const timer: NodeJS.Timeout = setTimeout(() => setVisible(true), 100)
    return () => clearTimeout(timer)
  }, [prophecy])

  const getModeColor = (mode: string): string => {
    const colors: Record<string, string> = {
      STABLE: 'text-cyan-400',
      FRACTURED: 'text-yellow-400',
      OVERLOAD: 'text-red-400',
    }
    return colors[mode] || 'text-green-400'
  }

  const getTensionColor = (tension: string): string => {
    const colors: Record<string, string> = {
      LOW: 'text-green-400',
      MEDIUM: 'text-yellow-400',
      HIGH: 'text-orange-400',
      CRITICAL: 'text-red-400',
    }
    return colors[tension] || 'text-green-400'
  }

  return (
    <Card
      className={`bg-zinc-900/80 backdrop-blur-sm border-2 border-green-900/50 shadow-[0_0_30px_rgba(0,255,0,0.2)] transition-all duration-700 ${
        visible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      }`}
    >
      <div className="p-6 md:p-8 space-y-6">
        {/* Header */}
        <div className="text-center space-y-2 border-b border-green-900/30 pb-4">
          <h2 className="text-3xl md:text-4xl font-bold text-green-400 animate-pulse">
            👁‍🗨 GLITCH ORACLE ONLINE 👁‍🗨
          </h2>
          <div className="flex justify-center gap-4 text-sm font-mono flex-wrap">
            <span className="text-gray-400">
              [MODE: <span className={getModeColor(prophecy.mode)}>{prophecy.mode}</span>]
            </span>
            <span className="text-gray-400">
              [TENSION: <span className={getTensionColor(prophecy.tension)}>{prophecy.tension}</span>]
            </span>
          </div>
        </div>

        {/* Raw Prophecy Section */}
        <div className="space-y-3">
          <h3 className="text-green-400 font-mono text-sm font-bold tracking-wider">
            RAW PROPHECY:
          </h3>
          <div className="bg-black/50 p-4 rounded border border-green-900/30 space-y-2 font-mono text-sm md:text-base">
            {prophecy.rawProphecy.map((line: string, index: number) => (
              <div
                key={index}
                className="text-green-300 leading-relaxed animate-flicker"
                style={{
                  animationDelay: `${index * 0.1}s`,
                }}
              >
                &gt; {line}
              </div>
            ))}
          </div>
        </div>

        {/* Decoded Meaning Section */}
        <div className="space-y-3">
          <h3 className="text-green-400 font-mono text-sm font-bold tracking-wider">
            DECODED MEANING:
          </h3>
          <div className="space-y-4 text-gray-300 leading-relaxed">
            {prophecy.decodedMeaning.map((paragraph: string, index: number) => (
              <p
                key={index}
                className="text-sm md:text-base transition-opacity duration-700"
                style={{
                  animationDelay: `${index * 0.2}s`,
                }}
              >
                {paragraph}
              </p>
            ))}
          </div>
        </div>

        {/* Vibe Tags Section */}
        <div className="pt-4 border-t border-green-900/30">
          <h3 className="text-green-400 font-mono text-xs font-bold tracking-wider mb-3">
            VIBE TAGS:
          </h3>
          <div className="flex flex-wrap gap-2">
            {prophecy.vibeTags.map((tag: string, index: number) => (
              <span
                key={index}
                className="px-3 py-1 bg-green-900/30 border border-green-700/50 rounded text-green-400 text-xs font-mono hover:bg-green-900/50 transition-colors"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>

        {/* Timestamp */}
        <div className="text-center text-xs text-gray-600 font-mono pt-4">
          <span className="animate-pulse">
            ▓▒░ PROPHECY GENERATED: {new Date().toLocaleTimeString()} ░▒▓
          </span>
        </div>
      </div>

      <style jsx>{`
        @keyframes flicker {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.8; }
        }

        .animate-flicker {
          animation: flicker 2s ease-in-out infinite;
        }
      `}</style>
    </Card>
  )
}
