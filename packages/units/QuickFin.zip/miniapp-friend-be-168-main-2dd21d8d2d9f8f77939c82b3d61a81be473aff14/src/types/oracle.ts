export type Mode = 'STABLE' | 'FRACTURED' | 'OVERLOAD'

export type Tension = 'LOW' | 'MEDIUM' | 'HIGH' | 'CRITICAL'

export interface Prophecy {
  mode: Mode
  tension: Tension
  rawProphecy: string[]
  decodedMeaning: string[]
  vibeTags: string[]
}
