'use client'

import type { ReactElement } from 'react'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { ScanVisualization } from '@/components/scan-visualization'

type Shape = 'winged' | 'four-legged' | 'human' | ''
type Distance = 'close' | 'midfield' | 'far' | ''
type Pattern = 'left-right' | 'grid' | ''

interface SightLog {
  id: string
  shape: string
  distance: string
  notes: string
  timestamp: string
}

export function DreamSight(): ReactElement {
  const [shape, setShape] = useState<Shape>('')
  const [distance, setDistance] = useState<Distance>('')
  const [sightNotes, setSightNotes] = useState<string>('')
  const [sightLogs, setSightLogs] = useState<SightLog[]>([])

  const [pattern, setPattern] = useState<Pattern>('')
  const [patternActive, setPatternActive] = useState<boolean>(false)
  const [currentStep, setCurrentStep] = useState<number>(0)

  // Load sight logs from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('dreamlongview-sights')
    if (stored) {
      try {
        setSightLogs(JSON.parse(stored))
      } catch (e) {
        console.error('Failed to parse sight logs', e)
      }
    }
  }, [])

  // Save sight logs to localStorage whenever they change
  useEffect(() => {
    if (sightLogs.length > 0) {
      localStorage.setItem('dreamlongview-sights', JSON.stringify(sightLogs))
    }
  }, [sightLogs])

  const shapeLabels: Record<Exclude<Shape, ''>, string> = {
    'winged': 'Winged Shape',
    'four-legged': 'Four-Legged Form',
    'human': 'Human Presence'
  }

  const distanceLabels: Record<Exclude<Distance, ''>, string> = {
    'close': 'Close',
    'midfield': 'Midfield',
    'far': 'Far Edge'
  }

  const handleSaveSight = (): void => {
    if (!shape || !distance) return

    const newSight: SightLog = {
      id: Date.now().toString(),
      shape: shapeLabels[shape as Exclude<Shape, ''>],
      distance: distanceLabels[distance as Exclude<Distance, ''>],
      notes: sightNotes,
      timestamp: new Date().toLocaleString()
    }

    setSightLogs([newSight, ...sightLogs])
    setShape('')
    setDistance('')
    setSightNotes('')
  }

  const getPatternSteps = (patternType: Pattern): string[] => {
    if (patternType === 'left-right') {
      return [
        'Scan far left edge',
        'Move gaze to center-left',
        'Focus on central zone',
        'Shift to center-right',
        'Complete at far right edge'
      ]
    } else if (patternType === 'grid') {
      return [
        'Top-left sector',
        'Top-center sector',
        'Top-right sector',
        'Middle-left sector',
        'Middle-center sector',
        'Middle-right sector',
        'Bottom-left sector',
        'Bottom-center sector',
        'Bottom-right sector'
      ]
    }
    return []
  }

  const handleStartPattern = (): void => {
    if (!pattern) return
    setPatternActive(true)
    setCurrentStep(0)
  }

  const handleNextStep = (): void => {
    const steps = getPatternSteps(pattern)
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1)
    } else {
      setPatternActive(false)
      setCurrentStep(0)
      setPattern('')
    }
  }

  return (
    <div className="space-y-6">
      {/* Card 1 - Log a Sight */}
      <Card className="border-indigo-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-indigo-900">Log a Sight</CardTitle>
          <CardDescription>Record what you observe in the Dream Realm</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="shape">Shape Type</Label>
            <Select value={shape} onValueChange={(value: string) => setShape(value as Shape)}>
              <SelectTrigger id="shape">
                <SelectValue placeholder="Select shape..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="winged">Winged Shape</SelectItem>
                <SelectItem value="four-legged">Four-Legged Form</SelectItem>
                <SelectItem value="human">Human Presence</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="distance">Distance</Label>
            <Select value={distance} onValueChange={(value: string) => setDistance(value as Distance)}>
              <SelectTrigger id="distance">
                <SelectValue placeholder="Select distance..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="close">Close</SelectItem>
                <SelectItem value="midfield">Midfield</SelectItem>
                <SelectItem value="far">Far Edge</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="sight-notes">Notes</Label>
            <Textarea
              id="sight-notes"
              placeholder="Describe what you sensed..."
              value={sightNotes}
              onChange={(e) => setSightNotes(e.target.value)}
              className="min-h-[80px]"
            />
          </div>

          <Button 
            onClick={handleSaveSight} 
            className="w-full bg-indigo-600 hover:bg-indigo-700"
            disabled={!shape || !distance}
          >
            Save Sight
          </Button>

          {sightLogs.length > 0 && (
            <div className="mt-6 space-y-3">
              <Label>Logged Sights</Label>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {sightLogs.map((log) => (
                  <div key={log.id} className="p-3 bg-indigo-50 rounded-lg border border-indigo-200">
                    <div className="flex justify-between items-start mb-1">
                      <span className="text-sm font-semibold text-indigo-900">
                        {log.shape} • {log.distance}
                      </span>
                      <span className="text-xs text-indigo-600">{log.timestamp}</span>
                    </div>
                    {log.notes && (
                      <p className="text-sm text-indigo-700 mt-1">{log.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Card 2 - Scan Pattern */}
      <Card className="border-purple-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-purple-900">Scan Pattern</CardTitle>
          <CardDescription>Follow a systematic awareness pattern</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!patternActive ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="pattern">Pattern Type</Label>
                <Select value={pattern} onValueChange={(value: string) => setPattern(value as Pattern)}>
                  <SelectTrigger id="pattern">
                    <SelectValue placeholder="Select pattern..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="left-right">Left-to-Right Sweep</SelectItem>
                    <SelectItem value="grid">3×3 Grid</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={handleStartPattern} 
                className="w-full bg-purple-600 hover:bg-purple-700"
                disabled={!pattern}
              >
                Start Pattern
              </Button>
            </>
          ) : (
            <div className="space-y-4">
              {/* Animated Visualization */}
              <ScanVisualization 
                pattern={pattern} 
                currentStep={currentStep}
                totalSteps={getPatternSteps(pattern).length}
              />

              <div className="p-4 bg-purple-50 rounded-lg border border-purple-200">
                <p className="text-sm font-semibold text-purple-900 mb-2">
                  Step {currentStep + 1} of {getPatternSteps(pattern).length}
                </p>
                <p className="text-lg text-purple-800 font-medium">
                  {getPatternSteps(pattern)[currentStep]}
                </p>
              </div>

              <Button 
                onClick={handleNextStep} 
                className="w-full bg-purple-600 hover:bg-purple-700"
              >
                {currentStep < getPatternSteps(pattern).length - 1 ? 'Next' : 'Complete'}
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
