'use client'

import type { ReactElement } from 'react'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'

type Scenario = 'high-vantage' | 'crossing-lanes' | 'flanking-path' | 'nexus-defense' | ''
type Obstacle = 'mist-walls' | 'light-pillars' | 'terrain-ridges' | 'moving-shapes'

interface AnalysisResult {
  view: string
  exposure: string
}

export function DreamTactics(): ReactElement {
  const [scenario, setScenario] = useState<Scenario>('')
  const [scenarioNotes, setScenarioNotes] = useState<string>('')
  const [scenarioSummary, setScenarioSummary] = useState<string>('')
  
  const [obstacles, setObstacles] = useState<Set<Obstacle>>(new Set())
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null)

  const handleGenerateSummary = (): void => {
    const summaries: Record<Exclude<Scenario, ''>, string> = {
      'high-vantage': '• Position yourself at elevated awareness points\n• Maintain clear sight lines across the realm\n• Stay mindful of exposure from multiple angles',
      'crossing-lanes': '• Observe all pathways with soft focus\n• Position at the convergence of flows\n• Balance visibility with protective presence',
      'flanking-path': '• Use indirect routes for unexpected perspectives\n• Maintain awareness of your surroundings\n• Clarity comes from unexpected angles',
      'nexus-defense': '• Hold the center with calm presence\n• Create overlapping fields of awareness\n• Protect the core with balanced vigilance'
    }

    if (scenario && scenario !== '') {
      setScenarioSummary(summaries[scenario])
    }
  }

  const toggleObstacle = (obstacle: Obstacle): void => {
    const newObstacles = new Set(obstacles)
    if (newObstacles.has(obstacle)) {
      newObstacles.delete(obstacle)
    } else {
      newObstacles.add(obstacle)
    }
    setObstacles(newObstacles)
  }

  const handleAnalyze = (): void => {
    const obstacleCount = obstacles.size
    
    let view: string
    let exposure: string

    if (obstacleCount === 0) {
      view = 'Wide'
      exposure = 'Overexposed'
    } else if (obstacleCount === 1 || obstacleCount === 2) {
      view = 'Wide'
      exposure = 'Balanced'
    } else if (obstacleCount === 3) {
      view = 'Narrow'
      exposure = 'Balanced'
    } else {
      view = 'Blocked'
      exposure = 'Hidden'
    }

    setAnalysisResult({ view, exposure })
  }

  return (
    <div className="space-y-6">
      {/* Card 1 - Scenario Picker */}
      <Card className="border-indigo-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-indigo-900">Scenario Picker</CardTitle>
          <CardDescription>Choose a Dream Realm scenario to analyze</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="scenario">Scenario</Label>
            <Select value={scenario} onValueChange={(value: string) => setScenario(value as Scenario)}>
              <SelectTrigger id="scenario">
                <SelectValue placeholder="Select a scenario..." />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="high-vantage">High Vantage Hold</SelectItem>
                <SelectItem value="crossing-lanes">Crossing Lanes</SelectItem>
                <SelectItem value="flanking-path">Flanking Path</SelectItem>
                <SelectItem value="nexus-defense">Nexus Defense</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="scenario-notes">Notes</Label>
            <Textarea
              id="scenario-notes"
              placeholder="Add your observations..."
              value={scenarioNotes}
              onChange={(e) => setScenarioNotes(e.target.value)}
              className="min-h-[100px]"
            />
          </div>

          <Button 
            onClick={handleGenerateSummary} 
            className="w-full bg-indigo-600 hover:bg-indigo-700"
            disabled={!scenario}
          >
            Generate Summary
          </Button>

          {scenarioSummary && (
            <div className="mt-4 p-4 bg-indigo-50 rounded-lg border border-indigo-200">
              <p className="text-sm font-semibold text-indigo-900 mb-2">Dream Realm Guidance:</p>
              <p className="text-sm text-indigo-800 whitespace-pre-line">{scenarioSummary}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Card 2 - Obstacle Picker */}
      <Card className="border-purple-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-purple-900">Obstacle Picker</CardTitle>
          <CardDescription>Select obstacles present in your realm</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Label>Obstacles</Label>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="mist-walls"
                checked={obstacles.has('mist-walls')}
                onCheckedChange={() => toggleObstacle('mist-walls')}
              />
              <label
                htmlFor="mist-walls"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Mist Walls
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="light-pillars"
                checked={obstacles.has('light-pillars')}
                onCheckedChange={() => toggleObstacle('light-pillars')}
              />
              <label
                htmlFor="light-pillars"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Light Pillars
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="terrain-ridges"
                checked={obstacles.has('terrain-ridges')}
                onCheckedChange={() => toggleObstacle('terrain-ridges')}
              />
              <label
                htmlFor="terrain-ridges"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Terrain Ridges
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="moving-shapes"
                checked={obstacles.has('moving-shapes')}
                onCheckedChange={() => toggleObstacle('moving-shapes')}
              />
              <label
                htmlFor="moving-shapes"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                Moving Shapes
              </label>
            </div>
          </div>

          <Button 
            onClick={handleAnalyze} 
            className="w-full bg-purple-600 hover:bg-purple-700"
            disabled={obstacles.size === 0}
          >
            Analyze
          </Button>

          {analysisResult && (
            <div className="mt-4 p-4 bg-purple-50 rounded-lg border border-purple-200 space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-purple-900">View:</span>
                <span className="text-sm text-purple-800">{analysisResult.view}</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm font-semibold text-purple-900">Exposure:</span>
                <span className="text-sm text-purple-800">{analysisResult.exposure}</span>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
