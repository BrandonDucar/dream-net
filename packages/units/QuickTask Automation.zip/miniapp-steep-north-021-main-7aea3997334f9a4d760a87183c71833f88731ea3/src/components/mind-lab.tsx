'use client'

import type { ReactElement } from 'react'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Checkbox } from '@/components/ui/checkbox'
import { playBreathTone } from '@/lib/audio-utils'

type BreathType = '4-6' | 'box' | ''

interface ChecklistEntry {
  id: string
  calm: boolean
  aware: boolean
  wholeField: boolean
  notes: string
  timestamp: string
}

export function MindLab(): ReactElement {
  const [breathType, setBreathType] = useState<BreathType>('')
  const [breathActive, setBreathActive] = useState<boolean>(false)
  const [breathStep, setBreathStep] = useState<string>('')
  const [breathPhase, setBreathPhase] = useState<number>(0)

  const [calm, setCalm] = useState<boolean>(false)
  const [aware, setAware] = useState<boolean>(false)
  const [wholeField, setWholeField] = useState<boolean>(false)
  const [checklistNotes, setChecklistNotes] = useState<string>('')
  const [checklistEntries, setChecklistEntries] = useState<ChecklistEntry[]>([])

  // Load checklist entries from localStorage on mount
  useEffect(() => {
    const stored = localStorage.getItem('dreamlongview-checklist')
    if (stored) {
      try {
        setChecklistEntries(JSON.parse(stored))
      } catch (e) {
        console.error('Failed to parse checklist entries', e)
      }
    }
  }, [])

  // Save checklist entries to localStorage whenever they change
  useEffect(() => {
    if (checklistEntries.length > 0) {
      localStorage.setItem('dreamlongview-checklist', JSON.stringify(checklistEntries))
    }
  }, [checklistEntries])

  useEffect(() => {
    if (!breathActive) return

    const phases46 = [
      { text: 'Inhale slowly... (4 seconds)', duration: 4000, tone: 'inhale' },
      { text: 'Hold gently... (2 seconds)', duration: 2000, tone: 'hold' },
      { text: 'Exhale slowly... (6 seconds)', duration: 6000, tone: 'exhale' },
      { text: 'Rest... (2 seconds)', duration: 2000, tone: 'rest' }
    ]

    const phasesBox = [
      { text: 'Inhale... (4 seconds)', duration: 4000, tone: 'inhale' },
      { text: 'Hold... (4 seconds)', duration: 4000, tone: 'hold' },
      { text: 'Exhale... (4 seconds)', duration: 4000, tone: 'exhale' },
      { text: 'Hold... (4 seconds)', duration: 4000, tone: 'hold' }
    ]

    const phases = breathType === '4-6' ? phases46 : phasesBox
    const currentPhase = phases[breathPhase]

    setBreathStep(currentPhase.text)
    
    // Play sound cue for breath phase
    playBreathTone(currentPhase.tone as 'inhale' | 'hold' | 'exhale' | 'rest')

    const timer = setTimeout(() => {
      if (breathPhase < phases.length - 1) {
        setBreathPhase(breathPhase + 1)
      } else {
        setBreathActive(false)
        setBreathPhase(0)
        setBreathStep('')
        setBreathType('')
      }
    }, currentPhase.duration)

    return () => clearTimeout(timer)
  }, [breathActive, breathPhase, breathType])

  const handleStartBreath = (): void => {
    if (!breathType) return
    setBreathActive(true)
    setBreathPhase(0)
  }

  const handleSaveChecklist = (): void => {
    const newEntry: ChecklistEntry = {
      id: Date.now().toString(),
      calm,
      aware,
      wholeField,
      notes: checklistNotes,
      timestamp: new Date().toLocaleString()
    }

    setChecklistEntries([newEntry, ...checklistEntries])
    setCalm(false)
    setAware(false)
    setWholeField(false)
    setChecklistNotes('')
  }

  return (
    <div className="space-y-6">
      {/* Card 1 - Breathing Drill */}
      <Card className="border-indigo-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-indigo-900">Breathing Drill</CardTitle>
          <CardDescription>Center yourself with guided breathing</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {!breathActive ? (
            <>
              <div className="space-y-2">
                <Label htmlFor="breath-type">Breath Pattern</Label>
                <Select value={breathType} onValueChange={(value: string) => setBreathType(value as BreathType)}>
                  <SelectTrigger id="breath-type">
                    <SelectValue placeholder="Select pattern..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="4-6">4–6 Grounding Breath</SelectItem>
                    <SelectItem value="box">Box Breath</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <Button 
                onClick={handleStartBreath} 
                className="w-full bg-indigo-600 hover:bg-indigo-700"
                disabled={!breathType}
              >
                Start
              </Button>
            </>
          ) : (
            <div className="p-6 bg-indigo-50 rounded-lg border border-indigo-200 text-center">
              <p className="text-2xl text-indigo-900 font-semibold animate-pulse">
                {breathStep}
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Card 2 - Quick Checklist */}
      <Card className="border-purple-200 bg-white/70 backdrop-blur">
        <CardHeader>
          <CardTitle className="text-purple-900">Quick Checklist</CardTitle>
          <CardDescription>Assess your current state of awareness</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-3">
            <Label>Current State</Label>
            
            <div className="flex items-center space-x-2">
              <Checkbox
                id="calm"
                checked={calm}
                onCheckedChange={(checked: boolean) => setCalm(checked)}
              />
              <label
                htmlFor="calm"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                I&apos;m calm
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="aware"
                checked={aware}
                onCheckedChange={(checked: boolean) => setAware(checked)}
              />
              <label
                htmlFor="aware"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                I&apos;m aware
              </label>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="whole-field"
                checked={wholeField}
                onCheckedChange={(checked: boolean) => setWholeField(checked)}
              />
              <label
                htmlFor="whole-field"
                className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70 cursor-pointer"
              >
                I see the whole field
              </label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="checklist-notes">Notes</Label>
            <Textarea
              id="checklist-notes"
              placeholder="Additional reflections..."
              value={checklistNotes}
              onChange={(e) => setChecklistNotes(e.target.value)}
              className="min-h-[80px]"
            />
          </div>

          <Button 
            onClick={handleSaveChecklist} 
            className="w-full bg-purple-600 hover:bg-purple-700"
          >
            Save Entry
          </Button>

          {checklistEntries.length > 0 && (
            <div className="mt-6 space-y-3">
              <Label>Past Entries</Label>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {checklistEntries.map((entry) => (
                  <div key={entry.id} className="p-3 bg-purple-50 rounded-lg border border-purple-200">
                    <div className="flex justify-between items-start mb-2">
                      <div className="space-y-1">
                        {entry.calm && (
                          <div className="text-xs text-purple-700">✓ Calm</div>
                        )}
                        {entry.aware && (
                          <div className="text-xs text-purple-700">✓ Aware</div>
                        )}
                        {entry.wholeField && (
                          <div className="text-xs text-purple-700">✓ Whole field</div>
                        )}
                      </div>
                      <span className="text-xs text-purple-600">{entry.timestamp}</span>
                    </div>
                    {entry.notes && (
                      <p className="text-sm text-purple-700 mt-2">{entry.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
