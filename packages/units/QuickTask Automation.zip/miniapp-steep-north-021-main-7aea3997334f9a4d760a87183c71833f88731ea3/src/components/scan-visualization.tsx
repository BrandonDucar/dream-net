'use client'

import type { ReactElement } from 'react'

interface ScanVisualizationProps {
  pattern: 'left-right' | 'grid' | ''
  currentStep: number
  totalSteps: number
}

export function ScanVisualization({ pattern, currentStep, totalSteps }: ScanVisualizationProps): ReactElement {
  if (pattern === 'left-right') {
    return (
      <div className="relative w-full h-32 bg-gradient-to-b from-purple-100 to-indigo-100 rounded-lg border border-purple-200 overflow-hidden">
        {/* Scanning line */}
        <div 
          className="absolute top-0 bottom-0 w-1 bg-purple-500 transition-all duration-1000 ease-in-out"
          style={{
            left: `${(currentStep / (totalSteps - 1)) * 100}%`,
            boxShadow: '0 0 20px rgba(168, 85, 247, 0.6)'
          }}
        />
        
        {/* Field indicators */}
        <div className="absolute inset-0 flex justify-between px-4 items-center opacity-30">
          <div className="text-xs text-purple-700 font-semibold">LEFT</div>
          <div className="text-xs text-purple-700 font-semibold">CENTER</div>
          <div className="text-xs text-purple-700 font-semibold">RIGHT</div>
        </div>

        {/* Progress indicator */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 text-xs text-purple-700 font-medium">
          {Math.round((currentStep / (totalSteps - 1)) * 100)}% Complete
        </div>
      </div>
    )
  }

  if (pattern === 'grid') {
    // 3x3 grid
    const gridPositions = [
      { row: 0, col: 0 }, { row: 0, col: 1 }, { row: 0, col: 2 },
      { row: 1, col: 0 }, { row: 1, col: 1 }, { row: 1, col: 2 },
      { row: 2, col: 0 }, { row: 2, col: 1 }, { row: 2, col: 2 }
    ]

    return (
      <div className="w-full bg-gradient-to-br from-purple-100 to-indigo-100 rounded-lg border border-purple-200 p-4">
        <div className="grid grid-cols-3 gap-2">
          {gridPositions.map((pos, index) => {
            const isActive = index === currentStep
            const isCompleted = index < currentStep
            
            return (
              <div
                key={index}
                className={`
                  aspect-square rounded-lg border-2 transition-all duration-500
                  flex items-center justify-center text-sm font-semibold
                  ${isActive ? 'bg-purple-500 border-purple-600 text-white scale-110 shadow-lg' : ''}
                  ${isCompleted ? 'bg-purple-200 border-purple-300 text-purple-700' : ''}
                  ${!isActive && !isCompleted ? 'bg-white/50 border-purple-200 text-purple-400' : ''}
                `}
              >
                {isActive && '●'}
                {isCompleted && '✓'}
                {!isActive && !isCompleted && (index + 1)}
              </div>
            )
          })}
        </div>
        
        {/* Progress text */}
        <div className="mt-3 text-center text-xs text-purple-700 font-medium">
          Sector {currentStep + 1} of {totalSteps}
        </div>
      </div>
    )
  }

  return <></>
}
