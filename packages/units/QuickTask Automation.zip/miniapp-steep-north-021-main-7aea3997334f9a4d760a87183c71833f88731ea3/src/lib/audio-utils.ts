// Audio utility functions for breath guidance

let audioContext: AudioContext | null = null

const getAudioContext = (): AudioContext => {
  if (!audioContext) {
    audioContext = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)()
  }
  return audioContext
}

export const playBreathTone = (phase: 'inhale' | 'hold' | 'exhale' | 'rest'): void => {
  try {
    const ctx = getAudioContext()
    const oscillator = ctx.createOscillator()
    const gainNode = ctx.createGain()

    oscillator.connect(gainNode)
    gainNode.connect(ctx.destination)

    // Frequency mapping for different breath phases
    const frequencies: Record<typeof phase, number> = {
      inhale: 432,    // A4 - calming upward breath
      hold: 384,      // G4 - steady hold
      exhale: 324,    // E4 - relaxing downward breath
      rest: 288       // D4 - peaceful rest
    }

    oscillator.type = 'sine'
    oscillator.frequency.setValueAtTime(frequencies[phase], ctx.currentTime)

    // Gentle fade in and out
    gainNode.gain.setValueAtTime(0, ctx.currentTime)
    gainNode.gain.linearRampToValueAtTime(0.15, ctx.currentTime + 0.1)
    gainNode.gain.linearRampToValueAtTime(0, ctx.currentTime + 0.5)

    oscillator.start(ctx.currentTime)
    oscillator.stop(ctx.currentTime + 0.5)
  } catch (e) {
    // Silently fail if audio is not supported or blocked
    console.debug('Audio playback not available', e)
  }
}
