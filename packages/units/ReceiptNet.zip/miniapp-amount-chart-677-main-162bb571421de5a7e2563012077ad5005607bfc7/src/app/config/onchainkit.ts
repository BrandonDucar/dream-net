export const ONCHAINKIT_PROJECT_ID = 'ohara-base-receipts';
export const ONCHAINKIT_API_KEY = 'ohara-miniapp-key';
