import type { Metadata } from 'next';
import localFont from 'next/font/local';
import '@coinbase/onchainkit/styles.css';
import './globals.css';
import { ResponseLogger } from '@/components/response-logger';
import { cookies } from 'next/headers';
import { ReadyNotifier } from '@/components/ready-notifier';
import { Providers } from './providers';
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: './fonts/GeistVF.woff',
  variable: '--font-geist-sans',
  weight: '100 900',
});
const geistMono = localFont({
  src: './fonts/GeistMonoVF.woff',
  variable: '--font-geist-mono',
  weight: '100 900',
});

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const cookieStore = await cookies();
  const requestId = cookieStore.get('x-request-id')?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
          </head>
          <body className={`${geistSans.variable} ${geistMono.variable} antialiased`}>
            <ReadyNotifier />
            <Providers>
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      </Providers>
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "ReceiptNet",
        description: "Generate on-chain receipts for crypto payments. Features include auto-generate PDFs/HTMLs, categorized expenses, refund options, tax tagging, export capabilities, and split receipts.",
        other: { "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_4bad3d96-01d1-4603-96d5-02a1accf79cb-elhVONsx2AoDTF5wvgeckAEFte3T90","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"ReceiptNet","url":"https://amount-chart-677.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}
        ) }
    };
