'use client'
import { useState, useEffect } from 'react';
import { useAccount } from 'wagmi';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ReceiptCard } from '@/components/receipt-card';
import { CategorySelector } from '@/components/category-selector';
import { TaxTagSelector } from '@/components/tax-tag-selector';
import { SplitReceiptDialog } from '@/components/split-receipt-dialog';
import { ExportDialog } from '@/components/export-dialog';
import { RefundDialog } from '@/components/refund-dialog';
import { useTransactionHistory } from '@/hooks/use-transaction-history';
import type { TransactionReceipt, ReceiptCategory, TaxTag } from '@/types/receipt';
import { formatCurrency, calculateTaxSummary, calculateCategorySummary } from '@/lib/receipt-utils';
import { Download, Wallet, TrendingUp, PieChart, Receipt } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { address, status } = useAccount();
  const { receipts, isLoading, updateReceipt, getReceiptById } = useTransactionHistory();
  const [selectedReceipt, setSelectedReceipt] = useState<TransactionReceipt | null>(null);
  const [splitDialogOpen, setSplitDialogOpen] = useState<boolean>(false);
  const [exportDialogOpen, setExportDialogOpen] = useState<boolean>(false);
  const [refundDialogOpen, setRefundDialogOpen] = useState<boolean>(false);
  const [filterCategory, setFilterCategory] = useState<ReceiptCategory | 'All'>('All');
  const [filterTaxTag, setFilterTaxTag] = useState<TaxTag | 'All'>('All');

  const handleCategoryChange = (id: string, category: string) => {
    updateReceipt(id, { category: category as ReceiptCategory });
  };

  const handleTaxTagChange = (id: string, taxTag: string) => {
    updateReceipt(id, { taxTag: taxTag as TaxTag });
  };

  const handleSplitClick = (id: string) => {
    const receipt = getReceiptById(id);
    setSelectedReceipt(receipt || null);
    setSplitDialogOpen(true);
  };

  const handleRefundClick = (id: string) => {
    const receipt = getReceiptById(id);
    setSelectedReceipt(receipt || null);
    setRefundDialogOpen(true);
  };

  const filteredReceipts = receipts.filter((receipt: TransactionReceipt) => {
    const categoryMatch = filterCategory === 'All' || receipt.category === filterCategory;
    const taxMatch = filterTaxTag === 'All' || receipt.taxTag === filterTaxTag;
    return categoryMatch && taxMatch;
  });

  const totalSpent = receipts.reduce(
    (sum: number, r: TransactionReceipt) => sum + r.valueUSD + r.gasCostUSD,
    0
  );
  const taxSummary = calculateTaxSummary(receipts);
  const categorySummary = calculateCategorySummary(receipts);

  if (status === 'connecting' || status === 'reconnecting') {
    return (
      <main className="min-h-screen flex items-center justify-center p-4 bg-white">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Connecting to your wallet...</p>
        </div>
      </main>
    );
  }

  if (!address) {
    return (
      <main className="min-h-screen flex items-center justify-center p-4 bg-white">
        <Card className="max-w-md w-full">
          <CardHeader className="text-center">
            <div className="text-6xl mb-4">🧾</div>
            <CardTitle className="text-2xl">Welcome to ReceiptNet</CardTitle>
            <p className="text-gray-600 mt-2">
              Every crypto payment comes with a real receipt
            </p>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h3 className="font-semibold mb-2">What you get:</h3>
              <ul className="space-y-2 text-sm text-gray-700">
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  Auto-generated receipts for all transactions
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  Expense categorization
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  Tax tagging and summaries
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  PDF/CSV export for accounting
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  Split receipts with friends
                </li>
                <li className="flex items-center gap-2">
                  <span className="text-green-500">✓</span>
                  Refund request buttons
                </li>
              </ul>
            </div>
            <p className="text-sm text-center text-gray-600">
              Connect your wallet to view your receipts on Base
            </p>
          </CardContent>
        </Card>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-200 bg-white sticky top-0 z-10">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <span className="text-3xl">🧾</span>
              <div>
                <h1 className="text-xl font-bold text-black">ReceiptNet</h1>
                <p className="text-xs text-gray-500">Base Blockchain Receipts</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="hidden sm:flex items-center gap-1">
                <Wallet className="w-3 h-3" />
                {address.slice(0, 6)}...{address.slice(-4)}
              </Badge>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6 space-y-6">
        {/* Stats Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <Receipt className="w-4 h-4" />
                Total Receipts
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-black">{receipts.length}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <TrendingUp className="w-4 h-4" />
                Total Spent
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-black">{formatCurrency(totalSpent)}</div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600 flex items-center gap-2">
                <PieChart className="w-4 h-4" />
                Categories
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-black">
                {Object.keys(categorySummary).filter((key: string) => categorySummary[key as ReceiptCategory] > 0).length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Actions Bar */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex flex-wrap gap-3">
              <Button onClick={() => setExportDialogOpen(true)} className="flex-1 sm:flex-none">
                <Download className="w-4 h-4 mr-2" />
                Export All
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Main Content */}
        <Tabs defaultValue="receipts" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="receipts">All Receipts</TabsTrigger>
            <TabsTrigger value="summary">Summary</TabsTrigger>
          </TabsList>

          <TabsContent value="receipts" className="space-y-4 mt-6">
            {/* Filters */}
            <Card>
              <CardContent className="pt-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <CategorySelector
                      value={filterCategory === 'All' ? 'Other' : filterCategory}
                      onChange={(val: ReceiptCategory) => setFilterCategory(val)}
                      label="Filter by Category"
                    />
                    <Button
                      variant="link"
                      size="sm"
                      onClick={() => setFilterCategory('All')}
                      className="mt-1"
                    >
                      Show All
                    </Button>
                  </div>
                  <div>
                    <TaxTagSelector
                      value={filterTaxTag === 'All' ? 'None' : filterTaxTag}
                      onChange={(val: TaxTag) => setFilterTaxTag(val)}
                      label="Filter by Tax Tag"
                    />
                    <Button
                      variant="link"
                      size="sm"
                      onClick={() => setFilterTaxTag('All')}
                      className="mt-1"
                    >
                      Show All
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Receipts List */}
            {isLoading ? (
              <div className="text-center py-12">
                <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
                <p className="text-gray-600">Loading receipts...</p>
              </div>
            ) : filteredReceipts.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <span className="text-6xl mb-4 block">📭</span>
                  <p className="text-gray-600">No receipts found</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredReceipts.map((receipt: TransactionReceipt) => (
                  <ReceiptCard
                    key={receipt.id}
                    receipt={receipt}
                    onCategoryChange={handleCategoryChange}
                    onTaxTagChange={handleTaxTagChange}
                    onSplitClick={handleSplitClick}
                    onRefundClick={handleRefundClick}
                  />
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="summary" className="space-y-4 mt-6">
            {/* Tax Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Tax Summary</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(taxSummary).map(([tag, amount]: [string, number]) => (
                  <div key={tag} className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">{tag}</span>
                    <span className="font-semibold">{formatCurrency(amount)}</span>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Category Summary */}
            <Card>
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {Object.entries(categorySummary)
                  .filter(([, amount]: [string, number]) => amount > 0)
                  .sort(([, a]: [string, number], [, b]: [string, number]) => b - a)
                  .map(([category, amount]: [string, number]) => (
                    <div key={category} className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">{category}</span>
                      <span className="font-semibold">{formatCurrency(amount)}</span>
                    </div>
                  ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      {/* Dialogs */}
      <SplitReceiptDialog
        receipt={selectedReceipt}
        isOpen={splitDialogOpen}
        onClose={() => setSplitDialogOpen(false)}
      />
      <ExportDialog
        receipts={receipts}
        isOpen={exportDialogOpen}
        onClose={() => setExportDialogOpen(false)}
      />
      <RefundDialog
        receipt={selectedReceipt}
        isOpen={refundDialogOpen}
        onClose={() => setRefundDialogOpen(false)}
      />
    </main>
  );
}
