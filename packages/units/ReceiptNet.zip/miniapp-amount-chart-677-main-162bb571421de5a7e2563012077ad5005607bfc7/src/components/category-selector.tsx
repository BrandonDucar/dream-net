'use client';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import type { ReceiptCategory } from '@/types/receipt';

interface CategorySelectorProps {
  value: ReceiptCategory;
  onChange: (value: ReceiptCategory) => void;
  label?: string;
}

const categories: ReceiptCategory[] = [
  'Gas',
  'DeFi',
  'NFT',
  'Transfer',
  'Swap',
  'Food & Dining',
  'Entertainment',
  'Utilities',
  'Shopping',
  'Travel',
  'Other',
];

const categoryEmojis: Record<ReceiptCategory, string> = {
  Gas: '⛽',
  DeFi: '💰',
  NFT: '🖼️',
  Transfer: '💸',
  Swap: '🔄',
  'Food & Dining': '🍽️',
  Entertainment: '🎭',
  Utilities: '💡',
  Shopping: '🛍️',
  Travel: '✈️',
  Other: '📦',
};

export function CategorySelector({ value, onChange, label = 'Category' }: CategorySelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="category-select">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger id="category-select" className="w-full">
          <SelectValue placeholder="Select category" />
        </SelectTrigger>
        <SelectContent>
          {categories.map((category: ReceiptCategory) => (
            <SelectItem key={category} value={category}>
              <span className="flex items-center gap-2">
                <span>{categoryEmojis[category]}</span>
                <span>{category}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
