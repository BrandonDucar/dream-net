'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import type { TransactionReceipt } from '@/types/receipt';
import { exportToJSON, exportToCSV, calculateTaxSummary, calculateCategorySummary } from '@/lib/receipt-utils';
import { Download, FileJson, FileSpreadsheet } from 'lucide-react';

interface ExportDialogProps {
  receipts: TransactionReceipt[];
  isOpen: boolean;
  onClose: () => void;
}

export function ExportDialog({ receipts, isOpen, onClose }: ExportDialogProps) {
  const [format, setFormat] = useState<'json' | 'csv'>('csv');
  const [includeTaxSummary, setIncludeTaxSummary] = useState<boolean>(true);

  const handleExport = () => {
    let content: string;
    let filename: string;
    let mimeType: string;

    if (format === 'json') {
      content = exportToJSON(receipts);
      filename = `receipts-${Date.now()}.json`;
      mimeType = 'application/json';
    } else {
      content = exportToCSV(receipts);
      filename = `receipts-${Date.now()}.csv`;
      mimeType = 'text/csv';
    }

    if (includeTaxSummary && format === 'json') {
      const taxSummary = calculateTaxSummary(receipts);
      const categorySummary = calculateCategorySummary(receipts);
      const fullExport = {
        receipts,
        summary: {
          totalReceipts: receipts.length,
          taxBreakdown: taxSummary,
          categoryBreakdown: categorySummary,
          exportDate: new Date().toISOString(),
        },
      };
      content = JSON.stringify(fullExport, null, 2);
    }

    const blob = new Blob([content], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);

    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Download className="w-5 h-5" />
            Export Receipts
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="text-sm text-gray-600">Exporting</div>
            <div className="text-2xl font-bold">{receipts.length} receipts</div>
          </div>

          <div className="space-y-4">
            <Label className="text-base font-semibold">Export Format</Label>
            
            <div className="space-y-3">
              <button
                type="button"
                onClick={() => setFormat('csv')}
                className={`w-full p-4 rounded-lg border-2 transition-colors ${
                  format === 'csv'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <FileSpreadsheet className="w-6 h-6" />
                  <div className="text-left flex-1">
                    <div className="font-semibold">CSV Spreadsheet</div>
                    <div className="text-sm text-gray-600">
                      Open in Excel, Google Sheets, or accounting software
                    </div>
                  </div>
                  {format === 'csv' && (
                    <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                      <svg
                        className="w-3 h-3 text-white"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>

              <button
                type="button"
                onClick={() => setFormat('json')}
                className={`w-full p-4 rounded-lg border-2 transition-colors ${
                  format === 'json'
                    ? 'border-blue-500 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-center gap-3">
                  <FileJson className="w-6 h-6" />
                  <div className="text-left flex-1">
                    <div className="font-semibold">JSON Data</div>
                    <div className="text-sm text-gray-600">
                      Structured format for developers and advanced users
                    </div>
                  </div>
                  {format === 'json' && (
                    <div className="w-5 h-5 rounded-full bg-blue-500 flex items-center justify-center">
                      <svg
                        className="w-3 h-3 text-white"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  )}
                </div>
              </button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="tax-summary"
              checked={includeTaxSummary}
              onCheckedChange={(checked: boolean) => setIncludeTaxSummary(checked)}
            />
            <Label htmlFor="tax-summary" className="text-sm font-normal cursor-pointer">
              Include tax and category summary
            </Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleExport}>
            <Download className="w-4 h-4 mr-2" />
            Export
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
