'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import type { TransactionReceipt } from '@/types/receipt';
import { formatAddress, formatDate, formatCurrency, generateReceiptHTML } from '@/lib/receipt-utils';
import { Download, FileText, ExternalLink, Users, RefreshCw } from 'lucide-react';

interface ReceiptCardProps {
  receipt: TransactionReceipt;
  onCategoryChange: (id: string, category: string) => void;
  onTaxTagChange: (id: string, taxTag: string) => void;
  onSplitClick: (id: string) => void;
  onRefundClick: (id: string) => void;
}

export function ReceiptCard({
  receipt,
  onCategoryChange,
  onTaxTagChange,
  onSplitClick,
  onRefundClick,
}: ReceiptCardProps) {
  const [showDetails, setShowDetails] = useState<boolean>(false);

  const downloadHTML = () => {
    const html = generateReceiptHTML(receipt);
    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `receipt-${receipt.id}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const totalCost = receipt.valueUSD + receipt.gasCostUSD;

  return (
    <Card className="w-full hover:shadow-lg transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div className="flex-1">
            <CardTitle className="text-base font-semibold flex items-center gap-2">
              <span className="text-2xl">🧾</span>
              <span className="font-mono text-sm">{formatAddress(receipt.hash)}</span>
            </CardTitle>
            <p className="text-xs text-gray-500 mt-1">{formatDate(receipt.timestamp)}</p>
          </div>
          <Badge
            variant={receipt.status === 'success' ? 'default' : 'destructive'}
            className="ml-2"
          >
            {receipt.status}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="space-y-4">
        {/* Amount Summary */}
        <div className="bg-gray-50 p-4 rounded-lg">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Amount</span>
            <span className="font-semibold">{formatCurrency(receipt.valueUSD)}</span>
          </div>
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-600">Gas Fee</span>
            <span className="text-sm">{formatCurrency(receipt.gasCostUSD)}</span>
          </div>
          <div className="flex justify-between items-center pt-2 border-t border-gray-200">
            <span className="font-semibold">Total</span>
            <span className="font-bold text-lg">{formatCurrency(totalCost)}</span>
          </div>
        </div>

        {/* Categories and Tags */}
        <div className="flex flex-wrap gap-2">
          <Badge variant="outline" className="bg-blue-50">
            {receipt.category}
          </Badge>
          <Badge variant="outline" className="bg-yellow-50">
            {receipt.taxTag}
          </Badge>
        </div>

        {/* Transaction Details (Collapsible) */}
        {showDetails && (
          <div className="space-y-2 text-sm border-t pt-3">
            <div className="flex justify-between">
              <span className="text-gray-600">From:</span>
              <span className="font-mono text-xs">{formatAddress(receipt.from)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">To:</span>
              <span className="font-mono text-xs">
                {receipt.to ? formatAddress(receipt.to) : 'Contract'}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Block:</span>
              <span className="font-mono text-xs">{receipt.blockNumber}</span>
            </div>
            {receipt.methodName && (
              <div className="flex justify-between">
                <span className="text-gray-600">Method:</span>
                <span className="font-mono text-xs">{receipt.methodName}</span>
              </div>
            )}
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap gap-2 pt-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowDetails(!showDetails)}
            className="flex-1 min-w-[120px]"
          >
            <FileText className="w-4 h-4 mr-1" />
            {showDetails ? 'Hide' : 'Details'}
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={downloadHTML}
            className="flex-1 min-w-[120px]"
          >
            <Download className="w-4 h-4 mr-1" />
            Export
          </Button>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => onSplitClick(receipt.id)}
            className="flex-1 min-w-[120px]"
          >
            <Users className="w-4 h-4 mr-1" />
            Split
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={() => onRefundClick(receipt.id)}
            className="flex-1 min-w-[120px]"
          >
            <RefreshCw className="w-4 h-4 mr-1" />
            Refund
          </Button>
        </div>

        <Button
          variant="link"
          size="sm"
          className="w-full text-xs"
          onClick={() => window.open(`https://basescan.org/tx/${receipt.hash}`, '_blank')}
        >
          <ExternalLink className="w-3 h-3 mr-1" />
          View on BaseScan
        </Button>
      </CardContent>
    </Card>
  );
}
