'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import type { TransactionReceipt } from '@/types/receipt';
import { formatCurrency, formatAddress } from '@/lib/receipt-utils';
import { RefreshCw, AlertTriangle } from 'lucide-react';
import { useAccount } from 'wagmi';

interface RefundDialogProps {
  receipt: TransactionReceipt | null;
  isOpen: boolean;
  onClose: () => void;
}

export function RefundDialog({ receipt, isOpen, onClose }: RefundDialogProps) {
  const { address } = useAccount();
  const [refundAmount, setRefundAmount] = useState<string>('');
  const [reason, setReason] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);

  if (!receipt) return null;

  const maxRefund = receipt.valueUSD;

  const handleRefund = async () => {
    setIsProcessing(true);
    // In production, this would initiate an on-chain refund transaction
    // For now, we simulate the process
    await new Promise((resolve: (value: unknown) => void) => setTimeout(resolve, 2000));
    setIsProcessing(false);
    onClose();
    // Reset form
    setRefundAmount('');
    setReason('');
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <RefreshCw className="w-5 h-5" />
            Request Refund
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Warning Banner */}
          <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
            <div className="flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-yellow-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-yellow-900 mb-1">Important Notice</p>
                <p className="text-yellow-800">
                  Refund requests require approval from the recipient. Gas fees are not refundable.
                </p>
              </div>
            </div>
          </div>

          {/* Original Transaction Info */}
          <div className="bg-gray-50 p-4 rounded-lg space-y-2">
            <div className="text-sm font-semibold mb-2">Original Transaction</div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">To:</span>
              <span className="font-mono">{formatAddress(receipt.to || '')}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Amount:</span>
              <span className="font-semibold">{formatCurrency(receipt.valueUSD)}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Category:</span>
              <span>{receipt.category}</span>
            </div>
          </div>

          {/* Refund Amount Input */}
          <div className="space-y-2">
            <Label htmlFor="refund-amount">Refund Amount (USD)</Label>
            <div className="relative">
              <span className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-500">$</span>
              <Input
                id="refund-amount"
                type="number"
                placeholder="0.00"
                value={refundAmount}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRefundAmount(e.target.value)}
                className="pl-7"
                max={maxRefund}
                step="0.01"
              />
            </div>
            <p className="text-xs text-gray-500">
              Maximum refundable: {formatCurrency(maxRefund)}
            </p>
          </div>

          {/* Reason Input */}
          <div className="space-y-2">
            <Label htmlFor="refund-reason">Reason for Refund</Label>
            <Textarea
              id="refund-reason"
              placeholder="Please provide a reason for the refund request..."
              value={reason}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setReason(e.target.value)}
              rows={3}
            />
          </div>

          {/* Refund Preview */}
          {refundAmount && parseFloat(refundAmount) > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <div className="text-sm font-medium mb-2">Refund Preview</div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">You will receive:</span>
                <span className="text-xl font-bold text-blue-600">
                  {formatCurrency(parseFloat(refundAmount))}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-2">
                The recipient will need to approve this refund request
              </p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isProcessing}>
            Cancel
          </Button>
          <Button
            onClick={handleRefund}
            disabled={!refundAmount || parseFloat(refundAmount) <= 0 || !reason || isProcessing}
          >
            {isProcessing ? (
              <>
                <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <RefreshCw className="w-4 h-4 mr-2" />
                Request Refund
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
