'use client';

import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import type { TransactionReceipt } from '@/types/receipt';
import { formatCurrency } from '@/lib/receipt-utils';
import { Plus, Minus, Copy, Check } from 'lucide-react';

interface SplitReceiptDialogProps {
  receipt: TransactionReceipt | null;
  isOpen: boolean;
  onClose: () => void;
}

interface Participant {
  name: string;
  address: string;
  amount: number;
}

export function SplitReceiptDialog({ receipt, isOpen, onClose }: SplitReceiptDialogProps) {
  const [participants, setParticipants] = useState<Participant[]>([
    { name: 'You', address: '', amount: 0 },
  ]);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  if (!receipt) return null;

  const totalAmount = receipt.valueUSD + receipt.gasCostUSD;
  const splitAmount = totalAmount / participants.length;

  const addParticipant = () => {
    setParticipants([...participants, { name: '', address: '', amount: 0 }]);
  };

  const removeParticipant = (index: number) => {
    if (participants.length > 1) {
      setParticipants(participants.filter((_: Participant, i: number) => i !== index));
    }
  };

  const updateParticipant = (index: number, field: keyof Participant, value: string | number) => {
    const updated = [...participants];
    updated[index] = { ...updated[index], [field]: value };
    setParticipants(updated);
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Users className="w-5 h-5" />
            Split Receipt
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Receipt Summary */}
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium">Total Amount</span>
              <span className="text-lg font-bold">{formatCurrency(totalAmount)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Split {participants.length} ways</span>
              <Badge variant="outline">{formatCurrency(splitAmount)} each</Badge>
            </div>
          </div>

          {/* Participants */}
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <Label className="text-base font-semibold">Participants</Label>
              <Button size="sm" onClick={addParticipant} variant="outline">
                <Plus className="w-4 h-4 mr-1" />
                Add Person
              </Button>
            </div>

            {participants.map((participant: Participant, index: number) => (
              <div key={index} className="border rounded-lg p-4 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Person {index + 1}</span>
                  {participants.length > 1 && (
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => removeParticipant(index)}
                    >
                      <Minus className="w-4 h-4" />
                    </Button>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`name-${index}`}>Name</Label>
                  <Input
                    id={`name-${index}`}
                    type="text"
                    placeholder="Enter name"
                    value={participant.name}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                      updateParticipant(index, 'name', e.target.value)
                    }
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`address-${index}`}>Wallet Address (Optional)</Label>
                  <div className="flex gap-2">
                    <Input
                      id={`address-${index}`}
                      type="text"
                      placeholder="0x..."
                      value={participant.address}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                        updateParticipant(index, 'address', e.target.value)
                      }
                      className="flex-1"
                    />
                    {participant.address && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => copyToClipboard(participant.address, index)}
                      >
                        {copiedIndex === index ? (
                          <Check className="w-4 h-4" />
                        ) : (
                          <Copy className="w-4 h-4" />
                        )}
                      </Button>
                    )}
                  </div>
                </div>

                <div className="bg-blue-50 p-3 rounded text-center">
                  <span className="text-sm text-gray-600">Amount to pay:</span>
                  <div className="text-xl font-bold mt-1">{formatCurrency(splitAmount)}</div>
                </div>
              </div>
            ))}
          </div>

          {/* Payment Links */}
          <div className="bg-yellow-50 p-4 rounded-lg border border-yellow-200">
            <div className="flex items-start gap-2">
              <span className="text-xl">💡</span>
              <div className="text-sm">
                <p className="font-medium mb-1">Share payment links</p>
                <p className="text-gray-600">
                  Each participant can send {formatCurrency(splitAmount)} to complete the split
                </p>
              </div>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>
            Close
          </Button>
          <Button onClick={onClose}>Done</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function Users({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
