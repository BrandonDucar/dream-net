'use client';

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import type { TaxTag } from '@/types/receipt';

interface TaxTagSelectorProps {
  value: TaxTag;
  onChange: (value: TaxTag) => void;
  label?: string;
}

const taxTags: TaxTag[] = ['Business Expense', 'Personal', 'Investment', 'Charity', 'None'];

const taxTagEmojis: Record<TaxTag, string> = {
  'Business Expense': '💼',
  Personal: '🏠',
  Investment: '📈',
  Charity: '❤️',
  None: '➖',
};

export function TaxTagSelector({ value, onChange, label = 'Tax Tag' }: TaxTagSelectorProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="tax-tag-select">{label}</Label>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger id="tax-tag-select" className="w-full">
          <SelectValue placeholder="Select tax tag" />
        </SelectTrigger>
        <SelectContent>
          {taxTags.map((tag: TaxTag) => (
            <SelectItem key={tag} value={tag}>
              <span className="flex items-center gap-2">
                <span>{taxTagEmojis[tag]}</span>
                <span>{tag}</span>
              </span>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
}
