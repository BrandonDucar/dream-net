'use client';

import { useState, useEffect } from 'react';
import { useAccount, useBlockNumber } from 'wagmi';
import type { TransactionReceipt, ReceiptCategory, TaxTag } from '@/types/receipt';
import type { Address } from 'viem';

// Mock transaction data generator for demonstration
function generateMockTransactions(address: Address): TransactionReceipt[] {
  const now = Math.floor(Date.now() / 1000);
  
  return [
    {
      id: 'receipt-001',
      hash: '0x1234567890abcdef1234567890abcdef1234567890abcdef1234567890abcdef' as Address,
      from: address,
      to: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb' as Address,
      value: '0.05',
      valueUSD: 150.75,
      gasUsed: '21000',
      gasPrice: '2.5',
      gasCostUSD: 0.52,
      timestamp: now - 3600,
      category: 'Transfer' as ReceiptCategory,
      taxTag: 'Personal' as TaxTag,
      notes: 'Payment for coffee',
      blockNumber: 12345678,
      status: 'success',
      tokenSymbol: 'ETH',
    },
    {
      id: 'receipt-002',
      hash: '0xabcdef1234567890abcdef1234567890abcdef1234567890abcdef1234567890' as Address,
      from: address,
      to: '0x1F98431c8aD98523631AE4a59f267346ea31F984' as Address,
      value: '0.1',
      valueUSD: 301.50,
      gasUsed: '145000',
      gasPrice: '3.2',
      gasCostUSD: 4.64,
      timestamp: now - 7200,
      category: 'DeFi' as ReceiptCategory,
      taxTag: 'Investment' as TaxTag,
      notes: 'Uniswap V3 swap',
      blockNumber: 12345650,
      status: 'success',
      methodName: 'swap',
      tokenSymbol: 'USDC',
    },
    {
      id: 'receipt-003',
      hash: '0x9876543210fedcba9876543210fedcba9876543210fedcba9876543210fedcba' as Address,
      from: address,
      to: '0x60E4d786628Fea6478F785A6d7e704777c86a7c6' as Address,
      value: '0.025',
      valueUSD: 75.38,
      gasUsed: '84230',
      gasPrice: '2.8',
      gasCostUSD: 2.36,
      timestamp: now - 14400,
      category: 'NFT' as ReceiptCategory,
      taxTag: 'Personal' as TaxTag,
      notes: 'Minted Base Builder NFT',
      blockNumber: 12345620,
      status: 'success',
      methodName: 'mint',
    },
    {
      id: 'receipt-004',
      hash: '0xdeadbeef1234567890abcdef1234567890abcdef1234567890abcdef12345678' as Address,
      from: address,
      to: '0x4200000000000000000000000000000000000006' as Address,
      value: '0.2',
      valueUSD: 603.00,
      gasUsed: '52000',
      gasPrice: '2.1',
      gasCostUSD: 1.09,
      timestamp: now - 21600,
      category: 'Swap' as ReceiptCategory,
      taxTag: 'Investment' as TaxTag,
      notes: 'Wrapped ETH to WETH',
      blockNumber: 12345590,
      status: 'success',
      tokenSymbol: 'WETH',
    },
    {
      id: 'receipt-005',
      hash: '0xcafebabe1234567890abcdef1234567890abcdef1234567890abcdef12345678' as Address,
      from: address,
      to: '0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913' as Address,
      value: '0',
      valueUSD: 0,
      gasUsed: '65000',
      gasPrice: '2.9',
      gasCostUSD: 1.89,
      timestamp: now - 28800,
      category: 'Gas' as ReceiptCategory,
      taxTag: 'Business Expense' as TaxTag,
      notes: 'Contract interaction - USDC approval',
      blockNumber: 12345550,
      status: 'success',
      methodName: 'approve',
    },
  ];
}

export function useTransactionHistory() {
  const { address } = useAccount();
  const { data: blockNumber } = useBlockNumber({ watch: true });
  const [receipts, setReceipts] = useState<TransactionReceipt[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);

  useEffect(() => {
    if (address) {
      setIsLoading(true);
      // In production, this would fetch real transaction data from Base
      // For now, we use mock data
      const mockData = generateMockTransactions(address);
      setReceipts(mockData);
      setIsLoading(false);
    }
  }, [address, blockNumber]);

  const updateReceipt = (id: string, updates: Partial<TransactionReceipt>) => {
    setReceipts((prev: TransactionReceipt[]) =>
      prev.map((r: TransactionReceipt) => (r.id === id ? { ...r, ...updates } : r))
    );
  };

  const getReceiptById = (id: string): TransactionReceipt | undefined => {
    return receipts.find((r: TransactionReceipt) => r.id === id);
  };

  return {
    receipts,
    isLoading,
    updateReceipt,
    getReceiptById,
  };
}
