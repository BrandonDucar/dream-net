import type { TransactionReceipt, ReceiptCategory, TaxTag } from '@/types/receipt';
import { formatEther } from 'viem';

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function formatDate(timestamp: number): string {
  return new Date(timestamp * 1000).toLocaleString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
  }).format(amount);
}

export function generateReceiptHTML(receipt: TransactionReceipt): string {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>Receipt - ${receipt.hash}</title>
  <style>
    body { 
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif; 
      max-width: 800px; 
      margin: 40px auto; 
      padding: 20px;
      background: #ffffff;
      color: #000000;
    }
    .header { 
      text-align: center; 
      border-bottom: 2px solid #000; 
      padding-bottom: 20px; 
      margin-bottom: 30px; 
    }
    .logo { 
      font-size: 32px; 
      font-weight: bold; 
      color: #0052FF; 
      margin-bottom: 10px; 
    }
    .receipt-id { 
      font-size: 12px; 
      color: #666; 
      margin-top: 10px; 
    }
    .section { 
      margin: 20px 0; 
      padding: 15px; 
      background: #f5f5f5;
      border-radius: 8px;
    }
    .section-title { 
      font-weight: bold; 
      font-size: 14px; 
      text-transform: uppercase; 
      color: #333;
      margin-bottom: 10px;
      letter-spacing: 0.5px;
    }
    .row { 
      display: flex; 
      justify-content: space-between; 
      padding: 8px 0; 
      border-bottom: 1px solid #ddd; 
    }
    .row:last-child { 
      border-bottom: none; 
    }
    .label { 
      color: #666; 
      font-size: 14px; 
    }
    .value { 
      font-weight: 500; 
      color: #000;
      text-align: right;
    }
    .total { 
      font-size: 24px; 
      font-weight: bold; 
      text-align: right; 
      margin-top: 20px; 
      padding-top: 20px; 
      border-top: 3px solid #000; 
    }
    .badge { 
      display: inline-block; 
      padding: 4px 12px; 
      border-radius: 20px; 
      font-size: 12px; 
      font-weight: 600;
    }
    .badge-success { 
      background: #d4edda; 
      color: #155724; 
    }
    .badge-category { 
      background: #e7f3ff; 
      color: #004085; 
    }
    .badge-tax { 
      background: #fff3cd; 
      color: #856404; 
    }
    .footer { 
      margin-top: 40px; 
      padding-top: 20px; 
      border-top: 2px solid #ddd; 
      text-align: center; 
      color: #666; 
      font-size: 12px; 
    }
    .footer-note {
      margin-top: 10px;
      font-style: italic;
    }
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">🧾 RECEIPTNET</div>
    <div style="font-size: 18px; color: #333; margin-top: 5px;">Transaction Receipt</div>
    <div class="receipt-id">Receipt ID: ${receipt.id}</div>
  </div>

  <div class="section">
    <div class="section-title">Transaction Details</div>
    <div class="row">
      <span class="label">Transaction Hash:</span>
      <span class="value" style="font-family: monospace; font-size: 12px;">${receipt.hash}</span>
    </div>
    <div class="row">
      <span class="label">Date & Time:</span>
      <span class="value">${formatDate(receipt.timestamp)}</span>
    </div>
    <div class="row">
      <span class="label">Block Number:</span>
      <span class="value">${receipt.blockNumber}</span>
    </div>
    <div class="row">
      <span class="label">Status:</span>
      <span class="value">
        <span class="badge badge-success">${receipt.status.toUpperCase()}</span>
      </span>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Transaction Parties</div>
    <div class="row">
      <span class="label">From:</span>
      <span class="value" style="font-family: monospace; font-size: 12px;">${receipt.from}</span>
    </div>
    <div class="row">
      <span class="label">To:</span>
      <span class="value" style="font-family: monospace; font-size: 12px;">${receipt.to || 'Contract Creation'}</span>
    </div>
  </div>

  <div class="section">
    <div class="section-title">Amount & Fees</div>
    <div class="row">
      <span class="label">Amount Transferred:</span>
      <span class="value">${receipt.value} ETH (${formatCurrency(receipt.valueUSD)})</span>
    </div>
    <div class="row">
      <span class="label">Gas Used:</span>
      <span class="value">${receipt.gasUsed}</span>
    </div>
    <div class="row">
      <span class="label">Gas Price:</span>
      <span class="value">${receipt.gasPrice} gwei</span>
    </div>
    <div class="row">
      <span class="label">Gas Fee:</span>
      <span class="value">${formatCurrency(receipt.gasCostUSD)}</span>
    </div>
    <div class="total">
      Total Cost: ${formatCurrency(receipt.valueUSD + receipt.gasCostUSD)}
    </div>
  </div>

  <div class="section">
    <div class="section-title">Classification</div>
    <div class="row">
      <span class="label">Category:</span>
      <span class="value">
        <span class="badge badge-category">${receipt.category}</span>
      </span>
    </div>
    <div class="row">
      <span class="label">Tax Tag:</span>
      <span class="value">
        <span class="badge badge-tax">${receipt.taxTag}</span>
      </span>
    </div>
    ${receipt.notes ? `
    <div class="row">
      <span class="label">Notes:</span>
      <span class="value">${receipt.notes}</span>
    </div>
    ` : ''}
  </div>

  <div class="footer">
    <div><strong>ReceiptNet</strong> - Powered by Base Blockchain</div>
    <div class="footer-note">
      This receipt is automatically generated from on-chain transaction data.
      Verify at: https://basescan.org/tx/${receipt.hash}
    </div>
  </div>
</body>
</html>
  `.trim();
}

export function exportToJSON(receipts: TransactionReceipt[]): string {
  return JSON.stringify(receipts, null, 2);
}

export function exportToCSV(receipts: TransactionReceipt[]): string {
  const headers = [
    'Date',
    'Transaction Hash',
    'From',
    'To',
    'Amount (ETH)',
    'Amount (USD)',
    'Gas Cost (USD)',
    'Total (USD)',
    'Category',
    'Tax Tag',
    'Status',
    'Notes',
  ];

  const rows = receipts.map((r: TransactionReceipt) => [
    formatDate(r.timestamp),
    r.hash,
    r.from,
    r.to || '',
    r.value,
    r.valueUSD.toString(),
    r.gasCostUSD.toString(),
    (r.valueUSD + r.gasCostUSD).toString(),
    r.category,
    r.taxTag,
    r.status,
    r.notes || '',
  ]);

  return [headers.join(','), ...rows.map((row: string[]) => row.join(','))].join('\n');
}

export function calculateTaxSummary(receipts: TransactionReceipt[]): Record<TaxTag, number> {
  const summary: Record<TaxTag, number> = {
    'Business Expense': 0,
    Personal: 0,
    Investment: 0,
    Charity: 0,
    None: 0,
  };

  receipts.forEach((receipt: TransactionReceipt) => {
    summary[receipt.taxTag] += receipt.valueUSD + receipt.gasCostUSD;
  });

  return summary;
}

export function calculateCategorySummary(
  receipts: TransactionReceipt[]
): Record<ReceiptCategory, number> {
  const summary: Record<ReceiptCategory, number> = {
    Gas: 0,
    DeFi: 0,
    NFT: 0,
    Transfer: 0,
    Swap: 0,
    'Food & Dining': 0,
    Entertainment: 0,
    Utilities: 0,
    Shopping: 0,
    Travel: 0,
    Other: 0,
  };

  receipts.forEach((receipt: TransactionReceipt) => {
    summary[receipt.category] += receipt.valueUSD + receipt.gasCostUSD;
  });

  return summary;
}
