import type { Address } from 'viem';

export type ReceiptCategory =
  | 'Gas'
  | 'DeFi'
  | 'NFT'
  | 'Transfer'
  | 'Swap'
  | 'Food & Dining'
  | 'Entertainment'
  | 'Utilities'
  | 'Shopping'
  | 'Travel'
  | 'Other';

export type TaxTag = 'Business Expense' | 'Personal' | 'Investment' | 'Charity' | 'None';

export interface TransactionReceipt {
  id: string;
  hash: Address;
  from: Address;
  to: Address | null;
  value: string;
  valueUSD: number;
  gasUsed: string;
  gasPrice: string;
  gasCostUSD: number;
  timestamp: number;
  category: ReceiptCategory;
  taxTag: TaxTag;
  notes: string;
  blockNumber: number;
  status: 'success' | 'failed';
  methodName?: string;
  tokenSymbol?: string;
}

export interface SplitReceipt {
  receiptId: string;
  participants: SplitParticipant[];
  totalAmount: number;
  splitType: 'equal' | 'percentage' | 'custom';
}

export interface SplitParticipant {
  address: Address;
  name?: string;
  amount: number;
  percentage?: number;
  paid: boolean;
}

export interface ExportOptions {
  format: 'pdf' | 'html' | 'csv' | 'json';
  dateRange?: {
    start: Date;
    end: Date;
  };
  categories?: ReceiptCategory[];
  includeTaxSummary: boolean;
}
