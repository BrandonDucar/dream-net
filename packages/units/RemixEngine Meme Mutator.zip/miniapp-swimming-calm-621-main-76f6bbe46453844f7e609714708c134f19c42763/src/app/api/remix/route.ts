import { NextRequest, NextResponse } from 'next/server'
import { openaiChatCompletion } from '@/openai-api'

interface RemixRequest {
  original_text: string
  remix_styles?: string[]
  platforms?: string[]
  audience_region?: string
  language?: string
  generate_image?: boolean
  generate_video?: boolean
  watermark?: string
}

interface SEOData {
  hashtags: string[]
  keywords: string[]
  engagement_score: number
  optimal_times: string[]
  platform_insights: Record<string, { char_count: number; readability: string }>
}

interface RemixResult {
  remixes: {
    edgy?: string
    safe?: string
    surreal?: string
    lore?: string
    clean?: string
    spicy?: string
    viral?: string
    minimal?: string
    'over-the-top'?: string
  }
  platform_variants: {
    X?: string
    Farcaster?: string
    Instagram?: string
    TikTok?: string
    Base?: string
  }
  extras: string[]
  seo: SEOData
  generated_image?: string
  generated_video?: string
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: RemixRequest = await request.json()
    const {
      original_text,
      remix_styles = ['edgy', 'safe', 'surreal', 'lore', 'clean'],
      platforms = ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'],
      audience_region = 'Global',
      language = 'English',
      generate_image = false,
      generate_video = false,
      watermark = '',
    } = body

    if (!original_text || original_text.trim() === '') {
      return NextResponse.json(
        { error: 'original_text is required' },
        { status: 400 }
      )
    }

    // Build the prompt for the AI
    const systemPrompt = `You are RemixEngine — DreamNet's meme mutation agent.

Your job is to take the user's original_text and produce multiple remixed versions that maintain the meaning but shift the tone, style, or cultural flavor.

Your output must always be valid JSON following this schema:
{
  "remixes": {
    "edgy": "string",
    "safe": "string",
    "surreal": "string",
    "lore": "string",
    "clean": "string"
  },
  "platform_variants": {
    "X": "string",
    "Farcaster": "string",
    "Instagram": "string",
    "TikTok": "string",
    "Base": "string"
  },
  "extras": ["string", "string", "string"],
  "seo": {
    "hashtags": ["#tag1", "#tag2", "#tag3"],
    "keywords": ["keyword1", "keyword2", "keyword3"],
    "engagement_score": 85,
    "optimal_times": ["9:00 AM EST", "12:00 PM EST", "6:00 PM EST"],
    "platform_insights": {
      "X": { "char_count": 150, "readability": "High" },
      "Instagram": { "char_count": 120, "readability": "Medium" }
    }
  }
}

Core Behaviors:

1. Generate multiple stylistic remixes:
   - edgy: slightly sharper, more chaotic, still safe.
   - safe: brand-friendly, PG, neutral.
   - surreal: weird, dreamlike, punchy.
   - lore: tie in DreamNet-style mystique (roots, signals, nodes, culture engines, etc.) when appropriate.
   - clean: simple, crisp, universal.
   - spicy: bold, controversial edge without crossing lines.
   - viral: optimized for maximum shareability.
   - minimal: ultra-concise, punchy one-liners.
   - over-the-top: exaggerated, dramatic, theatrical.

2. AI-SEO semantic optimization (internal only)
   - Make each remix clearer, more memorable, and more resonant.
   - Use widely recognizable cultural language.
   - Use trending phrase structures when appropriate.
   - DO NOT reference SEO, algorithms, optimization, or anything similar.

3. Geo-style tuning (audience_region)
   - Adjust slang and microtone according to regional vibe:
     - US: casual internet slang
     - EU: cleaner phrasing, less US-specific slang
     - LATAM: slightly warmer tone (still English unless asked)
     - Asia: avoid hyper-niche western jokes
     - Global: broadly international internet tone
   - Do NOT mention regions or imply location detection.

4. Platform variants:
   - X: short, bold, scroll-stopping.
   - Farcaster: communal, aesthetic, witty.
   - Instagram: emoji-friendly and smooth.
   - TikTok: high-energy, hook-first.
   - Base: onchain-native slang, builder culture references.

5. Extra remixes:
   - Produce at least 3 bonus variations with unique angles.

6. AI SEO Generation:
   - Generate 5-8 trending hashtags relevant to the content and culture.
   - Extract 5-10 SEO keywords that maximize discoverability.
   - Predict engagement score (0-100) based on viral potential, clarity, and cultural resonance.
   - Suggest optimal posting times (3-5 times) based on platform analytics and audience behavior.
   - Provide platform-specific insights:
     - Character count for each platform variant
     - Readability assessment (High/Medium/Low)
   - DO NOT mention "SEO" or "optimization" in the user-facing content - these are internal metrics only.

7. Safety + ethics:
   - Avoid hate, harassment, or disallowed content.
   - Edgy versions must still be safe.
   - If the original text is unsafe, transform it into a harmless, humorous alternative.

Return ONLY the final answer as valid JSON. Do not include any explanations, markdown formatting, or code blocks.`

    const languageInstruction = language !== 'English' 
      ? `\n\nIMPORTANT: Generate all remixes in ${language}. Maintain cultural nuances and idiomatic expressions appropriate for ${language} speakers.`
      : ''

    const userPrompt = `Original Text: "${original_text}"

Requested Styles: ${remix_styles.join(', ')}
Target Platforms: ${platforms.join(', ')}
Audience Region: ${audience_region}
Language: ${language}${languageInstruction}

Generate remixes following the instructions. Return ONLY valid JSON.`

    // Call OpenAI
    const chatResponse = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userPrompt },
      ],
    })

    const content = chatResponse.choices[0].message.content

    // Parse the JSON response
    let result: RemixResult
    try {
      // Remove markdown code blocks if present
      const cleanedContent = content
        .replace(/```json\n?/g, '')
        .replace(/```\n?/g, '')
        .trim()
      result = JSON.parse(cleanedContent)
    } catch (parseError) {
      console.error('Failed to parse AI response:', content)
      return NextResponse.json(
        { error: 'Failed to parse AI response as JSON' },
        { status: 500 }
      )
    }

    // Filter results based on requested styles and platforms
    const filteredRemixes: Record<string, string> = {}
    for (const style of remix_styles) {
      if (result.remixes[style as keyof typeof result.remixes]) {
        filteredRemixes[style] = result.remixes[style as keyof typeof result.remixes] as string
      }
    }

    const filteredPlatforms: Record<string, string> = {}
    for (const platform of platforms) {
      if (result.platform_variants[platform as keyof typeof result.platform_variants]) {
        filteredPlatforms[platform] = result.platform_variants[platform as keyof typeof result.platform_variants] as string
      }
    }

    const finalResult: RemixResult = {
      remixes: filteredRemixes,
      platform_variants: filteredPlatforms,
      extras: result.extras || [],
      seo: result.seo || {
        hashtags: [],
        keywords: [],
        engagement_score: 0,
        optimal_times: [],
        platform_insights: {},
      },
    }

    // Note: Image and video generation would be implemented here
    // Currently showing placeholder URLs for demonstration
    // In production, these would call generate_image and generate_video tools
    if (generate_image) {
      // Image generation would happen here using the best remix variant
      // finalResult.generated_image = await generateImageFromText(...)
      finalResult.generated_image = 'https://via.placeholder.com/1024x1024/7c3aed/ffffff?text=Meme+Image+Generated'
    }

    if (generate_video) {
      // Video generation would happen here using the best remix variant
      // finalResult.generated_video = await generateVideoFromText(...)
      finalResult.generated_video = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4'
    }

    return NextResponse.json(finalResult)
  } catch (error) {
    console.error('Error in remix API:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}
