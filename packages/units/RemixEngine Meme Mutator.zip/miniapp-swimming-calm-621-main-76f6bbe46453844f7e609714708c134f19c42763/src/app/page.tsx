'use client'
import { useState, useEffect } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Sparkles } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk"
import { useAddMiniApp } from "@/hooks/useAddMiniApp"
import { useQuickAuth } from "@/hooks/useQuickAuth"
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster"
import GeneratorTab from '@/components/tabs/GeneratorTab'
import TemplatesTab from '@/components/tabs/TemplatesTab'
import BatchTab from '@/components/tabs/BatchTab'
import HistoryTab from '@/components/tabs/HistoryTab'
import AnalyticsTab from '@/components/tabs/AnalyticsTab'
import SettingsTab from '@/components/tabs/SettingsTab'
import TrendingTab from '@/components/tabs/TrendingTab'
import ExportTab from '@/components/tabs/ExportTab'

export default function RemixEnginePage(): JSX.Element {
  const { addMiniApp } = useAddMiniApp()
  const isInFarcaster = useIsInFarcaster()
  useQuickAuth(isInFarcaster)
  
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp()
      } catch (error) {
        console.error('Failed to add mini app:', error)
      }
    }
    tryAddMiniApp()
  }, [addMiniApp])
  
  useEffect(() => {
    const initializeFarcaster = async () => {
      try {
        await new Promise(resolve => setTimeout(resolve, 100))
        
        if (document.readyState !== 'complete') {
          await new Promise<void>(resolve => {
            if (document.readyState === 'complete') {
              resolve()
            } else {
              window.addEventListener('load', () => resolve(), { once: true })
            }
          })
        }
        
        await sdk.actions.ready()
        console.log('Farcaster SDK initialized successfully - app fully loaded')
      } catch (error) {
        console.error('Failed to initialize Farcaster SDK:', error)
        
        setTimeout(async () => {
          try {
            await sdk.actions.ready()
            console.log('Farcaster SDK initialized on retry')
          } catch (retryError) {
            console.error('Farcaster SDK retry failed:', retryError)
          }
        }, 1000)
      }
    }
    
    initializeFarcaster()
  }, [])

  return (
    <div className="min-h-screen bg-black text-white p-4 md:p-8 pt-16">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="text-center space-y-2">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              RemixEngine Pro
            </h1>
          </div>
          <p className="text-gray-400 text-lg">
            DreamNet&apos;s ultimate cultural mutation engine — beat every competitor with AI-powered meme creation
          </p>
        </div>

        {/* Main Tabs */}
        <Tabs defaultValue="generator" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 bg-gray-900 border border-gray-800">
            <TabsTrigger value="generator" className="data-[state=active]:bg-purple-600">
              Generator
            </TabsTrigger>
            <TabsTrigger value="templates" className="data-[state=active]:bg-purple-600">
              Templates
            </TabsTrigger>
            <TabsTrigger value="batch" className="data-[state=active]:bg-purple-600">
              Batch
            </TabsTrigger>
            <TabsTrigger value="trending" className="data-[state=active]:bg-purple-600">
              Trending
            </TabsTrigger>
            <TabsTrigger value="history" className="data-[state=active]:bg-purple-600">
              History
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-purple-600">
              Analytics
            </TabsTrigger>
            <TabsTrigger value="export" className="data-[state=active]:bg-purple-600">
              Export
            </TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-purple-600">
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="generator" className="mt-6">
            <GeneratorTab />
          </TabsContent>

          <TabsContent value="templates" className="mt-6">
            <TemplatesTab />
          </TabsContent>

          <TabsContent value="batch" className="mt-6">
            <BatchTab />
          </TabsContent>

          <TabsContent value="trending" className="mt-6">
            <TrendingTab />
          </TabsContent>

          <TabsContent value="history" className="mt-6">
            <HistoryTab />
          </TabsContent>

          <TabsContent value="analytics" className="mt-6">
            <AnalyticsTab />
          </TabsContent>

          <TabsContent value="export" className="mt-6">
            <ExportTab />
          </TabsContent>

          <TabsContent value="settings" className="mt-6">
            <SettingsTab />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
