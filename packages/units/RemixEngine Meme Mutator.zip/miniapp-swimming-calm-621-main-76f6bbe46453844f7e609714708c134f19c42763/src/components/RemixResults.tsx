'use client'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Label } from '@/components/ui/label'
import { Copy, CheckCheck, TrendingUp, Hash, Clock, Image as ImageIcon, Video } from 'lucide-react'
import { toast } from 'sonner'
import type { RemixResult } from '@/types/remix'

interface RemixResultsProps {
  result: RemixResult
}

export default function RemixResults({ result }: RemixResultsProps): JSX.Element {
  const [copiedField, setCopiedField] = useState<string | null>(null)

  const copyToClipboard = async (text: string, field: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text)
      setCopiedField(field)
      toast.success('Copied to clipboard!')
      setTimeout(() => setCopiedField(null), 2000)
    } catch (error) {
      toast.error('Failed to copy')
    }
  }

  const copyAllAsJson = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(result, null, 2))
      toast.success('Full JSON copied to clipboard!')
    } catch (error) {
      toast.error('Failed to copy JSON')
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-white">Remixed Variations</h2>
        <Button
          onClick={copyAllAsJson}
          variant="outline"
          className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
        >
          <Copy className="mr-2 h-4 w-4" />
          Copy Full JSON
        </Button>
      </div>

      {/* Generated Media */}
      {(result.generated_image || result.generated_video) && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {result.generated_image && (
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <ImageIcon className="h-5 w-5 text-purple-400" />
                  Generated Image
                </CardTitle>
              </CardHeader>
              <CardContent>
                <img
                  src={result.generated_image}
                  alt="Generated meme"
                  className="w-full rounded-md border border-gray-700"
                />
                <Button
                  onClick={() => window.open(result.generated_image, '_blank')}
                  className="w-full mt-3 bg-purple-600 hover:bg-purple-700"
                  size="sm"
                >
                  Open Full Size
                </Button>
              </CardContent>
            </Card>
          )}

          {result.generated_video && (
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white flex items-center gap-2">
                  <Video className="h-5 w-5 text-pink-400" />
                  Generated Video
                </CardTitle>
              </CardHeader>
              <CardContent>
                <video
                  src={result.generated_video}
                  controls
                  className="w-full rounded-md border border-gray-700"
                />
                <Button
                  onClick={() => window.open(result.generated_video, '_blank')}
                  className="w-full mt-3 bg-pink-600 hover:bg-pink-700"
                  size="sm"
                >
                  Open Full Size
                </Button>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Style Remixes */}
      {Object.keys(result.remixes).length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Style Variations</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(result.remixes).map(([key, value]: [string, string | undefined]) => (
              value && (
                <div key={key} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-purple-400 text-sm font-semibold uppercase">
                      {key}
                    </Label>
                    <Button
                      onClick={() => copyToClipboard(value, `remix-${key}`)}
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-white"
                    >
                      {copiedField === `remix-${key}` ? (
                        <CheckCheck className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-white bg-gray-800 p-3 rounded-md border border-gray-700">
                    {value}
                  </p>
                </div>
              )
            ))}
          </CardContent>
        </Card>
      )}

      {/* Platform Variants */}
      {Object.keys(result.platform_variants).length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Platform-Specific Variants</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(result.platform_variants).map(([key, value]: [string, string | undefined]) => (
              value && (
                <div key={key} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-blue-400 text-sm font-semibold uppercase">
                      {key}
                    </Label>
                    <Button
                      onClick={() => copyToClipboard(value, `platform-${key}`)}
                      variant="ghost"
                      size="sm"
                      className="text-gray-400 hover:text-white"
                    >
                      {copiedField === `platform-${key}` ? (
                        <CheckCheck className="h-4 w-4" />
                      ) : (
                        <Copy className="h-4 w-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-white bg-gray-800 p-3 rounded-md border border-gray-700">
                    {value}
                  </p>
                </div>
              )
            ))}
          </CardContent>
        </Card>
      )}

      {/* Extra Remixes */}
      {result.extras.length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Bonus Variations</CardTitle>
            <CardDescription className="text-gray-400">
              Extra creative mutations for maximum cultural reach
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {result.extras.map((extra: string, index: number) => (
              <div key={index} className="space-y-2">
                <div className="flex items-center justify-between">
                  <Label className="text-pink-400 text-sm font-semibold">
                    Variation #{index + 1}
                  </Label>
                  <Button
                    onClick={() => copyToClipboard(extra, `extra-${index}`)}
                    variant="ghost"
                    size="sm"
                    className="text-gray-400 hover:text-white"
                  >
                    {copiedField === `extra-${index}` ? (
                      <CheckCheck className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
                <p className="text-white bg-gray-800 p-3 rounded-md border border-gray-700">
                  {extra}
                </p>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      {/* AI SEO Insights */}
      {result.seo && (
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700">
          <CardHeader>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-purple-400" />
              <CardTitle className="text-white">AI SEO Insights</CardTitle>
            </div>
            <CardDescription className="text-gray-300">
              Optimized metadata and engagement analytics for maximum reach
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Trending Hashtags */}
            {result.seo.hashtags && result.seo.hashtags.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Hash className="h-4 w-4 text-purple-400" />
                  <Label className="text-purple-300 font-semibold">Trending Hashtags</Label>
                </div>
                <div className="flex flex-wrap gap-2">
                  {result.seo.hashtags.map((tag: string, idx: number) => (
                    <Badge
                      key={idx}
                      className="bg-purple-600/50 text-white border-purple-500 cursor-pointer hover:bg-purple-600"
                      onClick={() => copyToClipboard(tag, `hashtag-${idx}`)}
                    >
                      {tag}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Keywords */}
            {result.seo.keywords && result.seo.keywords.length > 0 && (
              <div className="space-y-2">
                <Label className="text-purple-300 font-semibold">SEO Keywords</Label>
                <div className="flex flex-wrap gap-2">
                  {result.seo.keywords.map((keyword: string, idx: number) => (
                    <Badge
                      key={idx}
                      variant="outline"
                      className="bg-gray-800/50 text-gray-200 border-purple-600"
                    >
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Engagement Score */}
            {result.seo.engagement_score && (
              <div className="space-y-2">
                <Label className="text-purple-300 font-semibold">Predicted Engagement Score</Label>
                <div className="flex items-center gap-3">
                  <div className="flex-1 bg-gray-800 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all"
                      style={{ width: `${result.seo.engagement_score}%` }}
                    />
                  </div>
                  <span className="text-white font-bold">{result.seo.engagement_score}%</span>
                </div>
              </div>
            )}

            {/* Optimal Posting Times */}
            {result.seo.optimal_times && result.seo.optimal_times.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <Clock className="h-4 w-4 text-purple-400" />
                  <Label className="text-purple-300 font-semibold">Optimal Posting Times</Label>
                </div>
                <div className="flex flex-wrap gap-2">
                  {result.seo.optimal_times.map((time: string, idx: number) => (
                    <Badge
                      key={idx}
                      className="bg-pink-600/50 text-white border-pink-500"
                    >
                      {time}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Platform Insights */}
            {result.seo.platform_insights && Object.keys(result.seo.platform_insights).length > 0 && (
              <div className="space-y-2">
                <Label className="text-purple-300 font-semibold">Platform Analytics</Label>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {Object.entries(result.seo.platform_insights).map(([platform, data]: [string, { char_count: number; readability: string }]) => (
                    <div
                      key={platform}
                      className="bg-gray-800/50 border border-purple-700/30 rounded-lg p-3 space-y-1"
                    >
                      <div className="text-purple-400 font-semibold text-sm">{platform}</div>
                      <div className="text-xs text-gray-300">
                        <span className="text-gray-400">Characters:</span> {data.char_count}
                      </div>
                      <div className="text-xs text-gray-300">
                        <span className="text-gray-400">Readability:</span> {data.readability}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* JSON View */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Full JSON Output</CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="text-xs text-gray-300 bg-gray-800 p-4 rounded-md border border-gray-700 overflow-x-auto">
            {JSON.stringify(result, null, 2)}
          </pre>
        </CardContent>
      </Card>
    </div>
  )
}
