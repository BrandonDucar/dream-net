'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, BarChart3, Zap, Target } from 'lucide-react'
import { getHistory, type HistoryItem } from '@/utils/history'

interface StyleStats {
  style: string
  count: number
  avgEngagement: number
}

interface PlatformStats {
  platform: string
  count: number
  avgEngagement: number
}

export default function AnalyticsTab(): JSX.Element {
  const [totalRemixes, setTotalRemixes] = useState<number>(0)
  const [avgEngagement, setAvgEngagement] = useState<number>(0)
  const [topStyles, setTopStyles] = useState<StyleStats[]>([])
  const [topPlatforms, setTopPlatforms] = useState<PlatformStats[]>([])
  const [topHashtags, setTopHashtags] = useState<string[]>([])

  useEffect(() => {
    analyzeHistory()
  }, [])

  const analyzeHistory = (): void => {
    const history = getHistory()
    
    if (history.length === 0) {
      return
    }

    // Total remixes
    setTotalRemixes(history.length)

    // Average engagement
    const engagementScores = history
      .map(h => h.result.seo?.engagement_score || 0)
      .filter(score => score > 0)
    const avg = engagementScores.length > 0
      ? engagementScores.reduce((a, b) => a + b, 0) / engagementScores.length
      : 0
    setAvgEngagement(Math.round(avg))

    // Style stats
    const styleMap = new Map<string, { count: number; totalEngagement: number }>()
    history.forEach(item => {
      item.settings.styles.forEach(style => {
        const existing = styleMap.get(style) || { count: 0, totalEngagement: 0 }
        styleMap.set(style, {
          count: existing.count + 1,
          totalEngagement: existing.totalEngagement + (item.result.seo?.engagement_score || 0),
        })
      })
    })

    const styleStats: StyleStats[] = Array.from(styleMap.entries())
      .map(([style, data]) => ({
        style,
        count: data.count,
        avgEngagement: data.count > 0 ? Math.round(data.totalEngagement / data.count) : 0,
      }))
      .sort((a, b) => b.avgEngagement - a.avgEngagement)
      .slice(0, 5)

    setTopStyles(styleStats)

    // Platform stats
    const platformMap = new Map<string, { count: number; totalEngagement: number }>()
    history.forEach(item => {
      item.settings.platforms.forEach(platform => {
        const existing = platformMap.get(platform) || { count: 0, totalEngagement: 0 }
        platformMap.set(platform, {
          count: existing.count + 1,
          totalEngagement: existing.totalEngagement + (item.result.seo?.engagement_score || 0),
        })
      })
    })

    const platformStats: PlatformStats[] = Array.from(platformMap.entries())
      .map(([platform, data]) => ({
        platform,
        count: data.count,
        avgEngagement: data.count > 0 ? Math.round(data.totalEngagement / data.count) : 0,
      }))
      .sort((a, b) => b.avgEngagement - a.avgEngagement)

    setTopPlatforms(platformStats)

    // Top hashtags
    const hashtagMap = new Map<string, number>()
    history.forEach(item => {
      item.result.seo?.hashtags?.forEach(tag => {
        hashtagMap.set(tag, (hashtagMap.get(tag) || 0) + 1)
      })
    })

    const topTags = Array.from(hashtagMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([tag]) => tag)

    setTopHashtags(topTags)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Performance Analytics</CardTitle>
          <CardDescription className="text-gray-400">
            Track your remix performance and optimize your content strategy — like Predis.ai analytics
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <Card className="bg-gradient-to-br from-purple-900/30 to-purple-800/30 border-purple-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Total Remixes</p>
                <p className="text-3xl font-bold text-white mt-1">{totalRemixes}</p>
              </div>
              <BarChart3 className="h-12 w-12 text-purple-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-pink-900/30 to-pink-800/30 border-pink-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Avg Engagement</p>
                <p className="text-3xl font-bold text-white mt-1">{avgEngagement}%</p>
              </div>
              <TrendingUp className="h-12 w-12 text-pink-400" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-blue-900/30 to-blue-800/30 border-blue-700">
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-gray-300 text-sm">Best Style</p>
                <p className="text-2xl font-bold text-white mt-1">
                  {topStyles[0]?.style || 'N/A'}
                </p>
              </div>
              <Zap className="h-12 w-12 text-blue-400" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Top Performing Styles */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Top Performing Styles</CardTitle>
          <CardDescription className="text-gray-400">
            Styles ranked by average engagement score
          </CardDescription>
        </CardHeader>
        <CardContent>
          {topStyles.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No data yet. Create some remixes to see analytics!</p>
          ) : (
            <div className="space-y-3">
              {topStyles.map((stat, index) => (
                <div key={stat.style} className="flex items-center justify-between bg-gray-800 p-3 rounded-md border border-gray-700">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-8 h-8 rounded-full bg-purple-600 text-white font-bold text-sm">
                      {index + 1}
                    </div>
                    <div>
                      <p className="text-white font-semibold">{stat.style}</p>
                      <p className="text-xs text-gray-400">Used {stat.count} times</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-xl font-bold text-white">{stat.avgEngagement}%</p>
                    <p className="text-xs text-gray-400">avg engagement</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Platform Performance */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Platform Performance</CardTitle>
          <CardDescription className="text-gray-400">
            See which platforms drive the most engagement
          </CardDescription>
        </CardHeader>
        <CardContent>
          {topPlatforms.length === 0 ? (
            <p className="text-gray-400 text-center py-8">No platform data yet</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {topPlatforms.map((stat) => (
                <div key={stat.platform} className="bg-gray-800 p-4 rounded-md border border-gray-700">
                  <div className="flex items-center justify-between mb-2">
                    <p className="text-white font-semibold">{stat.platform}</p>
                    <Badge className="bg-blue-600/50 text-white border-blue-500">
                      {stat.count}x
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="flex-1 bg-gray-700 rounded-full h-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-blue-500 to-purple-500"
                        style={{ width: `${stat.avgEngagement}%` }}
                      />
                    </div>
                    <span className="text-sm text-white font-semibold">{stat.avgEngagement}%</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Top Hashtags */}
      {topHashtags.length > 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardHeader>
            <CardTitle className="text-white">Most Used Hashtags</CardTitle>
            <CardDescription className="text-gray-400">
              Your most frequently generated hashtags
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {topHashtags.map((tag, index) => (
                <Badge
                  key={index}
                  className="bg-purple-600/50 text-white border-purple-500"
                >
                  {tag}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
