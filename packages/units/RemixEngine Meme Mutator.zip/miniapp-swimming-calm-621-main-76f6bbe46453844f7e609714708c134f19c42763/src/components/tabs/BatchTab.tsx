'use client'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Progress } from '@/components/ui/progress'
import { Loader2, Upload, Download, Sparkles } from 'lucide-react'
import { toast } from 'sonner'
import type { RemixResult } from '@/types/remix'

interface BatchResult {
  text: string
  result: RemixResult
  status: 'pending' | 'processing' | 'success' | 'error'
}

export default function BatchTab(): JSX.Element {
  const [batchTexts, setBatchTexts] = useState<string>('')
  const [processing, setProcessing] = useState<boolean>(false)
  const [results, setResults] = useState<BatchResult[]>([])
  const [progress, setProgress] = useState<number>(0)

  const handleBatchProcess = async (): Promise<void> => {
    const texts = batchTexts
      .split('\n')
      .filter(t => t.trim() !== '')
      .map(t => t.trim())

    if (texts.length === 0) {
      toast.error('Please enter at least one text to process')
      return
    }

    if (texts.length > 50) {
      toast.error('Maximum 50 texts allowed per batch')
      return
    }

    setProcessing(true)
    setProgress(0)

    const batchResults: BatchResult[] = texts.map(text => ({
      text,
      result: {} as RemixResult,
      status: 'pending',
    }))

    setResults(batchResults)

    // Process each text sequentially
    for (let i = 0; i < texts.length; i++) {
      batchResults[i].status = 'processing'
      setResults([...batchResults])

      try {
        const response = await fetch('/api/remix', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            original_text: texts[i],
            remix_styles: ['edgy', 'safe', 'viral'],
            platforms: ['X', 'Farcaster'],
            audience_region: 'Global',
          }),
        })

        if (!response.ok) {
          throw new Error('Failed to generate remix')
        }

        const data: RemixResult = await response.json()
        batchResults[i].result = data
        batchResults[i].status = 'success'
      } catch (error) {
        console.error('Error processing:', texts[i], error)
        batchResults[i].status = 'error'
      }

      setProgress(((i + 1) / texts.length) * 100)
      setResults([...batchResults])
    }

    setProcessing(false)
    toast.success(`Batch processing complete! ${batchResults.filter(r => r.status === 'success').length}/${texts.length} successful`)
  }

  const exportResults = (): void => {
    const csvContent = results
      .filter(r => r.status === 'success')
      .map(r => {
        const row = [
          r.text,
          r.result.remixes.edgy || '',
          r.result.remixes.safe || '',
          r.result.remixes.viral || '',
          r.result.platform_variants.X || '',
          r.result.platform_variants.Farcaster || '',
        ]
        return row.map(cell => `"${cell.replace(/"/g, '""')}"`).join(',')
      })

    const headers = ['Original Text', 'Edgy', 'Safe', 'Viral', 'X', 'Farcaster']
    const csv = [headers.join(','), ...csvContent].join('\n')

    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `remix-batch-${Date.now()}.csv`
    a.click()
    URL.revokeObjectURL(url)

    toast.success('Batch results exported as CSV')
  }

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Batch Processing</CardTitle>
          <CardDescription className="text-gray-400">
            Process up to 50 texts simultaneously — beats Kapwing&apos;s batch capabilities
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="batch-texts" className="text-white">
              Enter texts to process (one per line)
            </Label>
            <Textarea
              id="batch-texts"
              placeholder="Enter each meme or caption on a new line...&#10;Example:&#10;gm builders&#10;Base is the future&#10;Onchain summer never ends"
              value={batchTexts}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setBatchTexts(e.target.value)}
              className="min-h-[200px] bg-gray-800 border-gray-700 text-white placeholder:text-gray-500 font-mono"
            />
            <p className="text-xs text-gray-500">
              {batchTexts.split('\n').filter(t => t.trim() !== '').length} / 50 texts
            </p>
          </div>

          <Button
            onClick={handleBatchProcess}
            disabled={processing || batchTexts.trim() === ''}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            size="lg"
          >
            {processing ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Processing Batch...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-5 w-5" />
                Process Batch
              </>
            )}
          </Button>

          {processing && (
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-gray-400">Progress</span>
                <span className="text-white font-semibold">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </CardContent>
      </Card>

      {/* Results Section */}
      {results.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-bold text-white">Batch Results</h3>
            <Button
              onClick={exportResults}
              disabled={results.filter(r => r.status === 'success').length === 0}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
            >
              <Download className="mr-2 h-4 w-4" />
              Export as CSV
            </Button>
          </div>

          <div className="space-y-4">
            {results.map((result, index) => (
              <Card
                key={index}
                className={`bg-gray-900 border-gray-800 ${
                  result.status === 'success'
                    ? 'border-green-600/50'
                    : result.status === 'error'
                    ? 'border-red-600/50'
                    : result.status === 'processing'
                    ? 'border-purple-600/50'
                    : ''
                }`}
              >
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-white text-sm">
                      {result.text.substring(0, 50)}
                      {result.text.length > 50 ? '...' : ''}
                    </CardTitle>
                    <span
                      className={`text-xs px-2 py-1 rounded ${
                        result.status === 'success'
                          ? 'bg-green-600/20 text-green-400'
                          : result.status === 'error'
                          ? 'bg-red-600/20 text-red-400'
                          : result.status === 'processing'
                          ? 'bg-purple-600/20 text-purple-400'
                          : 'bg-gray-600/20 text-gray-400'
                      }`}
                    >
                      {result.status}
                    </span>
                  </div>
                </CardHeader>
                {result.status === 'success' && result.result.remixes && (
                  <CardContent className="space-y-2">
                    {result.result.remixes.edgy && (
                      <div className="bg-gray-800 p-2 rounded text-xs text-gray-300">
                        <span className="text-purple-400 font-semibold">Edgy:</span> {result.result.remixes.edgy}
                      </div>
                    )}
                    {result.result.remixes.safe && (
                      <div className="bg-gray-800 p-2 rounded text-xs text-gray-300">
                        <span className="text-blue-400 font-semibold">Safe:</span> {result.result.remixes.safe}
                      </div>
                    )}
                    {result.result.remixes.viral && (
                      <div className="bg-gray-800 p-2 rounded text-xs text-gray-300">
                        <span className="text-pink-400 font-semibold">Viral:</span> {result.result.remixes.viral}
                      </div>
                    )}
                  </CardContent>
                )}
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
