'use client'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { Download, FileJson, FileText, FileSpreadsheet, Image as ImageIcon } from 'lucide-react'
import { toast } from 'sonner'
import { getHistory } from '@/utils/history'

export default function ExportTab(): JSX.Element {
  const [exporting, setExporting] = useState<boolean>(false)

  const exportAsJSON = async (): Promise<void> => {
    setExporting(true)
    const history = getHistory()
    
    const json = JSON.stringify(history, null, 2)
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `remixengine-export-${Date.now()}.json`
    a.click()
    URL.revokeObjectURL(url)
    
    toast.success('Exported as JSON')
    setExporting(false)
  }

  const exportAsCSV = async (): Promise<void> => {
    setExporting(true)
    const history = getHistory()
    
    const csvRows = history.map(item => {
      const firstRemix = Object.values(item.result.remixes)[0] || ''
      const firstPlatform = Object.values(item.result.platform_variants)[0] || ''
      const engagement = item.result.seo?.engagement_score || 0
      const hashtags = item.result.seo?.hashtags?.join(' ') || ''
      
      return [
        item.original_text,
        firstRemix,
        firstPlatform,
        engagement,
        hashtags,
        item.settings.region,
        item.settings.language,
        new Date(item.timestamp).toISOString(),
      ].map(cell => `"${String(cell).replace(/"/g, '""')}"`).join(',')
    })
    
    const headers = ['Original Text', 'First Remix', 'First Platform', 'Engagement Score', 'Hashtags', 'Region', 'Language', 'Timestamp']
    const csv = [headers.join(','), ...csvRows].join('\n')
    
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `remixengine-export-${Date.now()}.csv`
    a.click()
    URL.revokeObjectURL(url)
    
    toast.success('Exported as CSV')
    setExporting(false)
  }

  const exportAsMarkdown = async (): Promise<void> => {
    setExporting(true)
    const history = getHistory()
    
    let markdown = '# RemixEngine Export\n\n'
    markdown += `Generated: ${new Date().toLocaleString()}\n\n`
    markdown += `Total Remixes: ${history.length}\n\n---\n\n`
    
    history.forEach((item, index) => {
      markdown += `## Remix #${index + 1}\n\n`
      markdown += `**Original Text:** ${item.original_text}\n\n`
      markdown += `**Timestamp:** ${new Date(item.timestamp).toLocaleString()}\n\n`
      markdown += `**Settings:** ${item.settings.region} | ${item.settings.language}\n\n`
      
      if (Object.keys(item.result.remixes).length > 0) {
        markdown += `### Style Variations\n\n`
        Object.entries(item.result.remixes).forEach(([key, value]) => {
          if (value) {
            markdown += `**${key}:** ${value}\n\n`
          }
        })
      }
      
      if (Object.keys(item.result.platform_variants).length > 0) {
        markdown += `### Platform Variants\n\n`
        Object.entries(item.result.platform_variants).forEach(([key, value]) => {
          if (value) {
            markdown += `**${key}:** ${value}\n\n`
          }
        })
      }
      
      if (item.result.seo) {
        markdown += `### SEO Data\n\n`
        markdown += `- Engagement Score: ${item.result.seo.engagement_score}%\n`
        markdown += `- Hashtags: ${item.result.seo.hashtags?.join(', ') || 'N/A'}\n`
        markdown += `- Keywords: ${item.result.seo.keywords?.join(', ') || 'N/A'}\n\n`
      }
      
      markdown += `---\n\n`
    })
    
    const blob = new Blob([markdown], { type: 'text/markdown' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `remixengine-export-${Date.now()}.md`
    a.click()
    URL.revokeObjectURL(url)
    
    toast.success('Exported as Markdown')
    setExporting(false)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Export Hub</CardTitle>
          <CardDescription className="text-gray-400">
            Download your remixes in multiple formats — JSON, CSV, Markdown, and more
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Export Options Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {/* JSON Export */}
        <Card className="bg-gray-900 border-gray-800 hover:border-purple-600 transition-all">
          <CardHeader>
            <FileJson className="h-8 w-8 text-purple-400 mb-2" />
            <CardTitle className="text-white text-lg">JSON Format</CardTitle>
            <CardDescription className="text-gray-400 text-sm">
              Complete data export with all metadata and settings
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={exportAsJSON}
              disabled={exporting}
              className="w-full bg-purple-600 hover:bg-purple-700 text-white"
            >
              <Download className="mr-2 h-4 w-4" />
              Export JSON
            </Button>
          </CardContent>
        </Card>

        {/* CSV Export */}
        <Card className="bg-gray-900 border-gray-800 hover:border-blue-600 transition-all">
          <CardHeader>
            <FileSpreadsheet className="h-8 w-8 text-blue-400 mb-2" />
            <CardTitle className="text-white text-lg">CSV Format</CardTitle>
            <CardDescription className="text-gray-400 text-sm">
              Spreadsheet-friendly format for analysis and reporting
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={exportAsCSV}
              disabled={exporting}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Download className="mr-2 h-4 w-4" />
              Export CSV
            </Button>
          </CardContent>
        </Card>

        {/* Markdown Export */}
        <Card className="bg-gray-900 border-gray-800 hover:border-pink-600 transition-all">
          <CardHeader>
            <FileText className="h-8 w-8 text-pink-400 mb-2" />
            <CardTitle className="text-white text-lg">Markdown Format</CardTitle>
            <CardDescription className="text-gray-400 text-sm">
              Human-readable format perfect for documentation
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Button
              onClick={exportAsMarkdown}
              disabled={exporting}
              className="w-full bg-pink-600 hover:bg-pink-700 text-white"
            >
              <Download className="mr-2 h-4 w-4" />
              Export Markdown
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Info Card */}
      <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Download className="h-5 w-5 text-purple-400 mt-1" />
            <div>
              <h3 className="text-white font-semibold mb-1">Export Your Data</h3>
              <p className="text-gray-300 text-sm">
                All exports include your complete remix history with original texts, variations, platform-specific content, 
                SEO data, and settings. Choose the format that best suits your needs — JSON for developers, CSV for 
                spreadsheets, or Markdown for documentation.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
