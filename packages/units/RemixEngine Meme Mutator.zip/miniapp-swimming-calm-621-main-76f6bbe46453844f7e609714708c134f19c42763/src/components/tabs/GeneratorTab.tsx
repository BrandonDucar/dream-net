'use client'
import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Loader2, Sparkles, Copy, CheckCheck, MapPin, TrendingUp, Hash, Clock, Image, Video, Download } from 'lucide-react'
import { toast } from 'sonner'
import { detectUserRegion, type GeolocationData } from '@/utils/geolocation'
import { saveToHistory } from '@/utils/history'
import RemixResults from '@/components/RemixResults'
import type { RemixResult } from '@/types/remix'

const REMIX_STYLES = ['edgy', 'safe', 'surreal', 'lore', 'clean', 'spicy', 'viral', 'minimal', 'over-the-top']
const PLATFORMS = ['X', 'Farcaster', 'Instagram', 'TikTok', 'Base']
const REGIONS = ['US', 'EU', 'LATAM', 'Asia', 'Global']
const LANGUAGES = [
  'English', 'Spanish', 'French', 'German', 'Italian', 'Portuguese', 
  'Chinese', 'Japanese', 'Korean', 'Arabic', 'Russian', 'Hindi'
]

export default function GeneratorTab(): JSX.Element {
  const [originalText, setOriginalText] = useState<string>('')
  const [selectedStyles, setSelectedStyles] = useState<string[]>(['edgy', 'safe', 'surreal', 'lore', 'clean'])
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>(['X', 'Farcaster', 'Instagram', 'TikTok', 'Base'])
  const [selectedRegion, setSelectedRegion] = useState<string>('Global')
  const [selectedLanguage, setSelectedLanguage] = useState<string>('English')
  const [generateImage, setGenerateImage] = useState<boolean>(false)
  const [generateVideo, setGenerateVideo] = useState<boolean>(false)
  const [watermarkText, setWatermarkText] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(false)
  const [result, setResult] = useState<RemixResult | null>(null)
  const [geoData, setGeoData] = useState<GeolocationData | null>(null)
  const [detectingLocation, setDetectingLocation] = useState<boolean>(true)

  // Detect user location on mount
  useEffect(() => {
    const detectLocation = async (): Promise<void> => {
      setDetectingLocation(true)
      const data = await detectUserRegion()
      setGeoData(data)
      if (data.detected) {
        setSelectedRegion(data.region)
        toast.success(`Location detected: ${data.country || data.region}`, {
          icon: '📍',
        })
      }
      setDetectingLocation(false)
    }
    detectLocation()
  }, [])

  const toggleStyle = (style: string): void => {
    setSelectedStyles(prev =>
      prev.includes(style) ? prev.filter(s => s !== style) : [...prev, style]
    )
  }

  const togglePlatform = (platform: string): void => {
    setSelectedPlatforms(prev =>
      prev.includes(platform) ? prev.filter(p => p !== platform) : [...prev, platform]
    )
  }

  const handleRemix = async (): Promise<void> => {
    if (!originalText.trim()) {
      toast.error('Please enter some text to remix')
      return
    }

    setLoading(true)
    setResult(null)

    try {
      const response = await fetch('/api/remix', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          original_text: originalText,
          remix_styles: selectedStyles,
          platforms: selectedPlatforms,
          audience_region: selectedRegion,
          language: selectedLanguage,
          generate_image: generateImage,
          generate_video: generateVideo,
          watermark: watermarkText,
        }),
      })

      if (!response.ok) {
        throw new Error('Failed to generate remixes')
      }

      const data: RemixResult = await response.json()
      setResult(data)
      
      // Save to history
      saveToHistory({
        id: Date.now().toString(),
        timestamp: Date.now(),
        original_text: originalText,
        result: data,
        settings: {
          styles: selectedStyles,
          platforms: selectedPlatforms,
          region: selectedRegion,
          language: selectedLanguage,
        },
      })
      
      toast.success('Remixes generated successfully!')
    } catch (error) {
      console.error('Error:', error)
      toast.error('Failed to generate remixes. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Input Section */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Input Your Text</CardTitle>
          <CardDescription className="text-gray-400">
            Enter the meme or caption you want to remix into new cultural variations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Original Text */}
          <div className="space-y-2">
            <Label htmlFor="original-text" className="text-white">Original Text *</Label>
            <Textarea
              id="original-text"
              placeholder="Enter your meme, caption, or text here..."
              value={originalText}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setOriginalText(e.target.value)}
              className="min-h-[120px] bg-gray-800 border-gray-700 text-white placeholder:text-gray-500"
            />
          </div>

          {/* Remix Styles */}
          <div className="space-y-2">
            <Label className="text-white">Remix Styles</Label>
            <div className="flex flex-wrap gap-2">
              {REMIX_STYLES.map((style: string) => (
                <Badge
                  key={style}
                  variant={selectedStyles.includes(style) ? 'default' : 'outline'}
                  className={`cursor-pointer transition-all ${
                    selectedStyles.includes(style)
                      ? 'bg-purple-600 hover:bg-purple-700 text-white'
                      : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
                  }`}
                  onClick={() => toggleStyle(style)}
                >
                  {style}
                </Badge>
              ))}
            </div>
          </div>

          {/* Platforms */}
          <div className="space-y-2">
            <Label className="text-white">Target Platforms</Label>
            <div className="flex flex-wrap gap-2">
              {PLATFORMS.map((platform: string) => (
                <Badge
                  key={platform}
                  variant={selectedPlatforms.includes(platform) ? 'default' : 'outline'}
                  className={`cursor-pointer transition-all ${
                    selectedPlatforms.includes(platform)
                      ? 'bg-blue-600 hover:bg-blue-700 text-white'
                      : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
                  }`}
                  onClick={() => togglePlatform(platform)}
                >
                  {platform}
                </Badge>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Language Selection */}
            <div className="space-y-2">
              <Label htmlFor="language" className="text-white">Language (110+ supported)</Label>
              <select
                id="language"
                value={selectedLanguage}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setSelectedLanguage(e.target.value)}
                className="w-full p-2 bg-gray-800 border border-gray-700 rounded-md text-white"
              >
                {LANGUAGES.map((lang: string) => (
                  <option key={lang} value={lang}>
                    {lang}
                  </option>
                ))}
              </select>
            </div>

            {/* Audience Region */}
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <Label htmlFor="region" className="text-white">Audience Region</Label>
                {geoData?.detected && (
                  <div className="flex items-center gap-1 text-xs text-green-400">
                    <MapPin className="h-3 w-3" />
                    <span>Auto-detected: {geoData.country || geoData.region}</span>
                  </div>
                )}
              </div>
              <select
                id="region"
                value={selectedRegion}
                onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setSelectedRegion(e.target.value)}
                className="w-full p-2 bg-gray-800 border border-gray-700 rounded-md text-white"
                disabled={detectingLocation}
              >
                {REGIONS.map((region: string) => (
                  <option key={region} value={region}>
                    {region}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Advanced Options */}
          <div className="space-y-4 border-t border-gray-800 pt-4">
            <Label className="text-white">Advanced Options</Label>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={generateImage}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setGenerateImage(e.target.checked)}
                  className="w-4 h-4 rounded bg-gray-800 border-gray-700"
                />
                <Image className="h-4 w-4 text-purple-400" />
                <span className="text-white text-sm">Generate Meme Image</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={generateVideo}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setGenerateVideo(e.target.checked)}
                  className="w-4 h-4 rounded bg-gray-800 border-gray-700"
                />
                <Video className="h-4 w-4 text-pink-400" />
                <span className="text-white text-sm">Generate Meme Video</span>
              </label>
            </div>

            {(generateImage || generateVideo) && (
              <div className="space-y-2">
                <Label htmlFor="watermark" className="text-white text-sm">
                  Custom Watermark (optional)
                </Label>
                <input
                  id="watermark"
                  type="text"
                  placeholder="Your brand name or logo text..."
                  value={watermarkText}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWatermarkText(e.target.value)}
                  className="w-full p-2 bg-gray-800 border border-gray-700 rounded-md text-white placeholder:text-gray-500 text-sm"
                />
              </div>
            )}
          </div>

          {/* Submit Button */}
          <Button
            onClick={handleRemix}
            disabled={loading || !originalText.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Remixing...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-5 w-5" />
                Generate Remixes
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Results Section */}
      {result && <RemixResults result={result} />}
    </div>
  )
}
