'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Trash2, Star, Copy, Search } from 'lucide-react'
import { toast } from 'sonner'
import { getHistory, clearHistory, toggleFavorite, type HistoryItem } from '@/utils/history'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

export default function HistoryTab(): JSX.Element {
  const [history, setHistory] = useState<HistoryItem[]>([])
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [filter, setFilter] = useState<'all' | 'favorites'>('all')

  useEffect(() => {
    loadHistory()
  }, [])

  const loadHistory = (): void => {
    const items = getHistory()
    setHistory(items)
  }

  const handleClearHistory = (): void => {
    if (window.confirm('Are you sure you want to clear all history?')) {
      clearHistory()
      loadHistory()
      toast.success('History cleared')
    }
  }

  const handleToggleFavorite = (id: string): void => {
    toggleFavorite(id)
    loadHistory()
  }

  const copyRemix = async (text: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text)
      toast.success('Copied to clipboard!')
    } catch (error) {
      toast.error('Failed to copy')
    }
  }

  const filteredHistory = history
    .filter(item => {
      const matchesSearch = searchQuery === '' || 
        item.original_text.toLowerCase().includes(searchQuery.toLowerCase())
      const matchesFavorite = filter === 'all' || (filter === 'favorites' && item.favorite)
      return matchesSearch && matchesFavorite
    })
    .sort((a, b) => b.timestamp - a.timestamp)

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white">Remix History</CardTitle>
              <CardDescription className="text-gray-400">
                View and manage your past remixes — save favorites for quick access
              </CardDescription>
            </div>
            <Button
              onClick={handleClearHistory}
              variant="outline"
              className="bg-red-600/20 border-red-600 text-red-400 hover:bg-red-600/30"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              Clear All
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search */}
          <div className="space-y-2">
            <Label htmlFor="search" className="text-white">Search History</Label>
            <Input
              id="search"
              placeholder="Search by original text..."
              value={searchQuery}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
            />
          </div>

          {/* Filters */}
          <div className="flex gap-2">
            <Badge
              variant={filter === 'all' ? 'default' : 'outline'}
              className={`cursor-pointer transition-all ${
                filter === 'all'
                  ? 'bg-purple-600 hover:bg-purple-700 text-white'
                  : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
              }`}
              onClick={() => setFilter('all')}
            >
              All ({history.length})
            </Badge>
            <Badge
              variant={filter === 'favorites' ? 'default' : 'outline'}
              className={`cursor-pointer transition-all ${
                filter === 'favorites'
                  ? 'bg-purple-600 hover:bg-purple-700 text-white'
                  : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
              }`}
              onClick={() => setFilter('favorites')}
            >
              <Star className="h-3 w-3 mr-1" />
              Favorites ({history.filter(h => h.favorite).length})
            </Badge>
          </div>
        </CardContent>
      </Card>

      {/* History Items */}
      {filteredHistory.length === 0 ? (
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="py-12 text-center">
            <p className="text-gray-400">
              {searchQuery || filter === 'favorites' ? 'No remixes found' : 'No history yet. Start creating remixes!'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {filteredHistory.map((item) => (
            <Card key={item.id} className="bg-gray-900 border-gray-800">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CardTitle className="text-white text-base">
                        {item.original_text.substring(0, 100)}
                        {item.original_text.length > 100 ? '...' : ''}
                      </CardTitle>
                      <Button
                        onClick={() => handleToggleFavorite(item.id)}
                        variant="ghost"
                        size="sm"
                        className="text-gray-400 hover:text-yellow-400"
                      >
                        <Star
                          className={`h-4 w-4 ${item.favorite ? 'fill-yellow-400 text-yellow-400' : ''}`}
                        />
                      </Button>
                    </div>
                    <CardDescription className="text-gray-400 text-xs">
                      {new Date(item.timestamp).toLocaleString()}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                {/* Settings */}
                <div className="flex flex-wrap gap-2">
                  {item.settings.styles.map(style => (
                    <Badge key={style} className="bg-purple-600/50 text-white border-purple-500 text-xs">
                      {style}
                    </Badge>
                  ))}
                  {item.settings.platforms.map(platform => (
                    <Badge key={platform} className="bg-blue-600/50 text-white border-blue-500 text-xs">
                      {platform}
                    </Badge>
                  ))}
                  <Badge className="bg-gray-600/50 text-white border-gray-500 text-xs">
                    {item.settings.region}
                  </Badge>
                  <Badge className="bg-green-600/50 text-white border-green-500 text-xs">
                    {item.settings.language}
                  </Badge>
                </div>

                {/* Sample Remixes */}
                {item.result.remixes && Object.keys(item.result.remixes).length > 0 && (
                  <div className="space-y-2">
                    {Object.entries(item.result.remixes).slice(0, 2).map(([key, value]: [string, string | undefined]) => (
                      value && (
                        <div key={key} className="bg-gray-800 p-2 rounded-md border border-gray-700 flex items-center justify-between">
                          <div className="flex-1">
                            <p className="text-xs text-purple-400 font-semibold uppercase mb-1">{key}</p>
                            <p className="text-xs text-gray-300">{value}</p>
                          </div>
                          <Button
                            onClick={() => copyRemix(value)}
                            variant="ghost"
                            size="sm"
                            className="ml-2"
                          >
                            <Copy className="h-3 w-3" />
                          </Button>
                        </div>
                      )
                    ))}
                  </div>
                )}

                {/* Engagement Score */}
                {item.result.seo?.engagement_score && (
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-400">Engagement Score:</span>
                    <div className="flex-1 bg-gray-800 rounded-full h-2 overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-purple-500 to-pink-500"
                        style={{ width: `${item.result.seo.engagement_score}%` }}
                      />
                    </div>
                    <span className="text-xs text-white font-semibold">{item.result.seo.engagement_score}%</span>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
