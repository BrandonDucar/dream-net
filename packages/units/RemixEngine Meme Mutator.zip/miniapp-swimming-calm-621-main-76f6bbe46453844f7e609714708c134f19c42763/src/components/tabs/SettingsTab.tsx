'use client'
import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Label } from '@/components/ui/label'
import { Input } from '@/components/ui/input'
import { Button } from '@/components/ui/button'
import { Textarea } from '@/components/ui/textarea'
import { Settings, Save, RefreshCw } from 'lucide-react'
import { toast } from 'sonner'

interface BrandVoice {
  name: string
  description: string
  tone: string
  keywords: string[]
  examples: string[]
}

export default function SettingsTab(): JSX.Element {
  const [brandVoice, setBrandVoice] = useState<BrandVoice>({
    name: 'DreamNet Default',
    description: 'Default DreamNet cultural mutation voice',
    tone: 'innovative, onchain-native, community-driven',
    keywords: ['culture', 'onchain', 'Base', 'builders', 'mutation'],
    examples: [
      'gm builders — time to mutate some culture',
      'Your favorite protocol just went onchain',
    ],
  })

  const [watermark, setWatermark] = useState<string>('DreamNet')
  const [saving, setSaving] = useState<boolean>(false)

  useEffect(() => {
    // Load settings from localStorage
    const savedBrandVoice = localStorage.getItem('remixengine_brand_voice')
    const savedWatermark = localStorage.getItem('remixengine_watermark')
    
    if (savedBrandVoice) {
      setBrandVoice(JSON.parse(savedBrandVoice))
    }
    if (savedWatermark) {
      setWatermark(savedWatermark)
    }
  }, [])

  const handleSaveSettings = (): void => {
    setSaving(true)
    
    localStorage.setItem('remixengine_brand_voice', JSON.stringify(brandVoice))
    localStorage.setItem('remixengine_watermark', watermark)
    
    setTimeout(() => {
      toast.success('Settings saved successfully!')
      setSaving(false)
    }, 500)
  }

  const handleResetSettings = (): void => {
    if (window.confirm('Are you sure you want to reset all settings to defaults?')) {
      localStorage.removeItem('remixengine_brand_voice')
      localStorage.removeItem('remixengine_watermark')
      
      setBrandVoice({
        name: 'DreamNet Default',
        description: 'Default DreamNet cultural mutation voice',
        tone: 'innovative, onchain-native, community-driven',
        keywords: ['culture', 'onchain', 'Base', 'builders', 'mutation'],
        examples: [
          'gm builders — time to mutate some culture',
          'Your favorite protocol just went onchain',
        ],
      })
      setWatermark('DreamNet')
      
      toast.success('Settings reset to defaults')
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white flex items-center gap-2">
            <Settings className="h-5 w-5 text-purple-400" />
            Settings & Brand Voice
          </CardTitle>
          <CardDescription className="text-gray-400">
            Customize RemixEngine to match your brand — train custom style profiles
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Brand Voice Training */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Brand Voice Profile</CardTitle>
          <CardDescription className="text-gray-400">
            Train RemixEngine to match your unique brand voice and style
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="voice-name" className="text-white">Voice Name</Label>
            <Input
              id="voice-name"
              value={brandVoice.name}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                setBrandVoice({ ...brandVoice, name: e.target.value })
              }
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="e.g., DreamNet Brand Voice"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="voice-description" className="text-white">Description</Label>
            <Textarea
              id="voice-description"
              value={brandVoice.description}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                setBrandVoice({ ...brandVoice, description: e.target.value })
              }
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Describe your brand voice..."
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="voice-tone" className="text-white">Tone & Style</Label>
            <Input
              id="voice-tone"
              value={brandVoice.tone}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                setBrandVoice({ ...brandVoice, tone: e.target.value })
              }
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="e.g., innovative, onchain-native, community-driven"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="voice-keywords" className="text-white">Brand Keywords (comma-separated)</Label>
            <Input
              id="voice-keywords"
              value={brandVoice.keywords.join(', ')}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                setBrandVoice({ ...brandVoice, keywords: e.target.value.split(',').map(k => k.trim()) })
              }
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="e.g., culture, onchain, Base, builders"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="voice-examples" className="text-white">Example Messages (one per line)</Label>
            <Textarea
              id="voice-examples"
              value={brandVoice.examples.join('\n')}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                setBrandVoice({ ...brandVoice, examples: e.target.value.split('\n').filter(ex => ex.trim() !== '') })
              }
              className="bg-gray-800 border-gray-700 text-white font-mono"
              placeholder="Add example messages that represent your brand voice..."
              rows={5}
            />
          </div>
        </CardContent>
      </Card>

      {/* Watermark Settings */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Default Watermark</CardTitle>
          <CardDescription className="text-gray-400">
            Set your default watermark text for generated images and videos
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="watermark" className="text-white">Watermark Text</Label>
            <Input
              id="watermark"
              value={watermark}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWatermark(e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
              placeholder="Your brand name or handle..."
            />
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex gap-3">
        <Button
          onClick={handleSaveSettings}
          disabled={saving}
          className="flex-1 bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
          size="lg"
        >
          {saving ? (
            <>
              <Save className="mr-2 h-5 w-5 animate-pulse" />
              Saving...
            </>
          ) : (
            <>
              <Save className="mr-2 h-5 w-5" />
              Save Settings
            </>
          )}
        </Button>

        <Button
          onClick={handleResetSettings}
          variant="outline"
          className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
          size="lg"
        >
          <RefreshCw className="mr-2 h-5 w-5" />
          Reset to Defaults
        </Button>
      </div>

      {/* Info Card */}
      <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <Settings className="h-5 w-5 text-purple-400 mt-1" />
            <div>
              <h3 className="text-white font-semibold mb-1">Custom Brand Voice</h3>
              <p className="text-gray-300 text-sm">
                Train RemixEngine to understand your brand&apos;s unique voice and style. Provide examples, keywords, 
                and tone descriptors to ensure all generated remixes match your brand identity. Your custom voice profile 
                will be applied to all future generations.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
