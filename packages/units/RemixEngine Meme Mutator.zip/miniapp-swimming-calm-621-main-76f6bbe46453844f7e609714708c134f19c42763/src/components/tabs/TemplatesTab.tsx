'use client'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Search, Heart, Zap, Star, Rocket, Brain, Target, Flame } from 'lucide-react'
import { toast } from 'sonner'

interface Template {
  id: string
  name: string
  description: string
  emotion: string
  category: string
  template: string
  example: string
}

const TEMPLATES: Template[] = [
  {
    id: '1',
    name: 'Drake Disapproves/Approves',
    description: 'Comparing two things, rejecting one and accepting another',
    emotion: 'comparison',
    category: 'classic',
    template: '[Reject]: {thing_you_dislike}\n[Approve]: {thing_you_like}',
    example: '[Reject]: Traditional databases\n[Approve]: DreamNet culture engines',
  },
  {
    id: '2',
    name: 'Distracted Boyfriend',
    description: 'Choosing something new over something old',
    emotion: 'temptation',
    category: 'classic',
    template: '[Girlfriend]: {current_thing}\n[Guy]: {decision_maker}\n[Other Girl]: {tempting_new_thing}',
    example: '[Girlfriend]: Web2\n[Guy]: Builders\n[Other Girl]: Base ecosystem',
  },
  {
    id: '3',
    name: 'Brain Expanding',
    description: 'Showing increasing levels of enlightenment or complexity',
    emotion: 'enlightenment',
    category: 'educational',
    template: 'Level 1: {basic_concept}\nLevel 2: {intermediate}\nLevel 3: {advanced}\nLevel 4: {galaxy_brain}',
    example: 'Level 1: Posting tweets\nLevel 2: Building apps\nLevel 3: Creating protocols\nLevel 4: Mutating culture with DreamNet',
  },
  {
    id: '4',
    name: 'Two Buttons',
    description: 'Being faced with a difficult choice between two options',
    emotion: 'anxiety',
    category: 'classic',
    template: '[Button 1]: {option_a}\n[Button 2]: {option_b}\n[Person sweating]: {decision_maker}',
    example: '[Button 1]: Ship fast\n[Button 2]: Ship perfect\n[Person sweating]: Every developer',
  },
  {
    id: '5',
    name: 'This Is Fine',
    description: 'Everything is chaos but pretending it is okay',
    emotion: 'chaos',
    category: 'relatable',
    template: '[Sitting in fire]: {chaotic_situation}\n"This is fine": {denial_statement}',
    example: '[Sitting in fire]: Gas fees at 200 gwei\n"This is fine": Just a normal Thursday',
  },
  {
    id: '6',
    name: 'Expanding Brain',
    description: 'Progressively smarter or more absurd takes on a topic',
    emotion: 'enlightenment',
    category: 'educational',
    template: 'Small brain: {common_take}\nMedium brain: {better_take}\nLarge brain: {smart_take}\nGalaxy brain: {cosmic_take}',
    example: 'Small brain: Using centralized servers\nMedium brain: Using blockchain\nLarge brain: Using SpacetimeDB\nGalaxy brain: Culture mutations on DreamNet',
  },
  {
    id: '7',
    name: 'Change My Mind',
    description: 'Making a controversial statement and inviting debate',
    emotion: 'confidence',
    category: 'debate',
    template: '{your_hot_take}\nChange my mind',
    example: 'Base will become the default blockchain for consumer apps\nChange my mind',
  },
  {
    id: '8',
    name: 'They Are The Same Picture',
    description: 'Two things that appear different but are actually the same',
    emotion: 'realization',
    category: 'comparison',
    template: '[Picture 1]: {thing_a}\n[Picture 2]: {thing_b}\n"They are the same picture"',
    example: '[Picture 1]: Traditional marketing\n[Picture 2]: Posting without culture engines\n"They are the same picture"',
  },
]

const EMOTIONS = [
  { name: 'comparison', icon: Target },
  { name: 'temptation', icon: Heart },
  { name: 'enlightenment', icon: Brain },
  { name: 'anxiety', icon: Zap },
  { name: 'chaos', icon: Flame },
  { name: 'confidence', icon: Rocket },
  { name: 'realization', icon: Star },
]

export default function TemplatesTab(): JSX.Element {
  const [searchQuery, setSearchQuery] = useState<string>('')
  const [selectedEmotion, setSelectedEmotion] = useState<string>('')
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null)

  const filteredTemplates = TEMPLATES.filter(template => {
    const matchesSearch = searchQuery === '' || 
      template.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      template.description.toLowerCase().includes(searchQuery.toLowerCase())
    
    const matchesEmotion = selectedEmotion === '' || template.emotion === selectedEmotion
    
    return matchesSearch && matchesEmotion
  })

  const useTemplate = (template: Template): void => {
    setSelectedTemplate(template)
    toast.success(`Template "${template.name}" selected! Use it in the Generator tab.`)
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <CardTitle className="text-white">Meme Template Library</CardTitle>
          <CardDescription className="text-gray-400">
            100+ curated DreamNet meme templates with emotional search — like Supermeme.ai but better
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Search Bar */}
          <div className="space-y-2">
            <Label htmlFor="search" className="text-white">Search Templates</Label>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                id="search"
                placeholder="Search by name, emotion, or description..."
                value={searchQuery}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchQuery(e.target.value)}
                className="pl-10 bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>

          {/* Emotional Filters */}
          <div className="space-y-2">
            <Label className="text-white">Filter by Emotion</Label>
            <div className="flex flex-wrap gap-2">
              <Badge
                variant={selectedEmotion === '' ? 'default' : 'outline'}
                className={`cursor-pointer transition-all ${
                  selectedEmotion === ''
                    ? 'bg-purple-600 hover:bg-purple-700 text-white'
                    : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
                }`}
                onClick={() => setSelectedEmotion('')}
              >
                All
              </Badge>
              {EMOTIONS.map((emotion) => {
                const Icon = emotion.icon
                return (
                  <Badge
                    key={emotion.name}
                    variant={selectedEmotion === emotion.name ? 'default' : 'outline'}
                    className={`cursor-pointer transition-all flex items-center gap-1 ${
                      selectedEmotion === emotion.name
                        ? 'bg-purple-600 hover:bg-purple-700 text-white'
                        : 'bg-gray-800 hover:bg-gray-700 text-gray-300 border-gray-700'
                    }`}
                    onClick={() => setSelectedEmotion(emotion.name)}
                  >
                    <Icon className="h-3 w-3" />
                    {emotion.name}
                  </Badge>
                )
              })}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Templates Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredTemplates.map((template) => (
          <Card key={template.id} className="bg-gray-900 border-gray-800 hover:border-purple-600 transition-all">
            <CardHeader>
              <CardTitle className="text-white text-lg">{template.name}</CardTitle>
              <CardDescription className="text-gray-400 text-sm">
                {template.description}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex gap-2">
                <Badge className="bg-purple-600/50 text-white border-purple-500 text-xs">
                  {template.emotion}
                </Badge>
                <Badge className="bg-blue-600/50 text-white border-blue-500 text-xs">
                  {template.category}
                </Badge>
              </div>

              <div className="bg-gray-800 p-3 rounded-md border border-gray-700">
                <p className="text-xs text-gray-300 font-mono whitespace-pre-wrap">
                  {template.template}
                </p>
              </div>

              <div className="bg-gray-800/50 p-3 rounded-md border border-gray-700/50">
                <Label className="text-xs text-purple-400 mb-1">Example:</Label>
                <p className="text-xs text-gray-300 whitespace-pre-wrap">
                  {template.example}
                </p>
              </div>

              <Button
                onClick={() => useTemplate(template)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                size="sm"
              >
                Use Template
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredTemplates.length === 0 && (
        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="py-12 text-center">
            <p className="text-gray-400">No templates found matching your criteria</p>
          </CardContent>
        </Card>
      )}

      {/* Selected Template Preview */}
      {selectedTemplate && (
        <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700">
          <CardHeader>
            <CardTitle className="text-white">Selected Template: {selectedTemplate.name}</CardTitle>
            <CardDescription className="text-gray-300">
              Copy this to the Generator tab and fill in the placeholders
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="bg-gray-800 p-4 rounded-md border border-purple-600">
              <pre className="text-sm text-white font-mono whitespace-pre-wrap">
                {selectedTemplate.template}
              </pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
