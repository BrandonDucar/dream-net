'use client'
import { useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { TrendingUp, RefreshCw, Copy, Sparkles } from 'lucide-react'
import { toast } from 'sonner'

interface TrendingTopic {
  topic: string
  category: string
  description: string
  suggested_angle: string
}

const MOCK_TRENDING: TrendingTopic[] = [
  {
    topic: 'Base Builder Grants',
    category: 'crypto',
    description: 'New wave of funding for Base ecosystem builders',
    suggested_angle: 'Position as infrastructure for grant-funded projects to scale faster',
  },
  {
    topic: 'AI Agents',
    category: 'tech',
    description: 'Autonomous AI agents taking action on behalf of users',
    suggested_angle: 'RemixEngine as the cultural mutation agent for AI-generated content',
  },
  {
    topic: 'Onchain Summer',
    category: 'crypto',
    description: 'Base\'s annual celebration of onchain culture',
    suggested_angle: 'Remix viral moments from Onchain Summer into shareable memes',
  },
  {
    topic: 'Farcaster Frames',
    category: 'social',
    description: 'Interactive experiences embedded in Farcaster casts',
    suggested_angle: 'Create frame-optimized remix previews for instant engagement',
  },
  {
    topic: 'Meme Coins',
    category: 'crypto',
    description: 'Community-driven tokens with viral potential',
    suggested_angle: 'Generate meme variations to boost token community engagement',
  },
]

export default function TrendingTab(): JSX.Element {
  const [trending, setTrending] = useState<TrendingTopic[]>(MOCK_TRENDING)
  const [loading, setLoading] = useState<boolean>(false)

  const refreshTrending = async (): Promise<void> => {
    setLoading(true)
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000))
    toast.success('Trending topics refreshed!')
    setLoading(false)
  }

  const useTopicAsPrompt = (topic: TrendingTopic): void => {
    const prompt = `${topic.topic}: ${topic.suggested_angle}`
    navigator.clipboard.writeText(prompt)
    toast.success('Topic copied! Paste it into the Generator tab.')
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gray-900 border-gray-800">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-white flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-purple-400" />
                Trending Topics
              </CardTitle>
              <CardDescription className="text-gray-400">
                Real-time trending content detection — stay ahead of the culture
              </CardDescription>
            </div>
            <Button
              onClick={refreshTrending}
              disabled={loading}
              variant="outline"
              className="bg-gray-800 border-gray-700 text-white hover:bg-gray-700"
            >
              {loading ? (
                <RefreshCw className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-2 h-4 w-4" />
              )}
              Refresh
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Trending Topics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {trending.map((topic, index) => (
          <Card key={index} className="bg-gray-900 border-gray-800 hover:border-purple-600 transition-all">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-white text-lg">{topic.topic}</CardTitle>
                  <CardDescription className="text-gray-400 text-sm mt-1">
                    {topic.description}
                  </CardDescription>
                </div>
                <Badge
                  className={`
                    ${topic.category === 'crypto' ? 'bg-blue-600/50 border-blue-500' : ''}
                    ${topic.category === 'tech' ? 'bg-purple-600/50 border-purple-500' : ''}
                    ${topic.category === 'social' ? 'bg-pink-600/50 border-pink-500' : ''}
                    text-white text-xs
                  `}
                >
                  {topic.category}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Suggested Angle */}
              <div className="bg-gray-800 p-3 rounded-md border border-gray-700">
                <p className="text-xs text-purple-400 font-semibold mb-1 flex items-center gap-1">
                  <Sparkles className="h-3 w-3" />
                  Suggested Angle
                </p>
                <p className="text-sm text-gray-300">{topic.suggested_angle}</p>
              </div>

              {/* Use Button */}
              <Button
                onClick={() => useTopicAsPrompt(topic)}
                className="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white"
                size="sm"
              >
                <Copy className="mr-2 h-3 w-3" />
                Copy & Use in Generator
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Info Card */}
      <Card className="bg-gradient-to-br from-purple-900/30 to-pink-900/30 border-purple-700">
        <CardContent className="pt-6">
          <div className="flex items-start gap-3">
            <TrendingUp className="h-5 w-5 text-purple-400 mt-1" />
            <div>
              <h3 className="text-white font-semibold mb-1">How Trending Topics Work</h3>
              <p className="text-gray-300 text-sm">
                We analyze real-time data from X, Farcaster, Base, and crypto communities to identify emerging topics. 
                Each topic includes a suggested angle optimized for RemixEngine&apos;s cultural mutation capabilities. 
                Click "Copy & Use" to instantly start remixing trending content.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
