export interface SEOData {
  hashtags: string[]
  keywords: string[]
  engagement_score: number
  optimal_times: string[]
  platform_insights: Record<string, { char_count: number; readability: string }>
}

export interface RemixResult {
  remixes: {
    edgy?: string
    safe?: string
    surreal?: string
    lore?: string
    clean?: string
    spicy?: string
    viral?: string
    minimal?: string
    'over-the-top'?: string
  }
  platform_variants: {
    X?: string
    Farcaster?: string
    Instagram?: string
    TikTok?: string
    Base?: string
  }
  extras: string[]
  seo: SEOData
  generated_image?: string
  generated_video?: string
}
