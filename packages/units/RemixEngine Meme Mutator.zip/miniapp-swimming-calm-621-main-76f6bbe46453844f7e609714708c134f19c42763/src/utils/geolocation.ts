export interface GeolocationData {
  region: 'US' | 'EU' | 'LATAM' | 'Asia' | 'Global'
  country?: string
  detected: boolean
}

export async function detectUserRegion(): Promise<GeolocationData> {
  try {
    // Try IP-based geolocation first
    const response = await fetch('https://ipapi.co/json/', {
      signal: AbortSignal.timeout(3000), // 3 second timeout
    })

    if (!response.ok) {
      throw new Error('Geolocation API failed')
    }

    const data = await response.json()
    const country: string = data.country_code || 'UNKNOWN'
    const continent: string = data.continent_code || 'UNKNOWN'

    // Map country/continent to regions
    let region: GeolocationData['region'] = 'Global'

    if (country === 'US' || country === 'CA') {
      region = 'US'
    } else if (continent === 'EU' || ['GB', 'DE', 'FR', 'IT', 'ES', 'NL', 'BE', 'SE', 'NO', 'DK', 'FI', 'PL', 'CH', 'AT'].includes(country)) {
      region = 'EU'
    } else if (continent === 'SA' || ['MX', 'AR', 'BR', 'CL', 'CO', 'PE', 'VE', 'CR', 'PA'].includes(country)) {
      region = 'LATAM'
    } else if (continent === 'AS' || ['CN', 'JP', 'KR', 'IN', 'TH', 'VN', 'PH', 'ID', 'MY', 'SG', 'TW', 'HK'].includes(country)) {
      region = 'Asia'
    }

    return {
      region,
      country: data.country_name || undefined,
      detected: true,
    }
  } catch (error) {
    console.error('Geolocation detection failed:', error)
    // Fallback to Global
    return {
      region: 'Global',
      detected: false,
    }
  }
}
