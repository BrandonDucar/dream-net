import type { RemixResult } from '@/types/remix'

export interface HistoryItem {
  id: string
  timestamp: number
  original_text: string
  result: RemixResult
  settings: {
    styles: string[]
    platforms: string[]
    region: string
    language: string
  }
  favorite?: boolean
}

const HISTORY_KEY = 'remixengine_history'
const MAX_HISTORY_ITEMS = 100

export function getHistory(): HistoryItem[] {
  if (typeof window === 'undefined') return []
  
  try {
    const stored = localStorage.getItem(HISTORY_KEY)
    if (!stored) return []
    
    const history: HistoryItem[] = JSON.parse(stored)
    return history.sort((a, b) => b.timestamp - a.timestamp)
  } catch (error) {
    console.error('Failed to load history:', error)
    return []
  }
}

export function saveToHistory(item: HistoryItem): void {
  if (typeof window === 'undefined') return
  
  try {
    const history = getHistory()
    
    // Add new item
    history.unshift(item)
    
    // Keep only the most recent items
    const trimmedHistory = history.slice(0, MAX_HISTORY_ITEMS)
    
    localStorage.setItem(HISTORY_KEY, JSON.stringify(trimmedHistory))
  } catch (error) {
    console.error('Failed to save to history:', error)
  }
}

export function clearHistory(): void {
  if (typeof window === 'undefined') return
  
  try {
    localStorage.removeItem(HISTORY_KEY)
  } catch (error) {
    console.error('Failed to clear history:', error)
  }
}

export function toggleFavorite(id: string): void {
  if (typeof window === 'undefined') return
  
  try {
    const history = getHistory()
    const item = history.find(h => h.id === id)
    
    if (item) {
      item.favorite = !item.favorite
      localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
    }
  } catch (error) {
    console.error('Failed to toggle favorite:', error)
  }
}

export function deleteHistoryItem(id: string): void {
  if (typeof window === 'undefined') return
  
  try {
    const history = getHistory().filter(h => h.id !== id)
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history))
  } catch (error) {
    console.error('Failed to delete history item:', error)
  }
}
