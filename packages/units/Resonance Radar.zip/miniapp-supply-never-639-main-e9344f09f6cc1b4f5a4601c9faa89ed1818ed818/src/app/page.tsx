'use client'
import { useState, useEffect } from 'react';
import { OverviewScreen } from '@/components/resonance/overview-screen';
import { UnitFormScreen } from '@/components/resonance/unit-form-screen';
import { UnitDetailScreen } from '@/components/resonance/unit-detail-screen';
import { PortfolioView } from '@/components/resonance/portfolio-view';
import { ComparisonView } from '@/components/resonance/comparison-view';
import { IntegrationsSettings } from '@/components/IntegrationsSettings';
import { AlertsDashboard } from '@/components/AlertsDashboard';
import { getAllUnits, getAllSnapshots, getAllSummaries } from '@/lib/resonance-storage';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";
import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

type Screen = 
  | { type: 'overview' }
  | { type: 'create' }
  | { type: 'edit'; unitId: string }
  | { type: 'detail'; unitId: string }
  | { type: 'portfolio' }
  | { type: 'comparison' }
  | { type: 'integrations' }
  | { type: 'alerts' };

export default function ResonanceRadarPage(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentScreen, setCurrentScreen] = useState<Screen>({ type: 'overview' });

  const navigateToOverview = (): void => {
    setCurrentScreen({ type: 'overview' });
  };

  const navigateToCreate = (): void => {
    setCurrentScreen({ type: 'create' });
  };

  const navigateToEdit = (unitId: string): void => {
    setCurrentScreen({ type: 'edit', unitId });
  };

  const navigateToDetail = (unitId: string): void => {
    setCurrentScreen({ type: 'detail', unitId });
  };

  const navigateToPortfolio = (): void => {
    setCurrentScreen({ type: 'portfolio' });
  };

  const navigateToComparison = (): void => {
    setCurrentScreen({ type: 'comparison' });
  };

  const navigateToIntegrations = (): void => {
    setCurrentScreen({ type: 'integrations' });
  };

  const navigateToAlerts = (): void => {
    setCurrentScreen({ type: 'alerts' });
  };

  const handleSaveUnit = (): void => {
    // After save, redirect to overview
    navigateToOverview();
  };

  return (
    <main className="min-h-screen bg-white">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {currentScreen.type === 'overview' && (
          <OverviewScreen
            onCreateUnit={navigateToCreate}
            onViewUnit={navigateToDetail}
            onViewPortfolio={navigateToPortfolio}
            onViewComparison={navigateToComparison}
            onViewIntegrations={navigateToIntegrations}
            onViewAlerts={navigateToAlerts}
          />
        )}

        {currentScreen.type === 'create' && (
          <UnitFormScreen
            unitId={null}
            onBack={navigateToOverview}
            onSave={handleSaveUnit}
          />
        )}

        {currentScreen.type === 'edit' && (
          <UnitFormScreen
            unitId={currentScreen.unitId}
            onBack={() => navigateToDetail(currentScreen.unitId)}
            onSave={() => navigateToDetail(currentScreen.unitId)}
          />
        )}

        {currentScreen.type === 'detail' && (
          <UnitDetailScreen
            unitId={currentScreen.unitId}
            onBack={navigateToOverview}
            onEdit={navigateToEdit}
          />
        )}

        {currentScreen.type === 'portfolio' && (
          <PortfolioView
            units={getAllUnits()}
            summaries={getAllSummaries()}
            snapshots={getAllSnapshots()}
            onBack={navigateToOverview}
          />
        )}

        {currentScreen.type === 'comparison' && (
          <ComparisonView
            units={getAllUnits()}
            summaries={getAllSummaries()}
            snapshots={getAllSnapshots()}
            onBack={navigateToOverview}
          />
        )}

        {currentScreen.type === 'integrations' && (
          <div className="space-y-4">
            <Button variant="ghost" onClick={navigateToOverview}>
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <IntegrationsSettings />
          </div>
        )}

        {currentScreen.type === 'alerts' && (
          <div className="space-y-4">
            <Button variant="ghost" onClick={navigateToOverview}>
              <ArrowLeft className="h-5 w-5 mr-2" />
              Back
            </Button>
            <AlertsDashboard />
          </div>
        )}
      </div>
    </main>
  );
}
