'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, TrendingUp, AlertTriangle, Target, Zap } from 'lucide-react';
import {
  loadAIInsightsForUnit,
  generateAIInsights,
  saveAIInsights,
  type AIInsight,
} from '@/lib/ai-insights';
import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/lib/types';

interface AIInsightsPanelProps {
  unit: TrackedUnit;
  snapshots: MetricsSnapshot[];
  summary: ResonanceSummary;
}

export function AIInsightsPanel({ unit, snapshots, summary }: AIInsightsPanelProps): JSX.Element {
  const [insights, setInsights] = useState<AIInsight[]>([]);

  useEffect(() => {
    loadInsights();
  }, [unit.id]);

  const loadInsights = (): void => {
    let loaded = loadAIInsightsForUnit(unit.id);
    
    // Generate new insights if none exist
    if (loaded.length === 0 && snapshots.length > 0) {
      const newInsights = generateAIInsights(unit, snapshots, summary);
      if (newInsights.length > 0) {
        saveAIInsights(newInsights);
        loaded = newInsights;
      }
    }
    
    setInsights(loaded);
  };

  const getInsightIcon = (type: AIInsight['type']): JSX.Element => {
    switch (type) {
      case 'opportunity':
        return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'warning':
        return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      case 'optimization':
        return <Target className="h-4 w-4 text-blue-600" />;
      case 'trend':
        return <Zap className="h-4 w-4 text-purple-600" />;
      default:
        return <Lightbulb className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getTypeColor = (type: AIInsight['type']): string => {
    switch (type) {
      case 'opportunity': return 'bg-green-100 text-green-800 border-green-300';
      case 'warning': return 'bg-orange-100 text-orange-800 border-orange-300';
      case 'optimization': return 'bg-blue-100 text-blue-800 border-blue-300';
      case 'trend': return 'bg-purple-100 text-purple-800 border-purple-300';
      default: return 'bg-yellow-100 text-yellow-800 border-yellow-300';
    }
  };

  if (insights.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Lightbulb className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p>No insights yet</p>
          <p className="text-sm mt-2">
            Add more metrics to get AI-powered recommendations
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Lightbulb className="h-5 w-5" />
        <h3 className="text-lg font-semibold">AI Insights</h3>
      </div>

      <div className="space-y-3">
        {insights.map((insight: AIInsight) => (
          <Card key={insight.id} className="border-l-4">
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-2">
                  {getInsightIcon(insight.type)}
                  <CardTitle className="text-base">{insight.title}</CardTitle>
                </div>
                <div className="flex gap-2 items-center">
                  <Badge variant="outline" className={getTypeColor(insight.type)}>
                    {insight.type}
                  </Badge>
                  <Badge variant="secondary">
                    {(insight.confidence * 100).toFixed(0)}% confident
                  </Badge>
                </div>
              </div>
            </CardHeader>
            <CardContent className="space-y-3">
              <p className="text-sm">{insight.description}</p>

              {insight.actionItems.length > 0 && (
                <div className="border-t pt-3">
                  <p className="text-xs font-semibold mb-2">Recommended Actions:</p>
                  <ul className="space-y-1">
                    {insight.actionItems.map((action: string, idx: number) => (
                      <li key={idx} className="text-xs flex items-start gap-2">
                        <span className="text-primary mt-0.5">→</span>
                        <span>{action}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}

              <p className="text-xs text-muted-foreground">
                Relevance: {insight.relevanceScore}/100
              </p>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
