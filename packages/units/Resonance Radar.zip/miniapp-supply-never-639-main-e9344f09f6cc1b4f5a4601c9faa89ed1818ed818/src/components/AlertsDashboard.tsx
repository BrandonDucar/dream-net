'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, AlertCircle, TrendingUp, Target, AlertTriangle } from 'lucide-react';
import {
  loadUnreadAlerts,
  loadAllAlerts,
  markAlertRead,
  dismissAlert,
  clearAllAlerts,
  type Alert,
} from '@/lib/alerts';

export function AlertsDashboard(): JSX.Element {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [showAll, setShowAll] = useState<boolean>(false);

  useEffect(() => {
    loadAlerts();
  }, [showAll]);

  const loadAlerts = (): void => {
    const loaded = showAll ? loadAllAlerts() : loadUnreadAlerts();
    setAlerts(loaded);
  };

  const handleMarkRead = (id: string): void => {
    markAlertRead(id);
    loadAlerts();
  };

  const handleDismiss = (id: string): void => {
    dismissAlert(id);
    loadAlerts();
  };

  const handleClearAll = (): void => {
    if (confirm('Clear all alerts?')) {
      clearAllAlerts();
      loadAlerts();
    }
  };

  const getAlertIcon = (type: Alert['type']): JSX.Element => {
    switch (type) {
      case 'resonance-spike':
        return <TrendingUp className="h-4 w-4 text-blue-600" />;
      case 'goal-achieved':
        return <Target className="h-4 w-4 text-green-600" />;
      case 'resonance-drop':
        return <AlertTriangle className="h-4 w-4 text-red-600" />;
      case 'performance-warning':
        return <AlertCircle className="h-4 w-4 text-orange-600" />;
      default:
        return <Bell className="h-4 w-4 text-gray-600" />;
    }
  };

  const getSeverityColor = (severity: Alert['severity']): string => {
    switch (severity) {
      case 'critical': return 'border-l-red-600 bg-red-50';
      case 'warning': return 'border-l-orange-600 bg-orange-50';
      default: return 'border-l-blue-600 bg-blue-50';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <div className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          <h2 className="text-2xl font-bold">Alerts</h2>
          {!showAll && alerts.length > 0 && (
            <Badge variant="destructive">{alerts.length}</Badge>
          )}
        </div>
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? 'Show Unread Only' : 'Show All'}
          </Button>
          {alerts.length > 0 && (
            <Button
              variant="outline"
              size="sm"
              onClick={handleClearAll}
            >
              Clear All
            </Button>
          )}
        </div>
      </div>

      {alerts.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center text-muted-foreground">
            <Bell className="h-12 w-12 mx-auto mb-4 opacity-20" />
            <p>No alerts to show</p>
            <p className="text-sm mt-2">
              You'll be notified here when resonance changes or goals are achieved
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {alerts.map((alert: Alert) => (
            <Card
              key={alert.id}
              className={`border-l-4 ${getSeverityColor(alert.severity)} ${
                alert.read ? 'opacity-60' : ''
              }`}
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start">
                  <div className="flex items-center gap-2">
                    {getAlertIcon(alert.type)}
                    <CardTitle className="text-base">{alert.title}</CardTitle>
                  </div>
                  <div className="flex gap-1">
                    {!alert.read && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleMarkRead(alert.id)}
                      >
                        Mark Read
                      </Button>
                    )}
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDismiss(alert.id)}
                    >
                      ×
                    </Button>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-foreground">{alert.message}</p>
                <p className="text-xs text-muted-foreground mt-2">
                  {new Date(alert.createdAt).toLocaleString()}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
