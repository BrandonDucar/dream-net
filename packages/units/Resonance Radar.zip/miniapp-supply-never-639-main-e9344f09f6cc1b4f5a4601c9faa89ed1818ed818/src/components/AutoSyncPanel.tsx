'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import type { TrackedUnit } from '@/lib/types';
import {
  loadSyncSchedule,
  saveSyncSchedule,
  calculateNextSync,
  syncUnit,
  type SyncSchedule,
} from '@/lib/auto-sync';

interface AutoSyncPanelProps {
  unit: TrackedUnit;
  onSync?: () => void;
}

export function AutoSyncPanel({ unit, onSync }: AutoSyncPanelProps): JSX.Element {
  const [schedule, setSchedule] = useState<SyncSchedule>(() => {
    const existing = loadSyncSchedule(unit.id);
    return existing || {
      unitId: unit.id,
      enabled: false,
      frequency: 'daily',
      lastSync: null,
      nextSync: null,
      platforms: {},
    };
  });
  const [syncing, setSyncing] = useState<boolean>(false);

  const handleSave = (): void => {
    if (schedule.enabled && !schedule.nextSync) {
      schedule.nextSync = calculateNextSync(schedule.frequency);
    }
    saveSyncSchedule(schedule);
  };

  const handleManualSync = async (): Promise<void> => {
    setSyncing(true);
    try {
      await syncUnit(unit, schedule);
      if (onSync) onSync();
    } catch (error) {
      console.error('Sync failed:', error);
    } finally {
      setSyncing(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Auto-Sync Configuration</CardTitle>
        <CardDescription>
          Automatically fetch metrics from integrated platforms
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="sync-enabled">Enable Auto-Sync</Label>
          <Switch
            id="sync-enabled"
            checked={schedule.enabled}
            onCheckedChange={(checked: boolean) => {
              setSchedule({ ...schedule, enabled: checked });
            }}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="sync-frequency">Sync Frequency</Label>
          <Select
            value={schedule.frequency}
            onValueChange={(value: 'hourly' | 'daily' | 'weekly') =>
              setSchedule({ ...schedule, frequency: value })
            }
          >
            <SelectTrigger id="sync-frequency">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="hourly">Hourly</SelectItem>
              <SelectItem value="daily">Daily</SelectItem>
              <SelectItem value="weekly">Weekly</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="border-t pt-4 space-y-4">
          <h4 className="font-semibold text-sm">Platform IDs</h4>
          <p className="text-xs text-muted-foreground">
            Enter the IDs from each platform to track
          </p>

          <div className="space-y-2">
            <Label htmlFor="twitter-id">Twitter Tweet ID</Label>
            <Input
              id="twitter-id"
              placeholder="1234567890"
              value={schedule.platforms.twitter?.tweetId || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSchedule({
                  ...schedule,
                  platforms: {
                    ...schedule.platforms,
                    twitter: { tweetId: e.target.value },
                  },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="farcaster-hash">Farcaster Cast Hash</Label>
            <Input
              id="farcaster-hash"
              placeholder="0x..."
              value={schedule.platforms.farcaster?.castHash || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSchedule({
                  ...schedule,
                  platforms: {
                    ...schedule.platforms,
                    farcaster: { castHash: e.target.value },
                  },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="zora-contract">Zora Contract Address</Label>
            <Input
              id="zora-contract"
              placeholder="0x..."
              value={schedule.platforms.zora?.contractAddress || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSchedule({
                  ...schedule,
                  platforms: {
                    ...schedule.platforms,
                    zora: {
                      contractAddress: e.target.value,
                      tokenId: schedule.platforms.zora?.tokenId || '',
                    },
                  },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="zora-token">Zora Token ID</Label>
            <Input
              id="zora-token"
              placeholder="1"
              value={schedule.platforms.zora?.tokenId || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSchedule({
                  ...schedule,
                  platforms: {
                    ...schedule.platforms,
                    zora: {
                      contractAddress: schedule.platforms.zora?.contractAddress || '',
                      tokenId: e.target.value,
                    },
                  },
                })
              }
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="base-contract">Base Contract Address</Label>
            <Input
              id="base-contract"
              placeholder="0x..."
              value={schedule.platforms.base?.contractAddress || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                setSchedule({
                  ...schedule,
                  platforms: {
                    ...schedule.platforms,
                    base: { contractAddress: e.target.value },
                  },
                })
              }
            />
          </div>
        </div>

        {schedule.lastSync && (
          <p className="text-xs text-muted-foreground">
            Last synced: {new Date(schedule.lastSync).toLocaleString()}
          </p>
        )}
        {schedule.nextSync && schedule.enabled && (
          <p className="text-xs text-muted-foreground">
            Next sync: {new Date(schedule.nextSync).toLocaleString()}
          </p>
        )}

        <div className="flex gap-2">
          <Button onClick={handleSave} className="flex-1">
            Save Schedule
          </Button>
          <Button 
            onClick={handleManualSync} 
            variant="outline"
            disabled={syncing}
          >
            {syncing ? 'Syncing...' : 'Sync Now'}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
