'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar } from 'recharts';
import { Download } from 'lucide-react';
import {
  getBenchmarkData,
  generateBenchmarkReport,
  type BenchmarkData,
} from '@/lib/benchmarking';
import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/lib/types';

interface BenchmarkComparisonProps {
  unit: TrackedUnit;
  snapshots: MetricsSnapshot[];
  summary: ResonanceSummary;
}

export function BenchmarkComparison({ unit, snapshots, summary }: BenchmarkComparisonProps): JSX.Element {
  const [benchmarks, setBenchmarks] = useState<BenchmarkData[]>([]);
  const [report, setReport] = useState<string>('');

  useEffect(() => {
    if (snapshots.length > 0) {
      const data = getBenchmarkData(unit, snapshots, summary);
      setBenchmarks(data);
      const reportText = generateBenchmarkReport(unit, data);
      setReport(reportText);
    }
  }, [unit, snapshots, summary]);

  const handleDownloadReport = (): void => {
    const blob = new Blob([report], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `benchmark-${unit.name}-${Date.now()}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const getStatusBadge = (status: BenchmarkData['status']): JSX.Element => {
    const config = {
      'leading': { label: '🥇 Leading', className: 'bg-green-100 text-green-800 border-green-300' },
      'above-average': { label: '📈 Above Average', className: 'bg-blue-100 text-blue-800 border-blue-300' },
      'average': { label: '➡️ Average', className: 'bg-gray-100 text-gray-800 border-gray-300' },
      'below-average': { label: '📉 Below Average', className: 'bg-orange-100 text-orange-800 border-orange-300' },
      'lagging': { label: '🔴 Lagging', className: 'bg-red-100 text-red-800 border-red-300' },
    };

    const { label, className } = config[status];

    return (
      <Badge variant="outline" className={className}>
        {label}
      </Badge>
    );
  };

  if (benchmarks.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <p>No benchmark data available</p>
          <p className="text-sm mt-2">
            Add metrics to compare against industry standards
          </p>
        </CardContent>
      </Card>
    );
  }

  // Prepare radar chart data
  const radarData = benchmarks.map((b: BenchmarkData) => ({
    metric: b.metric,
    'Your Score': b.percentile,
    'Industry Avg': 50,
    'Top Performer': 90,
  }));

  // Prepare comparison chart data
  const comparisonData = benchmarks.map((b: BenchmarkData) => {
    const isPercentage = b.metric.includes('Rate') || b.metric.includes('Score');
    return {
      metric: b.metric.replace(' Rate', '').replace(' Score', ''),
      yours: isPercentage ? b.yourValue : Math.log10(b.yourValue + 1),
      industry: isPercentage ? b.industryAverage : Math.log10(b.industryAverage + 1),
      top: isPercentage ? b.topPerformer : Math.log10(b.topPerformer + 1),
    };
  });

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h3 className="text-lg font-semibold mb-1">Competitive Benchmarking</h3>
          <p className="text-sm text-muted-foreground">
            Compare your performance against {benchmarks[0]?.category} industry standards
          </p>
        </div>
        <Button onClick={handleDownloadReport} size="sm" variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Download Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Performance Radar</CardTitle>
            <CardDescription>Your percentile ranking vs industry</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72 w-full flex items-center justify-center">
              <RadarChart
                width={350}
                height={280}
                data={radarData}
                margin={{ top: 20, right: 20, bottom: 20, left: 20 }}
              >
                <PolarGrid />
                <PolarAngleAxis dataKey="metric" tick={{ fontSize: 10 }} />
                <PolarRadiusAxis angle={90} domain={[0, 100]} />
                <Radar
                  name="Your Score"
                  dataKey="Your Score"
                  stroke="#4f46e5"
                  fill="#4f46e5"
                  fillOpacity={0.6}
                />
                <Legend />
              </RadarChart>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Industry Comparison</CardTitle>
            <CardDescription>How you stack up</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-72 w-full">
              <BarChart
                data={comparisonData}
                width={350}
                height={280}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="metric" tick={{ fontSize: 10 }} />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="yours" fill="#4f46e5" name="You" />
                <Bar dataKey="industry" fill="#94a3b8" name="Industry" />
                <Bar dataKey="top" fill="#22c55e" name="Top" />
              </BarChart>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Detailed Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {benchmarks.map((benchmark: BenchmarkData) => (
              <div
                key={benchmark.metric}
                className="flex items-center justify-between p-3 border rounded-lg"
              >
                <div className="flex-1">
                  <p className="font-medium text-sm">{benchmark.metric}</p>
                  <div className="flex items-center gap-4 mt-1 text-xs text-muted-foreground">
                    <span>
                      You: <strong>{formatValue(benchmark.yourValue, benchmark.metric)}</strong>
                    </span>
                    <span>
                      Avg: {formatValue(benchmark.industryAverage, benchmark.metric)}
                    </span>
                    <span>
                      Top: {formatValue(benchmark.topPerformer, benchmark.metric)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="text-sm font-medium">
                    {benchmark.percentile.toFixed(0)}th percentile
                  </span>
                  {getStatusBadge(benchmark.status)}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function formatValue(value: number, metric: string): string {
  if (metric.includes('Rate') || metric.includes('Score')) {
    return `${value.toFixed(1)}%`;
  }
  return value.toLocaleString();
}
