'use client';

import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import {
  loadGoalsForUnit,
  saveGoal,
  deleteGoal,
  createDefaultMilestones,
  loadMilestonesForGoal,
  type Goal,
  type Milestone,
} from '@/lib/goals';
import type { TrackedUnit } from '@/lib/types';

interface GoalsTrackerProps {
  unit: TrackedUnit;
}

export function GoalsTracker({ unit }: GoalsTrackerProps): JSX.Element {
  const [goals, setGoals] = useState<Goal[]>([]);
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);
  const [newGoal, setNewGoal] = useState<Partial<Goal>>({
    type: 'impressions',
    targetValue: 10000,
    deadline: '',
    notes: '',
  });

  useEffect(() => {
    loadGoals();
  }, [unit.id]);

  const loadGoals = (): void => {
    const loaded = loadGoalsForUnit(unit.id);
    setGoals(loaded);
  };

  const handleCreateGoal = (): void => {
    if (!newGoal.type || !newGoal.targetValue) return;

    const goal: Goal = {
      id: `goal-${Date.now()}`,
      unitId: unit.id,
      name: newGoal.name || `${newGoal.type} goal`,
      type: newGoal.type as Goal['type'],
      targetValue: newGoal.targetValue,
      currentValue: 0,
      deadline: newGoal.deadline || null,
      status: 'not-started',
      createdAt: new Date().toISOString(),
      achievedAt: null,
      notes: newGoal.notes || '',
    };

    saveGoal(goal);
    createDefaultMilestones(goal.id);
    loadGoals();
    setDialogOpen(false);
    setNewGoal({
      type: 'impressions',
      targetValue: 10000,
      deadline: '',
      notes: '',
    });
  };

  const handleDeleteGoal = (goalId: string): void => {
    if (confirm('Delete this goal?')) {
      deleteGoal(goalId);
      loadGoals();
    }
  };

  const getStatusColor = (status: Goal['status']): string => {
    switch (status) {
      case 'achieved': return 'text-green-600';
      case 'in-progress': return 'text-blue-600';
      case 'missed': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusBadge = (status: Goal['status']): string => {
    switch (status) {
      case 'achieved': return '✓ Achieved';
      case 'in-progress': return '→ In Progress';
      case 'missed': return '✗ Missed';
      default: return '○ Not Started';
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Goals & Milestones</h3>
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button size="sm">+ New Goal</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Goal</DialogTitle>
              <DialogDescription>
                Set a target to track progress towards
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="goal-name">Goal Name</Label>
                <Input
                  id="goal-name"
                  placeholder="e.g., Reach 100K impressions"
                  value={newGoal.name || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGoal({ ...newGoal, name: e.target.value })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="goal-type">Metric Type</Label>
                <Select
                  value={newGoal.type}
                  onValueChange={(value: Goal['type']) =>
                    setNewGoal({ ...newGoal, type: value })
                  }
                >
                  <SelectTrigger id="goal-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="impressions">Impressions</SelectItem>
                    <SelectItem value="clicks">Clicks</SelectItem>
                    <SelectItem value="mints">Mints/Buys</SelectItem>
                    <SelectItem value="remixes">Remixes/Reshares</SelectItem>
                    <SelectItem value="engagement">Engagement</SelectItem>
                    <SelectItem value="resonance-score">Resonance Score</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="goal-target">Target Value</Label>
                <Input
                  id="goal-target"
                  type="number"
                  placeholder="10000"
                  value={newGoal.targetValue || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGoal({ ...newGoal, targetValue: parseInt(e.target.value) || 0 })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="goal-deadline">Deadline (Optional)</Label>
                <Input
                  id="goal-deadline"
                  type="date"
                  value={newGoal.deadline || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setNewGoal({ ...newGoal, deadline: e.target.value })
                  }
                />
              </div>

              <Button onClick={handleCreateGoal} className="w-full">
                Create Goal
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {goals.length === 0 ? (
        <Card>
          <CardContent className="py-8 text-center text-muted-foreground">
            No goals set yet. Create one to start tracking!
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-3">
          {goals.map((goal: Goal) => {
            const progress = (goal.currentValue / goal.targetValue) * 100;
            const milestones = loadMilestonesForGoal(goal.id);

            return (
              <Card key={goal.id}>
                <CardHeader>
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-base">{goal.name}</CardTitle>
                      <CardDescription className="mt-1">
                        {goal.currentValue.toLocaleString()} / {goal.targetValue.toLocaleString()} {goal.type}
                      </CardDescription>
                    </div>
                    <div className="flex gap-2 items-center">
                      <span className={`text-xs font-medium ${getStatusColor(goal.status)}`}>
                        {getStatusBadge(goal.status)}
                      </span>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteGoal(goal.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-3">
                  <Progress value={Math.min(100, progress)} />
                  <p className="text-sm text-muted-foreground">
                    {progress.toFixed(0)}% complete
                  </p>

                  {goal.deadline && (
                    <p className="text-xs text-muted-foreground">
                      Deadline: {new Date(goal.deadline).toLocaleDateString()}
                    </p>
                  )}

                  {milestones.length > 0 && (
                    <div className="border-t pt-3 mt-3">
                      <p className="text-xs font-semibold mb-2">Milestones:</p>
                      <div className="space-y-1">
                        {milestones.map((milestone: Milestone) => (
                          <div key={milestone.id} className="flex items-center gap-2 text-xs">
                            <span className={milestone.achievedAt ? 'text-green-600' : 'text-gray-400'}>
                              {milestone.achievedAt ? '✓' : '○'}
                            </span>
                            <span>{milestone.name}</span>
                            {milestone.achievedAt && (
                              <span className="text-muted-foreground ml-auto">
                                {new Date(milestone.achievedAt).toLocaleDateString()}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
