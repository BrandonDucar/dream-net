'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  loadTwitterConfig, 
  saveTwitterConfig, 
  type TwitterConfig 
} from '@/lib/integrations/twitter';
import { 
  loadFarcasterConfig, 
  saveFarcasterConfig,
  type FarcasterConfig 
} from '@/lib/integrations/farcaster';
import { 
  loadZoraConfig, 
  saveZoraConfig,
  type ZoraConfig 
} from '@/lib/integrations/zora';
import { 
  loadBaseConfig, 
  saveBaseConfig,
  type BaseConfig 
} from '@/lib/integrations/base';

export function IntegrationsSettings(): JSX.Element {
  const [twitterConfig, setTwitterConfig] = useState<TwitterConfig>(loadTwitterConfig());
  const [farcasterConfig, setFarcasterConfig] = useState<FarcasterConfig>(loadFarcasterConfig());
  const [zoraConfig, setZoraConfig] = useState<ZoraConfig>(loadZoraConfig());
  const [baseConfig, setBaseConfig] = useState<BaseConfig>(loadBaseConfig());
  const [saved, setSaved] = useState<string>('');

  const handleSaveTwitter = (): void => {
    saveTwitterConfig(twitterConfig);
    setSaved('twitter');
    setTimeout(() => setSaved(''), 2000);
  };

  const handleSaveFarcaster = (): void => {
    saveFarcasterConfig(farcasterConfig);
    setSaved('farcaster');
    setTimeout(() => setSaved(''), 2000);
  };

  const handleSaveZora = (): void => {
    saveZoraConfig(zoraConfig);
    setSaved('zora');
    setTimeout(() => setSaved(''), 2000);
  };

  const handleSaveBase = (): void => {
    saveBaseConfig(baseConfig);
    setSaved('base');
    setTimeout(() => setSaved(''), 2000);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Analytics Integrations</h2>
        <p className="text-muted-foreground mt-1">
          Connect external platforms to auto-sync metrics
        </p>
      </div>

      <Tabs defaultValue="twitter" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="twitter">Twitter/X</TabsTrigger>
          <TabsTrigger value="farcaster">Farcaster</TabsTrigger>
          <TabsTrigger value="zora">Zora</TabsTrigger>
          <TabsTrigger value="base">Base Chain</TabsTrigger>
        </TabsList>

        <TabsContent value="twitter">
          <Card>
            <CardHeader>
              <CardTitle>Twitter/X API</CardTitle>
              <CardDescription>
                Connect to fetch tweet impressions and engagement
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="twitter-enabled">Enable Integration</Label>
                <Switch
                  id="twitter-enabled"
                  checked={twitterConfig.enabled}
                  onCheckedChange={(checked: boolean) => 
                    setTwitterConfig({ ...twitterConfig, enabled: checked })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="twitter-bearer">Bearer Token</Label>
                <Input
                  id="twitter-bearer"
                  type="password"
                  placeholder="Enter your Twitter API bearer token"
                  value={twitterConfig.bearerToken}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setTwitterConfig({ ...twitterConfig, bearerToken: e.target.value })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Get your bearer token from{' '}
                  <a 
                    href="https://developer.twitter.com/en/portal/dashboard"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Twitter Developer Portal
                  </a>
                </p>
              </div>

              <Button onClick={handleSaveTwitter} className="w-full">
                {saved === 'twitter' ? '✓ Saved!' : 'Save Configuration'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="farcaster">
          <Card>
            <CardHeader>
              <CardTitle>Farcaster (Neynar)</CardTitle>
              <CardDescription>
                Connect to fetch cast engagement metrics
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="farcaster-enabled">Enable Integration</Label>
                <Switch
                  id="farcaster-enabled"
                  checked={farcasterConfig.enabled}
                  onCheckedChange={(checked: boolean) =>
                    setFarcasterConfig({ ...farcasterConfig, enabled: checked })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="farcaster-key">Neynar API Key</Label>
                <Input
                  id="farcaster-key"
                  type="password"
                  placeholder="Enter your Neynar API key"
                  value={farcasterConfig.apiKey}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setFarcasterConfig({ ...farcasterConfig, apiKey: e.target.value })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Get your API key from{' '}
                  <a 
                    href="https://neynar.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="underline"
                  >
                    Neynar
                  </a>
                </p>
              </div>

              <Button onClick={handleSaveFarcaster} className="w-full">
                {saved === 'farcaster' ? '✓ Saved!' : 'Save Configuration'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="zora">
          <Card>
            <CardHeader>
              <CardTitle>Zora API</CardTitle>
              <CardDescription>
                Fetch mint and sales data from Zora
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="zora-enabled">Enable Integration</Label>
                <Switch
                  id="zora-enabled"
                  checked={zoraConfig.enabled}
                  onCheckedChange={(checked: boolean) =>
                    setZoraConfig({ ...zoraConfig, enabled: checked })
                  }
                />
              </div>

              <p className="text-sm text-muted-foreground">
                Zora's public GraphQL API doesn't require authentication. Simply enable to start tracking mints and sales.
              </p>

              <Button onClick={handleSaveZora} className="w-full">
                {saved === 'zora' ? '✓ Saved!' : 'Save Configuration'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="base">
          <Card>
            <CardHeader>
              <CardTitle>Base Chain (Dexscreener)</CardTitle>
              <CardDescription>
                Track on-chain metrics for CultureCoins
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="base-enabled">Enable Integration</Label>
                <Switch
                  id="base-enabled"
                  checked={baseConfig.enabled}
                  onCheckedChange={(checked: boolean) =>
                    setBaseConfig({ ...baseConfig, enabled: checked })
                  }
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="base-rpc">RPC URL (Optional)</Label>
                <Input
                  id="base-rpc"
                  type="url"
                  placeholder="https://mainnet.base.org"
                  value={baseConfig.rpcUrl}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) =>
                    setBaseConfig({ ...baseConfig, rpcUrl: e.target.value })
                  }
                />
                <p className="text-xs text-muted-foreground">
                  Uses Dexscreener public API by default
                </p>
              </div>

              <Button onClick={handleSaveBase} className="w-full">
                {saved === 'base' ? '✓ Saved!' : 'Save Configuration'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
