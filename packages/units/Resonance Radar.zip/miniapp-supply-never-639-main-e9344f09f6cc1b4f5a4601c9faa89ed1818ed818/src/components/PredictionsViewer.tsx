'use client';

import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, TrendingDown, Minus, Target } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, Area, ComposedChart } from 'recharts';
import {
  predictMetric,
  generateForecast,
  predictResonanceScore,
  type Prediction,
  type ForecastPoint,
} from '@/lib/predictions';
import type { MetricsSnapshot, ResonanceSummary } from '@/lib/types';

interface PredictionsViewerProps {
  snapshots: MetricsSnapshot[];
  summary: ResonanceSummary;
}

export function PredictionsViewer({ snapshots, summary }: PredictionsViewerProps): JSX.Element {
  if (snapshots.length < 3) {
    return (
      <Card>
        <CardContent className="py-12 text-center text-muted-foreground">
          <Target className="h-12 w-12 mx-auto mb-4 opacity-20" />
          <p>Not enough data for predictions</p>
          <p className="text-sm mt-2">
            Add at least 3 metrics snapshots to see forecasts
          </p>
        </CardContent>
      </Card>
    );
  }

  const impressionsPrediction = predictMetric(snapshots, 'impressions', '30d');
  const clicksPrediction = predictMetric(snapshots, 'clicks', '30d');
  const mintsPrediction = predictMetric(snapshots, 'mintsOrBuys', '30d');
  const resonancePrediction = predictResonanceScore(
    summary.resonanceScore,
    summary.trend,
    snapshots
  );

  const impressionsForecast = generateForecast(snapshots, 'impressions', 4);

  const getTrendIcon = (trend: Prediction['trend']): JSX.Element => {
    switch (trend) {
      case 'accelerating': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'decelerating': return <TrendingDown className="h-4 w-4 text-red-600" />;
      default: return <Minus className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTrendColor = (trend: Prediction['trend']): string => {
    switch (trend) {
      case 'accelerating': return 'text-green-600';
      case 'decelerating': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const renderPredictionCard = (prediction: Prediction | null, label: string): JSX.Element | null => {
    if (!prediction) return null;

    const change = prediction.predicted - prediction.current;
    const changePercent = (change / prediction.current) * 100;

    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center justify-between">
            <span>{label}</span>
            <Badge variant="secondary">
              {(prediction.confidence * 100).toFixed(0)}% confidence
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-bold">
              {prediction.predicted.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
            <span className="text-sm text-muted-foreground">
              in {prediction.timeframe}
            </span>
          </div>

          <div className="flex items-center gap-2">
            {getTrendIcon(prediction.trend)}
            <span className={`text-sm font-medium ${getTrendColor(prediction.trend)}`}>
              {change >= 0 ? '+' : ''}{changePercent.toFixed(1)}% from current
            </span>
          </div>

          <div className="text-xs text-muted-foreground space-y-1">
            <p className="font-semibold">Factors:</p>
            <ul className="space-y-0.5">
              {prediction.factors.map((factor: string, idx: number) => (
                <li key={idx}>• {factor}</li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>
    );
  };

  // Prepare chart data
  const chartData = impressionsForecast.map((point: ForecastPoint, idx: number) => ({
    period: `Week ${idx + 1}`,
    predicted: point.value,
    lower: point.lower,
    upper: point.upper,
  }));

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold mb-1">Predictive Analytics</h3>
        <p className="text-sm text-muted-foreground">
          AI-powered forecasts based on historical trends
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {renderPredictionCard(impressionsPrediction, 'Impressions')}
        {renderPredictionCard(clicksPrediction, 'Clicks')}
        {renderPredictionCard(mintsPrediction, 'Mints/Buys')}
        {renderPredictionCard(resonancePrediction, 'Resonance Score')}
      </div>

      {chartData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Impressions Forecast</CardTitle>
            <CardDescription>
              Next 4 weeks with 95% confidence interval
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="h-64 w-full">
              <ComposedChart
                data={chartData}
                width={600}
                height={250}
                margin={{ top: 5, right: 20, left: 0, bottom: 5 }}
              >
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="period" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Area
                  type="monotone"
                  dataKey="upper"
                  stackId="1"
                  stroke="none"
                  fill="#e0e7ff"
                  fillOpacity={0.6}
                  name="Upper Bound"
                />
                <Area
                  type="monotone"
                  dataKey="lower"
                  stackId="1"
                  stroke="none"
                  fill="#ffffff"
                  fillOpacity={1}
                  name="Lower Bound"
                />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  stroke="#4f46e5"
                  strokeWidth={2}
                  name="Predicted"
                />
              </ComposedChart>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
