'use client';

import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { TEMPLATES, applyTemplate, type Template } from '@/lib/templates';

interface TemplateSelectorProps {
  onSelect: (data: Partial<import('@/lib/types').TrackedUnit>) => void;
}

export function TemplateSelector({ onSelect }: TemplateSelectorProps): JSX.Element {
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [customName, setCustomName] = useState<string>('');
  const [dialogOpen, setDialogOpen] = useState<boolean>(false);

  const handleTemplateClick = (template: Template): void => {
    setSelectedTemplate(template);
    setCustomName('');
    setDialogOpen(true);
  };

  const handleApply = (): void => {
    if (selectedTemplate && customName.trim()) {
      const data = applyTemplate(selectedTemplate, customName);
      onSelect(data);
      setDialogOpen(false);
    }
  };

  return (
    <>
      <div className="space-y-4">
        <div>
          <h3 className="text-lg font-semibold">Quick Start Templates</h3>
          <p className="text-sm text-muted-foreground">
            Choose a template to get started quickly
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {TEMPLATES.map((template: Template) => (
            <Card 
              key={template.id}
              className="cursor-pointer hover:border-primary transition-colors"
              onClick={() => handleTemplateClick(template)}
            >
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <span className="text-2xl">{template.emoji}</span>
                  <span className="text-base">{template.name}</span>
                </CardTitle>
                <CardDescription>{template.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 text-sm">
                  <p className="text-muted-foreground">Includes:</p>
                  <ul className="list-disc list-inside space-y-1 text-xs">
                    <li>{template.defaultGeoTargets.length} geo targets</li>
                    <li>{template.defaultSEO.keywords.length} SEO keywords</li>
                    <li>{template.defaultSEO.hashtags.length} hashtags</li>
                    {template.sampleMetrics && (
                      <li>Sample metrics guidance</li>
                    )}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              {selectedTemplate && (
                <>
                  <span className="text-2xl">{selectedTemplate.emoji}</span>
                  {selectedTemplate.name}
                </>
              )}
            </DialogTitle>
            <DialogDescription>
              {selectedTemplate?.description}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="custom-name">Name Your Culture Object</Label>
              <Input
                id="custom-name"
                placeholder="e.g., Base Summer Coin"
                value={customName}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCustomName(e.target.value)}
              />
            </div>

            {selectedTemplate?.sampleMetrics && (
              <div className="bg-muted p-3 rounded-lg text-sm space-y-1">
                <p className="font-semibold">Expected Performance:</p>
                <p>Impressions: {selectedTemplate.sampleMetrics.impressions.toLocaleString()}</p>
                <p>Clicks: {selectedTemplate.sampleMetrics.clicks.toLocaleString()}</p>
                <p>Mints: {selectedTemplate.sampleMetrics.mintsOrBuys.toLocaleString()}</p>
              </div>
            )}

            <Button 
              onClick={handleApply}
              disabled={!customName.trim()}
              className="w-full"
            >
              Apply Template
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
