'use client'

import { useState, useMemo } from 'react';
import type { TrackedUnit, ResonanceSummary, MetricsSnapshot } from '@/types/resonance';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { 
  RadarChart, 
  PolarGrid, 
  PolarAngleAxis, 
  PolarRadiusAxis, 
  Radar, 
  ResponsiveContainer,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip as ChartTooltip,
} from 'recharts';

interface ComparisonViewProps {
  units: TrackedUnit[];
  summaries: ResonanceSummary[];
  snapshots: MetricsSnapshot[];
  onBack: () => void;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8'];

export function ComparisonView({ units, summaries, snapshots, onBack }: ComparisonViewProps): JSX.Element {
  const [selectedUnitIds, setSelectedUnitIds] = useState<string[]>([]);

  const toggleUnit = (unitId: string): void => {
    setSelectedUnitIds((prev: string[]) => {
      if (prev.includes(unitId)) {
        return prev.filter((id: string) => id !== unitId);
      }
      if (prev.length >= 5) {
        return prev; // Max 5 units for comparison
      }
      return [...prev, unitId];
    });
  };

  const comparisonData = useMemo(() => {
    return selectedUnitIds.map((unitId: string) => {
      const unit = units.find((u: TrackedUnit) => u.id === unitId);
      const summary = summaries.find((s: ResonanceSummary) => s.unitId === unitId);
      const unitSnapshots = snapshots
        .filter((s: MetricsSnapshot) => s.unitId === unitId)
        .sort((a: MetricsSnapshot, b: MetricsSnapshot) => 
          new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
        );
      
      const latestSnapshot = unitSnapshots[0];

      return {
        unit,
        summary,
        latestSnapshot,
        totalSnapshots: unitSnapshots.length,
      };
    }).filter((item) => item.unit && item.summary);
  }, [selectedUnitIds, units, summaries, snapshots]);

  // Radar chart data for resonance factors
  const radarData = useMemo(() => {
    if (comparisonData.length === 0) return [];

    const categories = ['Resonance', 'Impressions', 'Clicks', 'Conversions', 'Engagement'];
    
    return categories.map((category: string) => {
      const dataPoint: Record<string, string | number> = { category };
      
      comparisonData.forEach((item, index: number) => {
        if (!item.summary || !item.latestSnapshot) return;
        
        let value = 0;
        switch (category) {
          case 'Resonance':
            value = item.summary.resonanceScore;
            break;
          case 'Impressions':
            value = Math.min(100, (item.latestSnapshot.impressions / 10000) * 100);
            break;
          case 'Clicks':
            value = Math.min(100, (item.latestSnapshot.clicks / 1000) * 100);
            break;
          case 'Conversions':
            value = Math.min(100, (item.latestSnapshot.mintsOrBuys / 100) * 100);
            break;
          case 'Engagement':
            value = Math.min(100, ((item.latestSnapshot.comments + item.latestSnapshot.savesOrBookmarks) / 500) * 100);
            break;
        }
        
        dataPoint[item.unit?.name || `Unit ${index + 1}`] = Math.round(value);
      });
      
      return dataPoint;
    });
  }, [comparisonData]);

  // Bar chart for direct metrics comparison
  const barChartData = useMemo(() => {
    return comparisonData.map((item) => ({
      name: item.unit?.primaryEmoji + ' ' + (item.unit?.name.slice(0, 15) || ''),
      score: item.summary?.resonanceScore || 0,
      impressions: Math.log10((item.latestSnapshot?.impressions || 1)) * 10,
      clicks: Math.log10((item.latestSnapshot?.clicks || 1)) * 10,
      mints: (item.latestSnapshot?.mintsOrBuys || 0) * 2,
    }));
  }, [comparisonData]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-black">Compare Units</h1>
          <p className="text-gray-600 mt-1">Side-by-side comparison of culture objects</p>
        </div>
        <Button onClick={onBack} variant="outline">
          Back to Overview
        </Button>
      </div>

      {/* Unit Selection */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Select Units to Compare (max 5)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            {units.map((unit: TrackedUnit) => {
              const summary = summaries.find((s: ResonanceSummary) => s.unitId === unit.id);
              const isSelected = selectedUnitIds.includes(unit.id);
              const isDisabled = !isSelected && selectedUnitIds.length >= 5;

              return (
                <div
                  key={unit.id}
                  className={`flex items-center gap-3 p-3 border rounded-lg cursor-pointer transition-colors ${
                    isSelected ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
                  } ${isDisabled ? 'opacity-50 cursor-not-allowed' : ''}`}
                  onClick={() => !isDisabled && toggleUnit(unit.id)}
                >
                  <Checkbox
                    checked={isSelected}
                    disabled={isDisabled}
                    onCheckedChange={() => !isDisabled && toggleUnit(unit.id)}
                  />
                  <div className="text-2xl">{unit.primaryEmoji}</div>
                  <div className="flex-1">
                    <div className="font-semibold text-black text-sm">{unit.name}</div>
                    <div className="text-xs text-gray-500">{unit.type}</div>
                  </div>
                  {summary && (
                    <div className="text-right">
                      <div className="font-bold text-sm">{summary.resonanceScore}</div>
                      <Badge variant="secondary" className="text-xs">
                        {summary.trend === 'rising' ? '↑' : summary.trend === 'falling' ? '↓' : '→'}
                      </Badge>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {comparisonData.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <p className="text-gray-500">Select at least one unit to start comparing</p>
          </CardContent>
        </Card>
      )}

      {comparisonData.length > 0 && (
        <>
          {/* Summary Table */}
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Quick Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2 px-3 text-black">Unit</th>
                      <th className="text-center py-2 px-3 text-black">Score</th>
                      <th className="text-center py-2 px-3 text-black">Trend</th>
                      <th className="text-center py-2 px-3 text-black">Action</th>
                      <th className="text-right py-2 px-3 text-black">Impressions</th>
                      <th className="text-right py-2 px-3 text-black">Clicks</th>
                      <th className="text-right py-2 px-3 text-black">Mints</th>
                    </tr>
                  </thead>
                  <tbody>
                    {comparisonData.map((item, index: number) => (
                      <tr key={item.unit?.id} className="border-b">
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <span className="text-xl">{item.unit?.primaryEmoji}</span>
                            <span className="font-semibold text-black">{item.unit?.name}</span>
                          </div>
                        </td>
                        <td className="text-center py-3 px-3">
                          <span className="text-xl font-bold text-black">{item.summary?.resonanceScore}</span>
                        </td>
                        <td className="text-center py-3 px-3">
                          <Badge variant="secondary">
                            {item.summary?.trend === 'rising' ? '↑' : item.summary?.trend === 'falling' ? '↓' : '→'}
                          </Badge>
                        </td>
                        <td className="text-center py-3 px-3">
                          <Badge>{item.summary?.recommendation}</Badge>
                        </td>
                        <td className="text-right py-3 px-3 text-black">
                          {item.latestSnapshot?.impressions.toLocaleString() || 0}
                        </td>
                        <td className="text-right py-3 px-3 text-black">
                          {item.latestSnapshot?.clicks.toLocaleString() || 0}
                        </td>
                        <td className="text-right py-3 px-3 text-black">
                          {item.latestSnapshot?.mintsOrBuys.toLocaleString() || 0}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          {/* Radar Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Performance Radar</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <RadarChart data={radarData}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="category" />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  {comparisonData.map((item, index: number) => (
                    <Radar
                      key={item.unit?.id}
                      name={item.unit?.name || ''}
                      dataKey={item.unit?.name || ''}
                      stroke={COLORS[index % COLORS.length]}
                      fill={COLORS[index % COLORS.length]}
                      fillOpacity={0.3}
                    />
                  ))}
                  <Legend />
                </RadarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Bar Chart */}
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Metrics Comparison</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={barChartData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <ChartTooltip />
                  <Legend />
                  <Bar dataKey="score" fill="#8884d8" name="Resonance Score" />
                  <Bar dataKey="impressions" fill="#82ca9d" name="Impressions (log scale)" />
                  <Bar dataKey="clicks" fill="#ffc658" name="Clicks (log scale)" />
                  <Bar dataKey="mints" fill="#ff8042" name="Mints (×2)" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Main Drivers Comparison */}
          <Card>
            <CardHeader>
              <CardTitle className="text-black">Key Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {comparisonData.map((item, index: number) => (
                  <div key={item.unit?.id} className="p-4 border rounded-lg">
                    <div className="flex items-center gap-3 mb-2">
                      <span className="text-2xl">{item.unit?.primaryEmoji}</span>
                      <span className="font-bold text-black">{item.unit?.name}</span>
                    </div>
                    <ul className="list-disc list-inside space-y-1 text-sm text-gray-700">
                      {item.summary?.mainDrivers.map((driver: string, idx: number) => (
                        <li key={idx}>{driver}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  );
}
