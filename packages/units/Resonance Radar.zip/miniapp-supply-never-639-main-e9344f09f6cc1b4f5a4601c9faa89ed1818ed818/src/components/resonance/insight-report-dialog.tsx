'use client';

import { useMemo } from 'react';
import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/types/resonance';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Copy, Download } from 'lucide-react';
import { toast } from 'sonner';

interface InsightReportDialogProps {
  open: boolean;
  onClose: () => void;
  unit: TrackedUnit;
  snapshots: MetricsSnapshot[];
  summary: ResonanceSummary | null;
}

export function InsightReportDialog({ 
  open, 
  onClose, 
  unit, 
  snapshots, 
  summary 
}: InsightReportDialogProps) {
  
  const report = useMemo(() => {
    const lines: string[] = [];
    
    lines.push('═══════════════════════════════════════════════════════');
    lines.push(`RESONANCE RADAR INSIGHT REPORT`);
    lines.push(`Generated: ${new Date().toLocaleString()}`);
    lines.push('═══════════════════════════════════════════════════════');
    lines.push('');
    
    // Unit Info
    lines.push('📊 CULTURE OBJECT');
    lines.push('─────────────────────────────────────────────────────');
    lines.push(`${unit.primaryEmoji} ${unit.name}`);
    lines.push(`Type: ${unit.type}`);
    lines.push(`Chain: ${unit.chain}`);
    lines.push(`Status: ${unit.status}`);
    if (unit.refId) lines.push(`Reference ID: ${unit.refId}`);
    lines.push('');
    
    // Resonance Score
    if (summary) {
      lines.push('🎯 RESONANCE ANALYSIS');
      lines.push('─────────────────────────────────────────────────────');
      lines.push(`Score: ${summary.resonanceScore}/100`);
      lines.push(`Trend: ${summary.trend.toUpperCase()}`);
      lines.push(`Recommendation: ${summary.recommendation.toUpperCase()}`);
      lines.push(`Last Period: ${summary.lastPeriodLabel}`);
      lines.push('');
      lines.push('Key Drivers:');
      summary.mainDrivers.forEach((driver: string) => {
        lines.push(`  • ${driver}`);
      });
      lines.push('');
    }
    
    // Recent Metrics
    if (snapshots.length > 0) {
      lines.push('📈 RECENT PERFORMANCE');
      lines.push('─────────────────────────────────────────────────────');
      
      const recent = snapshots.slice(0, 3);
      recent.forEach((snapshot: MetricsSnapshot, index: number) => {
        if (index > 0) lines.push('');
        lines.push(`Period: ${snapshot.periodLabel}`);
        lines.push(`  Impressions: ${snapshot.impressions.toLocaleString()}`);
        lines.push(`  Clicks: ${snapshot.clicks.toLocaleString()} (CTR: ${((snapshot.clicks / snapshot.impressions) * 100).toFixed(2)}%)`);
        lines.push(`  Mints/Buys: ${snapshot.mintsOrBuys.toLocaleString()}`);
        lines.push(`  Remixes/Reshares: ${snapshot.remixesOrReshares.toLocaleString()}`);
        lines.push(`  Comments: ${snapshot.comments.toLocaleString()}`);
        lines.push(`  Saves/Bookmarks: ${snapshot.savesOrBookmarks.toLocaleString()}`);
        
        if (Object.keys(snapshot.channelBreakdown).length > 0) {
          lines.push('  Channels:');
          Object.entries(snapshot.channelBreakdown)
            .sort((a, b) => b[1] - a[1])
            .forEach(([channel, count]: [string, number]) => {
              const pct = ((count / snapshot.impressions) * 100).toFixed(1);
              lines.push(`    - ${channel}: ${count.toLocaleString()} (${pct}%)`);
            });
        }
        
        if (snapshot.notes) {
          lines.push(`  Notes: ${snapshot.notes}`);
        }
      });
      lines.push('');
    }
    
    // SEO
    lines.push('🔍 SEO METADATA');
    lines.push('─────────────────────────────────────────────────────');
    lines.push(`Title: ${unit.seoTitle || 'Not set'}`);
    lines.push(`Description: ${unit.seoDescription || 'Not set'}`);
    lines.push(`Alt Text: ${unit.altText || 'Not set'}`);
    
    if (unit.seoKeywords.length > 0) {
      lines.push(`Keywords: ${unit.seoKeywords.join(', ')}`);
    }
    
    if (unit.seoHashtags.length > 0) {
      lines.push(`Hashtags: ${unit.seoHashtags.join(' ')}`);
    }
    lines.push('');
    
    // Geo Targeting
    if (unit.primaryGeoTargets.length > 0) {
      lines.push('🌍 GEO TARGETING');
      lines.push('─────────────────────────────────────────────────────');
      
      unit.primaryGeoTargets.forEach((geo) => {
        lines.push(`${geo.region}${geo.country ? ` (${geo.country})` : ''}`);
        if (geo.cityOrMarket) lines.push(`  Market: ${geo.cityOrMarket}`);
        lines.push(`  Language: ${geo.language}`);
        
        const geoKey = geo.id;
        if (unit.captionLocalized[geoKey]) {
          lines.push(`  Caption: ${unit.captionLocalized[geoKey]}`);
        }
        if (unit.tagsLocalized[geoKey]) {
          lines.push(`  Tags: ${unit.tagsLocalized[geoKey].join(', ')}`);
        }
        lines.push('');
      });
    }
    
    // Action Items
    if (summary) {
      lines.push('✨ RECOMMENDED ACTIONS');
      lines.push('─────────────────────────────────────────────────────');
      
      switch (summary.recommendation) {
        case 'amplify':
          lines.push('🚀 AMPLIFY: This is performing exceptionally well!');
          lines.push('  • Increase budget and distribution');
          lines.push('  • Create spin-off content');
          lines.push('  • Leverage for partnership opportunities');
          break;
        case 'evolve':
          lines.push('🔄 EVOLVE: Good momentum, needs refinement');
          lines.push('  • Test variations of messaging');
          lines.push('  • Expand to new channels');
          lines.push('  • Gather more audience feedback');
          break;
        case 'watch':
          lines.push('👀 WATCH: Monitor closely for changes');
          lines.push('  • Track trends over next few periods');
          lines.push('  • Consider minor adjustments');
          lines.push('  • Don\'t make drastic changes yet');
          break;
        case 'pause':
          lines.push('⏸️ PAUSE: Consider reducing investment');
          lines.push('  • Reduce spend or effort');
          lines.push('  • Analyze what isn\'t working');
          lines.push('  • Test smaller experiments');
          break;
        case 'retire':
          lines.push('🛑 RETIRE: Time to move on');
          lines.push('  • Stop active promotion');
          lines.push('  • Learn from what didn\'t work');
          lines.push('  • Redirect resources to better performers');
          break;
      }
      lines.push('');
    }
    
    lines.push('═══════════════════════════════════════════════════════');
    lines.push('Generated by Resonance Radar');
    lines.push('═══════════════════════════════════════════════════════');
    
    return lines.join('\n');
  }, [unit, snapshots, summary]);

  const handleCopy = async (): Promise<void> => {
    try {
      await navigator.clipboard.writeText(report);
      toast.success('Report copied to clipboard');
    } catch (err) {
      toast.error('Failed to copy report');
    }
  };

  const handleDownload = (): void => {
    const blob = new Blob([report], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `resonance-report-${unit.name.replace(/\s+/g, '-').toLowerCase()}-${Date.now()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast.success('Report downloaded');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden flex flex-col">
        <DialogHeader>
          <DialogTitle>Insight Report: {unit.name}</DialogTitle>
        </DialogHeader>

        <div className="flex-1 overflow-hidden flex flex-col">
          <Textarea
            value={report}
            readOnly
            className="flex-1 font-mono text-xs resize-none"
            rows={25}
          />
        </div>

        <div className="flex gap-2 pt-4">
          <Button onClick={handleCopy} variant="outline" className="flex-1">
            <Copy className="h-4 w-4 mr-2" />
            Copy to Clipboard
          </Button>
          <Button onClick={handleDownload} className="flex-1">
            <Download className="h-4 w-4 mr-2" />
            Download Report
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
