'use client';

import { useState } from 'react';
import type { MetricsSnapshot } from '@/types/resonance';
import { saveSnapshot } from '@/lib/resonance-storage';
import { createResonanceSummary } from '@/lib/resonance-scoring';
import { saveSummary, getSnapshotsByUnitId } from '@/lib/resonance-storage';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from '@/components/ui/dialog';
import { Card, CardContent } from '@/components/ui/card';
import { Plus, X } from 'lucide-react';
import { toast } from 'sonner';

interface MetricsFormDialogProps {
  open: boolean;
  onClose: () => void;
  unitId: string;
  onSave: () => void;
}

export function MetricsFormDialog({ open, onClose, unitId, onSave }: MetricsFormDialogProps) {
  const [formData, setFormData] = useState<Partial<MetricsSnapshot>>({
    periodLabel: '',
    impressions: 0,
    clicks: 0,
    mintsOrBuys: 0,
    remixesOrReshares: 0,
    comments: 0,
    savesOrBookmarks: 0,
    channelBreakdown: {},
    notes: '',
  });

  const [channelKey, setChannelKey] = useState<string>('');
  const [channelValue, setChannelValue] = useState<string>('');

  const handleChange = (field: keyof MetricsSnapshot, value: string | number): void => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleAddChannel = (): void => {
    if (!channelKey.trim() || !channelValue) return;

    setFormData(prev => ({
      ...prev,
      channelBreakdown: {
        ...(prev.channelBreakdown || {}),
        [channelKey]: Number(channelValue),
      },
    }));

    setChannelKey('');
    setChannelValue('');
  };

  const handleRemoveChannel = (key: string): void => {
    const newBreakdown = { ...(formData.channelBreakdown || {}) };
    delete newBreakdown[key];
    setFormData(prev => ({ ...prev, channelBreakdown: newBreakdown }));
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.periodLabel) {
      toast.error('Period label is required');
      return;
    }

    const snapshot: MetricsSnapshot = {
      id: `snapshot_${Date.now()}`,
      unitId,
      periodLabel: formData.periodLabel,
      timestamp: new Date().toISOString(),
      impressions: Number(formData.impressions) || 0,
      clicks: Number(formData.clicks) || 0,
      mintsOrBuys: Number(formData.mintsOrBuys) || 0,
      remixesOrReshares: Number(formData.remixesOrReshares) || 0,
      comments: Number(formData.comments) || 0,
      savesOrBookmarks: Number(formData.savesOrBookmarks) || 0,
      channelBreakdown: formData.channelBreakdown || {},
      notes: formData.notes || '',
    };

    saveSnapshot(snapshot);

    // Auto-compute resonance summary
    const allSnapshots = getSnapshotsByUnitId(unitId);
    const latestSnapshot = snapshot;
    const previousSnapshot = allSnapshots.length > 0 ? allSnapshots[0] : null;

    const summary = createResonanceSummary(latestSnapshot, previousSnapshot);
    saveSummary(summary);

    toast.success('Metrics saved and resonance computed');

    // Reset form
    setFormData({
      periodLabel: '',
      impressions: 0,
      clicks: 0,
      mintsOrBuys: 0,
      remixesOrReshares: 0,
      comments: 0,
      savesOrBookmarks: 0,
      channelBreakdown: {},
      notes: '',
    });

    onSave();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Add Metrics Snapshot</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div>
            <Label htmlFor="periodLabel">Period Label *</Label>
            <Input
              id="periodLabel"
              value={formData.periodLabel || ''}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                handleChange('periodLabel', e.target.value)
              }
              placeholder="e.g., Week 1, Q1 2024, Last 7 days"
              required
            />
          </div>

          <Card>
            <CardContent className="pt-6 grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="impressions">Impressions</Label>
                <Input
                  id="impressions"
                  type="number"
                  value={formData.impressions || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('impressions', Number(e.target.value))
                  }
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="clicks">Clicks</Label>
                <Input
                  id="clicks"
                  type="number"
                  value={formData.clicks || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('clicks', Number(e.target.value))
                  }
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="mintsOrBuys">Mints / Buys</Label>
                <Input
                  id="mintsOrBuys"
                  type="number"
                  value={formData.mintsOrBuys || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('mintsOrBuys', Number(e.target.value))
                  }
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="remixesOrReshares">Remixes / Reshares</Label>
                <Input
                  id="remixesOrReshares"
                  type="number"
                  value={formData.remixesOrReshares || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('remixesOrReshares', Number(e.target.value))
                  }
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="comments">Comments</Label>
                <Input
                  id="comments"
                  type="number"
                  value={formData.comments || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('comments', Number(e.target.value))
                  }
                  min="0"
                />
              </div>

              <div>
                <Label htmlFor="savesOrBookmarks">Saves / Bookmarks</Label>
                <Input
                  id="savesOrBookmarks"
                  type="number"
                  value={formData.savesOrBookmarks || 0}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    handleChange('savesOrBookmarks', Number(e.target.value))
                  }
                  min="0"
                />
              </div>
            </CardContent>
          </Card>

          <div>
            <Label>Channel Breakdown (Optional)</Label>
            <div className="flex gap-2 mt-2">
              <Input
                placeholder="Channel name (e.g., X, Farcaster)"
                value={channelKey}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setChannelKey(e.target.value)}
              />
              <Input
                type="number"
                placeholder="Impressions"
                value={channelValue}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => setChannelValue(e.target.value)}
                min="0"
              />
              <Button type="button" onClick={handleAddChannel}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {formData.channelBreakdown && Object.keys(formData.channelBreakdown).length > 0 && (
              <div className="mt-3 space-y-2">
                {Object.entries(formData.channelBreakdown).map(([key, value]: [string, number]) => (
                  <div key={key} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                    <span className="font-medium">{key}</span>
                    <div className="flex items-center gap-2">
                      <span>{value.toLocaleString()}</span>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => handleRemoveChannel(key)}
                      >
                        <X className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div>
            <Label htmlFor="notes">Notes (Optional)</Label>
            <Textarea
              id="notes"
              value={formData.notes || ''}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => 
                handleChange('notes', e.target.value)
              }
              placeholder="Any observations or context for this period"
              rows={3}
            />
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">
              Save & Compute Resonance
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
