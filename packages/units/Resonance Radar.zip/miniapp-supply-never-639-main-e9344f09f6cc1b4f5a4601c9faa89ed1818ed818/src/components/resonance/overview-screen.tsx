'use client';

import { useState, useEffect } from 'react';
import type { TrackedUnit, ResonanceSummary, UnitType, UnitStatus, RecommendationType } from '@/types/resonance';
import { getAllUnits, getAllSummaries } from '@/lib/resonance-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { 
  ArrowUp, 
  ArrowDown, 
  ArrowRight, 
  HelpCircle, 
  Plus, 
  TrendingUp,
  BarChart3,
  GitCompare,
  Download,
  Upload,
  Settings,
  Bell
} from 'lucide-react';
import {
  exportAllUnitsJSON,
  exportUnitsCSV,
  exportMetricsCSV,
  exportSummariesCSV,
  importFromJSON,
} from '@/lib/export-utils';
import { getAllSnapshots, saveUnit, saveSnapshot, saveSummary } from '@/lib/resonance-storage';
import { toast } from 'sonner';
import type { MetricsSnapshot } from '@/types/resonance';

interface OverviewScreenProps {
  onCreateUnit: () => void;
  onViewUnit: (unitId: string) => void;
  onViewPortfolio: () => void;
  onViewComparison: () => void;
  onViewIntegrations?: () => void;
  onViewAlerts?: () => void;
}

export function OverviewScreen({ onCreateUnit, onViewUnit, onViewPortfolio, onViewComparison, onViewIntegrations, onViewAlerts }: OverviewScreenProps) {
  const [units, setUnits] = useState<TrackedUnit[]>([]);
  const [summaries, setSummaries] = useState<Map<string, ResonanceSummary>>(new Map());
  const [typeFilter, setTypeFilter] = useState<string>('all');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [recommendationFilter, setRecommendationFilter] = useState<string>('all');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = (): void => {
    const allUnits = getAllUnits();
    const allSummaries = getAllSummaries();
    
    const summaryMap = new Map<string, ResonanceSummary>();
    allSummaries.forEach((summary: ResonanceSummary) => {
      summaryMap.set(summary.unitId, summary);
    });
    
    setUnits(allUnits);
    setSummaries(summaryMap);
  };

  const handleExportAll = (): void => {
    const allSnapshots = getAllSnapshots();
    exportAllUnitsJSON(units, allSnapshots, Array.from(summaries.values()));
    toast.success('Data exported as JSON');
  };

  const handleExportCSV = (type: 'units' | 'metrics' | 'summaries'): void => {
    switch (type) {
      case 'units':
        exportUnitsCSV(units);
        break;
      case 'metrics':
        exportMetricsCSV(getAllSnapshots());
        break;
      case 'summaries':
        exportSummariesCSV(Array.from(summaries.values()));
        break;
    }
    toast.success(`${type} exported as CSV`);
  };

  const handleImport = async (event: React.ChangeEvent<HTMLInputElement>): Promise<void> => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      const data = await importFromJSON(file);
      
      // Save imported data
      data.units.forEach(saveUnit);
      data.snapshots.forEach(saveSnapshot);
      data.summaries.forEach(saveSummary);
      
      loadData();
      toast.success(`Imported ${data.units.length} units, ${data.snapshots.length} snapshots`);
    } catch (error) {
      toast.error('Failed to import data. Please check the file format.');
    }

    // Reset file input
    event.target.value = '';
  };

  const filteredUnits = units.filter((unit: TrackedUnit) => {
    if (typeFilter !== 'all' && unit.type !== typeFilter) return false;
    if (statusFilter !== 'all' && unit.status !== statusFilter) return false;
    if (recommendationFilter !== 'all') {
      const summary = summaries.get(unit.id);
      if (!summary || summary.recommendation !== recommendationFilter) return false;
    }
    return true;
  });

  const getTrendIcon = (trend: string): JSX.Element => {
    switch (trend) {
      case 'rising':
        return <ArrowUp className="h-4 w-4 text-green-500" />;
      case 'falling':
        return <ArrowDown className="h-4 w-4 text-red-500" />;
      case 'flat':
        return <ArrowRight className="h-4 w-4 text-yellow-500" />;
      default:
        return <HelpCircle className="h-4 w-4 text-gray-400" />;
    }
  };

  const getRecommendationBadge = (recommendation: RecommendationType): JSX.Element => {
    const variants: Record<RecommendationType, { variant: 'default' | 'secondary' | 'destructive' | 'outline', className: string }> = {
      amplify: { variant: 'default', className: 'bg-green-500 hover:bg-green-600' },
      evolve: { variant: 'default', className: 'bg-blue-500 hover:bg-blue-600' },
      watch: { variant: 'secondary', className: '' },
      pause: { variant: 'outline', className: '' },
      retire: { variant: 'destructive', className: '' },
    };
    
    const config = variants[recommendation];
    return (
      <Badge variant={config.variant} className={config.className}>
        {recommendation}
      </Badge>
    );
  };

  const getStatusBadge = (status: UnitStatus): JSX.Element => {
    const variants: Record<UnitStatus, 'default' | 'secondary' | 'outline'> = {
      new: 'default',
      growing: 'default',
      stable: 'secondary',
      declining: 'outline',
      retired: 'outline',
    };
    
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <TrendingUp className="h-8 w-8" />
            Resonance Radar
          </h1>
          <p className="text-gray-600 mt-1">
            Track cultural performance and resonance
          </p>
        </div>
        <div className="flex gap-2 flex-wrap">
          {onViewAlerts && (
            <Button onClick={onViewAlerts} variant="outline" size="lg">
              <Bell className="h-5 w-5 mr-2" />
              Alerts
            </Button>
          )}
          {onViewIntegrations && (
            <Button onClick={onViewIntegrations} variant="outline" size="lg">
              <Settings className="h-5 w-5 mr-2" />
              Integrations
            </Button>
          )}
          <Button onClick={onViewPortfolio} variant="outline" size="lg">
            <BarChart3 className="h-5 w-5 mr-2" />
            Portfolio
          </Button>
          <Button onClick={onViewComparison} variant="outline" size="lg">
            <GitCompare className="h-5 w-5 mr-2" />
            Compare
          </Button>
          <Button onClick={onCreateUnit} size="lg">
            <Plus className="h-5 w-5 mr-2" />
            Add Unit
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-4">
          <div className="flex-1 min-w-[200px]">
            <label className="text-sm font-medium mb-2 block">Type</label>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="culture-coin">CultureCoin</SelectItem>
                <SelectItem value="drop">Drop</SelectItem>
                <SelectItem value="meme">Meme</SelectItem>
                <SelectItem value="campaign">Campaign</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[200px]">
            <label className="text-sm font-medium mb-2 block">Status</label>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Statuses</SelectItem>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="growing">Growing</SelectItem>
                <SelectItem value="stable">Stable</SelectItem>
                <SelectItem value="declining">Declining</SelectItem>
                <SelectItem value="retired">Retired</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1 min-w-[200px]">
            <label className="text-sm font-medium mb-2 block">Recommendation</label>
            <Select value={recommendationFilter} onValueChange={setRecommendationFilter}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Recommendations</SelectItem>
                <SelectItem value="amplify">Amplify</SelectItem>
                <SelectItem value="evolve">Evolve</SelectItem>
                <SelectItem value="watch">Watch</SelectItem>
                <SelectItem value="pause">Pause</SelectItem>
                <SelectItem value="retire">Retire</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>
            Tracked Units ({filteredUnits.length})
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredUnits.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No units tracked yet</p>
              <Button onClick={onCreateUnit}>
                <Plus className="h-4 w-4 mr-2" />
                Create Your First Unit
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Name</TableHead>
                    <TableHead>Type</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Trend</TableHead>
                    <TableHead>Recommendation</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUnits.map((unit: TrackedUnit) => {
                    const summary = summaries.get(unit.id);
                    return (
                      <TableRow key={unit.id}>
                        <TableCell className="font-medium">
                          <div className="flex items-center gap-2">
                            {unit.primaryEmoji && (
                              <span className="text-2xl">{unit.primaryEmoji}</span>
                            )}
                            <span>{unit.name}</span>
                          </div>
                        </TableCell>
                        <TableCell>{unit.type}</TableCell>
                        <TableCell>{getStatusBadge(unit.status)}</TableCell>
                        <TableCell>
                          {summary ? (
                            <span className="font-bold text-lg">
                              {summary.resonanceScore}
                            </span>
                          ) : (
                            <span className="text-gray-400">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {summary ? (
                            <div className="flex items-center gap-1">
                              {getTrendIcon(summary.trend)}
                              <span className="text-sm">{summary.trend}</span>
                            </div>
                          ) : (
                            <span className="text-gray-400">—</span>
                          )}
                        </TableCell>
                        <TableCell>
                          {summary ? (
                            getRecommendationBadge(summary.recommendation)
                          ) : (
                            <Badge variant="outline">No data</Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <Button 
                            variant="outline" 
                            size="sm"
                            onClick={() => onViewUnit(unit.id)}
                          >
                            View Details
                          </Button>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900">How Resonance Score Works</CardTitle>
          </CardHeader>
          <CardContent className="text-sm text-blue-900">
            <p className="mb-2">
              The Resonance Score (0-100) measures cultural impact through:
            </p>
            <ul className="space-y-1 ml-4">
              <li><strong>CTR (25%):</strong> Click-through rate shows initial interest</li>
              <li><strong>Conversion (30%):</strong> Mints/buys indicate commitment</li>
              <li><strong>Engagement (20%):</strong> Comments + saves show connection</li>
              <li><strong>Remix Rate (25%):</strong> Reshares measure viral spread</li>
            </ul>
            <p className="mt-3">
              <strong>Recommendations:</strong> Amplify (70+), Evolve (40-69 rising), 
              Watch (40-69 flat/falling), Pause (20-39), Retire (&lt;20)
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-black">Data Management</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex flex-col gap-2">
              <Button onClick={handleExportAll} variant="outline" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export All Data (JSON)
              </Button>
              <div className="grid grid-cols-3 gap-2">
                <Button onClick={() => handleExportCSV('units')} variant="outline" size="sm">
                  Units CSV
                </Button>
                <Button onClick={() => handleExportCSV('metrics')} variant="outline" size="sm">
                  Metrics CSV
                </Button>
                <Button onClick={() => handleExportCSV('summaries')} variant="outline" size="sm">
                  Summaries CSV
                </Button>
              </div>
              <div className="relative">
                <input
                  type="file"
                  accept=".json"
                  onChange={handleImport}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                  id="file-import"
                />
                <Button variant="outline" className="w-full justify-start" asChild>
                  <label htmlFor="file-import" className="cursor-pointer">
                    <Upload className="h-4 w-4 mr-2" />
                    Import Data (JSON)
                  </label>
                </Button>
              </div>
            </div>
            <p className="text-xs text-gray-600">
              Export and import your data for backup or analysis in other tools.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
