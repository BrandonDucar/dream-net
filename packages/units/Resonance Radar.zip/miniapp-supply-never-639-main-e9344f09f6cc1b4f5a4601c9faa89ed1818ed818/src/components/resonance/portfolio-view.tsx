'use client'

import { useMemo } from 'react';
import type { TrackedUnit, ResonanceSummary, MetricsSnapshot } from '@/types/resonance';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  LineChart,
  Line,
} from 'recharts';

interface PortfolioViewProps {
  units: TrackedUnit[];
  summaries: ResonanceSummary[];
  snapshots: MetricsSnapshot[];
  onBack?: () => void;
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

import { Button } from '@/components/ui/button';
import { ArrowLeft } from 'lucide-react';

export function PortfolioView({ units, summaries, snapshots, onBack }: PortfolioViewProps): JSX.Element {
  const portfolioStats = useMemo(() => {
    const totalUnits = units.length;
    const activeUnits = units.filter((u: TrackedUnit) => 
      u.status === 'new' || u.status === 'growing' || u.status === 'stable'
    ).length;

    const avgScore = summaries.length > 0
      ? summaries.reduce((sum: number, s: ResonanceSummary) => sum + s.resonanceScore, 0) / summaries.length
      : 0;

    const totalImpressions = snapshots.reduce((sum: number, s: MetricsSnapshot) => sum + s.impressions, 0);
    const totalClicks = snapshots.reduce((sum: number, s: MetricsSnapshot) => sum + s.clicks, 0);
    const totalMintsOrBuys = snapshots.reduce((sum: number, s: MetricsSnapshot) => sum + s.mintsOrBuys, 0);
    const totalRemixes = snapshots.reduce((sum: number, s: MetricsSnapshot) => sum + s.remixesOrReshares, 0);

    const recommendationCounts = summaries.reduce((acc: Record<string, number>, s: ResonanceSummary) => {
      acc[s.recommendation] = (acc[s.recommendation] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const statusCounts = units.reduce((acc: Record<string, number>, u: TrackedUnit) => {
      acc[u.status] = (acc[u.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const typeCounts = units.reduce((acc: Record<string, number>, u: TrackedUnit) => {
      acc[u.type] = (acc[u.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      totalUnits,
      activeUnits,
      avgScore: Math.round(avgScore * 10) / 10,
      totalImpressions,
      totalClicks,
      totalMintsOrBuys,
      totalRemixes,
      recommendationCounts,
      statusCounts,
      typeCounts,
    };
  }, [units, summaries, snapshots]);

  // Top performers
  const topPerformers = useMemo(() => {
    return [...summaries]
      .sort((a: ResonanceSummary, b: ResonanceSummary) => b.resonanceScore - a.resonanceScore)
      .slice(0, 5)
      .map((summary: ResonanceSummary) => {
        const unit = units.find((u: TrackedUnit) => u.id === summary.unitId);
        return { summary, unit };
      })
      .filter((item: { summary: ResonanceSummary; unit: TrackedUnit | undefined }) => item.unit !== undefined);
  }, [summaries, units]);

  // Bottom performers (needs attention)
  const needsAttention = useMemo(() => {
    return [...summaries]
      .filter((s: ResonanceSummary) => s.recommendation === 'pause' || s.recommendation === 'retire')
      .sort((a: ResonanceSummary, b: ResonanceSummary) => a.resonanceScore - b.resonanceScore)
      .slice(0, 5)
      .map((summary: ResonanceSummary) => {
        const unit = units.find((u: TrackedUnit) => u.id === summary.unitId);
        return { summary, unit };
      })
      .filter((item: { summary: ResonanceSummary; unit: TrackedUnit | undefined }) => item.unit !== undefined);
  }, [summaries, units]);

  // Chart data for recommendations
  const recommendationData = Object.entries(portfolioStats.recommendationCounts).map(([key, value]) => ({
    name: key,
    value: value as number,
  }));

  // Chart data for types
  const typeData = Object.entries(portfolioStats.typeCounts).map(([key, value]) => ({
    name: key,
    count: value as number,
  }));

  // Status data
  const statusData = Object.entries(portfolioStats.statusCounts).map(([key, value]) => ({
    name: key,
    value: value as number,
  }));

  // Performance over time (last 10 snapshots across all units)
  const performanceOverTime = useMemo(() => {
    const recentSnapshots = [...snapshots]
      .sort((a: MetricsSnapshot, b: MetricsSnapshot) => 
        new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
      )
      .slice(-10);

    return recentSnapshots.map((s: MetricsSnapshot) => ({
      period: s.periodLabel,
      impressions: s.impressions,
      clicks: s.clicks,
      mints: s.mintsOrBuys,
    }));
  }, [snapshots]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {onBack && (
            <Button variant="ghost" onClick={onBack}>
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <div>
            <h1 className="text-3xl font-bold text-black">Portfolio Dashboard</h1>
            <p className="text-gray-600 mt-1">Aggregate view of all culture objects</p>
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Units</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{portfolioStats.totalUnits}</div>
            <p className="text-xs text-gray-500 mt-1">{portfolioStats.activeUnits} active</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Avg Resonance Score</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">{portfolioStats.avgScore}</div>
            <Progress value={portfolioStats.avgScore} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Impressions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {portfolioStats.totalImpressions.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {portfolioStats.totalClicks.toLocaleString()} clicks
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Conversions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-black">
              {portfolioStats.totalMintsOrBuys.toLocaleString()}
            </div>
            <p className="text-xs text-gray-500 mt-1">
              {portfolioStats.totalRemixes.toLocaleString()} remixes
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recommendations Distribution */}
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Recommendations Distribution</CardTitle>
            <CardDescription>Actions suggested for your units</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={recommendationData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry: { name: string; value: number }) => `${entry.name}: ${entry.value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {recommendationData.map((_entry: { name: string; value: number }, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Unit Types */}
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Unit Types</CardTitle>
            <CardDescription>Distribution by object type</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={typeData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Bar dataKey="count" fill="#0088FE" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Performance Over Time */}
      {performanceOverTime.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Performance Trends</CardTitle>
            <CardDescription>Recent activity across all units</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={performanceOverTime}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="period" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="impressions" stroke="#8884d8" />
                <Line type="monotone" dataKey="clicks" stroke="#82ca9d" />
                <Line type="monotone" dataKey="mints" stroke="#ffc658" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Top Performers */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">🏆 Top Performers</CardTitle>
          <CardDescription>Your best-performing culture objects</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {topPerformers.length === 0 ? (
              <p className="text-gray-500 text-center py-4">No data yet. Add metrics to see top performers.</p>
            ) : (
              topPerformers.map((item: { summary: ResonanceSummary; unit: TrackedUnit | undefined }, index: number) => {
                if (!item.unit) return null;
                return (
                  <div key={item.unit.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl font-bold text-gray-400">#{index + 1}</div>
                      <div className="text-2xl">{item.unit.primaryEmoji}</div>
                      <div>
                        <div className="font-semibold text-black">{item.unit.name}</div>
                        <div className="text-sm text-gray-500">{item.unit.type} • {item.unit.chain}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-black">{item.summary.resonanceScore}</div>
                      <Badge variant={item.summary.trend === 'rising' ? 'default' : 'secondary'}>
                        {item.summary.trend === 'rising' ? '↑' : item.summary.trend === 'falling' ? '↓' : '→'} {item.summary.recommendation}
                      </Badge>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      {/* Needs Attention */}
      {needsAttention.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-black">⚠️ Needs Attention</CardTitle>
            <CardDescription>Units requiring review or action</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {needsAttention.map((item: { summary: ResonanceSummary; unit: TrackedUnit | undefined }) => {
                if (!item.unit) return null;
                return (
                  <div key={item.unit.id} className="flex items-center justify-between p-3 border border-red-200 rounded-lg bg-red-50">
                    <div className="flex items-center gap-3">
                      <div className="text-2xl">{item.unit.primaryEmoji}</div>
                      <div>
                        <div className="font-semibold text-black">{item.unit.name}</div>
                        <div className="text-sm text-gray-500">{item.unit.type} • {item.unit.chain}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-2xl font-bold text-red-600">{item.summary.resonanceScore}</div>
                      <Badge variant="destructive">{item.summary.recommendation}</Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Status Distribution */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Status Overview</CardTitle>
          <CardDescription>Current state of all units</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {statusData.map((item: { name: string; value: number }) => (
              <div key={item.name} className="text-center p-4 border rounded-lg">
                <div className="text-3xl font-bold text-black">{item.value}</div>
                <div className="text-sm text-gray-600 capitalize mt-1">{item.name}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
