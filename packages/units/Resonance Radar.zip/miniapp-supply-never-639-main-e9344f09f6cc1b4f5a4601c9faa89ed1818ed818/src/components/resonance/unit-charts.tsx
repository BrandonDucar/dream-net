'use client'

import type { MetricsSnapshot, ResonanceSummary } from '@/types/resonance';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from 'recharts';

interface UnitChartsProps {
  snapshots: MetricsSnapshot[];
  summaries?: ResonanceSummary[];
}

const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884d8', '#82ca9d'];

export function UnitCharts({ snapshots, summaries }: UnitChartsProps): JSX.Element {
  // Sort snapshots by timestamp
  const sortedSnapshots = [...snapshots].sort((a: MetricsSnapshot, b: MetricsSnapshot) => 
    new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
  );

  // Time series data for resonance score
  const resonanceOverTime = sortedSnapshots.map((snapshot: MetricsSnapshot) => {
    // Calculate score for each snapshot
    const impressions = Math.max(snapshot.impressions, 1);
    const ctr = (snapshot.clicks / impressions) * 100;
    const conversionRate = (snapshot.mintsOrBuys / impressions) * 100;
    const engagementRate = ((snapshot.comments + snapshot.savesOrBookmarks) / impressions) * 100;
    
    return {
      period: snapshot.periodLabel,
      impressions: snapshot.impressions,
      clicks: snapshot.clicks,
      mints: snapshot.mintsOrBuys,
      ctr: Math.round(ctr * 100) / 100,
      conversionRate: Math.round(conversionRate * 100) / 100,
      engagementRate: Math.round(engagementRate * 100) / 100,
    };
  });

  // Channel breakdown from latest snapshot
  const latestSnapshot = sortedSnapshots[sortedSnapshots.length - 1];
  const channelData = latestSnapshot
    ? Object.entries(latestSnapshot.channelBreakdown).map(([channel, count]) => ({
        name: channel,
        value: count as number,
      }))
    : [];

  // Engagement breakdown
  const engagementData = latestSnapshot
    ? [
        { name: 'Clicks', value: latestSnapshot.clicks },
        { name: 'Mints/Buys', value: latestSnapshot.mintsOrBuys },
        { name: 'Comments', value: latestSnapshot.comments },
        { name: 'Saves', value: latestSnapshot.savesOrBookmarks },
        { name: 'Remixes', value: latestSnapshot.remixesOrReshares },
      ]
    : [];

  if (snapshots.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <p className="text-gray-500">No metrics data yet. Add snapshots to see charts.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {/* Performance Over Time */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Performance Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={resonanceOverTime}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="impressions" stroke="#8884d8" name="Impressions" />
              <Line type="monotone" dataKey="clicks" stroke="#82ca9d" name="Clicks" />
              <Line type="monotone" dataKey="mints" stroke="#ffc658" name="Mints/Buys" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Rates Over Time */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Conversion Rates Over Time</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={resonanceOverTime}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="period" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="ctr" stroke="#0088FE" name="CTR %" />
              <Line type="monotone" dataKey="conversionRate" stroke="#00C49F" name="Conversion Rate %" />
              <Line type="monotone" dataKey="engagementRate" stroke="#FFBB28" name="Engagement Rate %" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Channel Breakdown */}
      {channelData.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="text-black">Channel Distribution (Latest)</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={channelData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry: { name: string; value: number }) => 
                    `${entry.name}: ${entry.value.toLocaleString()}`
                  }
                  outerRadius={100}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {channelData.map((_entry: { name: string; value: number }, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}

      {/* Engagement Breakdown */}
      <Card>
        <CardHeader>
          <CardTitle className="text-black">Engagement Breakdown (Latest)</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={engagementData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="value" fill="#8884d8">
                {engagementData.map((_entry: { name: string; value: number }, index: number) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
