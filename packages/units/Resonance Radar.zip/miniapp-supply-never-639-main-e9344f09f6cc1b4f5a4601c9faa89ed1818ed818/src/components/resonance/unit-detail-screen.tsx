'use client';

import { useState, useEffect } from 'react';
import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/types/resonance';
import { 
  getUnitById, 
  getSnapshotsByUnitId, 
  getSummaryByUnitId, 
  saveUnit,
  deleteUnit 
} from '@/lib/resonance-storage';
import { createResonanceSummary } from '@/lib/resonance-scoring';
import { saveSummary } from '@/lib/resonance-storage';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Separator } from '@/components/ui/separator';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  ArrowLeft, 
  Edit, 
  Plus, 
  RefreshCw, 
  FileText, 
  TrendingUp,
  TrendingDown,
  Activity,
  Trash2,
  AlertCircle
} from 'lucide-react';
import { MetricsFormDialog } from './metrics-form-dialog';
import { InsightReportDialog } from './insight-report-dialog';
import { UnitCharts } from './unit-charts';
import { GoalsTracker } from '@/components/GoalsTracker';
import { AIInsightsPanel } from '@/components/AIInsightsPanel';
import { PredictionsViewer } from '@/components/PredictionsViewer';
import { BenchmarkComparison } from '@/components/BenchmarkComparison';
import { AutoSyncPanel } from '@/components/AutoSyncPanel';
import { toast } from 'sonner';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from '@/components/ui/alert-dialog';

interface UnitDetailScreenProps {
  unitId: string;
  onBack: () => void;
  onEdit: (unitId: string) => void;
}

export function UnitDetailScreen({ unitId, onBack, onEdit }: UnitDetailScreenProps) {
  const [unit, setUnit] = useState<TrackedUnit | null>(null);
  const [snapshots, setSnapshots] = useState<MetricsSnapshot[]>([]);
  const [summary, setSummary] = useState<ResonanceSummary | null>(null);
  const [showMetricsDialog, setShowMetricsDialog] = useState<boolean>(false);
  const [showReportDialog, setShowReportDialog] = useState<boolean>(false);

  useEffect(() => {
    loadData();
  }, [unitId]);

  const loadData = (): void => {
    const unitData = getUnitById(unitId);
    const snapshotData = getSnapshotsByUnitId(unitId);
    const summaryData = getSummaryByUnitId(unitId);

    setUnit(unitData);
    setSnapshots(snapshotData);
    setSummary(summaryData);
  };

  const handleStatusChange = (newStatus: string): void => {
    if (!unit) return;
    
    const updatedUnit = { ...unit, status: newStatus as TrackedUnit['status'] };
    saveUnit(updatedUnit);
    setUnit(updatedUnit);
    toast.success('Status updated');
  };

  const handleRecomputeResonance = (): void => {
    if (snapshots.length === 0) {
      toast.error('No metrics data to compute resonance');
      return;
    }

    const latestSnapshot = snapshots[0];
    const previousSnapshot = snapshots.length > 1 ? snapshots[1] : null;

    const newSummary = createResonanceSummary(latestSnapshot, previousSnapshot);
    saveSummary(newSummary);
    setSummary(newSummary);
    toast.success('Resonance score recomputed');
  };

  const handleMetricsSaved = (): void => {
    setShowMetricsDialog(false);
    loadData();
  };

  const handleDeleteUnit = (): void => {
    deleteUnit(unitId);
    toast.success('Unit deleted');
    onBack();
  };

  if (!unit) {
    return (
      <div className="flex items-center justify-center h-96">
        <p className="text-gray-500">Unit not found</p>
      </div>
    );
  }

  const getScoreColor = (score: number): string => {
    if (score >= 70) return 'text-green-600';
    if (score >= 40) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getTrendIcon = (trend: string): JSX.Element => {
    switch (trend) {
      case 'rising':
        return <TrendingUp className="h-6 w-6 text-green-500" />;
      case 'falling':
        return <TrendingDown className="h-6 w-6 text-red-500" />;
      default:
        return <Activity className="h-6 w-6 text-yellow-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <div className="flex items-center gap-3">
            {unit.primaryEmoji && (
              <span className="text-4xl">{unit.primaryEmoji}</span>
            )}
            <div>
              <h1 className="text-3xl font-bold">{unit.name}</h1>
              <p className="text-gray-600">
                {unit.type} on {unit.chain}
              </p>
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => onEdit(unitId)}>
            <Edit className="h-4 w-4 mr-2" />
            Edit
          </Button>
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button variant="destructive">
                <Trash2 className="h-4 w-4 mr-2" />
                Delete
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Delete Unit</AlertDialogTitle>
                <AlertDialogDescription>
                  This will permanently delete &quot;{unit.name}&quot; and all its metrics data. 
                  This action cannot be undone.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction onClick={handleDeleteUnit} className="bg-red-600 hover:bg-red-700">
                  Delete
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium text-gray-600">Status</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={unit.status} onValueChange={handleStatusChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="new">New</SelectItem>
                <SelectItem value="growing">Growing</SelectItem>
                <SelectItem value="stable">Stable</SelectItem>
                <SelectItem value="declining">Declining</SelectItem>
                <SelectItem value="retired">Retired</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {summary && (
          <>
            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Resonance Score</CardTitle>
              </CardHeader>
              <CardContent>
                <div className={`text-4xl font-bold ${getScoreColor(summary.resonanceScore)}`}>
                  {summary.resonanceScore}
                </div>
                <p className="text-xs text-gray-500 mt-1">
                  Last period: {summary.lastPeriodLabel}
                </p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardTitle className="text-sm font-medium text-gray-600">Trend & Action</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 mb-2">
                  {getTrendIcon(summary.trend)}
                  <span className="font-medium capitalize">{summary.trend}</span>
                </div>
                <Badge 
                  variant={
                    summary.recommendation === 'amplify' ? 'default' :
                    summary.recommendation === 'retire' ? 'destructive' : 'secondary'
                  }
                  className={
                    summary.recommendation === 'amplify' ? 'bg-green-500' :
                    summary.recommendation === 'evolve' ? 'bg-blue-500' : ''
                  }
                >
                  {summary.recommendation}
                </Badge>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      {summary && (
        <Card className="bg-blue-50 border-blue-200">
          <CardHeader>
            <CardTitle className="text-blue-900 flex items-center gap-2">
              <AlertCircle className="h-5 w-5" />
              Key Drivers
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-1 text-sm text-blue-900">
              {summary.mainDrivers.map((driver: string, index: number) => (
                <li key={index}>• {driver}</li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Metrics History</CardTitle>
            <div className="flex gap-2">
              <Button onClick={handleRecomputeResonance} variant="outline" size="sm">
                <RefreshCw className="h-4 w-4 mr-2" />
                Recompute
              </Button>
              <Button onClick={() => setShowMetricsDialog(true)} size="sm">
                <Plus className="h-4 w-4 mr-2" />
                Add Metrics
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {snapshots.length === 0 ? (
            <div className="text-center py-12">
              <p className="text-gray-500 mb-4">No metrics data yet</p>
              <Button onClick={() => setShowMetricsDialog(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add First Metrics Snapshot
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Period</TableHead>
                    <TableHead>Impressions</TableHead>
                    <TableHead>Clicks</TableHead>
                    <TableHead>Mints/Buys</TableHead>
                    <TableHead>Remixes</TableHead>
                    <TableHead>Engagement</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {snapshots.map((snapshot: MetricsSnapshot) => (
                    <TableRow key={snapshot.id}>
                      <TableCell className="font-medium">{snapshot.periodLabel}</TableCell>
                      <TableCell>{snapshot.impressions.toLocaleString()}</TableCell>
                      <TableCell>{snapshot.clicks.toLocaleString()}</TableCell>
                      <TableCell>{snapshot.mintsOrBuys.toLocaleString()}</TableCell>
                      <TableCell>{snapshot.remixesOrReshares.toLocaleString()}</TableCell>
                      <TableCell>
                        {(snapshot.comments + snapshot.savesOrBookmarks).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-sm text-gray-500">
                        {new Date(snapshot.timestamp).toLocaleDateString()}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>SEO & Geo Information</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium mb-2">SEO Metadata</h3>
            <div className="space-y-2 text-sm">
              <div>
                <span className="font-medium">Title:</span> {unit.seoTitle || 'Not set'}
              </div>
              <div>
                <span className="font-medium">Description:</span> {unit.seoDescription || 'Not set'}
              </div>
              <div className="flex flex-wrap gap-1">
                <span className="font-medium">Keywords:</span>
                {unit.seoKeywords.length > 0 ? (
                  unit.seoKeywords.map((kw: string, i: number) => (
                    <Badge key={i} variant="outline">{kw}</Badge>
                  ))
                ) : (
                  <span className="text-gray-500">None</span>
                )}
              </div>
              <div className="flex flex-wrap gap-1">
                <span className="font-medium">Hashtags:</span>
                {unit.seoHashtags.length > 0 ? (
                  unit.seoHashtags.map((tag: string, i: number) => (
                    <Badge key={i} variant="secondary">{tag}</Badge>
                  ))
                ) : (
                  <span className="text-gray-500">None</span>
                )}
              </div>
            </div>
          </div>

          {unit.primaryGeoTargets.length > 0 && (
            <>
              <Separator />
              <div>
                <h3 className="font-medium mb-2">Geo Targets</h3>
                <div className="flex flex-wrap gap-2">
                  {unit.primaryGeoTargets.map((geo, i: number) => (
                    <Badge key={i}>
                      {geo.region} {geo.cityOrMarket && `- ${geo.cityOrMarket}`} ({geo.language})
                    </Badge>
                  ))}
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>

      {snapshots.length > 0 && (
        <div>
          <h2 className="text-2xl font-bold mb-4">Performance Charts</h2>
          <UnitCharts snapshots={snapshots} />
        </div>
      )}

      <Tabs defaultValue="insights" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
          <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
          <TabsTrigger value="goals">Goals</TabsTrigger>
          <TabsTrigger value="sync">Auto-Sync</TabsTrigger>
        </TabsList>

        <TabsContent value="insights" className="mt-6">
          {summary && (
            <AIInsightsPanel unit={unit} snapshots={snapshots} summary={summary} />
          )}
        </TabsContent>

        <TabsContent value="predictions" className="mt-6">
          {summary && (
            <PredictionsViewer snapshots={snapshots} summary={summary} />
          )}
        </TabsContent>

        <TabsContent value="benchmarks" className="mt-6">
          {summary && (
            <BenchmarkComparison unit={unit} snapshots={snapshots} summary={summary} />
          )}
        </TabsContent>

        <TabsContent value="goals" className="mt-6">
          <GoalsTracker unit={unit} />
        </TabsContent>

        <TabsContent value="sync" className="mt-6">
          <AutoSyncPanel unit={unit} onSync={loadData} />
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Export & Share</CardTitle>
        </CardHeader>
        <CardContent>
          <Button onClick={() => setShowReportDialog(true)} className="w-full" size="lg">
            <FileText className="h-5 w-5 mr-2" />
            Generate Insight Report
          </Button>
          <p className="text-sm text-gray-600 mt-2">
            Export a comprehensive summary with metrics, recommendations, and SEO data
          </p>
        </CardContent>
      </Card>

      <MetricsFormDialog
        open={showMetricsDialog}
        onClose={() => setShowMetricsDialog(false)}
        unitId={unitId}
        onSave={handleMetricsSaved}
      />

      <InsightReportDialog
        open={showReportDialog}
        onClose={() => setShowReportDialog(false)}
        unit={unit}
        snapshots={snapshots}
        summary={summary}
      />
    </div>
  );
}
