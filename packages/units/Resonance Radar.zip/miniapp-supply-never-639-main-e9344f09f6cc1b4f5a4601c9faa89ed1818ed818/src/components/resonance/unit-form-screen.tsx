'use client';

import { useState, useEffect } from 'react';
import type { TrackedUnit, UnitType, UnitStatus, GeoTarget } from '@/types/resonance';
import { getUnitById, saveUnit } from '@/lib/resonance-storage';
import { generateSEO, generateGeoVariants } from '@/lib/resonance-scoring';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ArrowLeft, Save, RefreshCw, Plus, X, Globe } from 'lucide-react';
import { toast } from 'sonner';

interface UnitFormScreenProps {
  unitId: string | null;
  onBack: () => void;
  onSave: () => void;
}

export function UnitFormScreen({ unitId, onBack, onSave }: UnitFormScreenProps) {
  const [formData, setFormData] = useState<Partial<TrackedUnit>>({
    type: 'culture-coin',
    chain: 'Base',
    status: 'new',
    primaryEmoji: '🎯',
    name: '',
    refId: '',
    seoTitle: '',
    seoDescription: '',
    seoKeywords: [],
    seoHashtags: [],
    altText: '',
    primaryGeoTargets: [],
    captionLocalized: {},
    tagsLocalized: {},
  });

  const [keywordInput, setKeywordInput] = useState<string>('');
  const [hashtagInput, setHashtagInput] = useState<string>('');
  const [geoForm, setGeoForm] = useState<Partial<GeoTarget>>({
    region: '',
    country: '',
    cityOrMarket: '',
    language: 'en',
  });

  useEffect(() => {
    if (unitId) {
      const unit = getUnitById(unitId);
      if (unit) {
        setFormData(unit);
      }
    }
  }, [unitId]);

  const handleChange = (field: keyof TrackedUnit, value: string): void => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleRegenerateSEO = (): void => {
    if (!formData.name || !formData.type || !formData.chain) {
      toast.error('Please fill in name, type, and chain first');
      return;
    }

    const seo = generateSEO(formData as TrackedUnit);
    setFormData(prev => ({ ...prev, ...seo }));
    toast.success('SEO metadata regenerated');
  };

  const handleAddKeyword = (): void => {
    if (keywordInput.trim()) {
      const keywords = formData.seoKeywords || [];
      setFormData(prev => ({ 
        ...prev, 
        seoKeywords: [...keywords, keywordInput.trim()] 
      }));
      setKeywordInput('');
    }
  };

  const handleRemoveKeyword = (index: number): void => {
    const keywords = formData.seoKeywords || [];
    setFormData(prev => ({ 
      ...prev, 
      seoKeywords: keywords.filter((_: string, i: number) => i !== index) 
    }));
  };

  const handleAddHashtag = (): void => {
    if (hashtagInput.trim()) {
      const hashtags = formData.seoHashtags || [];
      const tag = hashtagInput.trim().startsWith('#') 
        ? hashtagInput.trim() 
        : `#${hashtagInput.trim()}`;
      setFormData(prev => ({ 
        ...prev, 
        seoHashtags: [...hashtags, tag] 
      }));
      setHashtagInput('');
    }
  };

  const handleRemoveHashtag = (index: number): void => {
    const hashtags = formData.seoHashtags || [];
    setFormData(prev => ({ 
      ...prev, 
      seoHashtags: hashtags.filter((_: string, i: number) => i !== index) 
    }));
  };

  const handleAddGeoTarget = (): void => {
    if (!geoForm.region || !geoForm.language) {
      toast.error('Region and language are required');
      return;
    }

    const newGeo: GeoTarget = {
      id: `${geoForm.region?.toLowerCase()}-${geoForm.language}`,
      region: geoForm.region || '',
      country: geoForm.country || '',
      cityOrMarket: geoForm.cityOrMarket || '',
      language: geoForm.language || 'en',
    };

    const geoTargets = formData.primaryGeoTargets || [];
    setFormData(prev => ({ 
      ...prev, 
      primaryGeoTargets: [...geoTargets, newGeo] 
    }));

    setGeoForm({ region: '', country: '', cityOrMarket: '', language: 'en' });
    toast.success('Geo target added');
  };

  const handleRemoveGeoTarget = (index: number): void => {
    const geoTargets = formData.primaryGeoTargets || [];
    setFormData(prev => ({ 
      ...prev, 
      primaryGeoTargets: geoTargets.filter((_: GeoTarget, i: number) => i !== index) 
    }));
  };

  const handleGenerateGeoVariants = (): void => {
    if (!formData.name || !formData.primaryGeoTargets || formData.primaryGeoTargets.length === 0) {
      toast.error('Add geo targets first');
      return;
    }

    const variants = generateGeoVariants(formData as TrackedUnit);
    setFormData(prev => ({ 
      ...prev, 
      captionLocalized: variants.captionLocalized,
      tagsLocalized: variants.tagsLocalized,
    }));
    toast.success('Geo variants generated');
  };

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();

    if (!formData.name || !formData.type) {
      toast.error('Name and type are required');
      return;
    }

    const unit: TrackedUnit = {
      id: unitId || `unit_${Date.now()}`,
      type: (formData.type || 'culture-coin') as UnitType,
      refId: formData.refId || '',
      name: formData.name,
      primaryEmoji: formData.primaryEmoji || '🎯',
      chain: formData.chain || 'Base',
      status: (formData.status || 'new') as UnitStatus,
      seoTitle: formData.seoTitle || '',
      seoDescription: formData.seoDescription || '',
      seoKeywords: formData.seoKeywords || [],
      seoHashtags: formData.seoHashtags || [],
      altText: formData.altText || '',
      primaryGeoTargets: formData.primaryGeoTargets || [],
      captionLocalized: formData.captionLocalized || {},
      tagsLocalized: formData.tagsLocalized || {},
      createdAt: unitId ? (getUnitById(unitId)?.createdAt || new Date().toISOString()) : new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveUnit(unit);
    toast.success(unitId ? 'Unit updated' : 'Unit created');
    onSave();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" onClick={onBack}>
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h1 className="text-3xl font-bold">
            {unitId ? 'Edit Unit' : 'Create New Unit'}
          </h1>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Basic Information</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="name">Name *</Label>
                <Input
                  id="name"
                  value={formData.name || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('name', e.target.value)}
                  placeholder="My CultureCoin"
                  required
                />
              </div>

              <div>
                <Label htmlFor="primaryEmoji">Primary Emoji</Label>
                <Input
                  id="primaryEmoji"
                  value={formData.primaryEmoji || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('primaryEmoji', e.target.value)}
                  placeholder="🎯"
                />
              </div>

              <div>
                <Label htmlFor="type">Type *</Label>
                <Select 
                  value={formData.type || 'culture-coin'} 
                  onValueChange={(value: string) => handleChange('type', value)}
                >
                  <SelectTrigger id="type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="culture-coin">CultureCoin</SelectItem>
                    <SelectItem value="drop">Drop</SelectItem>
                    <SelectItem value="meme">Meme</SelectItem>
                    <SelectItem value="campaign">Campaign</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="chain">Chain</Label>
                <Input
                  id="chain"
                  value={formData.chain || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('chain', e.target.value)}
                  placeholder="Base"
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select 
                  value={formData.status || 'new'} 
                  onValueChange={(value: string) => handleChange('status', value)}
                >
                  <SelectTrigger id="status">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="growing">Growing</SelectItem>
                    <SelectItem value="stable">Stable</SelectItem>
                    <SelectItem value="declining">Declining</SelectItem>
                    <SelectItem value="retired">Retired</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="refId">Reference ID</Label>
                <Input
                  id="refId"
                  value={formData.refId || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('refId', e.target.value)}
                  placeholder="Link to other apps"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>SEO Metadata</CardTitle>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={handleRegenerateSEO}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Regenerate SEO
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="seoTitle">SEO Title</Label>
              <Input
                id="seoTitle"
                value={formData.seoTitle || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('seoTitle', e.target.value)}
                placeholder="Title for search engines"
              />
            </div>

            <div>
              <Label htmlFor="seoDescription">SEO Description</Label>
              <Textarea
                id="seoDescription"
                value={formData.seoDescription || ''}
                onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('seoDescription', e.target.value)}
                placeholder="Description for search engines"
                rows={3}
              />
            </div>

            <div>
              <Label htmlFor="altText">Alt Text</Label>
              <Input
                id="altText"
                value={formData.altText || ''}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('altText', e.target.value)}
                placeholder="Image alt text"
              />
            </div>

            <div>
              <Label>Keywords</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={keywordInput}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setKeywordInput(e.target.value)}
                  placeholder="Add keyword"
                  onKeyPress={(e: React.KeyboardEvent) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddKeyword();
                    }
                  }}
                />
                <Button type="button" onClick={handleAddKeyword}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {(formData.seoKeywords || []).map((keyword: string, index: number) => (
                  <Badge key={index} variant="secondary">
                    {keyword}
                    <button
                      type="button"
                      onClick={() => handleRemoveKeyword(index)}
                      className="ml-2"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>

            <div>
              <Label>Hashtags</Label>
              <div className="flex gap-2 mb-2">
                <Input
                  value={hashtagInput}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setHashtagInput(e.target.value)}
                  placeholder="Add hashtag"
                  onKeyPress={(e: React.KeyboardEvent) => {
                    if (e.key === 'Enter') {
                      e.preventDefault();
                      handleAddHashtag();
                    }
                  }}
                />
                <Button type="button" onClick={handleAddHashtag}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              <div className="flex flex-wrap gap-2">
                {(formData.seoHashtags || []).map((hashtag: string, index: number) => (
                  <Badge key={index} variant="secondary">
                    {hashtag}
                    <button
                      type="button"
                      onClick={() => handleRemoveHashtag(index)}
                      className="ml-2"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Geo Targeting
              </CardTitle>
              <Button 
                type="button" 
                variant="outline" 
                size="sm"
                onClick={handleGenerateGeoVariants}
              >
                <RefreshCw className="h-4 w-4 mr-2" />
                Generate Variants
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div>
                <Label>Region</Label>
                <Input
                  value={geoForm.region || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setGeoForm(prev => ({ ...prev, region: e.target.value }))
                  }
                  placeholder="US, LATAM, EU"
                />
              </div>
              <div>
                <Label>Country</Label>
                <Input
                  value={geoForm.country || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setGeoForm(prev => ({ ...prev, country: e.target.value }))
                  }
                  placeholder="ISO code"
                />
              </div>
              <div>
                <Label>City/Market</Label>
                <Input
                  value={geoForm.cityOrMarket || ''}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                    setGeoForm(prev => ({ ...prev, cityOrMarket: e.target.value }))
                  }
                  placeholder="Miami, Berlin"
                />
              </div>
              <div>
                <Label>Language</Label>
                <Select 
                  value={geoForm.language || 'en'} 
                  onValueChange={(value: string) => 
                    setGeoForm(prev => ({ ...prev, language: value }))
                  }
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="en">English</SelectItem>
                    <SelectItem value="es">Spanish</SelectItem>
                    <SelectItem value="pt-BR">Portuguese (BR)</SelectItem>
                    <SelectItem value="fr">French</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button type="button" onClick={handleAddGeoTarget} className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Geo Target
            </Button>

            {formData.primaryGeoTargets && formData.primaryGeoTargets.length > 0 && (
              <>
                <Separator />
                <div className="space-y-2">
                  <Label>Current Geo Targets</Label>
                  <div className="space-y-2">
                    {formData.primaryGeoTargets.map((geo: GeoTarget, index: number) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                        <div className="flex flex-wrap gap-2">
                          <Badge>{geo.region}</Badge>
                          {geo.country && <Badge variant="outline">{geo.country}</Badge>}
                          {geo.cityOrMarket && <Badge variant="outline">{geo.cityOrMarket}</Badge>}
                          <Badge variant="secondary">{geo.language}</Badge>
                        </div>
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveGeoTarget(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                  </div>
                </div>

                {Object.keys(formData.captionLocalized || {}).length > 0 && (
                  <>
                    <Separator />
                    <div className="space-y-2">
                      <Label>Localized Captions & Tags</Label>
                      <div className="space-y-3">
                        {Object.entries(formData.captionLocalized || {}).map(([geoKey, caption]: [string, string]) => (
                          <div key={geoKey} className="p-3 bg-blue-50 rounded">
                            <div className="font-medium mb-1">{geoKey}</div>
                            <div className="text-sm mb-2">{caption}</div>
                            <div className="flex flex-wrap gap-1">
                              {((formData.tagsLocalized || {})[geoKey] || []).map((tag: string, i: number) => (
                                <Badge key={i} variant="outline" className="text-xs">
                                  {tag}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  </>
                )}
              </>
            )}
          </CardContent>
        </Card>

        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline" onClick={onBack}>
            Cancel
          </Button>
          <Button type="submit">
            <Save className="h-4 w-4 mr-2" />
            {unitId ? 'Update Unit' : 'Create Unit'}
          </Button>
        </div>
      </form>
    </div>
  );
}
