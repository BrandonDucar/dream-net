/**
 * AI-Powered Insights Engine
 * 
 * Generates smart recommendations based on patterns and historical data
 */

import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from './types';

export interface AIInsight {
  id: string;
  unitId: string;
  type: 'opportunity' | 'warning' | 'optimization' | 'trend' | 'recommendation';
  title: string;
  description: string;
  confidence: number; // 0-1
  actionItems: string[];
  createdAt: string;
  relevanceScore: number; // 0-100
}

export function generateAIInsights(
  unit: TrackedUnit,
  snapshots: MetricsSnapshot[],
  summary: ResonanceSummary
): AIInsight[] {
  const insights: AIInsight[] = [];
  const now = new Date().toISOString();

  // Pattern 1: Identify best performing channel
  const channelInsight = analyzeChannelPerformance(unit, snapshots);
  if (channelInsight) {
    insights.push({ ...channelInsight, id: `${Date.now()}-channel`, unitId: unit.id, createdAt: now });
  }

  // Pattern 2: Time-of-day optimization
  const timeInsight = analyzeTimePatterns(snapshots);
  if (timeInsight) {
    insights.push({ ...timeInsight, id: `${Date.now()}-time`, unitId: unit.id, createdAt: now });
  }

  // Pattern 3: Engagement quality
  const engagementInsight = analyzeEngagementQuality(snapshots);
  if (engagementInsight) {
    insights.push({ ...engagementInsight, id: `${Date.now()}-engagement`, unitId: unit.id, createdAt: now });
  }

  // Pattern 4: Momentum analysis
  const momentumInsight = analyzeMomentum(snapshots, summary);
  if (momentumInsight) {
    insights.push({ ...momentumInsight, id: `${Date.now()}-momentum`, unitId: unit.id, createdAt: now });
  }

  // Pattern 5: Conversion optimization
  const conversionInsight = analyzeConversionFunnel(snapshots);
  if (conversionInsight) {
    insights.push({ ...conversionInsight, id: `${Date.now()}-conversion`, unitId: unit.id, createdAt: now });
  }

  return insights.sort((a: AIInsight, b: AIInsight) => b.relevanceScore - a.relevanceScore);
}

function analyzeChannelPerformance(
  unit: TrackedUnit,
  snapshots: MetricsSnapshot[]
): Omit<AIInsight, 'id' | 'unitId' | 'createdAt'> | null {
  if (snapshots.length === 0) return null;

  // Aggregate channel data
  const channelTotals: Record<string, number> = {};
  snapshots.forEach((snapshot: MetricsSnapshot) => {
    if (snapshot.channelBreakdown) {
      Object.entries(snapshot.channelBreakdown).forEach(([channel, value]) => {
        channelTotals[channel] = (channelTotals[channel] || 0) + value;
      });
    }
  });

  const channels = Object.entries(channelTotals).sort((a, b) => b[1] - a[1]);
  if (channels.length === 0) return null;

  const topChannel = channels[0];
  const totalImpressions = channels.reduce((sum, [, val]) => sum + val, 0);
  const topChannelShare = (topChannel[1] / totalImpressions) * 100;

  if (topChannelShare > 60) {
    return {
      type: 'warning',
      title: 'Channel Over-Concentration',
      description: `${topChannelShare.toFixed(0)}% of impressions come from ${topChannel[0]}. Diversifying channels can reduce risk.`,
      confidence: 0.85,
      actionItems: [
        `Explore expansion to ${channels[1]?.[0] || 'alternative channels'}`,
        'Create channel-specific content variations',
        'Test new distribution platforms',
      ],
      relevanceScore: 75,
    };
  } else if (channels.length >= 3) {
    return {
      type: 'opportunity',
      title: 'Multi-Channel Success',
      description: `Strong performance across ${channels.length} channels. ${topChannel[0]} leads with ${topChannelShare.toFixed(0)}%.`,
      confidence: 0.9,
      actionItems: [
        `Double down on ${topChannel[0]} with more content`,
        'Replicate winning formats to other channels',
        'Cross-promote between channels',
      ],
      relevanceScore: 85,
    };
  }

  return null;
}

function analyzeTimePatterns(
  snapshots: MetricsSnapshot[]
): Omit<AIInsight, 'id' | 'unitId' | 'createdAt'> | null {
  if (snapshots.length < 5) return null;

  // Simple heuristic: check if recent snapshots show better engagement
  const recent = snapshots.slice(0, 3);
  const older = snapshots.slice(3, 6);

  const recentAvgEngagement = recent.reduce((sum: number, s: MetricsSnapshot) => 
    sum + s.comments + s.savesOrBookmarks, 0) / recent.length;
  const olderAvgEngagement = older.reduce((sum: number, s: MetricsSnapshot) => 
    sum + s.comments + s.savesOrBookmarks, 0) / older.length;

  if (recentAvgEngagement > olderAvgEngagement * 1.3) {
    return {
      type: 'trend',
      title: 'Engagement Momentum Building',
      description: 'Recent posts show 30%+ higher engagement. Timing and content resonating better.',
      confidence: 0.75,
      actionItems: [
        'Analyze what changed in recent content',
        'Maintain current posting schedule',
        'Document successful content patterns',
      ],
      relevanceScore: 70,
    };
  }

  return null;
}

function analyzeEngagementQuality(
  snapshots: MetricsSnapshot[]
): Omit<AIInsight, 'id' | 'unitId' | 'createdAt'> | null {
  if (snapshots.length === 0) return null;

  const latest = snapshots[0];
  const engagementRate = latest.impressions > 0
    ? ((latest.comments + latest.savesOrBookmarks + latest.remixesOrReshares) / latest.impressions) * 100
    : 0;

  if (engagementRate > 5) {
    return {
      type: 'opportunity',
      title: 'High-Quality Engagement',
      description: `${engagementRate.toFixed(1)}% engagement rate indicates strong community connection.`,
      confidence: 0.9,
      actionItems: [
        'Leverage this momentum for community building',
        'Create remixable content to encourage participation',
        'Ask community for feedback and ideas',
      ],
      relevanceScore: 90,
    };
  } else if (engagementRate < 0.5 && latest.impressions > 1000) {
    return {
      type: 'warning',
      title: 'Low Engagement Despite Reach',
      description: `Only ${engagementRate.toFixed(2)}% engagement with ${latest.impressions.toLocaleString()} impressions. Content may not resonate.`,
      confidence: 0.8,
      actionItems: [
        'Test different content formats or messaging',
        'Add clear calls-to-action',
        'Survey audience for preferences',
      ],
      relevanceScore: 80,
    };
  }

  return null;
}

function analyzeMomentum(
  snapshots: MetricsSnapshot[],
  summary: ResonanceSummary
): Omit<AIInsight, 'id' | 'unitId' | 'createdAt'> | null {
  if (snapshots.length < 3) return null;

  if (summary.trend === 'rising' && summary.resonanceScore > 70) {
    return {
      type: 'recommendation',
      title: 'Strike While Hot',
      description: `Resonance at ${summary.resonanceScore.toFixed(0)} and rising. Prime time for amplification.`,
      confidence: 0.95,
      actionItems: [
        'Increase posting frequency while momentum lasts',
        'Activate paid promotion or collaborations',
        'Create sequel or spin-off content',
        'Launch complementary products or drops',
      ],
      relevanceScore: 95,
    };
  } else if (summary.trend === 'falling' && summary.resonanceScore < 40) {
    return {
      type: 'warning',
      title: 'Losing Momentum',
      description: `Resonance declining to ${summary.resonanceScore.toFixed(0)}. Time to pivot or refresh.`,
      confidence: 0.85,
      actionItems: [
        'Pause and analyze what changed',
        'Refresh creative or messaging',
        'Consider a relaunch or evolution',
        'Engage community for input',
      ],
      relevanceScore: 85,
    };
  }

  return null;
}

function analyzeConversionFunnel(
  snapshots: MetricsSnapshot[]
): Omit<AIInsight, 'id' | 'unitId' | 'createdAt'> | null {
  if (snapshots.length === 0) return null;

  const latest = snapshots[0];
  const ctr = latest.impressions > 0 ? (latest.clicks / latest.impressions) * 100 : 0;
  const conversionRate = latest.clicks > 0 ? (latest.mintsOrBuys / latest.clicks) * 100 : 0;

  if (ctr > 5 && conversionRate < 2) {
    return {
      type: 'optimization',
      title: 'Conversion Bottleneck',
      description: `Good CTR (${ctr.toFixed(1)}%) but low conversion (${conversionRate.toFixed(1)}%). Landing experience needs optimization.`,
      confidence: 0.8,
      actionItems: [
        'Simplify mint/buy process',
        'Improve landing page clarity',
        'Reduce friction points',
        'A/B test pricing or offers',
      ],
      relevanceScore: 80,
    };
  } else if (ctr < 2 && latest.impressions > 1000) {
    return {
      type: 'optimization',
      title: 'Low Click-Through',
      description: `Only ${ctr.toFixed(2)}% CTR. Creative or messaging not compelling enough.`,
      confidence: 0.85,
      actionItems: [
        'Test new headlines or hooks',
        'Improve visual creative',
        'Add social proof or urgency',
        'Clarify value proposition',
      ],
      relevanceScore: 85,
    };
  }

  return null;
}

export function saveAIInsights(insights: AIInsight[]): void {
  const stored = loadAllAIInsights();
  const newInsights = [...insights, ...stored];
  
  // Keep only last 200 insights
  if (newInsights.length > 200) {
    newInsights.splice(200);
  }
  
  localStorage.setItem('resonance_ai_insights', JSON.stringify(newInsights));
}

export function loadAllAIInsights(): AIInsight[] {
  const stored = localStorage.getItem('resonance_ai_insights');
  return stored ? JSON.parse(stored) : [];
}

export function loadAIInsightsForUnit(unitId: string): AIInsight[] {
  const allInsights = loadAllAIInsights();
  return allInsights.filter((i: AIInsight) => i.unitId === unitId);
}
