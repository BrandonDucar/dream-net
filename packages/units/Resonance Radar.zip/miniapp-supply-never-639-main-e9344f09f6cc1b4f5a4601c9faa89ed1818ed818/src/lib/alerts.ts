/**
 * Alerts & Notifications System
 * 
 * Alert when resonance drops, spikes, or milestones are hit
 */

import type { TrackedUnit, ResonanceSummary } from './types';
import type { Goal } from './goals';

export interface Alert {
  id: string;
  unitId: string;
  type: 'resonance-drop' | 'resonance-spike' | 'goal-achieved' | 'milestone-hit' | 'performance-warning';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  actionUrl?: string;
  createdAt: string;
  read: boolean;
  dismissed: boolean;
}

export interface AlertRule {
  id: string;
  unitId: string | 'all';
  enabled: boolean;
  type: 'resonance-threshold' | 'resonance-change' | 'goal-progress' | 'metric-threshold';
  condition: {
    metric?: 'resonance-score' | 'impressions' | 'clicks' | 'mints';
    operator?: 'above' | 'below' | 'change-up' | 'change-down';
    value?: number;
    percentage?: number;
  };
}

export function saveAlert(alert: Alert): void {
  const alerts = loadAllAlerts();
  alerts.unshift(alert); // Add to beginning
  
  // Keep only last 100 alerts
  if (alerts.length > 100) {
    alerts.splice(100);
  }
  
  localStorage.setItem('resonance_alerts', JSON.stringify(alerts));
}

export function loadAllAlerts(): Alert[] {
  const stored = localStorage.getItem('resonance_alerts');
  return stored ? JSON.parse(stored) : [];
}

export function loadAlertsForUnit(unitId: string): Alert[] {
  const allAlerts = loadAllAlerts();
  return allAlerts.filter((a: Alert) => a.unitId === unitId);
}

export function loadUnreadAlerts(): Alert[] {
  const allAlerts = loadAllAlerts();
  return allAlerts.filter((a: Alert) => !a.read && !a.dismissed);
}

export function markAlertRead(id: string): void {
  const alerts = loadAllAlerts();
  const alert = alerts.find((a: Alert) => a.id === id);
  if (alert) {
    alert.read = true;
    localStorage.setItem('resonance_alerts', JSON.stringify(alerts));
  }
}

export function dismissAlert(id: string): void {
  const alerts = loadAllAlerts();
  const alert = alerts.find((a: Alert) => a.id === id);
  if (alert) {
    alert.dismissed = true;
    localStorage.setItem('resonance_alerts', JSON.stringify(alerts));
  }
}

export function clearAllAlerts(): void {
  localStorage.setItem('resonance_alerts', JSON.stringify([]));
}

export function saveAlertRule(rule: AlertRule): void {
  const rules = loadAllAlertRules();
  const index = rules.findIndex((r: AlertRule) => r.id === rule.id);
  
  if (index >= 0) {
    rules[index] = rule;
  } else {
    rules.push(rule);
  }
  
  localStorage.setItem('resonance_alert_rules', JSON.stringify(rules));
}

export function loadAllAlertRules(): AlertRule[] {
  const stored = localStorage.getItem('resonance_alert_rules');
  return stored ? JSON.parse(stored) : [];
}

export function deleteAlertRule(id: string): void {
  const rules = loadAllAlertRules();
  const filtered = rules.filter((r: AlertRule) => r.id !== id);
  localStorage.setItem('resonance_alert_rules', JSON.stringify(filtered));
}

export function checkAlerts(
  unit: TrackedUnit,
  oldSummary: ResonanceSummary | null,
  newSummary: ResonanceSummary
): void {
  const rules = loadAllAlertRules().filter(
    (r: AlertRule) => r.enabled && (r.unitId === unit.id || r.unitId === 'all')
  );

  rules.forEach((rule: AlertRule) => {
    if (rule.type === 'resonance-threshold') {
      checkThresholdRule(unit, newSummary, rule);
    } else if (rule.type === 'resonance-change' && oldSummary) {
      checkChangeRule(unit, oldSummary, newSummary, rule);
    }
  });
}

function checkThresholdRule(
  unit: TrackedUnit,
  summary: ResonanceSummary,
  rule: AlertRule
): void {
  const { condition } = rule;
  const value = summary.resonanceScore;
  
  if (condition.operator === 'below' && condition.value && value < condition.value) {
    saveAlert({
      id: `${Date.now()}-${Math.random()}`,
      unitId: unit.id,
      type: 'performance-warning',
      severity: 'warning',
      title: `Low Resonance: ${unit.name}`,
      message: `Resonance score dropped to ${value.toFixed(0)}, below threshold of ${condition.value}`,
      createdAt: new Date().toISOString(),
      read: false,
      dismissed: false,
    });
  } else if (condition.operator === 'above' && condition.value && value > condition.value) {
    saveAlert({
      id: `${Date.now()}-${Math.random()}`,
      unitId: unit.id,
      type: 'resonance-spike',
      severity: 'info',
      title: `High Performance: ${unit.name}`,
      message: `Resonance score reached ${value.toFixed(0)}, above threshold of ${condition.value}!`,
      createdAt: new Date().toISOString(),
      read: false,
      dismissed: false,
    });
  }
}

function checkChangeRule(
  unit: TrackedUnit,
  oldSummary: ResonanceSummary,
  newSummary: ResonanceSummary,
  rule: AlertRule
): void {
  const { condition } = rule;
  const change = newSummary.resonanceScore - oldSummary.resonanceScore;
  const percentChange = (change / oldSummary.resonanceScore) * 100;
  
  if (condition.operator === 'change-down' && condition.percentage && percentChange < -condition.percentage) {
    saveAlert({
      id: `${Date.now()}-${Math.random()}`,
      unitId: unit.id,
      type: 'resonance-drop',
      severity: 'critical',
      title: `Sharp Drop: ${unit.name}`,
      message: `Resonance fell ${Math.abs(percentChange).toFixed(0)}% (${oldSummary.resonanceScore.toFixed(0)} → ${newSummary.resonanceScore.toFixed(0)})`,
      createdAt: new Date().toISOString(),
      read: false,
      dismissed: false,
    });
  } else if (condition.operator === 'change-up' && condition.percentage && percentChange > condition.percentage) {
    saveAlert({
      id: `${Date.now()}-${Math.random()}`,
      unitId: unit.id,
      type: 'resonance-spike',
      severity: 'info',
      title: `Momentum Surge: ${unit.name}`,
      message: `Resonance jumped ${percentChange.toFixed(0)}% (${oldSummary.resonanceScore.toFixed(0)} → ${newSummary.resonanceScore.toFixed(0)})!`,
      createdAt: new Date().toISOString(),
      read: false,
      dismissed: false,
    });
  }
}

export function createGoalAchievedAlert(unit: TrackedUnit, goal: Goal): void {
  saveAlert({
    id: `${Date.now()}-${Math.random()}`,
    unitId: unit.id,
    type: 'goal-achieved',
    severity: 'info',
    title: `Goal Achieved: ${goal.name}`,
    message: `${unit.name} reached the goal "${goal.name}" with ${goal.currentValue} ${goal.type}!`,
    createdAt: new Date().toISOString(),
    read: false,
    dismissed: false,
  });
}

export function createMilestoneAlert(unit: TrackedUnit, milestoneName: string, percentage: number): void {
  saveAlert({
    id: `${Date.now()}-${Math.random()}`,
    unitId: unit.id,
    type: 'milestone-hit',
    severity: 'info',
    title: `Milestone: ${milestoneName}`,
    message: `${unit.name} reached ${percentage}% of goal!`,
    createdAt: new Date().toISOString(),
    read: false,
    dismissed: false,
  });
}
