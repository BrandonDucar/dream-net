# Analytics Integration Guide for Resonance Radar

This guide explains how to integrate external analytics APIs for auto-importing metrics into Resonance Radar.

## Overview

Currently, Resonance Radar stores all data locally in your browser. However, you can extend it to automatically pull metrics from various analytics platforms.

## Supported Integration Types

### 1. Social Media Analytics

#### Twitter/X API
```typescript
// Example: Fetch tweet metrics
async function fetchTwitterMetrics(tweetId: string, bearerToken: string) {
  const response = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'https',
      origin: 'api.twitter.com',
      path: `/2/tweets/${tweetId}?tweet.fields=public_metrics`,
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${bearerToken}`,
      },
    }),
  });
  
  const data = await response.json();
  return {
    impressions: data.data.public_metrics.impression_count,
    clicks: data.data.public_metrics.url_link_clicks || 0,
    comments: data.data.public_metrics.reply_count,
    remixes: data.data.public_metrics.retweet_count + data.data.public_metrics.quote_count,
    savesOrBookmarks: data.data.public_metrics.bookmark_count,
  };
}
```

#### Farcaster API
```typescript
// Example: Fetch cast metrics from Neynar
async function fetchFarcasterMetrics(castHash: string, apiKey: string) {
  const response = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'https',
      origin: 'api.neynar.com',
      path: `/v2/farcaster/cast?identifier=${castHash}&type=hash`,
      method: 'GET',
      headers: {
        'api_key': apiKey,
      },
    }),
  });
  
  const data = await response.json();
  return {
    impressions: data.cast.reactions.count * 10, // Estimate
    clicks: 0, // Not directly available
    comments: data.cast.replies.count,
    remixes: data.cast.reactions.recasts,
    savesOrBookmarks: data.cast.reactions.likes,
  };
}
```

### 2. Blockchain Analytics

#### Base Chain Explorer
```typescript
// Example: Fetch NFT/token metrics
async function fetchBaseMetrics(contractAddress: string) {
  const response = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'https',
      origin: 'api.basescan.org',
      path: `/api?module=stats&action=tokensupply&contractaddress=${contractAddress}`,
      method: 'GET',
      headers: {},
    }),
  });
  
  const data = await response.json();
  // Map to your metrics...
}
```

#### Zora API (for NFT drops)
```typescript
async function fetchZoraDropMetrics(contractAddress: string, chainId: number) {
  const response = await fetch('/api/proxy', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      protocol: 'https',
      origin: 'api.zora.co',
      path: `/discover/tokens/${chainId}:${contractAddress}`,
      method: 'GET',
      headers: {},
    }),
  });
  
  const data = await response.json();
  return {
    mintsOrBuys: data.token.totalMinted,
    // Map other metrics...
  };
}
```

### 3. Third-Party Analytics Platforms

Based on our research, here are platforms you can integrate:

#### LunarCrush (Crypto Social Analytics)
- **Use Case**: Track social sentiment and engagement for CultureCoins
- **Metrics**: Galaxy Score, mentions, engagement, sentiment
- **API**: https://lunarcrush.com/developers

#### Sharpe.ai (Narrative Tracking)
- **Use Case**: Track memecoin/culture narrative mindshare
- **Metrics**: Narrative performance, sector trends
- **API**: Contact for API access

#### NFTGo (NFT Analytics)
- **Use Case**: Track NFT drop performance
- **Metrics**: Floor price, volume, sales, holder behavior
- **API**: https://docs.nftgo.io

## Implementation Example

Here's how to create an auto-import feature:

```typescript
// src/lib/auto-import.ts

import type { MetricsSnapshot } from '@/types/resonance';
import { saveSnapshot, saveSummary } from './resonance-storage';
import { createResonanceSummary } from './resonance-scoring';

interface ImportConfig {
  unitId: string;
  source: 'twitter' | 'farcaster' | 'zora' | 'custom';
  credentials: {
    apiKey?: string;
    bearerToken?: string;
  };
  sourceId: string; // tweet ID, cast hash, contract address, etc.
}

export async function autoImportMetrics(config: ImportConfig): Promise<MetricsSnapshot> {
  let metrics;
  
  switch (config.source) {
    case 'twitter':
      metrics = await fetchTwitterMetrics(config.sourceId, config.credentials.bearerToken!);
      break;
    case 'farcaster':
      metrics = await fetchFarcasterMetrics(config.sourceId, config.credentials.apiKey!);
      break;
    case 'zora':
      metrics = await fetchZoraDropMetrics(config.sourceId, 8453); // Base chain
      break;
    default:
      throw new Error('Unsupported source');
  }
  
  const snapshot: MetricsSnapshot = {
    id: crypto.randomUUID(),
    unitId: config.unitId,
    periodLabel: `auto-${new Date().toISOString().split('T')[0]}`,
    timestamp: new Date().toISOString(),
    impressions: metrics.impressions || 0,
    clicks: metrics.clicks || 0,
    mintsOrBuys: metrics.mintsOrBuys || 0,
    remixesOrReshares: metrics.remixes || 0,
    comments: metrics.comments || 0,
    savesOrBookmarks: metrics.savesOrBookmarks || 0,
    channelBreakdown: {},
    notes: `Auto-imported from ${config.source}`,
  };
  
  saveSnapshot(snapshot);
  
  // Auto-compute resonance
  const summary = createResonanceSummary(snapshot, null);
  saveSummary(summary);
  
  return snapshot;
}
```

## UI Integration

Add an "Auto-Import" button to your unit detail screen:

```typescript
// In unit-detail-screen.tsx

const [importConfig, setImportConfig] = useState<ImportConfig | null>(null);

const handleAutoImport = async () => {
  if (!importConfig) return;
  
  try {
    await autoImportMetrics(importConfig);
    loadData();
    toast.success('Metrics imported successfully');
  } catch (error) {
    toast.error('Failed to import metrics');
  }
};
```

## Best Practices

1. **Rate Limiting**: Respect API rate limits by caching data and implementing backoff strategies
2. **Authentication**: Store API keys securely (never in client code - use server-side routes)
3. **Data Mapping**: Create consistent mapping between platform metrics and Resonance Radar metrics
4. **Error Handling**: Gracefully handle API failures and provide fallback options
5. **Cost Management**: Be aware of API pricing tiers and usage limits

## Recommended Architecture

For production use:

1. **Create server-side API routes** in `src/app/api/` for each integration
2. **Store credentials** in environment variables (not in localStorage)
3. **Implement caching** to reduce API calls
4. **Use webhooks** where available for real-time updates
5. **Schedule periodic imports** for batch updates

## Next Steps

- Implement server-side routes for secure API calls
- Add credential management UI
- Create scheduling system for auto-imports
- Build mapping configuration for custom metrics
- Add data validation and error recovery

## Resources

- [Twitter API Docs](https://developer.twitter.com/en/docs)
- [Neynar Farcaster API](https://docs.neynar.com/)
- [Zora API Docs](https://docs.zora.co/)
- [Basescan API](https://docs.basescan.org/)
- [LunarCrush API](https://lunarcrush.com/developers)
- [NFTGo API Docs](https://docs.nftgo.io/)
