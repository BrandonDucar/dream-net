/**
 * Auto-Sync Scheduling System
 * 
 * Automatically fetches metrics from integrated platforms on schedule
 */

import type { TrackedUnit, MetricsSnapshot } from '@/types/resonance';
import { fetchTwitterMetrics, loadTwitterConfig } from './integrations/twitter';
import { fetchFarcasterMetrics, loadFarcasterConfig } from './integrations/farcaster';
import { fetchZoraMetrics, loadZoraConfig } from './integrations/zora';
import { fetchBaseMetrics, loadBaseConfig } from './integrations/base';
import { saveSnapshot } from './resonance-storage';

export interface SyncSchedule {
  unitId: string;
  enabled: boolean;
  frequency: 'hourly' | 'daily' | 'weekly';
  lastSync: string | null;
  nextSync: string | null;
  platforms: {
    twitter?: { tweetId: string };
    farcaster?: { castHash: string };
    zora?: { contractAddress: string; tokenId: string };
    base?: { contractAddress: string };
  };
}

export function saveSyncSchedule(schedule: SyncSchedule): void {
  const schedules = loadAllSyncSchedules();
  const index = schedules.findIndex((s: SyncSchedule) => s.unitId === schedule.unitId);
  
  if (index >= 0) {
    schedules[index] = schedule;
  } else {
    schedules.push(schedule);
  }
  
  localStorage.setItem('resonance_sync_schedules', JSON.stringify(schedules));
}

export function loadSyncSchedule(unitId: string): SyncSchedule | null {
  const schedules = loadAllSyncSchedules();
  return schedules.find((s: SyncSchedule) => s.unitId === unitId) || null;
}

export function loadAllSyncSchedules(): SyncSchedule[] {
  const stored = localStorage.getItem('resonance_sync_schedules');
  return stored ? JSON.parse(stored) : [];
}

export function deleteSyncSchedule(unitId: string): void {
  const schedules = loadAllSyncSchedules();
  const filtered = schedules.filter((s: SyncSchedule) => s.unitId !== unitId);
  localStorage.setItem('resonance_sync_schedules', JSON.stringify(filtered));
}

export function calculateNextSync(frequency: 'hourly' | 'daily' | 'weekly'): string {
  const now = new Date();
  
  switch (frequency) {
    case 'hourly':
      now.setHours(now.getHours() + 1);
      break;
    case 'daily':
      now.setDate(now.getDate() + 1);
      break;
    case 'weekly':
      now.setDate(now.getDate() + 7);
      break;
  }
  
  return now.toISOString();
}

export async function syncUnit(unit: TrackedUnit, schedule: SyncSchedule): Promise<boolean> {
  try {
    let totalImpressions = 0;
    let totalClicks = 0;
    let totalMints = 0;
    let totalRemixes = 0;
    let totalComments = 0;
    let totalSaves = 0;
    const channelBreakdown: Record<string, number> = {};

    // Fetch from Twitter
    if (schedule.platforms.twitter) {
      const twitterConfig = loadTwitterConfig();
      const metrics = await fetchTwitterMetrics(
        schedule.platforms.twitter.tweetId,
        twitterConfig
      );
      
      if (metrics) {
        totalImpressions += metrics.impressions;
        totalClicks += metrics.clicks;
        totalRemixes += metrics.retweets;
        totalComments += metrics.replies;
        totalSaves += metrics.bookmarks;
        channelBreakdown.twitter = metrics.impressions;
      }
    }

    // Fetch from Farcaster
    if (schedule.platforms.farcaster) {
      const farcasterConfig = loadFarcasterConfig();
      const metrics = await fetchFarcasterMetrics(
        schedule.platforms.farcaster.castHash,
        farcasterConfig
      );
      
      if (metrics) {
        totalRemixes += metrics.recasts;
        totalComments += metrics.replies;
        channelBreakdown.farcaster = metrics.likes + metrics.recasts;
      }
    }

    // Fetch from Zora
    if (schedule.platforms.zora) {
      const zoraConfig = loadZoraConfig();
      const metrics = await fetchZoraMetrics(
        schedule.platforms.zora.contractAddress,
        schedule.platforms.zora.tokenId,
        zoraConfig
      );
      
      if (metrics) {
        totalMints += metrics.totalMints;
        channelBreakdown.zora = metrics.totalMints;
      }
    }

    // Fetch from Base
    if (schedule.platforms.base) {
      const baseConfig = loadBaseConfig();
      const metrics = await fetchBaseMetrics(
        schedule.platforms.base.contractAddress,
        baseConfig
      );
      
      if (metrics) {
        totalClicks += metrics.transactions;
        channelBreakdown.base = metrics.transactions;
      }
    }

    // Create metrics snapshot
    const now = new Date();
    const periodLabel = `Auto-sync ${now.toLocaleDateString()} ${now.toLocaleTimeString()}`;
    
    const snapshot: MetricsSnapshot = {
      id: `snapshot_${Date.now()}`,
      unitId: unit.id,
      periodLabel,
      timestamp: now.toISOString(),
      impressions: totalImpressions,
      clicks: totalClicks,
      mintsOrBuys: totalMints,
      remixesOrReshares: totalRemixes,
      comments: totalComments,
      savesOrBookmarks: totalSaves,
      channelBreakdown,
      notes: 'Auto-synced from integrated platforms',
    };
    
    saveSnapshot(snapshot);

    // Update schedule
    schedule.lastSync = now.toISOString();
    schedule.nextSync = calculateNextSync(schedule.frequency);
    saveSyncSchedule(schedule);

    return true;
  } catch (error) {
    console.error('Error syncing unit:', error);
    return false;
  }
}

export async function syncAllDue(): Promise<void> {
  const schedules = loadAllSyncSchedules();
  const now = new Date();

  for (const schedule of schedules) {
    if (!schedule.enabled) continue;
    if (!schedule.nextSync) continue;
    
    const nextSync = new Date(schedule.nextSync);
    if (now >= nextSync) {
      // Unit needs syncing - but we need the full unit data
      // This would be called from a component that has access to units
      console.log(`Unit ${schedule.unitId} needs syncing`);
    }
  }
}
