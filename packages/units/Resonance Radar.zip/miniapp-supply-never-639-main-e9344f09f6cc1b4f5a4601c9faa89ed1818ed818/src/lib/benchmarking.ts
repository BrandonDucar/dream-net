/**
 * Competitive Benchmarking
 * 
 * Compare performance against similar projects and industry standards
 */

import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from './types';

export interface BenchmarkData {
  category: string;
  metric: string;
  yourValue: number;
  industryAverage: number;
  topPerformer: number;
  percentile: number; // 0-100, where you rank
  status: 'leading' | 'above-average' | 'average' | 'below-average' | 'lagging';
}

export interface IndustryBenchmark {
  type: TrackedUnit['type'];
  category: string;
  averages: {
    impressions: number;
    ctr: number; // percentage
    conversionRate: number; // percentage
    engagementRate: number; // percentage
    resonanceScore: number;
  };
  topPercentile: {
    impressions: number;
    ctr: number;
    conversionRate: number;
    engagementRate: number;
    resonanceScore: number;
  };
}

// Industry benchmark data (could be crowdsourced or API-driven in production)
const INDUSTRY_BENCHMARKS: IndustryBenchmark[] = [
  {
    type: 'culture-coin',
    category: 'CultureCoins',
    averages: {
      impressions: 15000,
      ctr: 3.5,
      conversionRate: 2.0,
      engagementRate: 4.0,
      resonanceScore: 55,
    },
    topPercentile: {
      impressions: 100000,
      ctr: 8.0,
      conversionRate: 5.0,
      engagementRate: 10.0,
      resonanceScore: 85,
    },
  },
  {
    type: 'drop',
    category: 'NFT Drops',
    averages: {
      impressions: 8000,
      ctr: 4.0,
      conversionRate: 3.5,
      engagementRate: 5.0,
      resonanceScore: 60,
    },
    topPercentile: {
      impressions: 50000,
      ctr: 10.0,
      conversionRate: 8.0,
      engagementRate: 12.0,
      resonanceScore: 90,
    },
  },
  {
    type: 'meme',
    category: 'Memes & Viral Content',
    averages: {
      impressions: 50000,
      ctr: 2.5,
      conversionRate: 0.5,
      engagementRate: 6.0,
      resonanceScore: 50,
    },
    topPercentile: {
      impressions: 500000,
      ctr: 5.0,
      conversionRate: 2.0,
      engagementRate: 15.0,
      resonanceScore: 80,
    },
  },
  {
    type: 'campaign',
    category: 'Marketing Campaigns',
    averages: {
      impressions: 25000,
      ctr: 3.0,
      conversionRate: 2.5,
      engagementRate: 3.5,
      resonanceScore: 58,
    },
    topPercentile: {
      impressions: 150000,
      ctr: 7.0,
      conversionRate: 6.0,
      engagementRate: 8.0,
      resonanceScore: 88,
    },
  },
  {
    type: 'other',
    category: 'Other Culture Objects',
    averages: {
      impressions: 10000,
      ctr: 3.0,
      conversionRate: 2.0,
      engagementRate: 4.0,
      resonanceScore: 52,
    },
    topPercentile: {
      impressions: 80000,
      ctr: 7.5,
      conversionRate: 5.5,
      engagementRate: 10.0,
      resonanceScore: 85,
    },
  },
];

export function getBenchmarkData(
  unit: TrackedUnit,
  snapshots: MetricsSnapshot[],
  summary: ResonanceSummary
): BenchmarkData[] {
  const benchmark = INDUSTRY_BENCHMARKS.find((b: IndustryBenchmark) => b.type === unit.type);
  if (!benchmark || snapshots.length === 0) return [];

  const latest = snapshots[0];
  const results: BenchmarkData[] = [];

  // Calculate your metrics
  const ctr = latest.impressions > 0 ? (latest.clicks / latest.impressions) * 100 : 0;
  const conversionRate = latest.clicks > 0 ? (latest.mintsOrBuys / latest.clicks) * 100 : 0;
  const engagementRate = latest.impressions > 0
    ? ((latest.comments + latest.savesOrBookmarks + latest.remixesOrReshares) / latest.impressions) * 100
    : 0;

  // Impressions benchmark
  results.push(createBenchmark(
    benchmark.category,
    'Impressions',
    latest.impressions,
    benchmark.averages.impressions,
    benchmark.topPercentile.impressions
  ));

  // CTR benchmark
  results.push(createBenchmark(
    benchmark.category,
    'Click-Through Rate',
    ctr,
    benchmark.averages.ctr,
    benchmark.topPercentile.ctr
  ));

  // Conversion Rate benchmark
  results.push(createBenchmark(
    benchmark.category,
    'Conversion Rate',
    conversionRate,
    benchmark.averages.conversionRate,
    benchmark.topPercentile.conversionRate
  ));

  // Engagement Rate benchmark
  results.push(createBenchmark(
    benchmark.category,
    'Engagement Rate',
    engagementRate,
    benchmark.averages.engagementRate,
    benchmark.topPercentile.engagementRate
  ));

  // Resonance Score benchmark
  results.push(createBenchmark(
    benchmark.category,
    'Resonance Score',
    summary.resonanceScore,
    benchmark.averages.resonanceScore,
    benchmark.topPercentile.resonanceScore
  ));

  return results;
}

function createBenchmark(
  category: string,
  metric: string,
  yourValue: number,
  industryAverage: number,
  topPerformer: number
): BenchmarkData {
  // Calculate percentile (simplified)
  const range = topPerformer - 0;
  const position = yourValue - 0;
  const percentile = Math.min(100, Math.max(0, (position / range) * 100));

  let status: BenchmarkData['status'];
  if (yourValue >= topPerformer * 0.9) {
    status = 'leading';
  } else if (yourValue >= industryAverage * 1.2) {
    status = 'above-average';
  } else if (yourValue >= industryAverage * 0.8) {
    status = 'average';
  } else if (yourValue >= industryAverage * 0.5) {
    status = 'below-average';
  } else {
    status = 'lagging';
  }

  return {
    category,
    metric,
    yourValue,
    industryAverage,
    topPerformer,
    percentile,
    status,
  };
}

export function compareUnits(units: TrackedUnit[]): {
  unit: TrackedUnit;
  summary: ResonanceSummary | null;
  rank: number;
  strengths: string[];
  weaknesses: string[];
}[] {
  // This would use actual summary data in production
  // For now, placeholder implementation
  return units.map((unit: TrackedUnit, index: number) => ({
    unit,
    summary: null,
    rank: index + 1,
    strengths: ['High engagement', 'Strong conversion'],
    weaknesses: ['Low reach', 'Limited channels'],
  }));
}

export function generateBenchmarkReport(
  unit: TrackedUnit,
  benchmarks: BenchmarkData[]
): string {
  const leading = benchmarks.filter((b: BenchmarkData) => b.status === 'leading');
  const lagging = benchmarks.filter((b: BenchmarkData) => b.status === 'lagging' || b.status === 'below-average');

  let report = `# Competitive Benchmark Report: ${unit.name}\n\n`;
  report += `## Performance Summary\n\n`;

  if (leading.length > 0) {
    report += `### 🏆 Leading Metrics\n`;
    leading.forEach((b: BenchmarkData) => {
      report += `- **${b.metric}**: ${formatValue(b.yourValue, b.metric)} (Top ${(100 - b.percentile).toFixed(0)}%)\n`;
    });
    report += '\n';
  }

  if (lagging.length > 0) {
    report += `### ⚠️ Areas for Improvement\n`;
    lagging.forEach((b: BenchmarkData) => {
      const gap = ((b.industryAverage - b.yourValue) / b.industryAverage) * 100;
      report += `- **${b.metric}**: ${formatValue(b.yourValue, b.metric)} (${gap.toFixed(0)}% below average)\n`;
    });
    report += '\n';
  }

  report += `## Detailed Comparison\n\n`;
  report += `| Metric | Your Value | Industry Average | Top Performer | Status |\n`;
  report += `|--------|-----------|------------------|---------------|--------|\n`;
  
  benchmarks.forEach((b: BenchmarkData) => {
    const statusEmoji = {
      'leading': '🥇',
      'above-average': '📈',
      'average': '➡️',
      'below-average': '📉',
      'lagging': '🔴',
    }[b.status as string];
    
    report += `| ${b.metric} | ${formatValue(b.yourValue, b.metric)} | ${formatValue(b.industryAverage, b.metric)} | ${formatValue(b.topPerformer, b.metric)} | ${statusEmoji} ${b.status} |\n`;
  });

  return report;
}

function formatValue(value: number, metric: string): string {
  if (metric.includes('Rate') || metric.includes('Score')) {
    return `${value.toFixed(1)}%`;
  }
  return value.toLocaleString();
}
