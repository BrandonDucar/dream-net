// Export utilities for CSV and JSON downloads

import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/types/resonance';

export function exportToJSON(data: unknown, filename: string): void {
  const jsonStr = JSON.stringify(data, null, 2);
  const blob = new Blob([jsonStr], { type: 'application/json' });
  downloadBlob(blob, filename);
}

export function exportToCSV(
  data: Array<Record<string, unknown>>,
  filename: string,
  headers?: string[]
): void {
  if (data.length === 0) return;

  const allKeys = headers || Object.keys(data[0]);
  const csvRows: string[] = [];

  // Header row
  csvRows.push(allKeys.join(','));

  // Data rows
  for (const row of data) {
    const values = allKeys.map((key: string) => {
      const value = row[key as keyof typeof row];
      const stringValue = value !== null && value !== undefined ? String(value) : '';
      // Escape quotes and wrap in quotes if contains comma or quote
      if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
        return `"${stringValue.replace(/"/g, '""')}"`;
      }
      return stringValue;
    });
    csvRows.push(values.join(','));
  }

  const csvStr = csvRows.join('\n');
  const blob = new Blob([csvStr], { type: 'text/csv;charset=utf-8;' });
  downloadBlob(blob, filename);
}

function downloadBlob(blob: Blob, filename: string): void {
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Export all units data
export function exportAllUnitsJSON(
  units: TrackedUnit[],
  snapshots: MetricsSnapshot[],
  summaries: ResonanceSummary[]
): void {
  const data = {
    exportedAt: new Date().toISOString(),
    units,
    snapshots,
    summaries,
  };
  exportToJSON(data, `resonance-radar-full-export-${Date.now()}.json`);
}

// Export units as CSV
export function exportUnitsCSV(units: TrackedUnit[]): void {
  const data = units.map((unit: TrackedUnit) => ({
    id: unit.id,
    type: unit.type,
    name: unit.name,
    emoji: unit.primaryEmoji,
    chain: unit.chain,
    status: unit.status,
    refId: unit.refId,
    createdAt: unit.createdAt,
    updatedAt: unit.updatedAt,
  }));
  exportToCSV(data, `resonance-units-${Date.now()}.csv`);
}

// Export metrics snapshots as CSV
export function exportMetricsCSV(snapshots: MetricsSnapshot[]): void {
  const data = snapshots.map((snapshot: MetricsSnapshot) => ({
    id: snapshot.id,
    unitId: snapshot.unitId,
    periodLabel: snapshot.periodLabel,
    timestamp: snapshot.timestamp,
    impressions: snapshot.impressions,
    clicks: snapshot.clicks,
    mintsOrBuys: snapshot.mintsOrBuys,
    remixesOrReshares: snapshot.remixesOrReshares,
    comments: snapshot.comments,
    savesOrBookmarks: snapshot.savesOrBookmarks,
    notes: snapshot.notes,
  }));
  exportToCSV(data, `resonance-metrics-${Date.now()}.csv`);
}

// Export resonance summaries as CSV
export function exportSummariesCSV(summaries: ResonanceSummary[]): void {
  const data = summaries.map((summary: ResonanceSummary) => ({
    unitId: summary.unitId,
    lastPeriodLabel: summary.lastPeriodLabel,
    resonanceScore: summary.resonanceScore,
    trend: summary.trend,
    recommendation: summary.recommendation,
    mainDrivers: summary.mainDrivers.join('; '),
    computedAt: summary.computedAt,
  }));
  exportToCSV(data, `resonance-summaries-${Date.now()}.csv`);
}

// Import from JSON
export function importFromJSON(file: File): Promise<{
  units: TrackedUnit[];
  snapshots: MetricsSnapshot[];
  summaries: ResonanceSummary[];
}> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e: ProgressEvent<FileReader>) => {
      try {
        const result = e.target?.result;
        if (typeof result !== 'string') {
          throw new Error('Invalid file content');
        }
        const data = JSON.parse(result);
        resolve({
          units: data.units || [],
          snapshots: data.snapshots || [],
          summaries: data.summaries || [],
        });
      } catch (error) {
        reject(error);
      }
    };
    reader.onerror = () => reject(new Error('Failed to read file'));
    reader.readAsText(file);
  });
}
