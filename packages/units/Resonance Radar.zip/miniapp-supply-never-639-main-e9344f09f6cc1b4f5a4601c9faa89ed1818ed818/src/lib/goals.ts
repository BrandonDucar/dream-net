/**
 * Goals & Milestones System
 * 
 * Set targets and track progress towards goals
 */

export interface Goal {
  id: string;
  unitId: string;
  name: string;
  type: 'impressions' | 'clicks' | 'mints' | 'remixes' | 'engagement' | 'resonance-score';
  targetValue: number;
  currentValue: number;
  deadline: string | null;
  status: 'not-started' | 'in-progress' | 'achieved' | 'missed';
  createdAt: string;
  achievedAt: string | null;
  notes: string;
}

export interface Milestone {
  id: string;
  goalId: string;
  name: string;
  percentage: number; // 25, 50, 75, 100
  achievedAt: string | null;
}

export function saveGoal(goal: Goal): void {
  const goals = loadAllGoals();
  const index = goals.findIndex((g: Goal) => g.id === goal.id);
  
  if (index >= 0) {
    goals[index] = goal;
  } else {
    goals.push(goal);
  }
  
  localStorage.setItem('resonance_goals', JSON.stringify(goals));
}

export function loadGoal(id: string): Goal | null {
  const goals = loadAllGoals();
  return goals.find((g: Goal) => g.id === id) || null;
}

export function loadAllGoals(): Goal[] {
  const stored = localStorage.getItem('resonance_goals');
  return stored ? JSON.parse(stored) : [];
}

export function loadGoalsForUnit(unitId: string): Goal[] {
  const allGoals = loadAllGoals();
  return allGoals.filter((g: Goal) => g.unitId === unitId);
}

export function deleteGoal(id: string): void {
  const goals = loadAllGoals();
  const filtered = goals.filter((g: Goal) => g.id !== id);
  localStorage.setItem('resonance_goals', JSON.stringify(filtered));
  
  // Delete associated milestones
  const milestones = loadAllMilestones();
  const filteredMilestones = milestones.filter((m: Milestone) => m.goalId !== id);
  localStorage.setItem('resonance_milestones', JSON.stringify(filteredMilestones));
}

export function saveMilestone(milestone: Milestone): void {
  const milestones = loadAllMilestones();
  const index = milestones.findIndex((m: Milestone) => m.id === milestone.id);
  
  if (index >= 0) {
    milestones[index] = milestone;
  } else {
    milestones.push(milestone);
  }
  
  localStorage.setItem('resonance_milestones', JSON.stringify(milestones));
}

export function loadAllMilestones(): Milestone[] {
  const stored = localStorage.getItem('resonance_milestones');
  return stored ? JSON.parse(stored) : [];
}

export function loadMilestonesForGoal(goalId: string): Milestone[] {
  const allMilestones = loadAllMilestones();
  return allMilestones.filter((m: Milestone) => m.goalId === goalId);
}

export function updateGoalProgress(goal: Goal, newValue: number): Goal {
  const updatedGoal = { ...goal, currentValue: newValue };
  
  // Calculate progress percentage
  const progress = (newValue / goal.targetValue) * 100;
  
  // Update milestones
  const milestones = loadMilestonesForGoal(goal.id);
  const now = new Date().toISOString();
  
  milestones.forEach((milestone: Milestone) => {
    if (progress >= milestone.percentage && !milestone.achievedAt) {
      milestone.achievedAt = now;
      saveMilestone(milestone);
    }
  });
  
  // Update goal status
  if (progress >= 100) {
    updatedGoal.status = 'achieved';
    updatedGoal.achievedAt = now;
  } else if (progress > 0) {
    updatedGoal.status = 'in-progress';
  }
  
  // Check if deadline passed
  if (goal.deadline && new Date(goal.deadline) < new Date() && updatedGoal.status !== 'achieved') {
    updatedGoal.status = 'missed';
  }
  
  saveGoal(updatedGoal);
  return updatedGoal;
}

export function createDefaultMilestones(goalId: string): void {
  const milestones: Milestone[] = [
    {
      id: `${goalId}-25`,
      goalId,
      name: '25% Complete',
      percentage: 25,
      achievedAt: null,
    },
    {
      id: `${goalId}-50`,
      goalId,
      name: 'Halfway There',
      percentage: 50,
      achievedAt: null,
    },
    {
      id: `${goalId}-75`,
      goalId,
      name: '75% Complete',
      percentage: 75,
      achievedAt: null,
    },
    {
      id: `${goalId}-100`,
      goalId,
      name: 'Goal Achieved!',
      percentage: 100,
      achievedAt: null,
    },
  ];
  
  milestones.forEach(saveMilestone);
}
