/**
 * Base Chain Analytics Integration
 * 
 * Fetches on-chain data for CultureCoins and contracts on Base
 */

export interface BaseConfig {
  rpcUrl: string;
  enabled: boolean;
}

export interface BaseMetrics {
  holders: number;
  transactions: number;
  volume24h: number;
  marketCap: number;
  price: number;
  priceChange24h: number;
}

export async function fetchBaseMetrics(
  contractAddress: string,
  config: BaseConfig
): Promise<BaseMetrics | null> {
  if (!config.enabled) {
    return null;
  }

  try {
    // Using Dexscreener API for Base chain data
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.dexscreener.com',
        path: `/latest/dex/tokens/${contractAddress}`,
        method: 'GET',
        headers: {},
      }),
    });

    if (!response.ok) {
      console.error('Base chain API error:', response.statusText);
      return null;
    }

    const data = await response.json();
    const pairs = data.pairs || [];
    
    // Find Base chain pair
    const basePair = pairs.find((p: { chainId: string }) => p.chainId === 'base');

    if (!basePair) {
      return null;
    }

    return {
      holders: 0, // Would need separate Basescan API call
      transactions: basePair.txns?.h24?.buys + basePair.txns?.h24?.sells || 0,
      volume24h: parseFloat(basePair.volume?.h24 || '0'),
      marketCap: parseFloat(basePair.marketCap || '0'),
      price: parseFloat(basePair.priceUsd || '0'),
      priceChange24h: parseFloat(basePair.priceChange?.h24 || '0'),
    };
  } catch (error) {
    console.error('Error fetching Base metrics:', error);
    return null;
  }
}

export function saveBaseConfig(config: BaseConfig): void {
  localStorage.setItem('resonance_base_config', JSON.stringify(config));
}

export function loadBaseConfig(): BaseConfig {
  const stored = localStorage.getItem('resonance_base_config');
  if (stored) {
    return JSON.parse(stored);
  }
  return {
    rpcUrl: 'https://mainnet.base.org',
    enabled: false,
  };
}
