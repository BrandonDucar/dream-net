/**
 * Farcaster Analytics Integration
 * 
 * Fetches engagement metrics from Farcaster (via Neynar or Warpcast API)
 */

export interface FarcasterConfig {
  apiKey: string;
  enabled: boolean;
}

export interface FarcasterMetrics {
  impressions: number;
  likes: number;
  recasts: number;
  replies: number;
  quotes: number;
}

export async function fetchFarcasterMetrics(
  castHash: string,
  config: FarcasterConfig
): Promise<FarcasterMetrics | null> {
  if (!config.enabled || !config.apiKey) {
    return null;
  }

  try {
    // Using Neynar API for Farcaster data
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.neynar.com',
        path: `/v2/farcaster/cast?identifier=${castHash}&type=hash`,
        method: 'GET',
        headers: {
          'api_key': config.apiKey,
        },
      }),
    });

    if (!response.ok) {
      console.error('Farcaster API error:', response.statusText);
      return null;
    }

    const data = await response.json();
    const cast = data.cast;

    return {
      impressions: 0, // Not available via API, would need analytics access
      likes: cast?.reactions?.likes_count || 0,
      recasts: cast?.reactions?.recasts_count || 0,
      replies: cast?.replies?.count || 0,
      quotes: cast?.reactions?.quotes_count || 0,
    };
  } catch (error) {
    console.error('Error fetching Farcaster metrics:', error);
    return null;
  }
}

export function saveFarcasterConfig(config: FarcasterConfig): void {
  localStorage.setItem('resonance_farcaster_config', JSON.stringify(config));
}

export function loadFarcasterConfig(): FarcasterConfig {
  const stored = localStorage.getItem('resonance_farcaster_config');
  if (stored) {
    return JSON.parse(stored);
  }
  return {
    apiKey: '',
    enabled: false,
  };
}
