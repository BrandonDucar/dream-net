/**
 * Twitter/X Analytics Integration
 * 
 * Fetches engagement metrics from Twitter API
 */

export interface TwitterConfig {
  apiKey: string;
  apiSecret: string;
  bearerToken: string;
  enabled: boolean;
}

export interface TwitterMetrics {
  impressions: number;
  clicks: number;
  likes: number;
  retweets: number;
  replies: number;
  bookmarks: number;
  profileVisits: number;
}

export async function fetchTwitterMetrics(
  tweetId: string,
  config: TwitterConfig
): Promise<TwitterMetrics | null> {
  if (!config.enabled || !config.bearerToken) {
    return null;
  }

  try {
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.twitter.com',
        path: `/2/tweets/${tweetId}`,
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${config.bearerToken}`,
        },
      }),
    });

    if (!response.ok) {
      console.error('Twitter API error:', response.statusText);
      return null;
    }

    const data = await response.json();
    const metrics = data.data?.public_metrics || {};

    return {
      impressions: metrics.impression_count || 0,
      clicks: 0, // Not available in public API
      likes: metrics.like_count || 0,
      retweets: metrics.retweet_count || 0,
      replies: metrics.reply_count || 0,
      bookmarks: metrics.bookmark_count || 0,
      profileVisits: 0, // Not available in public API
    };
  } catch (error) {
    console.error('Error fetching Twitter metrics:', error);
    return null;
  }
}

export function saveTwitterConfig(config: TwitterConfig): void {
  localStorage.setItem('resonance_twitter_config', JSON.stringify(config));
}

export function loadTwitterConfig(): TwitterConfig {
  const stored = localStorage.getItem('resonance_twitter_config');
  if (stored) {
    return JSON.parse(stored);
  }
  return {
    apiKey: '',
    apiSecret: '',
    bearerToken: '',
    enabled: false,
  };
}
