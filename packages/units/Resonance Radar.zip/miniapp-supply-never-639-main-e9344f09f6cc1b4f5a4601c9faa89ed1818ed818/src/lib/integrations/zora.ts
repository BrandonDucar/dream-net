/**
 * Zora Analytics Integration
 * 
 * Fetches mint and sales data from Zora API
 */

export interface ZoraConfig {
  enabled: boolean;
}

export interface ZoraMetrics {
  totalMints: number;
  totalSales: number;
  uniqueCollectors: number;
  totalVolume: number;
  floorPrice: number;
}

export async function fetchZoraMetrics(
  contractAddress: string,
  tokenId: string,
  config: ZoraConfig
): Promise<ZoraMetrics | null> {
  if (!config.enabled) {
    return null;
  }

  try {
    // Using Zora's public GraphQL API
    const query = `
      query GetTokenMetrics($contractAddress: String!, $tokenId: String!) {
        token(
          token: {
            address: $contractAddress
            tokenId: $tokenId
          }
          network: {
            chain: BASE
          }
        ) {
          token {
            tokenId
            collectionAddress
          }
          sales {
            nodes {
              salePrice {
                nativePrice {
                  decimal
                }
              }
            }
          }
          mintInfo {
            totalMinted
          }
        }
      }
    `;

    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.zora.co',
        path: '/graphql',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          query,
          variables: {
            contractAddress,
            tokenId,
          },
        }),
      }),
    });

    if (!response.ok) {
      console.error('Zora API error:', response.statusText);
      return null;
    }

    const data = await response.json();
    const token = data.data?.token;

    const sales = token?.sales?.nodes || [];
    const totalMinted = token?.mintInfo?.totalMinted || 0;

    return {
      totalMints: totalMinted,
      totalSales: sales.length,
      uniqueCollectors: 0, // Would need separate query
      totalVolume: sales.reduce((sum: number, sale: { salePrice: { nativePrice: { decimal: number } } }) => {
        return sum + (sale.salePrice?.nativePrice?.decimal || 0);
      }, 0),
      floorPrice: 0, // Would need separate query
    };
  } catch (error) {
    console.error('Error fetching Zora metrics:', error);
    return null;
  }
}

export function saveZoraConfig(config: ZoraConfig): void {
  localStorage.setItem('resonance_zora_config', JSON.stringify(config));
}

export function loadZoraConfig(): ZoraConfig {
  const stored = localStorage.getItem('resonance_zora_config');
  if (stored) {
    return JSON.parse(stored);
  }
  return {
    enabled: false,
  };
}
