/**
 * Predictive Analytics
 * 
 * Forecast future performance based on historical trends
 */

import type { MetricsSnapshot } from './types';

export interface Prediction {
  metric: 'impressions' | 'clicks' | 'mints' | 'resonance-score';
  current: number;
  predicted: number;
  timeframe: '7d' | '30d' | '90d';
  confidence: number; // 0-1
  trend: 'accelerating' | 'steady' | 'decelerating';
  factors: string[];
}

export interface ForecastPoint {
  date: string;
  value: number;
  lower: number; // confidence interval lower bound
  upper: number; // confidence interval upper bound
}

export function predictMetric(
  snapshots: MetricsSnapshot[],
  metric: 'impressions' | 'clicks' | 'mintsOrBuys',
  timeframe: '7d' | '30d' | '90d'
): Prediction | null {
  if (snapshots.length < 3) return null;

  const values = snapshots.map((s: MetricsSnapshot) => {
    if (metric === 'impressions') return s.impressions;
    if (metric === 'clicks') return s.clicks;
    return s.mintsOrBuys;
  }).reverse(); // oldest to newest

  // Simple linear regression
  const n = values.length;
  const xMean = (n - 1) / 2;
  const yMean = values.reduce((sum: number, v: number) => sum + v, 0) / n;

  let numerator = 0;
  let denominator = 0;

  for (let i = 0; i < n; i++) {
    numerator += (i - xMean) * (values[i] - yMean);
    denominator += Math.pow(i - xMean, 2);
  }

  const slope = numerator / denominator;
  const intercept = yMean - slope * xMean;

  // Predict future value
  const daysAhead = timeframe === '7d' ? 7 : timeframe === '30d' ? 30 : 90;
  const periodAhead = Math.ceil(daysAhead / 7); // assuming weekly snapshots
  const futureX = n - 1 + periodAhead;
  const predicted = slope * futureX + intercept;

  // Calculate confidence based on R²
  const yPredicted = values.map((_: number, i: number) => slope * i + intercept);
  const ssRes = values.reduce((sum: number, y: number, i: number) => 
    sum + Math.pow(y - yPredicted[i], 2), 0);
  const ssTot = values.reduce((sum: number, y: number) => 
    sum + Math.pow(y - yMean, 2), 0);
  const rSquared = 1 - (ssRes / ssTot);
  const confidence = Math.max(0, Math.min(1, rSquared));

  // Determine trend
  const recent = values.slice(-3);
  const recentSlope = (recent[2] - recent[0]) / 2;
  const trend = recentSlope > slope * 1.2 ? 'accelerating' 
    : recentSlope < slope * 0.8 ? 'decelerating' 
    : 'steady';

  // Generate factors
  const factors: string[] = [];
  if (slope > 0) {
    factors.push('Consistent growth trajectory');
  } else if (slope < 0) {
    factors.push('Declining trend detected');
  } else {
    factors.push('Stable performance');
  }

  if (confidence > 0.7) {
    factors.push('High confidence based on consistent pattern');
  } else {
    factors.push('Variable performance reduces confidence');
  }

  if (trend === 'accelerating') {
    factors.push('Recent acceleration suggests upward momentum');
  } else if (trend === 'decelerating') {
    factors.push('Recent deceleration may impact forecast');
  }

  return {
    metric: metric === 'mintsOrBuys' ? 'mints' : metric,
    current: values[values.length - 1],
    predicted: Math.max(0, predicted),
    timeframe,
    confidence,
    trend,
    factors,
  };
}

export function generateForecast(
  snapshots: MetricsSnapshot[],
  metric: 'impressions' | 'clicks' | 'mintsOrBuys',
  periods: number = 4
): ForecastPoint[] {
  if (snapshots.length < 3) return [];

  const values = snapshots.map((s: MetricsSnapshot) => {
    if (metric === 'impressions') return s.impressions;
    if (metric === 'clicks') return s.clicks;
    return s.mintsOrBuys;
  }).reverse();

  // Linear regression
  const n = values.length;
  const xMean = (n - 1) / 2;
  const yMean = values.reduce((sum: number, v: number) => sum + v, 0) / n;

  let numerator = 0;
  let denominator = 0;

  for (let i = 0; i < n; i++) {
    numerator += (i - xMean) * (values[i] - yMean);
    denominator += Math.pow(i - xMean, 2);
  }

  const slope = numerator / denominator;
  const intercept = yMean - slope * xMean;

  // Calculate standard error
  const residuals = values.map((y: number, i: number) => y - (slope * i + intercept));
  const sse = residuals.reduce((sum: number, r: number) => sum + r * r, 0);
  const standardError = Math.sqrt(sse / (n - 2));

  const forecast: ForecastPoint[] = [];
  const today = new Date();

  for (let i = 1; i <= periods; i++) {
    const x = n - 1 + i;
    const predicted = slope * x + intercept;
    const futureDate = new Date(today);
    futureDate.setDate(futureDate.getDate() + i * 7); // weekly intervals

    // Confidence interval (95% ≈ 2 standard errors)
    const margin = 2 * standardError * Math.sqrt(1 + 1/n + Math.pow(x - xMean, 2) / denominator);

    forecast.push({
      date: futureDate.toISOString().split('T')[0],
      value: Math.max(0, predicted),
      lower: Math.max(0, predicted - margin),
      upper: predicted + margin,
    });
  }

  return forecast;
}

export function predictResonanceScore(
  currentScore: number,
  trend: 'rising' | 'flat' | 'falling' | 'unknown',
  snapshots: MetricsSnapshot[]
): Prediction {
  const timeframe = '30d';
  let predicted = currentScore;
  let confidence = 0.5;
  const factors: string[] = [];

  if (trend === 'rising') {
    predicted = Math.min(100, currentScore * 1.15);
    confidence = 0.7;
    factors.push('Upward momentum suggests continued growth');
  } else if (trend === 'falling') {
    predicted = Math.max(0, currentScore * 0.85);
    confidence = 0.65;
    factors.push('Declining trend may continue without intervention');
  } else if (trend === 'flat') {
    predicted = currentScore;
    confidence = 0.8;
    factors.push('Stable performance likely to continue');
  } else {
    predicted = currentScore;
    confidence = 0.4;
    factors.push('Insufficient data for reliable prediction');
  }

  // Adjust based on recent data volume
  if (snapshots.length >= 5) {
    confidence += 0.1;
    factors.push('Multiple data points increase confidence');
  }

  const trendLabel = predicted > currentScore ? 'accelerating' 
    : predicted < currentScore ? 'decelerating' 
    : 'steady';

  return {
    metric: 'resonance-score',
    current: currentScore,
    predicted,
    timeframe,
    confidence: Math.min(1, confidence),
    trend: trendLabel,
    factors,
  };
}
