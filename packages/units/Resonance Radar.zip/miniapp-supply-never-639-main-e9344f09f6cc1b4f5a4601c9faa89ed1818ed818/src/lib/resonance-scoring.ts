// Resonance scoring and recommendation logic

import type { 
  TrackedUnit, 
  MetricsSnapshot, 
  ResonanceSummary, 
  TrendType, 
  RecommendationType,
  GeoTarget 
} from '@/types/resonance';

/**
 * RESONANCE SCORE ALGORITHM
 * 
 * The score (0-100) is computed from these factors:
 * 
 * 1. CTR (Click-Through Rate): clicks / impressions
 *    - Weight: 25%
 *    - Higher CTR = better audience interest
 * 
 * 2. Conversion Rate: (mintsOrBuys) / impressions
 *    - Weight: 30%
 *    - Shows actual commitment/purchase intent
 * 
 * 3. Engagement Rate: (comments + savesOrBookmarks) / impressions
 *    - Weight: 20%
 *    - Indicates deeper audience connection
 * 
 * 4. Remix/Reshare Rate: remixesOrReshares / impressions
 *    - Weight: 25%
 *    - Shows virality and cultural spread
 * 
 * Each rate is normalized to 0-100 using sigmoid function.
 * Final score = weighted sum of normalized rates.
 * 
 * TREND: Compare current score to previous period's score
 * - Rising: +5% or more increase
 * - Falling: -5% or more decrease
 * - Flat: within ±5%
 * - Unknown: no previous data
 * 
 * RECOMMENDATION:
 * - Amplify: Score ≥ 70 AND rising/flat
 * - Evolve: Score 40-69 AND rising
 * - Watch: Score 40-69 AND flat/falling
 * - Pause: Score 20-39
 * - Retire: Score < 20
 */

function sigmoid(x: number, midpoint: number = 0.05, steepness: number = 100): number {
  return 100 / (1 + Math.exp(-steepness * (x - midpoint)));
}

function normalizeRate(rate: number, typical: number = 0.05): number {
  return Math.min(100, sigmoid(rate, typical));
}

export function computeResonanceScore(snapshot: MetricsSnapshot): {
  score: number;
  ctr: number;
  conversionRate: number;
  engagementRate: number;
  remixRate: number;
  breakdown: Record<string, number>;
} {
  const { impressions, clicks, mintsOrBuys, comments, savesOrBookmarks, remixesOrReshares } = snapshot;
  
  // Avoid division by zero
  const safeImpressions = Math.max(impressions, 1);
  
  // Calculate raw rates
  const ctr = clicks / safeImpressions;
  const conversionRate = mintsOrBuys / safeImpressions;
  const engagementRate = (comments + savesOrBookmarks) / safeImpressions;
  const remixRate = remixesOrReshares / safeImpressions;
  
  // Normalize each rate to 0-100
  const ctrScore = normalizeRate(ctr, 0.03); // 3% typical CTR
  const conversionScore = normalizeRate(conversionRate, 0.01); // 1% typical conversion
  const engagementScore = normalizeRate(engagementRate, 0.02); // 2% typical engagement
  const remixScore = normalizeRate(remixRate, 0.005); // 0.5% typical remix rate
  
  // Weighted sum
  const score = (
    ctrScore * 0.25 +
    conversionScore * 0.30 +
    engagementScore * 0.20 +
    remixScore * 0.25
  );
  
  return {
    score: Math.round(score * 10) / 10,
    ctr: Math.round(ctr * 10000) / 100, // as percentage
    conversionRate: Math.round(conversionRate * 10000) / 100,
    engagementRate: Math.round(engagementRate * 10000) / 100,
    remixRate: Math.round(remixRate * 10000) / 100,
    breakdown: {
      'CTR Score (25%)': Math.round(ctrScore * 10) / 10,
      'Conversion Score (30%)': Math.round(conversionScore * 10) / 10,
      'Engagement Score (20%)': Math.round(engagementScore * 10) / 10,
      'Remix Score (25%)': Math.round(remixScore * 10) / 10,
    },
  };
}

export function determineTrend(
  currentScore: number,
  previousScore: number | null
): TrendType {
  if (previousScore === null) return 'unknown';
  
  const percentChange = ((currentScore - previousScore) / previousScore) * 100;
  
  if (percentChange >= 5) return 'rising';
  if (percentChange <= -5) return 'falling';
  return 'flat';
}

export function determineRecommendation(
  score: number,
  trend: TrendType
): RecommendationType {
  if (score >= 70) {
    return trend === 'falling' ? 'watch' : 'amplify';
  }
  
  if (score >= 40) {
    if (trend === 'rising') return 'evolve';
    return 'watch';
  }
  
  if (score >= 20) {
    return 'pause';
  }
  
  return 'retire';
}

export function identifyMainDrivers(
  snapshot: MetricsSnapshot,
  breakdown: Record<string, number>
): string[] {
  const drivers: string[] = [];
  const { impressions, clicks, mintsOrBuys, remixesOrReshares, comments, savesOrBookmarks, channelBreakdown } = snapshot;
  
  // Check each component score
  if (breakdown['CTR Score (25%)'] >= 70) {
    drivers.push(`Strong CTR: ${clicks} clicks from ${impressions} impressions`);
  }
  
  if (breakdown['Conversion Score (30%)'] >= 70) {
    drivers.push(`High conversions: ${mintsOrBuys} mints/buys`);
  }
  
  if (breakdown['Engagement Score (20%)'] >= 70) {
    drivers.push(`Deep engagement: ${comments} comments, ${savesOrBookmarks} saves`);
  }
  
  if (breakdown['Remix Score (25%)'] >= 70) {
    drivers.push(`Viral spread: ${remixesOrReshares} remixes/reshares`);
  }
  
  // Channel analysis
  const channels = Object.entries(channelBreakdown).sort((a, b) => b[1] - a[1]);
  if (channels.length > 0) {
    const topChannel = channels[0];
    const channelPct = (topChannel[1] / impressions) * 100;
    if (channelPct >= 50) {
      drivers.push(`Dominated by ${topChannel[0]} (${Math.round(channelPct)}%)`);
    }
  }
  
  // If no strong drivers, add general observation
  if (drivers.length === 0) {
    drivers.push('Balanced performance across all metrics');
  }
  
  return drivers;
}

export function createResonanceSummary(
  snapshot: MetricsSnapshot,
  previousSnapshot: MetricsSnapshot | null
): ResonanceSummary {
  const { score, breakdown } = computeResonanceScore(snapshot);
  
  let previousScore: number | null = null;
  if (previousSnapshot) {
    const prev = computeResonanceScore(previousSnapshot);
    previousScore = prev.score;
  }
  
  const trend = determineTrend(score, previousScore);
  const recommendation = determineRecommendation(score, trend);
  const mainDrivers = identifyMainDrivers(snapshot, breakdown);
  
  return {
    unitId: snapshot.unitId,
    lastPeriodLabel: snapshot.periodLabel,
    resonanceScore: score,
    trend,
    recommendation,
    mainDrivers,
    computedAt: new Date().toISOString(),
  };
}

// SEO Generation
export function generateSEO(unit: TrackedUnit): {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
} {
  const typeLabels: Record<string, string> = {
    'culture-coin': 'CultureCoin',
    'drop': 'Drop',
    'meme': 'Meme',
    'campaign': 'Campaign',
    'other': 'Culture Object',
  };
  
  const typeLabel = typeLabels[unit.type] || 'Culture Object';
  const emoji = unit.primaryEmoji || '🎯';
  
  return {
    seoTitle: `${emoji} ${unit.name} | ${typeLabel} on ${unit.chain}`,
    seoDescription: `Track and analyze ${unit.name}, a ${typeLabel} on ${unit.chain}. Monitor resonance, engagement, and cultural impact in real-time.`,
    seoKeywords: [
      unit.name.toLowerCase(),
      typeLabel.toLowerCase(),
      unit.chain.toLowerCase(),
      'culture',
      'crypto',
      'web3',
      'engagement',
      'metrics',
    ],
    seoHashtags: [
      `#${unit.name.replace(/\s+/g, '')}`,
      `#${typeLabel}`,
      `#${unit.chain}`,
      '#CultureObjects',
      '#Web3Culture',
    ],
    altText: `${typeLabel} ${unit.name} on ${unit.chain} - Performance tracking and resonance analysis`,
  };
}

// Geo Variants Generation
export function generateGeoVariants(
  unit: TrackedUnit,
  baseCaption?: string
): {
  captionLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
} {
  const caption = baseCaption || `Discover ${unit.name} - ${unit.type} on ${unit.chain}`;
  
  const captionLocalized: Record<string, string> = {};
  const tagsLocalized: Record<string, string[]> = {};
  
  for (const geo of unit.primaryGeoTargets) {
    const geoKey = geo.id;
    
    // Generate localized caption based on language
    switch (geo.language) {
      case 'es':
        captionLocalized[geoKey] = `Descubre ${unit.name} - ${unit.type} en ${unit.chain}`;
        tagsLocalized[geoKey] = [`cultura`, `cripto`, `${unit.chain.toLowerCase()}`, `web3`];
        break;
      case 'pt-BR':
        captionLocalized[geoKey] = `Descubra ${unit.name} - ${unit.type} em ${unit.chain}`;
        tagsLocalized[geoKey] = [`cultura`, `cripto`, `${unit.chain.toLowerCase()}`, `web3`];
        break;
      case 'fr':
        captionLocalized[geoKey] = `Découvrez ${unit.name} - ${unit.type} sur ${unit.chain}`;
        tagsLocalized[geoKey] = [`culture`, `crypto`, `${unit.chain.toLowerCase()}`, `web3`];
        break;
      default:
        captionLocalized[geoKey] = caption;
        tagsLocalized[geoKey] = [`culture`, `crypto`, `${unit.chain.toLowerCase()}`, `web3`, geo.region.toLowerCase()];
    }
    
    // Add location-specific tags
    if (geo.cityOrMarket) {
      tagsLocalized[geoKey].push(geo.cityOrMarket.toLowerCase().replace(/\s+/g, ''));
    }
  }
  
  return { captionLocalized, tagsLocalized };
}
