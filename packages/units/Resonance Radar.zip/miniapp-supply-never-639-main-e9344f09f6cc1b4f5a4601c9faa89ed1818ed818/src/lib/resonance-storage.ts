// Local storage utilities for Resonance Radar

import type { TrackedUnit, MetricsSnapshot, ResonanceSummary } from '@/types/resonance';

const STORAGE_KEYS = {
  UNITS: 'resonance_tracked_units',
  SNAPSHOTS: 'resonance_metrics_snapshots',
  SUMMARIES: 'resonance_summaries',
} as const;

// TrackedUnits
export function getAllUnits(): TrackedUnit[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.UNITS);
  return data ? JSON.parse(data) : [];
}

export function getUnitById(id: string): TrackedUnit | null {
  const units = getAllUnits();
  return units.find((u: TrackedUnit) => u.id === id) || null;
}

export function saveUnit(unit: TrackedUnit): void {
  const units = getAllUnits();
  const index = units.findIndex((u: TrackedUnit) => u.id === unit.id);
  if (index >= 0) {
    units[index] = { ...unit, updatedAt: new Date().toISOString() };
  } else {
    units.push(unit);
  }
  localStorage.setItem(STORAGE_KEYS.UNITS, JSON.stringify(units));
}

export function deleteUnit(id: string): void {
  const units = getAllUnits().filter((u: TrackedUnit) => u.id !== id);
  localStorage.setItem(STORAGE_KEYS.UNITS, JSON.stringify(units));
  
  // Also delete related snapshots and summary
  const snapshots = getAllSnapshots().filter((s: MetricsSnapshot) => s.unitId !== id);
  localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));
  
  const summaries = getAllSummaries().filter((s: ResonanceSummary) => s.unitId !== id);
  localStorage.setItem(STORAGE_KEYS.SUMMARIES, JSON.stringify(summaries));
}

// MetricsSnapshots
export function getAllSnapshots(): MetricsSnapshot[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
  return data ? JSON.parse(data) : [];
}

export function getSnapshotsByUnitId(unitId: string): MetricsSnapshot[] {
  const snapshots = getAllSnapshots();
  return snapshots
    .filter((s: MetricsSnapshot) => s.unitId === unitId)
    .sort((a: MetricsSnapshot, b: MetricsSnapshot) => 
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
}

export function saveSnapshot(snapshot: MetricsSnapshot): void {
  const snapshots = getAllSnapshots();
  const index = snapshots.findIndex((s: MetricsSnapshot) => s.id === snapshot.id);
  if (index >= 0) {
    snapshots[index] = snapshot;
  } else {
    snapshots.push(snapshot);
  }
  localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));
}

export function deleteSnapshot(id: string): void {
  const snapshots = getAllSnapshots().filter((s: MetricsSnapshot) => s.id !== id);
  localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));
}

// ResonanceSummaries
export function getAllSummaries(): ResonanceSummary[] {
  if (typeof window === 'undefined') return [];
  const data = localStorage.getItem(STORAGE_KEYS.SUMMARIES);
  return data ? JSON.parse(data) : [];
}

export function getSummaryByUnitId(unitId: string): ResonanceSummary | null {
  const summaries = getAllSummaries();
  return summaries.find((s: ResonanceSummary) => s.unitId === unitId) || null;
}

export function saveSummary(summary: ResonanceSummary): void {
  const summaries = getAllSummaries();
  const index = summaries.findIndex((s: ResonanceSummary) => s.unitId === summary.unitId);
  if (index >= 0) {
    summaries[index] = summary;
  } else {
    summaries.push(summary);
  }
  localStorage.setItem(STORAGE_KEYS.SUMMARIES, JSON.stringify(summaries));
}
