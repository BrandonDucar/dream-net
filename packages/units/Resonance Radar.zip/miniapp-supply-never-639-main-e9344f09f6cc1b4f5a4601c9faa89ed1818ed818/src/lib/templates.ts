/**
 * Templates & Presets System
 * 
 * Quick setup templates for common culture object types
 */

import type { TrackedUnit, GeoTarget } from './types';

export interface Template {
  id: string;
  name: string;
  description: string;
  emoji: string;
  type: TrackedUnit['type'];
  defaultGeoTargets: GeoTarget[];
  defaultSEO: {
    keywords: string[];
    hashtags: string[];
  };
  sampleMetrics?: {
    impressions: number;
    clicks: number;
    mintsOrBuys: number;
  };
}

export const TEMPLATES: Template[] = [
  {
    id: 'culture-coin-launch',
    name: 'CultureCoin Launch',
    description: 'Track a new CultureCoin from launch',
    emoji: '🪙',
    type: 'culture-coin',
    defaultGeoTargets: [
      {
        id: 'us-en',
        region: 'US',
        country: 'US',
        cityOrMarket: 'National',
        language: 'en',
      },
      {
        id: 'global-en',
        region: 'Global',
        country: '',
        cityOrMarket: 'Crypto Twitter',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['culturecoin', 'base', 'crypto', 'meme coin', 'community token'],
      hashtags: ['#CultureCoin', '#Base', '#Crypto', '#Web3'],
    },
    sampleMetrics: {
      impressions: 10000,
      clicks: 500,
      mintsOrBuys: 50,
    },
  },
  {
    id: 'nft-drop',
    name: 'NFT Drop',
    description: 'Track an NFT collection or limited edition drop',
    emoji: '🎨',
    type: 'drop',
    defaultGeoTargets: [
      {
        id: 'us-en',
        region: 'US',
        country: 'US',
        cityOrMarket: 'National',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['nft', 'drop', 'collectible', 'digital art', 'base'],
      hashtags: ['#NFT', '#NFTDrop', '#DigitalArt', '#Base'],
    },
    sampleMetrics: {
      impressions: 5000,
      clicks: 250,
      mintsOrBuys: 100,
    },
  },
  {
    id: 'viral-meme',
    name: 'Viral Meme',
    description: 'Track a meme or viral content piece',
    emoji: '🔥',
    type: 'meme',
    defaultGeoTargets: [
      {
        id: 'global-en',
        region: 'Global',
        country: '',
        cityOrMarket: 'Internet',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['meme', 'viral', 'trending', 'culture', 'social'],
      hashtags: ['#Meme', '#Viral', '#Trending'],
    },
    sampleMetrics: {
      impressions: 50000,
      clicks: 2000,
      mintsOrBuys: 0,
    },
  },
  {
    id: 'marketing-campaign',
    name: 'Marketing Campaign',
    description: 'Track a marketing or awareness campaign',
    emoji: '📢',
    type: 'campaign',
    defaultGeoTargets: [
      {
        id: 'us-en',
        region: 'US',
        country: 'US',
        cityOrMarket: 'National',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['campaign', 'marketing', 'promotion', 'announcement'],
      hashtags: ['#Marketing', '#Campaign', '#Promo'],
    },
    sampleMetrics: {
      impressions: 20000,
      clicks: 1000,
      mintsOrBuys: 200,
    },
  },
  {
    id: 'community-event',
    name: 'Community Event',
    description: 'Track a community event or activation',
    emoji: '🎉',
    type: 'other',
    defaultGeoTargets: [
      {
        id: 'us-en',
        region: 'US',
        country: 'US',
        cityOrMarket: 'Local',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['event', 'community', 'meetup', 'activation'],
      hashtags: ['#Community', '#Event', '#IRL'],
    },
    sampleMetrics: {
      impressions: 3000,
      clicks: 300,
      mintsOrBuys: 50,
    },
  },
  {
    id: 'global-expansion',
    name: 'Global Expansion',
    description: 'Track multi-region expansion with localized content',
    emoji: '🌍',
    type: 'campaign',
    defaultGeoTargets: [
      {
        id: 'us-en',
        region: 'US',
        country: 'US',
        cityOrMarket: 'National',
        language: 'en',
      },
      {
        id: 'latam-es',
        region: 'LATAM',
        country: '',
        cityOrMarket: 'Regional',
        language: 'es',
      },
      {
        id: 'eu-en',
        region: 'EU',
        country: '',
        cityOrMarket: 'Regional',
        language: 'en',
      },
      {
        id: 'asia-en',
        region: 'Asia',
        country: '',
        cityOrMarket: 'Regional',
        language: 'en',
      },
    ],
    defaultSEO: {
      keywords: ['global', 'international', 'expansion', 'multilingual'],
      hashtags: ['#Global', '#International', '#Web3'],
    },
    sampleMetrics: {
      impressions: 100000,
      clicks: 5000,
      mintsOrBuys: 500,
    },
  },
];

export function getTemplate(id: string): Template | undefined {
  return TEMPLATES.find((t: Template) => t.id === id);
}

export function applyTemplate(template: Template, customName: string): Partial<TrackedUnit> {
  return {
    type: template.type,
    name: customName,
    primaryEmoji: template.emoji,
    chain: 'Base',
    status: 'new',
    primaryGeoTargets: template.defaultGeoTargets,
    seoKeywords: template.defaultSEO.keywords,
    seoHashtags: template.defaultSEO.hashtags,
  };
}
