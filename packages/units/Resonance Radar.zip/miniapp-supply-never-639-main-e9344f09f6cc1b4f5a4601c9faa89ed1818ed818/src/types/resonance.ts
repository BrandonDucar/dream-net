// Type definitions for Resonance Radar

export type UnitType = "culture-coin" | "drop" | "meme" | "campaign" | "other";

export type UnitStatus = "new" | "growing" | "stable" | "declining" | "retired";

export type TrendType = "rising" | "flat" | "falling" | "unknown";

export type RecommendationType = "amplify" | "evolve" | "pause" | "retire" | "watch";

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface TrackedUnit {
  id: string;
  type: UnitType;
  refId: string;
  name: string;
  primaryEmoji: string;
  chain: string;
  status: UnitStatus;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
  primaryGeoTargets: GeoTarget[];
  captionLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  createdAt: string;
  updatedAt: string;
}

export interface MetricsSnapshot {
  id: string;
  unitId: string;
  periodLabel: string;
  timestamp: string;
  impressions: number;
  clicks: number;
  mintsOrBuys: number;
  remixesOrReshares: number;
  comments: number;
  savesOrBookmarks: number;
  channelBreakdown: Record<string, number>;
  notes: string;
}

export interface ResonanceSummary {
  unitId: string;
  lastPeriodLabel: string;
  resonanceScore: number;
  trend: TrendType;
  recommendation: RecommendationType;
  mainDrivers: string[];
  computedAt: string;
}
