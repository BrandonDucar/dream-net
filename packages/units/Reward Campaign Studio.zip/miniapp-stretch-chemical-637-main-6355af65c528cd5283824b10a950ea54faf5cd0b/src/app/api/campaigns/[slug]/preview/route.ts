import { NextResponse } from 'next/server';
import { getCampaignBySlug, getLatestPreviewByCampaignId } from '@/lib/storage';
import { generateCampaignPreview } from '@/lib/campaign-utils';

interface RouteParams {
  params: Promise<{
    slug: string;
  }>;
}

export async function GET(
  request: Request,
  { params }: RouteParams
): Promise<NextResponse> {
  try {
    const { slug } = await params;
    const campaign = getCampaignBySlug(slug);
    
    if (!campaign) {
      return NextResponse.json(
        { success: false, error: 'Campaign not found' },
        { status: 404 }
      );
    }

    // Try to get latest preview, or generate a new one
    let preview = getLatestPreviewByCampaignId(campaign.id);
    
    if (!preview) {
      preview = generateCampaignPreview(campaign);
    }

    return NextResponse.json({
      success: true,
      campaign: {
        id: campaign.id,
        name: campaign.name,
        slug: campaign.slug,
        status: campaign.status,
        reward_type: campaign.reward_type,
      },
      preview: {
        id: preview.id,
        created_at: preview.created_at,
        eligible_count: preview.eligible_count,
        excluded_count: preview.excluded_count,
        payload: preview.payload_preview,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { success: false, error: 'Failed to generate preview' },
      { status: 500 }
    );
  }
}
