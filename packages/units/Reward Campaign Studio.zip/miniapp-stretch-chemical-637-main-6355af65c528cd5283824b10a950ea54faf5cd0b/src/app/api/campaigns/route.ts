import { NextRequest, NextResponse } from 'next/server'
import { getCampaigns } from '@/lib/storage'

export async function GET(): Promise<NextResponse> {
  try {
    const campaigns = getCampaigns()
    
    // Return basic campaign info for API consumers
    const campaignsList = campaigns.map(campaign => ({
      id: campaign.id,
      name: campaign.name,
      url_name: campaign.url_name,
      status: campaign.status,
      reward_type: campaign.reward_type,
      reward_value: campaign.reward_value,
      total_budget: campaign.total_budget,
      created_at: campaign.created_at,
      updated_at: campaign.updated_at,
      categories: campaign.categories
    }))

    return NextResponse.json({
      success: true,
      campaigns: campaignsList,
      total: campaignsList.length
    })
  } catch (error) {
    console.error('Error fetching campaigns:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch campaigns' },
      { status: 500 }
    )
  }
}