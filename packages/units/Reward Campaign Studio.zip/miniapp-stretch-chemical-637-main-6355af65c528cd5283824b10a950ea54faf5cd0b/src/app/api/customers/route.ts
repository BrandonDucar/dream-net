import { NextRequest, NextResponse } from 'next/server'
import { getCustomerPool } from '@/lib/storage'

export async function GET(): Promise<NextResponse> {
  try {
    const customers = getCustomerPool()
    
    return NextResponse.json({
      success: true,
      customers: customers,
      total: customers.length,
      stats: {
        total_customers: customers.length,
        avg_activity_score: customers.reduce((acc, c) => acc + (c.activity_score ?? 0), 0) / customers.length,
        high_engagement: customers.filter(c => (c.activity_score ?? 0) >= 80).length,
        segments: Array.from(new Set(customers.map(c => c.customer_segment).filter(Boolean))).length
      }
    })
  } catch (error) {
    console.error('Error fetching customers:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch customers' },
      { status: 500 }
    )
  }
}