import { NextRequest, NextResponse } from 'next/server'
import { getCustomerPool } from '@/lib/storage'

// Legacy API endpoint - redirects to customers for compatibility
export async function GET(): Promise<NextResponse> {
  try {
    const customers = getCustomerPool()
    
    // Convert customer data to legacy wallet format for compatibility
    const wallets = customers.map(customer => ({
      wallet_address: customer.customer_id,
      stage_slug: customer.customer_segment,
      packs: customer.tiers || [],
      last_score: customer.activity_score,
      last_seen: customer.last_active,
      tags: customer.notes || []
    }))

    return NextResponse.json({
      success: true,
      wallets: wallets,
      total: wallets.length,
      message: 'This API endpoint is deprecated. Please use /api/customers instead.'
    })
  } catch (error) {
    console.error('Error fetching wallet data:', error)
    return NextResponse.json(
      { success: false, error: 'Failed to fetch wallet data' },
      { status: 500 }
    )
  }
}