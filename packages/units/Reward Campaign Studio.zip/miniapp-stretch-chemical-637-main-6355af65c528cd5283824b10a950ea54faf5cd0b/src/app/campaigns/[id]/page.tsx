'use client'

import { useParams } from 'next/navigation'
import CampaignForm from '@/components/campaign-form'

export default function EditCampaignPage(): JSX.Element {
  const params = useParams()
  const campaignId = params?.id as string

  return <CampaignForm campaignId={campaignId} />
}