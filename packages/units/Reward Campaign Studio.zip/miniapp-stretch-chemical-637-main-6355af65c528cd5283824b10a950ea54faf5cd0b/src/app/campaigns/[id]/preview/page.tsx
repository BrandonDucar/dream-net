'use client'

import { useState, useEffect } from 'react'
import { useParams } from 'next/navigation'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowLeft, Download, Copy, CheckCircle, Users, Target, Award, Calendar } from 'lucide-react'
import { getCampaignById, getCustomerPool, saveCampaignPreview } from '@/lib/storage'
import { generateCampaignPreview, getStatusDisplay, getRewardTypeLabel } from '@/lib/campaign-utils'
import type { RewardCampaign, CustomerRecord, CampaignPreview } from '@/types'

export default function CampaignPreviewPage(): JSX.Element {
  const params = useParams()
  const campaignId = params?.id as string
  
  const [campaign, setCampaign] = useState<RewardCampaign | null>(null)
  const [preview, setPreview] = useState<CampaignPreview | null>(null)
  const [loading, setLoading] = useState<boolean>(true)
  const [copied, setCopied] = useState<boolean>(false)

  useEffect(() => {
    if (!campaignId) return

    const campaignData = getCampaignById(campaignId)
    if (!campaignData) {
      setLoading(false)
      return
    }

    setCampaign(campaignData)

    // Generate preview
    const customerPool = getCustomerPool()
    const previewData = generateCampaignPreview(campaignData, customerPool)
    setPreview(previewData)
    
    // Save preview for audit trail
    saveCampaignPreview(previewData)
    
    setLoading(false)
  }, [campaignId])

  const handleCopyData = async (): Promise<void> => {
    if (!preview) return
    
    try {
      await navigator.clipboard.writeText(JSON.stringify(preview.export_data, null, 2))
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (error) {
      console.error('Failed to copy:', error)
    }
  }

  const handleDownloadData = (): void => {
    if (!preview) return
    
    const dataStr = JSON.stringify(preview.export_data, null, 2)
    const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr)
    
    const exportFileDefaultName = `${campaign?.url_name || 'campaign'}-export-${new Date().getTime()}.json`
    
    const linkElement = document.createElement('a')
    linkElement.setAttribute('href', dataUri)
    linkElement.setAttribute('download', exportFileDefaultName)
    linkElement.click()
  }

  if (loading) {
    return <div className="p-8">Loading campaign preview...</div>
  }

  if (!campaign) {
    return (
      <div className="min-h-screen bg-gray-900 text-white">
        <div className="container mx-auto px-6 py-8">
          <div className="text-center py-12">
            <h1 className="text-2xl font-bold text-white mb-4">Campaign Not Found</h1>
            <p className="text-gray-400 mb-6">The campaign you're looking for doesn't exist.</p>
            <Button asChild>
              <Link href="/campaigns">Back to Campaigns</Link>
            </Button>
          </div>
        </div>
      </div>
    )
  }

  if (!preview) {
    return <div className="p-8">Generating preview...</div>
  }

  const statusDisplay = getStatusDisplay(campaign.status)

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button asChild variant="outline" className="border-gray-600 text-gray-200">
              <Link href={`/campaigns/${campaign.id}`}>
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Edit
              </Link>
            </Button>
            <div>
              <h1 className="text-4xl font-bold text-white">Campaign Preview</h1>
              <p className="text-gray-400">See who will receive rewards and export the data</p>
            </div>
          </div>
          
          <div className="flex space-x-2">
            <Button onClick={handleCopyData} variant="outline" className="border-gray-600 text-gray-200">
              {copied ? (
                <>
                  <CheckCircle className="mr-2 h-4 w-4 text-green-400" />
                  Copied!
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" />
                  Copy Data
                </>
              )}
            </Button>
            <Button onClick={handleDownloadData} className="bg-blue-600 hover:bg-blue-700">
              <Download className="mr-2 h-4 w-4" />
              Download JSON
            </Button>
          </div>
        </div>

        {/* Campaign Summary */}
        <Card className="bg-gray-800 border-gray-700 mb-8">
          <CardHeader>
            <CardTitle className="flex items-center text-white">
              <Award className="mr-2 h-6 w-6 text-blue-400" />
              {campaign.name}
            </CardTitle>
            <CardDescription className="text-gray-400">
              {campaign.description}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-700 rounded-lg">
                  <Target className="h-5 w-5 text-blue-400" />
                </div>
                <div>
                  <div className="text-sm text-gray-400">Status</div>
                  <Badge
                    variant="outline"
                    className={`${
                      statusDisplay.color === 'green' ? 'border-green-600 text-green-400' :
                      statusDisplay.color === 'blue' ? 'border-blue-600 text-blue-400' :
                      statusDisplay.color === 'orange' ? 'border-orange-600 text-orange-400' :
                      statusDisplay.color === 'purple' ? 'border-purple-600 text-purple-400' :
                      'border-gray-600 text-gray-400'
                    }`}
                  >
                    {statusDisplay.label}
                  </Badge>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-700 rounded-lg">
                  <Award className="h-5 w-5 text-purple-400" />
                </div>
                <div>
                  <div className="text-sm text-gray-400">Reward Type</div>
                  <div className="text-white font-medium">{getRewardTypeLabel(campaign.reward_type)}</div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-700 rounded-lg">
                  <Users className="h-5 w-5 text-green-400" />
                </div>
                <div>
                  <div className="text-sm text-gray-400">Reward Value</div>
                  <div className="text-white font-medium">{campaign.reward_value || '-'}</div>
                </div>
              </div>

              <div className="flex items-center space-x-3">
                <div className="p-2 bg-gray-700 rounded-lg">
                  <Calendar className="h-5 w-5 text-orange-400" />
                </div>
                <div>
                  <div className="text-sm text-gray-400">Budget</div>
                  <div className="text-white font-medium">{campaign.total_budget || '-'}</div>
                </div>
              </div>
            </div>

            {campaign.start_date && (
              <div className="mt-4 pt-4 border-t border-gray-700">
                <div className="text-sm text-gray-400">
                  <span className="mr-4">
                    <strong>Starts:</strong> {new Date(campaign.start_date).toLocaleString()}
                  </span>
                  {campaign.end_date && (
                    <span>
                      <strong>Ends:</strong> {new Date(campaign.end_date).toLocaleString()}
                    </span>
                  )}
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Preview Results */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Eligible Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-400">{preview.eligible_count}</div>
              <p className="text-xs text-gray-400">will receive rewards</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Excluded Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-orange-400">{preview.excluded_count}</div>
              <p className="text-xs text-gray-400">don't meet criteria</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Estimated Cost</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-400">
                {campaign.total_budget || 'N/A'}
              </div>
              <p className="text-xs text-gray-400">total budget</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Coverage</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-purple-400">
                {Math.round((preview.eligible_count / (preview.eligible_count + preview.excluded_count)) * 100)}%
              </div>
              <p className="text-xs text-gray-400">of customer base</p>
            </CardContent>
          </Card>
        </div>

        {/* Eligible Customers Table */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Eligible Customers</CardTitle>
            <CardDescription className="text-gray-400">
              Customers who will receive rewards from this campaign
            </CardDescription>
          </CardHeader>
          <CardContent>
            {preview.eligible_customers.length === 0 ? (
              <div className="text-center py-12">
                <Users className="mx-auto h-12 w-12 text-gray-600 mb-4" />
                <h3 className="text-lg font-medium text-gray-300 mb-2">No Eligible Customers</h3>
                <p className="text-gray-400">
                  No customers match the targeting criteria for this campaign.
                </p>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-200">Customer ID</TableHead>
                    <TableHead className="text-gray-200">Segment</TableHead>
                    <TableHead className="text-gray-200">Activity Score</TableHead>
                    <TableHead className="text-gray-200">Tiers</TableHead>
                    <TableHead className="text-gray-200">Last Active</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {preview.eligible_customers.map((customer) => (
                    <TableRow key={customer.customer_id} className="border-gray-700">
                      <TableCell className="text-white font-medium">
                        {customer.customer_id}
                      </TableCell>
                      <TableCell>
                        {customer.customer_segment ? (
                          <Badge variant="outline" className="border-gray-600 text-gray-300">
                            {customer.customer_segment}
                          </Badge>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {customer.activity_score !== undefined ? (
                          <div className="flex items-center">
                            <div className="w-16 bg-gray-700 rounded-full h-2 mr-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${customer.activity_score}%` }}
                              />
                            </div>
                            <span className="text-white text-sm">{customer.activity_score}</span>
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {customer.tiers && customer.tiers.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {customer.tiers.map((tier) => (
                              <Badge key={tier} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                                {tier}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-gray-400">
                        {customer.last_active 
                          ? new Date(customer.last_active).toLocaleDateString()
                          : '-'
                        }
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}