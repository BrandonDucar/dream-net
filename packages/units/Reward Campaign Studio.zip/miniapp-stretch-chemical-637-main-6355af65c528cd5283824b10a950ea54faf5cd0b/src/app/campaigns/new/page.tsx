'use client'

import CampaignForm from '@/components/campaign-form'

export default function NewCampaignPage(): JSX.Element {
  return <CampaignForm />
}