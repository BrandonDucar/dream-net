'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu'
import { ArrowLeft, Plus, Search, MoreVertical, Copy, Archive, Edit, Eye } from 'lucide-react'
import { getCampaigns, saveCampaign, deleteCampaign } from '@/lib/storage'
import { getStatusDisplay, getRewardTypeLabel, generateUrlName } from '@/lib/campaign-utils'
import type { RewardCampaign, CampaignStatus, RewardType } from '@/types'

export default function CampaignsPage(): JSX.Element {
  const [campaigns, setCampaigns] = useState<RewardCampaign[]>([])
  const [filteredCampaigns, setFilteredCampaigns] = useState<RewardCampaign[]>([])
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [statusFilter, setStatusFilter] = useState<CampaignStatus | ''>('')
  const [rewardTypeFilter, setRewardTypeFilter] = useState<RewardType | ''>('')
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const loadCampaigns = (): void => {
      const campaignData = getCampaigns()
      setCampaigns(campaignData)
      setFilteredCampaigns(campaignData)
      setLoading(false)
    }
    
    loadCampaigns()
  }, [])

  useEffect(() => {
    let filtered = campaigns

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(campaign =>
        campaign.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        campaign.description?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        campaign.categories?.some(cat => cat.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    // Apply status filter
    if (statusFilter) {
      filtered = filtered.filter(campaign => campaign.status === statusFilter)
    }

    // Apply reward type filter
    if (rewardTypeFilter) {
      filtered = filtered.filter(campaign => campaign.reward_type === rewardTypeFilter)
    }

    setFilteredCampaigns(filtered)
  }, [campaigns, searchTerm, statusFilter, rewardTypeFilter])

  const handleDuplicateCampaign = (campaign: RewardCampaign): void => {
    const newCampaign: RewardCampaign = {
      ...campaign,
      id: `campaign-${Date.now()}`,
      name: `Copy of ${campaign.name}`,
      url_name: generateUrlName(`copy-of-${campaign.name}`),
      status: 'draft',
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    }
    
    saveCampaign(newCampaign)
    setCampaigns([...campaigns, newCampaign])
  }

  const handleArchiveCampaign = (campaignId: string): void => {
    const updatedCampaigns = campaigns.map(campaign =>
      campaign.id === campaignId
        ? { ...campaign, status: 'paused' as CampaignStatus, updated_at: new Date().toISOString() }
        : campaign
    )
    setCampaigns(updatedCampaigns)
    
    const updatedCampaign = updatedCampaigns.find(c => c.id === campaignId)
    if (updatedCampaign) {
      saveCampaign(updatedCampaign)
    }
  }

  const handleDeleteCampaign = (campaignId: string): void => {
    const updatedCampaigns = campaigns.filter(c => c.id !== campaignId)
    setCampaigns(updatedCampaigns)
    deleteCampaign(campaignId)
  }

  if (loading) {
    return <div className="p-8">Loading campaigns...</div>
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button asChild variant="outline" className="border-gray-600 text-gray-200">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-4xl font-bold text-white">Campaign Manager</h1>
              <p className="text-gray-400">Create and manage your customer reward campaigns</p>
            </div>
          </div>
          
          <Button asChild className="bg-blue-600 hover:bg-blue-700">
            <Link href="/campaigns/new">
              <Plus className="mr-2 h-4 w-4" />
              Create Campaign
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Total Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{campaigns.length}</div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Active</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-400">
                {campaigns.filter(c => c.status === 'active').length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Scheduled</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-400">
                {campaigns.filter(c => c.status === 'scheduled').length}
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Draft</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-gray-400">
                {campaigns.filter(c => c.status === 'draft').length}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Filter Campaigns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="Search campaigns..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="md:w-48">
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as CampaignStatus | '')}
                  className="w-full p-2 rounded border bg-gray-700 border-gray-600 text-white"
                >
                  <option value="">All Statuses</option>
                  <option value="draft">Draft</option>
                  <option value="scheduled">Scheduled</option>
                  <option value="active">Active</option>
                  <option value="completed">Completed</option>
                  <option value="paused">Paused</option>
                </select>
              </div>
              <div className="md:w-48">
                <select
                  value={rewardTypeFilter}
                  onChange={(e) => setRewardTypeFilter(e.target.value as RewardType | '')}
                  className="w-full p-2 rounded border bg-gray-700 border-gray-600 text-white"
                >
                  <option value="">All Reward Types</option>
                  <option value="points">Points</option>
                  <option value="discount">Discount</option>
                  <option value="access">Access</option>
                  <option value="gift">Gift</option>
                  <option value="entry">Entry</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Campaigns Table */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Your Campaigns</CardTitle>
            <CardDescription className="text-gray-400">
              Showing {filteredCampaigns.length} of {campaigns.length} campaigns
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredCampaigns.length === 0 ? (
              <div className="text-center py-12">
                <div className="text-gray-600 text-6xl mb-4">🎁</div>
                <h3 className="text-xl font-medium text-gray-300 mb-2">
                  {campaigns.length === 0 ? 'No campaigns yet' : 'No campaigns match your filters'}
                </h3>
                <p className="text-gray-400 mb-6">
                  {campaigns.length === 0 
                    ? 'Create your first reward campaign to get started'
                    : 'Try adjusting your search or filters'
                  }
                </p>
                {campaigns.length === 0 && (
                  <Button asChild className="bg-blue-600 hover:bg-blue-700">
                    <Link href="/campaigns/new">
                      <Plus className="mr-2 h-4 w-4" />
                      Create Your First Campaign
                    </Link>
                  </Button>
                )}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-200">Campaign Name</TableHead>
                    <TableHead className="text-gray-200">Status</TableHead>
                    <TableHead className="text-gray-200">Reward Type</TableHead>
                    <TableHead className="text-gray-200">Reward Value</TableHead>
                    <TableHead className="text-gray-200">Budget</TableHead>
                    <TableHead className="text-gray-200">Updated</TableHead>
                    <TableHead className="text-gray-200">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCampaigns.map((campaign) => {
                    const statusDisplay = getStatusDisplay(campaign.status)
                    return (
                      <TableRow key={campaign.id} className="border-gray-700">
                        <TableCell>
                          <div>
                            <div className="font-medium text-white">{campaign.name}</div>
                            {campaign.description && (
                              <div className="text-sm text-gray-400 max-w-md truncate">
                                {campaign.description}
                              </div>
                            )}
                            {campaign.categories && campaign.categories.length > 0 && (
                              <div className="flex gap-1 mt-1">
                                {campaign.categories.slice(0, 2).map((category) => (
                                  <Badge key={category} variant="outline" className="border-gray-600 text-gray-400 text-xs">
                                    {category}
                                  </Badge>
                                ))}
                                {campaign.categories.length > 2 && (
                                  <Badge variant="outline" className="border-gray-600 text-gray-400 text-xs">
                                    +{campaign.categories.length - 2}
                                  </Badge>
                                )}
                              </div>
                            )}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={`${
                              statusDisplay.color === 'green' ? 'border-green-600 text-green-400' :
                              statusDisplay.color === 'blue' ? 'border-blue-600 text-blue-400' :
                              statusDisplay.color === 'orange' ? 'border-orange-600 text-orange-400' :
                              statusDisplay.color === 'purple' ? 'border-purple-600 text-purple-400' :
                              'border-gray-600 text-gray-400'
                            }`}
                          >
                            {statusDisplay.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {getRewardTypeLabel(campaign.reward_type)}
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {campaign.reward_value || '-'}
                        </TableCell>
                        <TableCell className="text-gray-300">
                          {campaign.total_budget || '-'}
                        </TableCell>
                        <TableCell className="text-gray-400">
                          {new Date(campaign.updated_at).toLocaleDateString()}
                        </TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button asChild size="sm" variant="outline" className="border-gray-600 text-gray-200">
                              <Link href={`/campaigns/${campaign.id}/preview`}>
                                <Eye className="h-3 w-3" />
                              </Link>
                            </Button>
                            <Button asChild size="sm" variant="outline" className="border-gray-600 text-gray-200">
                              <Link href={`/campaigns/${campaign.id}`}>
                                <Edit className="h-3 w-3" />
                              </Link>
                            </Button>
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <Button size="sm" variant="outline" className="border-gray-600 text-gray-200">
                                  <MoreVertical className="h-3 w-3" />
                                </Button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent className="bg-gray-800 border-gray-700">
                                <DropdownMenuItem 
                                  onClick={() => handleDuplicateCampaign(campaign)}
                                  className="text-gray-200 hover:bg-gray-700"
                                >
                                  <Copy className="mr-2 h-4 w-4" />
                                  Duplicate
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => handleArchiveCampaign(campaign.id)}
                                  className="text-gray-200 hover:bg-gray-700"
                                >
                                  <Archive className="mr-2 h-4 w-4" />
                                  Pause
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  onClick={() => handleDeleteCampaign(campaign.id)}
                                  className="text-red-400 hover:bg-red-600/20"
                                >
                                  <Archive className="mr-2 h-4 w-4" />
                                  Delete
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}