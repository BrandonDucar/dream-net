'use client'

import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { ArrowLeft, Upload, Search, Plus, Edit, Trash2, Users } from 'lucide-react'
import { getCustomerPool, saveCustomerPool, saveCustomer, deleteCustomer } from '@/lib/storage'
import { parseCustomerInput, formatCustomerForDisplay } from '@/lib/campaign-utils'
import type { CustomerRecord } from '@/types'

export default function CustomersPage(): JSX.Element {
  const [customers, setCustomers] = useState<CustomerRecord[]>([])
  const [filteredCustomers, setFilteredCustomers] = useState<CustomerRecord[]>([])
  const [searchTerm, setSearchTerm] = useState<string>('')
  const [segmentFilter, setSegmentFilter] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(true)
  const [importText, setImportText] = useState<string>('')
  const [showImportDialog, setShowImportDialog] = useState<boolean>(false)
  const [editingCustomer, setEditingCustomer] = useState<CustomerRecord | null>(null)

  useEffect(() => {
    const loadCustomers = (): void => {
      const customerData = getCustomerPool()
      setCustomers(customerData)
      setFilteredCustomers(customerData)
      setLoading(false)
    }
    
    loadCustomers()
  }, [])

  useEffect(() => {
    let filtered = customers

    // Apply search filter
    if (searchTerm) {
      filtered = filtered.filter(customer =>
        customer.customer_id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.customer_segment?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        customer.tiers?.some(tier => tier.toLowerCase().includes(searchTerm.toLowerCase())) ||
        customer.notes?.some(note => note.toLowerCase().includes(searchTerm.toLowerCase()))
      )
    }

    // Apply segment filter
    if (segmentFilter) {
      filtered = filtered.filter(customer => customer.customer_segment === segmentFilter)
    }

    setFilteredCustomers(filtered)
  }, [customers, searchTerm, segmentFilter])

  const handleImportCustomers = (): void => {
    if (!importText.trim()) return

    try {
      const newCustomers = parseCustomerInput(importText)
      
      // Merge with existing customers
      const updatedCustomers = [...customers]
      
      newCustomers.forEach(newCustomer => {
        const existingIndex = updatedCustomers.findIndex(
          c => c.customer_id === newCustomer.customer_id
        )
        
        if (existingIndex >= 0) {
          // Update existing customer
          updatedCustomers[existingIndex] = { ...updatedCustomers[existingIndex], ...newCustomer }
        } else {
          // Add new customer
          updatedCustomers.push(newCustomer)
        }
      })

      setCustomers(updatedCustomers)
      saveCustomerPool(updatedCustomers)
      setImportText('')
      setShowImportDialog(false)
    } catch (error) {
      console.error('Error importing customers:', error)
    }
  }

  const handleSaveCustomer = (customer: CustomerRecord): void => {
    const updatedCustomers = customers.map(c =>
      c.customer_id === customer.customer_id ? customer : c
    )
    setCustomers(updatedCustomers)
    saveCustomer(customer)
    setEditingCustomer(null)
  }

  const handleDeleteCustomer = (customerId: string): void => {
    const updatedCustomers = customers.filter(c => c.customer_id !== customerId)
    setCustomers(updatedCustomers)
    deleteCustomer(customerId)
  }

  const uniqueSegments = Array.from(new Set(customers.map(c => c.customer_segment).filter(Boolean)))
  const avgActivityScore = customers.reduce((acc, c) => acc + (c.activity_score ?? 0), 0) / customers.length

  if (loading) {
    return <div className="p-8">Loading customer database...</div>
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Button asChild variant="outline" className="border-gray-600 text-gray-200">
              <Link href="/">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Back to Dashboard
              </Link>
            </Button>
            <div>
              <h1 className="text-4xl font-bold text-white">Customer Database</h1>
              <p className="text-gray-400">Manage your customer information and segments</p>
            </div>
          </div>
          
          <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
            <DialogTrigger asChild>
              <Button className="bg-blue-600 hover:bg-blue-700">
                <Upload className="mr-2 h-4 w-4" />
                Import Customers
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gray-800 border-gray-700 text-white max-w-2xl">
              <DialogHeader>
                <DialogTitle className="text-white">Import Customer Data</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="import-text" className="text-gray-200">Customer Data</Label>
                  <Textarea
                    id="import-text"
                    placeholder="Enter customer data - one per line:&#10;&#10;Simple format:&#10;john@email.com&#10;sarah@email.com&#10;&#10;CSV format (ID, Segment, Score, Tiers):&#10;john@email.com, active_shopper, 85, VIP;Premium&#10;sarah@email.com, new_customer, 45, Basic"
                    value={importText}
                    onChange={(e) => setImportText(e.target.value)}
                    rows={10}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowImportDialog(false)} className="border-gray-600 text-gray-200">
                    Cancel
                  </Button>
                  <Button onClick={handleImportCustomers} className="bg-blue-600 hover:bg-blue-700">
                    Import Customers
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Total Customers</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{customers.length}</div>
              <p className="text-xs text-gray-400">In your database</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Customer Segments</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{uniqueSegments.length}</div>
              <p className="text-xs text-gray-400">Different segments</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">Avg Activity Score</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{Math.round(avgActivityScore)}</div>
              <p className="text-xs text-gray-400">Out of 100</p>
            </CardContent>
          </Card>
          
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">High Engagement</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">
                {customers.filter(c => (c.activity_score ?? 0) >= 80).length}
              </div>
              <p className="text-xs text-gray-400">Score 80+</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters and Search */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Filter Customers</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <Label htmlFor="search" className="text-gray-200">Search Customers</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                  <Input
                    id="search"
                    placeholder="Search by email, segment, tier, or notes..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                  />
                </div>
              </div>
              <div className="md:w-48">
                <Label htmlFor="segment-filter" className="text-gray-200">Filter by Segment</Label>
                <select
                  id="segment-filter"
                  value={segmentFilter}
                  onChange={(e) => setSegmentFilter(e.target.value)}
                  className="w-full p-2 rounded border bg-gray-700 border-gray-600 text-white"
                >
                  <option value="">All Segments</option>
                  {uniqueSegments.map(segment => (
                    <option key={segment} value={segment}>{segment}</option>
                  ))}
                </select>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Customer Table */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Customer List</CardTitle>
            <CardDescription className="text-gray-400">
              Showing {filteredCustomers.length} of {customers.length} customers
            </CardDescription>
          </CardHeader>
          <CardContent>
            {filteredCustomers.length === 0 ? (
              <div className="text-center py-8">
                <Users className="mx-auto h-12 w-12 text-gray-600 mb-4" />
                <p className="text-gray-400 mb-4">
                  {customers.length === 0 ? 'No customers in your database yet' : 'No customers match your filters'}
                </p>
                <Button onClick={() => setShowImportDialog(true)} className="bg-blue-600 hover:bg-blue-700">
                  <Upload className="mr-2 h-4 w-4" />
                  Import Your First Customers
                </Button>
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-700">
                    <TableHead className="text-gray-200">Customer ID</TableHead>
                    <TableHead className="text-gray-200">Segment</TableHead>
                    <TableHead className="text-gray-200">Activity Score</TableHead>
                    <TableHead className="text-gray-200">Tiers</TableHead>
                    <TableHead className="text-gray-200">Last Active</TableHead>
                    <TableHead className="text-gray-200">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredCustomers.map((customer) => (
                    <TableRow key={customer.customer_id} className="border-gray-700">
                      <TableCell className="text-white font-medium">
                        {customer.customer_id}
                      </TableCell>
                      <TableCell>
                        {customer.customer_segment ? (
                          <Badge variant="outline" className="border-gray-600 text-gray-300">
                            {customer.customer_segment}
                          </Badge>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {customer.activity_score !== undefined ? (
                          <div className="flex items-center">
                            <div className="w-16 bg-gray-700 rounded-full h-2 mr-2">
                              <div
                                className="bg-blue-600 h-2 rounded-full"
                                style={{ width: `${customer.activity_score}%` }}
                              />
                            </div>
                            <span className="text-white text-sm">{customer.activity_score}</span>
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell>
                        {customer.tiers && customer.tiers.length > 0 ? (
                          <div className="flex flex-wrap gap-1">
                            {customer.tiers.map((tier) => (
                              <Badge key={tier} variant="outline" className="border-gray-600 text-gray-300 text-xs">
                                {tier}
                              </Badge>
                            ))}
                          </div>
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </TableCell>
                      <TableCell className="text-gray-400">
                        {customer.last_active 
                          ? new Date(customer.last_active).toLocaleDateString()
                          : '-'
                        }
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => setEditingCustomer(customer)}
                            className="border-gray-600 text-gray-200"
                          >
                            <Edit className="h-3 w-3" />
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleDeleteCustomer(customer.customer_id)}
                            className="border-red-600 text-red-400 hover:bg-red-600"
                          >
                            <Trash2 className="h-3 w-3" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Edit Customer Dialog */}
        {editingCustomer && (
          <Dialog open={!!editingCustomer} onOpenChange={() => setEditingCustomer(null)}>
            <DialogContent className="bg-gray-800 border-gray-700 text-white">
              <DialogHeader>
                <DialogTitle className="text-white">Edit Customer</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-200">Customer ID</Label>
                  <Input 
                    value={editingCustomer.customer_id} 
                    disabled 
                    className="bg-gray-700 border-gray-600 text-gray-400"
                  />
                </div>
                <div>
                  <Label className="text-gray-200">Customer Segment</Label>
                  <Input 
                    value={editingCustomer.customer_segment || ''} 
                    onChange={(e) => setEditingCustomer({
                      ...editingCustomer,
                      customer_segment: e.target.value || undefined
                    })}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="e.g. active_shopper, new_customer"
                  />
                </div>
                <div>
                  <Label className="text-gray-200">Activity Score (0-100)</Label>
                  <Input 
                    type="number"
                    min="0"
                    max="100"
                    value={editingCustomer.activity_score || ''} 
                    onChange={(e) => setEditingCustomer({
                      ...editingCustomer,
                      activity_score: e.target.value ? parseInt(e.target.value) : undefined
                    })}
                    className="bg-gray-700 border-gray-600 text-white"
                  />
                </div>
                <div>
                  <Label className="text-gray-200">Tiers (comma-separated)</Label>
                  <Input 
                    value={editingCustomer.tiers?.join(', ') || ''} 
                    onChange={(e) => setEditingCustomer({
                      ...editingCustomer,
                      tiers: e.target.value ? e.target.value.split(',').map(t => t.trim()).filter(t => t) : undefined
                    })}
                    className="bg-gray-700 border-gray-600 text-white"
                    placeholder="e.g. VIP, Premium, Basic"
                  />
                </div>
                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setEditingCustomer(null)} className="border-gray-600 text-gray-200">
                    Cancel
                  </Button>
                  <Button onClick={() => handleSaveCustomer(editingCustomer)} className="bg-blue-600 hover:bg-blue-700">
                    Save Changes
                  </Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        )}
      </div>
    </div>
  )
}