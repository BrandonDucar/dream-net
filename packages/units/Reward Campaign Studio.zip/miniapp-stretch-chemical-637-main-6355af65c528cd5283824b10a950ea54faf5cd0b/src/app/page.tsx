'use client'
import { useState, useEffect } from 'react'
import Link from 'next/link'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Plus, Users, TrendingUp, Gift, Calendar } from 'lucide-react'
import { getCampaigns, getCustomerPool, getCampaignPreviews } from '@/lib/storage'
import { getStatusDisplay, getRewardTypeLabel } from '@/lib/campaign-utils'
import type { RewardCampaign } from '@/types'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Dashboard(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [campaigns, setCampaigns] = useState<RewardCampaign[]>([])
  const [loading, setLoading] = useState<boolean>(true)

  useEffect(() => {
    const loadData = (): void => {
      setCampaigns(getCampaigns())
      setLoading(false)
    }
    
    loadData()
  }, [])

  if (loading) {
    return <div className="p-8">Loading your campaign dashboard...</div>
  }

  const customers = getCustomerPool()
  const previews = getCampaignPreviews()
  
  const activeCampaigns = campaigns.filter(c => c.status === 'active')
  const scheduledCampaigns = campaigns.filter(c => c.status === 'scheduled')
  const recentCampaigns = campaigns
    .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime())
    .slice(0, 5)

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white mb-2">
              Reward Campaign Manager
            </h1>
            <p className="text-gray-400">
              Create and manage customer reward campaigns with ease
            </p>
          </div>
          <Button asChild size="lg" className="bg-blue-600 hover:bg-blue-700">
            <Link href="/campaigns/new">
              <Plus className="mr-2 h-5 w-5" />
              Create Campaign
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">
                Total Campaigns
              </CardTitle>
              <Gift className="h-4 w-4 text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{campaigns.length}</div>
              <p className="text-xs text-gray-400">
                All campaigns created
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">
                Active Campaigns
              </CardTitle>
              <TrendingUp className="h-4 w-4 text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{activeCampaigns.length}</div>
              <p className="text-xs text-gray-400">
                Currently running
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">
                Scheduled
              </CardTitle>
              <Calendar className="h-4 w-4 text-orange-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{scheduledCampaigns.length}</div>
              <p className="text-xs text-gray-400">
                Ready to launch
              </p>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium text-gray-200">
                Total Customers
              </CardTitle>
              <Users className="h-4 w-4 text-purple-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-white">{customers.length}</div>
              <p className="text-xs text-gray-400">
                In your database
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Action Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Gift className="mr-2 h-5 w-5 text-blue-400" />
                Create Campaign
              </CardTitle>
              <CardDescription className="text-gray-400">
                Set up a new reward campaign for your customers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full border-gray-600 text-gray-200">
                <Link href="/campaigns/new">
                  Start New Campaign
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <Users className="mr-2 h-5 w-5 text-purple-400" />
                Manage Customers
              </CardTitle>
              <CardDescription className="text-gray-400">
                Add and organize your customer database
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full border-gray-600 text-gray-200">
                <Link href="/customers">
                  View Customers
                </Link>
              </Button>
            </CardContent>
          </Card>

          <Card className="bg-gray-800 border-gray-700 hover:bg-gray-750 transition-colors">
            <CardHeader>
              <CardTitle className="flex items-center text-white">
                <TrendingUp className="mr-2 h-5 w-5 text-green-400" />
                All Campaigns
              </CardTitle>
              <CardDescription className="text-gray-400">
                View and manage all your reward campaigns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Button asChild variant="outline" className="w-full border-gray-600 text-gray-200">
                <Link href="/campaigns">
                  View All Campaigns
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Recent Campaigns */}
        <Card className="bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle className="text-white">Recent Campaigns</CardTitle>
            <CardDescription className="text-gray-400">
              Your most recently updated campaigns
            </CardDescription>
          </CardHeader>
          <CardContent>
            {recentCampaigns.length === 0 ? (
              <div className="text-center py-8">
                <Gift className="mx-auto h-12 w-12 text-gray-600 mb-4" />
                <p className="text-gray-400 mb-4">No campaigns yet</p>
                <Button asChild className="bg-blue-600 hover:bg-blue-700">
                  <Link href="/campaigns/new">
                    Create Your First Campaign
                  </Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {recentCampaigns.map((campaign) => {
                  const statusDisplay = getStatusDisplay(campaign.status)
                  return (
                    <div
                      key={campaign.id}
                      className="flex items-center justify-between p-4 rounded-lg bg-gray-750 border border-gray-600"
                    >
                      <div className="flex-1">
                        <h3 className="font-medium text-white">
                          {campaign.name}
                        </h3>
                        <div className="flex items-center space-x-4 mt-1 text-sm text-gray-400">
                          <span>{getRewardTypeLabel(campaign.reward_type)}</span>
                          {campaign.reward_value && (
                            <span>• {campaign.reward_value}</span>
                          )}
                          <span>• Updated {new Date(campaign.updated_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Badge
                          variant="outline"
                          className={`${
                            statusDisplay.color === 'green' ? 'border-green-600 text-green-400' :
                            statusDisplay.color === 'blue' ? 'border-blue-600 text-blue-400' :
                            statusDisplay.color === 'orange' ? 'border-orange-600 text-orange-400' :
                            statusDisplay.color === 'purple' ? 'border-purple-600 text-purple-400' :
                            'border-gray-600 text-gray-400'
                          }`}
                        >
                          {statusDisplay.label}
                        </Badge>
                        <Button asChild variant="outline" size="sm" className="border-gray-600 text-gray-200">
                          <Link href={`/campaigns/${campaign.id}`}>
                            Edit
                          </Link>
                        </Button>
                      </div>
                    </div>
                  )
                })}
                <div className="text-center pt-4">
                  <Button asChild variant="outline" className="border-gray-600 text-gray-200">
                    <Link href="/campaigns">
                      View All Campaigns
                    </Link>
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}