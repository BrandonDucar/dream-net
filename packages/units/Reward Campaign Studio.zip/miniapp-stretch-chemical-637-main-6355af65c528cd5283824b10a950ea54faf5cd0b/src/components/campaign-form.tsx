'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { X, Plus, Save, Eye } from 'lucide-react'
import { getCampaigns, saveCampaign } from '@/lib/storage'
import { generateUrlName, isUrlNameUnique, validateCampaign } from '@/lib/campaign-utils'
import type { RewardCampaign, CampaignStatus, RewardType } from '@/types'

interface CampaignFormProps {
  campaignId?: string
}

export default function CampaignForm({ campaignId }: CampaignFormProps): JSX.Element {
  const router = useRouter()
  const [loading, setLoading] = useState<boolean>(true)
  const [saving, setSaving] = useState<boolean>(false)
  const [errors, setErrors] = useState<string[]>([])
  const [campaign, setCampaign] = useState<Partial<RewardCampaign>>({
    name: '',
    url_name: '',
    description: '',
    status: 'draft',
    reward_type: 'points',
    reward_value: '',
    total_budget: '',
    start_date: '',
    end_date: '',
    targeting: {
      min_activity_score: undefined,
      max_activity_score: undefined,
      customer_segments: [],
      customer_tiers: [],
      excluded_customers: [],
      included_customers: [],
      max_participants: undefined,
      requirements: ''
    },
    custom_details: {},
    categories: []
  })
  const [newCategory, setNewCategory] = useState<string>('')

  useEffect(() => {
    if (campaignId) {
      // Load existing campaign
      const campaigns = getCampaigns()
      const existing = campaigns.find(c => c.id === campaignId)
      if (existing) {
        setCampaign(existing)
      } else {
        router.push('/campaigns')
        return
      }
    }
    setLoading(false)
  }, [campaignId, router])

  const handleNameChange = (name: string): void => {
    const urlName = generateUrlName(name)
    setCampaign(prev => ({ ...prev, name, url_name: urlName }))
  }

  const handleSave = async (redirect: boolean = false): Promise<void> => {
    setSaving(true)
    setErrors([])

    // Validate campaign
    const validationErrors = validateCampaign(campaign)
    
    // Check URL name uniqueness
    if (campaign.url_name) {
      const campaigns = getCampaigns()
      if (!isUrlNameUnique(campaign.url_name, campaigns, campaign.id)) {
        validationErrors.push('URL name must be unique')
      }
    }

    if (validationErrors.length > 0) {
      setErrors(validationErrors)
      setSaving(false)
      return
    }

    try {
      const now = new Date().toISOString()
      const campaignToSave: RewardCampaign = {
        id: campaign.id || `campaign-${Date.now()}`,
        name: campaign.name!,
        url_name: campaign.url_name!,
        description: campaign.description,
        status: campaign.status!,
        reward_type: campaign.reward_type!,
        reward_value: campaign.reward_value,
        total_budget: campaign.total_budget,
        start_date: campaign.start_date,
        end_date: campaign.end_date,
        created_at: campaign.created_at || now,
        updated_at: now,
        targeting: campaign.targeting!,
        custom_details: campaign.custom_details,
        categories: campaign.categories
      }

      saveCampaign(campaignToSave)
      
      if (redirect) {
        router.push('/campaigns')
      } else {
        setCampaign(campaignToSave)
      }
    } catch (error) {
      console.error('Error saving campaign:', error)
      setErrors(['Failed to save campaign. Please try again.'])
    }

    setSaving(false)
  }

  const addCategory = (): void => {
    if (newCategory.trim() && !campaign.categories?.includes(newCategory.trim())) {
      setCampaign(prev => ({
        ...prev,
        categories: [...(prev.categories || []), newCategory.trim()]
      }))
      setNewCategory('')
    }
  }

  const removeCategory = (categoryToRemove: string): void => {
    setCampaign(prev => ({
      ...prev,
      categories: prev.categories?.filter(cat => cat !== categoryToRemove)
    }))
  }

  if (loading) {
    return <div className="p-8">Loading campaign editor...</div>
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <div className="container mx-auto px-6 py-8 max-w-4xl">
        {/* Header */}
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold text-white">
              {campaignId ? 'Edit Campaign' : 'Create New Campaign'}
            </h1>
            <p className="text-gray-400">
              {campaignId ? 'Update your campaign settings' : 'Set up a reward campaign for your customers'}
            </p>
          </div>
          <div className="flex space-x-2">
            {campaign.id && (
              <Button
                onClick={() => router.push(`/campaigns/${campaign.id}/preview`)}
                variant="outline"
                className="border-gray-600 text-gray-200"
              >
                <Eye className="mr-2 h-4 w-4" />
                Preview
              </Button>
            )}
            <Button onClick={() => handleSave(false)} disabled={saving}>
              <Save className="mr-2 h-4 w-4" />
              {saving ? 'Saving...' : 'Save'}
            </Button>
            <Button onClick={() => handleSave(true)} variant="outline" disabled={saving} className="border-gray-600 text-gray-200">
              Save & Close
            </Button>
          </div>
        </div>

        {/* Error Messages */}
        {errors.length > 0 && (
          <Card className="bg-red-900/20 border-red-700 mb-6">
            <CardContent className="pt-6">
              <h3 className="text-red-400 font-medium mb-2">Please fix the following issues:</h3>
              <ul className="list-disc list-inside text-red-300 space-y-1">
                {errors.map((error, index) => (
                  <li key={index}>{error}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}

        {/* Basic Information */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Basic Information</CardTitle>
            <CardDescription className="text-gray-400">
              Set up the core details of your reward campaign
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-gray-200">Campaign Name *</Label>
              <Input
                id="name"
                value={campaign.name || ''}
                onChange={(e) => handleNameChange(e.target.value)}
                placeholder="e.g. VIP Early Access Program"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label htmlFor="url_name" className="text-gray-200">URL Name *</Label>
              <Input
                id="url_name"
                value={campaign.url_name || ''}
                onChange={(e) => setCampaign(prev => ({ ...prev, url_name: e.target.value }))}
                placeholder="vip-early-access"
                className="bg-gray-700 border-gray-600 text-white"
              />
              <p className="text-sm text-gray-400 mt-1">
                Used in URLs. Must be unique and URL-friendly.
              </p>
            </div>

            <div>
              <Label htmlFor="description" className="text-gray-200">Description</Label>
              <Textarea
                id="description"
                value={campaign.description || ''}
                onChange={(e) => setCampaign(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Describe what this campaign is about and who it's for..."
                rows={3}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="status" className="text-gray-200">Status</Label>
                <Select value={campaign.status} onValueChange={(value: CampaignStatus) => setCampaign(prev => ({ ...prev, status: value }))}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="scheduled">Scheduled</SelectItem>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                    <SelectItem value="paused">Paused</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="reward_type" className="text-gray-200">Reward Type *</Label>
                <Select value={campaign.reward_type} onValueChange={(value: RewardType) => setCampaign(prev => ({ ...prev, reward_type: value }))}>
                  <SelectTrigger className="bg-gray-700 border-gray-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-700 border-gray-600">
                    <SelectItem value="points">Loyalty Points</SelectItem>
                    <SelectItem value="discount">Discount Code</SelectItem>
                    <SelectItem value="access">Special Access</SelectItem>
                    <SelectItem value="gift">Gift Reward</SelectItem>
                    <SelectItem value="entry">Contest Entry</SelectItem>
                    <SelectItem value="other">Custom Reward</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="reward_value" className="text-gray-200">Reward Value</Label>
                <Input
                  id="reward_value"
                  value={campaign.reward_value || ''}
                  onChange={(e) => setCampaign(prev => ({ ...prev, reward_value: e.target.value }))}
                  placeholder="e.g. 500 points, $10 discount, Early access"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="total_budget" className="text-gray-200">Total Budget</Label>
                <Input
                  id="total_budget"
                  value={campaign.total_budget || ''}
                  onChange={(e) => setCampaign(prev => ({ ...prev, total_budget: e.target.value }))}
                  placeholder="e.g. $5,000, 10,000 points value"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="start_date" className="text-gray-200">Start Date</Label>
                <Input
                  id="start_date"
                  type="datetime-local"
                  value={campaign.start_date ? new Date(campaign.start_date).toISOString().slice(0, 16) : ''}
                  onChange={(e) => setCampaign(prev => ({ ...prev, start_date: e.target.value ? new Date(e.target.value).toISOString() : '' }))}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="end_date" className="text-gray-200">End Date</Label>
                <Input
                  id="end_date"
                  type="datetime-local"
                  value={campaign.end_date ? new Date(campaign.end_date).toISOString().slice(0, 16) : ''}
                  onChange={(e) => setCampaign(prev => ({ ...prev, end_date: e.target.value ? new Date(e.target.value).toISOString() : '' }))}
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Targeting Rules */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Customer Targeting</CardTitle>
            <CardDescription className="text-gray-400">
              Define which customers are eligible for this campaign
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="min_activity_score" className="text-gray-200">Minimum Activity Score</Label>
                <Input
                  id="min_activity_score"
                  type="number"
                  min="0"
                  max="100"
                  value={campaign.targeting?.min_activity_score || ''}
                  onChange={(e) => setCampaign(prev => ({
                    ...prev,
                    targeting: {
                      ...prev.targeting!,
                      min_activity_score: e.target.value ? parseInt(e.target.value) : undefined
                    }
                  }))}
                  placeholder="0-100"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>

              <div>
                <Label htmlFor="max_activity_score" className="text-gray-200">Maximum Activity Score</Label>
                <Input
                  id="max_activity_score"
                  type="number"
                  min="0"
                  max="100"
                  value={campaign.targeting?.max_activity_score || ''}
                  onChange={(e) => setCampaign(prev => ({
                    ...prev,
                    targeting: {
                      ...prev.targeting!,
                      max_activity_score: e.target.value ? parseInt(e.target.value) : undefined
                    }
                  }))}
                  placeholder="0-100"
                  className="bg-gray-700 border-gray-600 text-white"
                />
              </div>
            </div>

            <div>
              <Label htmlFor="customer_segments" className="text-gray-200">Customer Segments</Label>
              <Input
                id="customer_segments"
                value={campaign.targeting?.customer_segments?.join(', ') || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    customer_segments: e.target.value ? e.target.value.split(',').map(s => s.trim()).filter(s => s) : []
                  }
                }))}
                placeholder="e.g. active_shopper, new_customer, loyal_customer"
                className="bg-gray-700 border-gray-600 text-white"
              />
              <p className="text-sm text-gray-400 mt-1">
                Separate multiple segments with commas
              </p>
            </div>

            <div>
              <Label htmlFor="customer_tiers" className="text-gray-200">Customer Tiers</Label>
              <Input
                id="customer_tiers"
                value={campaign.targeting?.customer_tiers?.join(', ') || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    customer_tiers: e.target.value ? e.target.value.split(',').map(s => s.trim()).filter(s => s) : []
                  }
                }))}
                placeholder="e.g. VIP, Premium, Basic"
                className="bg-gray-700 border-gray-600 text-white"
              />
              <p className="text-sm text-gray-400 mt-1">
                Separate multiple tiers with commas
              </p>
            </div>

            <div>
              <Label htmlFor="max_participants" className="text-gray-200">Maximum Participants</Label>
              <Input
                id="max_participants"
                type="number"
                min="1"
                value={campaign.targeting?.max_participants || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    max_participants: e.target.value ? parseInt(e.target.value) : undefined
                  }
                }))}
                placeholder="e.g. 100"
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label htmlFor="included_customers" className="text-gray-200">Always Include Customers</Label>
              <Textarea
                id="included_customers"
                value={campaign.targeting?.included_customers?.join('\n') || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    included_customers: e.target.value ? e.target.value.split('\n').map(s => s.trim()).filter(s => s) : []
                  }
                }))}
                placeholder="Enter customer IDs, one per line"
                rows={3}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label htmlFor="excluded_customers" className="text-gray-200">Exclude Customers</Label>
              <Textarea
                id="excluded_customers"
                value={campaign.targeting?.excluded_customers?.join('\n') || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    excluded_customers: e.target.value ? e.target.value.split('\n').map(s => s.trim()).filter(s => s) : []
                  }
                }))}
                placeholder="Enter customer IDs to exclude, one per line"
                rows={3}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>

            <div>
              <Label htmlFor="requirements" className="text-gray-200">Additional Requirements</Label>
              <Textarea
                id="requirements"
                value={campaign.targeting?.requirements || ''}
                onChange={(e) => setCampaign(prev => ({
                  ...prev,
                  targeting: {
                    ...prev.targeting!,
                    requirements: e.target.value
                  }
                }))}
                placeholder="Any additional targeting notes or requirements..."
                rows={2}
                className="bg-gray-700 border-gray-600 text-white"
              />
            </div>
          </CardContent>
        </Card>

        {/* Categories */}
        <Card className="bg-gray-800 border-gray-700 mb-6">
          <CardHeader>
            <CardTitle className="text-white">Categories</CardTitle>
            <CardDescription className="text-gray-400">
              Add categories to help organize your campaigns
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                placeholder="Add a category..."
                onKeyPress={(e) => e.key === 'Enter' && addCategory()}
                className="bg-gray-700 border-gray-600 text-white"
              />
              <Button onClick={addCategory} variant="outline" className="border-gray-600 text-gray-200">
                <Plus className="h-4 w-4" />
              </Button>
            </div>

            {campaign.categories && campaign.categories.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {campaign.categories.map((category) => (
                  <Badge key={category} variant="outline" className="border-gray-600 text-gray-300">
                    {category}
                    <X
                      className="ml-1 h-3 w-3 cursor-pointer"
                      onClick={() => removeCategory(category)}
                    />
                  </Badge>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}