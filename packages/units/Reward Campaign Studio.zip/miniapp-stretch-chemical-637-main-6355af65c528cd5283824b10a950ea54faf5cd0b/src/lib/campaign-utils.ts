// Campaign utilities for Reward Campaign Manager

import type { RewardCampaign, CustomerRecord, CampaignTargeting, CampaignPreview } from '@/types'

// Generate a URL-friendly name from a campaign name
export function generateUrlName(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '') // Remove special characters except spaces and hyphens
    .replace(/\s+/g, '-')         // Replace spaces with hyphens
    .replace(/-+/g, '-')          // Replace multiple hyphens with single hyphen
    .replace(/^-|-$/g, '')        // Remove leading/trailing hyphens
}

// Validate if URL name is unique
export function isUrlNameUnique(urlName: string, campaigns: RewardCampaign[], excludeId?: string): boolean {
  return !campaigns.some(campaign => 
    campaign.url_name === urlName && campaign.id !== excludeId
  )
}

// Get reward type display label
export function getRewardTypeLabel(rewardType: string): string {
  const labels: Record<string, string> = {
    points: 'Loyalty Points',
    discount: 'Discount Code',
    access: 'Special Access',
    gift: 'Gift Reward',
    entry: 'Contest Entry',
    other: 'Custom Reward'
  }
  return labels[rewardType as keyof typeof labels] || rewardType
}

// Get status display label and color
export function getStatusDisplay(status: string): { label: string; color: string } {
  const displays: Record<string, { label: string; color: string }> = {
    draft: { label: 'Draft', color: 'gray' },
    scheduled: { label: 'Scheduled', color: 'blue' },
    active: { label: 'Active', color: 'green' },
    completed: { label: 'Completed', color: 'purple' },
    paused: { label: 'Paused', color: 'orange' }
  }
  return displays[status as keyof typeof displays] || { label: status, color: 'gray' }
}

// Generate campaign preview based on targeting rules
export function generateCampaignPreview(
  campaign: RewardCampaign,
  customerPool: CustomerRecord[]
): CampaignPreview {
  const targeting = campaign.targeting
  let eligible: CustomerRecord[] = []
  let excluded = 0

  // Start with all customers
  let candidates = [...customerPool]

  // Apply activity score filters
  if (targeting.min_activity_score !== undefined) {
    candidates = candidates.filter(customer => 
      (customer.activity_score ?? 0) >= targeting.min_activity_score!
    )
    excluded += customerPool.length - candidates.length
  }

  if (targeting.max_activity_score !== undefined) {
    const beforeFilter = candidates.length
    candidates = candidates.filter(customer => 
      (customer.activity_score ?? 100) <= targeting.max_activity_score!
    )
    excluded += beforeFilter - candidates.length
  }

  // Apply customer segment filters
  if (targeting.customer_segments && targeting.customer_segments.length > 0) {
    const beforeFilter = candidates.length
    candidates = candidates.filter(customer => 
      customer.customer_segment && targeting.customer_segments!.includes(customer.customer_segment)
    )
    excluded += beforeFilter - candidates.length
  }

  // Apply tier filters
  if (targeting.customer_tiers && targeting.customer_tiers.length > 0) {
    const beforeFilter = candidates.length
    candidates = candidates.filter(customer =>
      customer.tiers && customer.tiers.some(tier => targeting.customer_tiers!.includes(tier))
    )
    excluded += beforeFilter - candidates.length
  }

  // Remove specifically excluded customers
  if (targeting.excluded_customers && targeting.excluded_customers.length > 0) {
    const beforeFilter = candidates.length
    candidates = candidates.filter(customer =>
      !targeting.excluded_customers!.includes(customer.customer_id)
    )
    excluded += beforeFilter - candidates.length
  }

  // Add specifically included customers (even if they don't meet other criteria)
  if (targeting.included_customers && targeting.included_customers.length > 0) {
    const forcedIncludes = customerPool.filter(customer =>
      targeting.included_customers!.includes(customer.customer_id) &&
      !candidates.some(c => c.customer_id === customer.customer_id)
    )
    candidates = [...candidates, ...forcedIncludes]
  }

  // Apply participant limit
  if (targeting.max_participants && candidates.length > targeting.max_participants) {
    // Sort by activity score (highest first) before limiting
    candidates.sort((a, b) => (b.activity_score ?? 0) - (a.activity_score ?? 0))
    excluded += candidates.length - targeting.max_participants
    candidates = candidates.slice(0, targeting.max_participants)
  }

  eligible = candidates

  // Generate export data
  const exportData = {
    campaign_name: campaign.name,
    campaign_url: campaign.url_name,
    reward_type: campaign.reward_type,
    reward_value: campaign.reward_value,
    total_budget: campaign.total_budget,
    participants: eligible.map(customer => ({
      customer_id: customer.customer_id,
      customer_segment: customer.customer_segment,
      tiers: customer.tiers,
      activity_score: customer.activity_score
    })),
    summary: {
      total_eligible: eligible.length,
      total_excluded: excluded,
      targeting_rules: targeting
    }
  }

  return {
    id: `preview-${campaign.id}-${Date.now()}`,
    campaign_id: campaign.id,
    created_at: new Date().toISOString(),
    eligible_customers: eligible,
    eligible_count: eligible.length,
    excluded_count: excluded,
    export_data: exportData,
    summary: `${eligible.length} customers qualify for this campaign`
  }
}

// Parse customer data from text input
export function parseCustomerInput(input: string): CustomerRecord[] {
  const lines = input.trim().split('\n').filter(line => line.trim())
  const customers: CustomerRecord[] = []

  for (const line of lines) {
    const trimmed = line.trim()
    if (!trimmed) continue

    // Check if it's CSV format (has commas)
    if (trimmed.includes(',')) {
      const parts = trimmed.split(',').map(p => p.trim())
      const [customerId, segment, score, tiers] = parts
      
      if (customerId) {
        customers.push({
          customer_id: customerId,
          customer_segment: segment || undefined,
          activity_score: score ? parseInt(score) : undefined,
          tiers: tiers ? tiers.split(';').map(t => t.trim()) : undefined,
          last_active: new Date().toISOString()
        })
      }
    } else {
      // Simple format - just customer ID
      customers.push({
        customer_id: trimmed,
        last_active: new Date().toISOString()
      })
    }
  }

  return customers
}

// Format customer data for display
export function formatCustomerForDisplay(customer: CustomerRecord): string {
  let display = customer.customer_id
  
  if (customer.customer_segment) {
    display += ` (${customer.customer_segment})`
  }
  
  if (customer.activity_score !== undefined) {
    display += ` - Score: ${customer.activity_score}`
  }
  
  if (customer.tiers && customer.tiers.length > 0) {
    display += ` - Tiers: ${customer.tiers.join(', ')}`
  }
  
  return display
}

// Validate campaign data
export function validateCampaign(campaign: Partial<RewardCampaign>): string[] {
  const errors: string[] = []

  if (!campaign.name?.trim()) {
    errors.push('Campaign name is required')
  }

  if (!campaign.url_name?.trim()) {
    errors.push('URL name is required')
  }

  if (!campaign.reward_type) {
    errors.push('Reward type is required')
  }

  if (campaign.reward_type === 'points' && !campaign.reward_value?.trim()) {
    errors.push('Reward value is required for points campaigns')
  }

  if (campaign.reward_type === 'discount' && !campaign.reward_value?.trim()) {
    errors.push('Discount value is required for discount campaigns')
  }

  return errors
}