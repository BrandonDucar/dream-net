// Simple storage for Reward Campaign Manager
// Saves your campaigns and customer data locally in your browser

import type { RewardCampaign, CustomerRecord, CampaignPreview } from '@/types'

const CAMPAIGNS_KEY = 'reward_campaigns'
const CUSTOMERS_KEY = 'customer_records'
const PREVIEWS_KEY = 'campaign_previews'

// Campaign Management
export const getCampaigns = (): RewardCampaign[] => {
  try {
    const stored = localStorage.getItem(CAMPAIGNS_KEY)
    return stored ? JSON.parse(stored) : getDefaultCampaigns()
  } catch {
    return getDefaultCampaigns()
  }
}

export const saveCampaigns = (campaigns: RewardCampaign[]): void => {
  try {
    localStorage.setItem(CAMPAIGNS_KEY, JSON.stringify(campaigns))
  } catch (e) {
    console.warn('Failed to save campaigns to localStorage:', e)
  }
}

export const getCampaignById = (id: string): RewardCampaign | undefined => {
  return getCampaigns().find(campaign => campaign.id === id)
}

export const getCampaignByUrlName = (urlName: string): RewardCampaign | undefined => {
  return getCampaigns().find(campaign => campaign.url_name === urlName)
}

export const getCampaignBySlug = (slug: string): RewardCampaign | undefined => {
  return getCampaignByUrlName(slug)
}

export const getLatestPreviewByCampaignId = (campaignId: string): CampaignPreview | undefined => {
  const previews = getCampaignPreviews().filter(p => p.campaign_id === campaignId)
  return previews.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0]
}

export const saveCampaign = (campaign: RewardCampaign): void => {
  const campaigns = getCampaigns()
  const existing = campaigns.findIndex(c => c.id === campaign.id)
  if (existing >= 0) {
    campaigns[existing] = campaign
  } else {
    campaigns.push(campaign)
  }
  saveCampaigns(campaigns)
}

export const deleteCampaign = (id: string): void => {
  const campaigns = getCampaigns().filter(c => c.id !== id)
  saveCampaigns(campaigns)
}

// Customer Database Management
export const getCustomerPool = (): CustomerRecord[] => {
  try {
    const stored = localStorage.getItem(CUSTOMERS_KEY)
    return stored ? JSON.parse(stored) : getDefaultCustomers()
  } catch {
    return getDefaultCustomers()
  }
}

export const saveCustomerPool = (customers: CustomerRecord[]): void => {
  try {
    localStorage.setItem(CUSTOMERS_KEY, JSON.stringify(customers))
  } catch (e) {
    console.warn('Failed to save customers to localStorage:', e)
  }
}

export const getCustomerById = (id: string): CustomerRecord | undefined => {
  return getCustomerPool().find(customer => customer.customer_id === id)
}

export const saveCustomer = (customer: CustomerRecord): void => {
  const customers = getCustomerPool()
  const existing = customers.findIndex(c => c.customer_id === customer.customer_id)
  if (existing >= 0) {
    customers[existing] = customer
  } else {
    customers.push(customer)
  }
  saveCustomerPool(customers)
}

export const deleteCustomer = (id: string): void => {
  const customers = getCustomerPool().filter(c => c.customer_id !== id)
  saveCustomerPool(customers)
}

// Campaign Preview Management
export const getCampaignPreviews = (): CampaignPreview[] => {
  try {
    const stored = localStorage.getItem(PREVIEWS_KEY)
    return stored ? JSON.parse(stored) : []
  } catch {
    return []
  }
}

export const saveCampaignPreview = (preview: CampaignPreview): void => {
  try {
    const previews = getCampaignPreviews()
    const existing = previews.findIndex(p => p.campaign_id === preview.campaign_id)
    if (existing >= 0) {
      previews[existing] = preview
    } else {
      previews.push(preview)
    }
    localStorage.setItem(PREVIEWS_KEY, JSON.stringify(previews))
  } catch (e) {
    console.warn('Failed to save campaign preview to localStorage:', e)
  }
}

// Default/Seed Data - Sample campaigns and customers
const getDefaultCampaigns = (): RewardCampaign[] => [
  {
    id: '1',
    name: 'VIP Early Access Program',
    url_name: 'vip-early-access',
    description: 'Reward our most loyal customers with exclusive early access to new products.',
    status: 'draft',
    reward_type: 'access',
    reward_value: 'Early access + 20% discount',
    total_budget: '$5,000',
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    targeting: {
      min_activity_score: 70,
      customer_tiers: ['VIP', 'Premium'],
      max_participants: 100,
      requirements: 'Target highly engaged VIP customers'
    },
    categories: ['early-access', 'vip']
  },
  {
    id: '2',
    name: 'Customer Appreciation Points',
    url_name: 'appreciation-points',
    description: 'Give bonus points to our most active customers as a thank you.',
    status: 'scheduled',
    reward_type: 'points',
    reward_value: '500 points',
    total_budget: '$2,000 value',
    start_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
    targeting: {
      min_activity_score: 80,
      max_participants: 200
    },
    categories: ['points', 'appreciation']
  }
]

const getDefaultCustomers = (): CustomerRecord[] => [
  {
    customer_id: 'john.doe@email.com',
    customer_segment: 'active_shopper',
    tiers: ['VIP', 'Early Adopter'],
    activity_score: 85,
    last_active: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    notes: ['high_engagement', 'verified_email']
  },
  {
    customer_id: 'sarah.smith@email.com',
    customer_segment: 'new_customer',
    tiers: ['Premium'],
    activity_score: 45,
    last_active: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
    notes: ['recent_signup']
  },
  {
    customer_id: 'mike.wilson@email.com',
    customer_segment: 'loyal_customer',
    tiers: ['VIP', 'Premium'],
    activity_score: 92,
    last_active: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000).toISOString(),
    notes: ['top_spender', 'brand_advocate']
  },
  {
    customer_id: 'lisa.brown@email.com',
    customer_segment: 'occasional_buyer',
    tiers: ['Basic'],
    activity_score: 65,
    last_active: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
    notes: ['holiday_shopper']
  }
]