export type RewardType = 
  | 'token_airdrop'
  | 'role_grant'
  | 'allowlist_slot'
  | 'badge'
  | 'loot_box'
  | 'custom';

export type CampaignStatus = 
  | 'draft'
  | 'scheduled'
  | 'running'
  | 'completed'
  | 'archived';

export interface CampaignTargeting {
  min_score?: number;
  max_score?: number;
  allowed_stages?: string[];
  allowed_pack_ids?: string[];
  exclude_wallets?: string[];
  include_wallets?: string[];
  max_wallets?: number;
  notes?: string;
}

export interface RewardCampaign {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: CampaignStatus;
  reward_type: RewardType;
  chain?: string;
  token_symbol?: string;
  token_amount_per_wallet?: string;
  total_budget_estimate?: string;
  start_time?: string;
  end_time?: string;
  created_at: string;
  updated_at: string;
  targeting: CampaignTargeting;
  payload_template?: Record<string, unknown>;
  tags?: string[];
}

export interface WalletRecord {
  wallet_address: string;
  stage_slug?: string;
  packs?: string[];
  last_score?: number;
  last_seen?: string;
  tags?: string[];
}

export interface CampaignRunPreview {
  id: string;
  campaign_id: string;
  created_at: string;
  eligible_wallets: WalletRecord[];
  eligible_count: number;
  excluded_count: number;
  payload_preview: Record<string, unknown>;
  notes?: string;
}

export interface CampaignPayload {
  campaign_slug: string;
  reward_type: RewardType;
  chain?: string;
  token_symbol?: string;
  token_amount_per_wallet?: string;
  wallets: string[];
  metadata: Record<string, unknown>;
}
