// Reward Campaign Manager Types - User-friendly campaign management

export type RewardType =
  | "points"            // Award points to customers
  | "discount"          // Give discount codes or coupons
  | "access"            // Grant special access or VIP status
  | "gift"              // Physical or digital gifts
  | "entry"             // Contest or giveaway entries
  | "other"             // Custom reward type

export type CampaignStatus =
  | "draft"             // Still being created
  | "scheduled"         // Ready to launch on a specific date
  | "active"            // Currently running
  | "completed"         // Finished successfully
  | "paused"            // Temporarily stopped

export interface RewardCampaign {
  id: string
  name: string
  url_name: string            // unique, URL-friendly name
  description?: string
  status: CampaignStatus
  reward_type: RewardType
  reward_value?: string       // value of reward (e.g. "10 points", "$5 discount")
  total_budget?: string       // total budget for campaign
  start_date?: string         // when campaign starts
  end_date?: string           // when campaign ends
  created_at: string
  updated_at: string
  targeting: CampaignTargeting
  custom_details?: any        // additional reward details
  categories?: string[]       // campaign categories/tags
}

export interface CampaignTargeting {
  min_activity_score?: number     // minimum customer activity level (0-100)
  max_activity_score?: number     // maximum customer activity level (0-100)
  customer_segments?: string[]    // which customer groups to include
  customer_tiers?: string[]       // VIP, Premium, Basic, etc.
  excluded_customers?: string[]   // specific customers to exclude
  included_customers?: string[]   // specific customers to always include
  max_participants?: number       // maximum number of participants
  requirements?: string           // additional requirements or notes
}

export interface CustomerRecord {
  customer_id: string         // email, phone, or unique ID
  customer_segment?: string   // their journey stage
  tiers?: string[]           // membership tiers (VIP, Premium, etc.)
  activity_score?: number    // engagement level 0-100
  last_active?: string       // when they were last active
  notes?: string[]           // additional notes or tags
}

export interface CampaignPreview {
  id: string
  campaign_id: string
  created_at: string
  eligible_customers: CustomerRecord[]
  eligible_count: number
  excluded_count: number
  export_data: any           // data ready for export or integration
  summary?: string
}