'use client'
import { useState, useEffect } from 'react';
import { usePrivy } from '@privy-io/react-auth';
import { WalletInfo } from '@/components/wallet-info';
import { RewindPaymentForm } from '@/components/rewind-payment-form';
import { PaymentHistory } from '@/components/payment-history';
import type { RewindPayment } from '@/types/rewind';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { ready, authenticated } = usePrivy();
  const [payments, setPayments] = useState<RewindPayment[]>([]);

  useEffect(() => {
    const stored = localStorage.getItem('rewindPayments');
    if (stored) {
      try {
        setPayments(JSON.parse(stored));
      } catch (err) {
        console.error('Failed to parse stored payments:', err);
      }
    }
  }, []);

  const handlePaymentSent = (payment: RewindPayment): void => {
    const updatedPayments = [payment, ...payments];
    setPayments(updatedPayments);
    localStorage.setItem('rewindPayments', JSON.stringify(updatedPayments));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-8 md:py-16 space-y-12">
        {/* Hero Section */}
        <div className="text-center space-y-4 max-w-3xl mx-auto pt-8 md:pt-0">
          <h1 className="text-4xl md:text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            RewindPay
          </h1>
          <p className="text-xl md:text-2xl text-gray-700">
            Reward Backwards
          </p>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Pay people for things they already did. Someone posted a great thread? Released open-source code? 
            Helped you in a DM? If it moved you today, you can pay them today — even if it was last month.
          </p>
        </div>

        {/* Examples Section */}
        <div className="max-w-3xl mx-auto">
          <div className="bg-white rounded-lg border p-6 space-y-3">
            <h2 className="font-semibold text-gray-900">What can you reward?</h2>
            <ul className="space-y-2 text-gray-600">
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">→</span>
                <span>Someone posts a great thread</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">→</span>
                <span>Someone releases open-source code</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">→</span>
                <span>Someone helps you in a DM</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">→</span>
                <span>Someone drops a good meme</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-blue-600 mt-1">→</span>
                <span>Someone mentors you for free</span>
              </li>
            </ul>
            <p className="text-sm text-gray-500 italic pt-2">
              Most tokens = pay forward. RewindPay = reward backwards.
            </p>
          </div>
        </div>

        {/* Wallet Connection */}
        <div className="flex justify-center">
          <WalletInfo />
        </div>

        {/* Payment Form - Only show when authenticated */}
        {ready && authenticated && (
          <div className="flex justify-center">
            <RewindPaymentForm onPaymentSent={handlePaymentSent} />
          </div>
        )}

        {/* Payment History - Only show when authenticated */}
        {ready && authenticated && (
          <div className="flex justify-center">
            <PaymentHistory payments={payments} />
          </div>
        )}

        {/* Footer */}
        <div className="text-center text-sm text-gray-500 pt-8">
          <p>Built on Base • Creating a culture of retroactive gratitude</p>
        </div>
      </div>
    </div>
  );
}
