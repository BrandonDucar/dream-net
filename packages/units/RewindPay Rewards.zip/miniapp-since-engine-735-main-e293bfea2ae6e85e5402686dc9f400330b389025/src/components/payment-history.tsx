'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { RewindPayment } from '@/types/rewind';

interface PaymentHistoryProps {
  payments: RewindPayment[];
}

export function PaymentHistory({ payments }: PaymentHistoryProps) {
  if (payments.length === 0) {
    return (
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Payment History</CardTitle>
          <CardDescription>Your rewind payments will appear here</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 text-center py-8">
            No payments yet. Send your first rewind payment to get started!
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>Payment History</CardTitle>
        <CardDescription>All your retroactive rewards</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {payments.map((payment) => (
          <div
            key={payment.id}
            className="border rounded-lg p-4 space-y-2 hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-start justify-between">
              <div className="space-y-1 flex-1">
                <p className="text-sm font-medium">{payment.note}</p>
                <p className="text-xs text-gray-500">
                  To: {payment.recipientAddress.slice(0, 6)}...{payment.recipientAddress.slice(-4)}
                </p>
                <p className="text-xs text-gray-500">
                  {new Date(payment.timestamp).toLocaleDateString()} at {new Date(payment.timestamp).toLocaleTimeString()}
                </p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <Badge variant="outline" className="font-mono">
                  {payment.amount} ETH
                </Badge>
                <Badge 
                  variant={payment.status === 'confirmed' ? 'default' : payment.status === 'pending' ? 'secondary' : 'destructive'}
                >
                  {payment.status}
                </Badge>
              </div>
            </div>
            {payment.txHash && (
              <a
                href={`https://basescan.org/tx/${payment.txHash}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-blue-600 hover:underline"
              >
                View on BaseScan →
              </a>
            )}
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
