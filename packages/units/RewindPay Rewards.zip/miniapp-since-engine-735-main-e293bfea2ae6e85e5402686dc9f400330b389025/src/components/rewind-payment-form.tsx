'use client'

import { useState } from 'react';
import { usePrivy, useWallets } from '@privy-io/react-auth';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { parseEther } from 'viem';
import type { RewindPayment } from '@/types/rewind';

interface RewindPaymentFormProps {
  onPaymentSent: (payment: RewindPayment) => void;
}

export function RewindPaymentForm({ onPaymentSent }: RewindPaymentFormProps) {
  const { ready, authenticated } = usePrivy();
  const { wallets } = useWallets();
  const [recipientAddress, setRecipientAddress] = useState<string>('');
  const [amount, setAmount] = useState<string>('');
  const [note, setNote] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>('');

  const handleSendPayment = async (): Promise<void> => {
    if (!authenticated || !wallets.length) {
      setError('Please connect your wallet first');
      return;
    }

    if (!recipientAddress || !amount || !note) {
      setError('Please fill in all fields');
      return;
    }

    setIsLoading(true);
    setError('');

    try {
      const wallet = wallets[0];
      
      if (wallet.walletClientType === 'privy') {
        setError('Please use an external wallet or switch to a connected wallet');
        setIsLoading(false);
        return;
      }

      const provider = await wallet.getEthereumProvider();

      const transactionRequest = {
        to: recipientAddress,
        value: `0x${parseEther(amount).toString(16)}`,
        from: wallet.address,
      };

      const txHash = await provider.request({
        method: 'eth_sendTransaction',
        params: [transactionRequest],
      }) as string;

      const payment: RewindPayment = {
        id: Date.now().toString(),
        recipientAddress,
        amount,
        note,
        timestamp: Date.now(),
        txHash,
        status: 'confirmed',
      };

      onPaymentSent(payment);
      
      setRecipientAddress('');
      setAmount('');
      setNote('');
    } catch (err) {
      console.error('Payment error:', err);
      setError(err instanceof Error ? err.message : 'Failed to send payment');
    } finally {
      setIsLoading(false);
    }
  };

  if (!ready || !authenticated) {
    return null;
  }

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle>Send a Rewind Payment</CardTitle>
        <CardDescription>
          Reward someone for something they already did
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="recipient">Recipient Wallet Address</Label>
          <Input
            id="recipient"
            type="text"
            placeholder="0x..."
            value={recipientAddress}
            onChange={(e) => setRecipientAddress(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="amount">Amount (ETH)</Label>
          <Input
            id="amount"
            type="number"
            step="0.001"
            placeholder="0.01"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="note">What are you rewarding?</Label>
          <Textarea
            id="note"
            placeholder="That brilliant thread you posted last week..."
            value={note}
            onChange={(e) => setNote(e.target.value)}
            rows={4}
          />
        </div>

        {error && (
          <div className="text-sm text-red-600 bg-red-50 p-3 rounded-md">
            {error}
          </div>
        )}

        <Button 
          onClick={handleSendPayment} 
          disabled={isLoading || !recipientAddress || !amount || !note}
          className="w-full"
        >
          {isLoading ? 'Sending...' : 'Send Rewind Payment'}
        </Button>
      </CardContent>
    </Card>
  );
}
