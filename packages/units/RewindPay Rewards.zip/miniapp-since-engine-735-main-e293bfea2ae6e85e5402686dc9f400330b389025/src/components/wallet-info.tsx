'use client'

import { usePrivy, useWallets } from '@privy-io/react-auth';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function WalletInfo() {
  const { ready, authenticated, login, logout } = usePrivy();
  const { wallets } = useWallets();

  if (!ready) {
    return (
      <div className="flex justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <p className="text-center text-gray-500">Loading...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="flex justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6 space-y-4">
            <p className="text-center text-gray-700">
              Connect your wallet to start rewarding backwards
            </p>
            <Button onClick={login} className="w-full">
              Connect Wallet
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const connectedWallet = wallets[0];

  return (
    <Card className="w-full max-w-md">
      <CardContent className="pt-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="space-y-1">
            <p className="text-sm text-gray-500">Connected Wallet</p>
            <p className="font-mono text-sm">
              {connectedWallet?.address.slice(0, 6)}...{connectedWallet?.address.slice(-4)}
            </p>
          </div>
          <Badge variant="secondary">Base</Badge>
        </div>
        <Button onClick={logout} variant="outline" className="w-full">
          Disconnect
        </Button>
      </CardContent>
    </Card>
  );
}
