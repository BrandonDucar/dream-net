export interface RewindPayment {
  id: string;
  recipientAddress: string;
  amount: string;
  note: string;
  timestamp: number;
  txHash?: string;
  status: 'pending' | 'confirmed' | 'failed';
}
