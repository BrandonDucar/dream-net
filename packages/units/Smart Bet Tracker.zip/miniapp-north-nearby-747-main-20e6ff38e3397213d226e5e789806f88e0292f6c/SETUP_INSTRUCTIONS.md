# 🏈 Sports Betting Analytics Platform - Setup Guide

## Quick Start (5 Minutes)

Your app is already configured for server-side API management! You just need to add your The Odds API key once, and all your end users will automatically have access to live sports data.

### Step 1: Get Your Free API Key

1. Visit: **https://the-odds-api.com**
2. Click "Sign Up" (100% free, no credit card required)
3. Verify your email and log in
4. Go to your dashboard
5. Copy your API key from the account settings

**Free Tier Includes:**
- 500 requests/month
- NFL, NBA, NHL, MLB, and 70+ other sports
- Access to 40+ bookmakers
- Real-time odds updates

### Step 2: Add Your Key to the Server Config

1. Open `src/lib/server-config.ts` in your code editor
2. Find line 29 that says:
   ```typescript
   ODDS_API_KEY: 'YOUR_ODDS_API_KEY_HERE',
   ```
3. Replace `'YOUR_ODDS_API_KEY_HERE'` with your actual API key:
   ```typescript
   ODDS_API_KEY: 'abc123def456ghi789jkl012mno345pq',
   ```
4. Save the file

### Step 3: Build and Deploy

Run the build verification tool, and your app is ready! All end users will automatically have access to:

✅ Real-time odds from 40+ sportsbooks
✅ Live line movements and analytics
✅ AI-powered insights (OpenAI & Perplexity)
✅ Closing line value (CLV) tracking
✅ Kelly criterion staking recommendations
✅ Zero configuration required for end users

---

## What's Already Configured

### ✅ Server-Side API Management
- The Odds API key is stored server-side only (never exposed to clients)
- OpenAI and Perplexity AI are pre-configured via Ohara connections
- All API calls go through secure server routes

### ✅ Real-Time Sports Data
- Live odds for NFL, NBA, NHL, MLB
- Multiple bookmakers comparison
- Spread, moneyline, and totals markets
- Automatic 30-second refresh

### ✅ AI-Powered Insights
- General game analytics (available immediately)
- Personalized betting patterns (after 5 logged bets)
- Tilt risk predictions
- Line movement analysis

### ✅ Zero End User Configuration
- No API keys needed by end users
- No setup screens or onboarding friction
- Instant access to all features

---

## Architecture Overview

```
End User Browser
    ↓
Your Next.js App (Client)
    ↓
Server API Routes (/api/matchups/today, /api/ai/insights)
    ↓
Server Config (src/lib/server-config.ts) ← YOU ADD KEY HERE ONCE
    ↓
External APIs (The Odds API, OpenAI, Perplexity)
```

**Key Point**: The API key lives in the server config file. End users never see it, never configure it, and never need to know about it. You add it once, and everyone benefits!

---

## Need More Requests?

If 500 requests/month isn't enough:
- **$50/month**: 10,000 requests
- **$100/month**: 25,000 requests  
- **$250/month**: 100,000 requests

Visit https://the-odds-api.com/pricing for details.

---

## Support

Questions? Check the implementation in:
- `src/lib/server-config.ts` - Server-side configuration
- `src/app/api/matchups/today/route.ts` - Main sports data API
- `src/openai-api.ts` - OpenAI integration
- `src/perplexity-api.ts` - Perplexity AI integration
