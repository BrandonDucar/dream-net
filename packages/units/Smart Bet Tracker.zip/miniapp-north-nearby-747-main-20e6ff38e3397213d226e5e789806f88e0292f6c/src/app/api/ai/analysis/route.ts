import { NextRequest, NextResponse } from 'next/server';
import { openaiChatCompletion } from '@/openai-api';
import type { EnhancedBet } from '@/types/odds';

/**
 * AI-powered betting pattern analysis using OpenAI
 * 
 * POST /api/ai/analysis
 * Body: { bets: EnhancedBet[], bankroll: number }
 * 
 * Returns: Actionable insights about betting patterns, tilt behavior, and edge identification
 */

interface AnalysisRequest {
  bets: EnhancedBet[];
  bankroll: number;
  timeframe?: 'all' | 'week' | 'month';
}

interface AnalysisResponse {
  insights: string[];
  tiltRisk: number; // 0-1
  edgeAnalysis: {
    sport: string;
    roi: number;
    winRate: number;
    recommendation: string;
  }[];
  recommendations: string[];
  timestamp: number;
}

export async function POST(request: NextRequest): Promise<NextResponse<AnalysisResponse>> {
  try {
    const body: AnalysisRequest = await request.json();
    const { bets, bankroll, timeframe = 'all' } = body;

    if (!bets || !Array.isArray(bets) || bets.length === 0) {
      return NextResponse.json(
        {
          insights: ['Not enough bet history to analyze patterns.'],
          tiltRisk: 0,
          edgeAnalysis: [],
          recommendations: ['Log more bets to get personalized insights.'],
          timestamp: Date.now()
        },
        { status: 200 }
      );
    }

    // Filter bets based on timeframe
    let filteredBets = bets;
    if (timeframe !== 'all') {
      const cutoff = Date.now() - (timeframe === 'week' ? 7 * 86400000 : 30 * 86400000);
      filteredBets = bets.filter((bet: EnhancedBet) => bet.placedAt >= cutoff);
    }

    // Prepare betting summary for AI analysis
    const summary = generateBettingSummary(filteredBets, bankroll);

    // Call OpenAI for pattern analysis
    const aiResponse = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        {
          role: 'system',
          content: `You are an expert sports betting analyst specializing in bankroll management and behavioral analysis. 
Analyze betting patterns and provide 3-5 actionable insights. Focus on:
1. Identifying profitable edges (sports/leagues with positive ROI)
2. Detecting tilt behavior (stake escalation, frequency spikes, emotional betting)
3. CLV performance (are they getting good lines?)
4. Stake sizing discipline
5. Time-of-day patterns

Be concise, specific, and always include dollar amounts when relevant. Format each insight as a single clear sentence.`
        },
        {
          role: 'user',
          content: `Analyze this betting data and provide insights:

${summary}

Provide exactly 3-5 insights, each on a new line. Then provide 2-3 recommendations for improvement.`
        }
      ]
    });

    const aiContent = aiResponse.choices[0]?.message?.content || '';
    
    // Parse AI response
    const lines = aiContent.split('\n').filter((line: string) => line.trim().length > 0);
    const insights: string[] = [];
    const recommendations: string[] = [];
    let inRecommendations = false;

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.toLowerCase().includes('recommendation') || trimmed.toLowerCase().includes('improve')) {
        inRecommendations = true;
        continue;
      }

      if (inRecommendations) {
        recommendations.push(trimmed.replace(/^[-•*]\s*/, ''));
      } else {
        insights.push(trimmed.replace(/^[-•*]\s*/, ''));
      }
    }

    // Calculate tilt risk based on recent behavior
    const tiltRisk = calculateTiltRisk(filteredBets);

    // Generate edge analysis by sport
    const edgeAnalysis = generateEdgeAnalysis(filteredBets);

    return NextResponse.json({
      insights: insights.slice(0, 5),
      tiltRisk,
      edgeAnalysis,
      recommendations: recommendations.slice(0, 3),
      timestamp: Date.now()
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error analyzing betting patterns:', errorMessage);
    return NextResponse.json(
      {
        insights: ['Analysis temporarily unavailable. Please try again.'],
        tiltRisk: 0,
        edgeAnalysis: [],
        recommendations: [],
        timestamp: Date.now()
      },
      { status: 200 }
    );
  }
}

function generateBettingSummary(bets: EnhancedBet[], bankroll: number): string {
  const totalBets = bets.length;
  const wins = bets.filter((b: EnhancedBet) => b.outcome === 'win').length;
  const losses = bets.filter((b: EnhancedBet) => b.outcome === 'loss').length;
  const winRate = losses > 0 ? ((wins / (wins + losses)) * 100).toFixed(1) : '0';
  
  const totalStaked = bets.reduce((sum: number, b: EnhancedBet) => sum + b.stake, 0);
  const totalPL = bets.reduce((sum: number, b: EnhancedBet) => sum + b.profitLoss, 0);
  const avgStake = totalStaked / totalBets;
  const roi = ((totalPL / totalStaked) * 100).toFixed(1);

  // CLV stats
  const betsWithCLV = bets.filter((b: EnhancedBet) => b.clv);
  const avgCLV = betsWithCLV.length > 0
    ? (betsWithCLV.reduce((sum: number, b: EnhancedBet) => sum + (b.clv?.clvPercent || 0), 0) / betsWithCLV.length).toFixed(2)
    : 'N/A';

  // Recent behavior (last 10 bets)
  const recent = bets.slice(-10);
  const recentStakeIncrease = recent.length >= 2 ? 
    recent[recent.length - 1].stake > recent[0].stake * 1.5 : false;

  // Sport breakdown
  const sportStats = new Map<string, { bets: number; pl: number; wins: number; losses: number }>();
  bets.forEach((bet: EnhancedBet) => {
    const stats = sportStats.get(bet.sport) || { bets: 0, pl: 0, wins: 0, losses: 0 };
    stats.bets++;
    stats.pl += bet.profitLoss;
    if (bet.outcome === 'win') stats.wins++;
    if (bet.outcome === 'loss') stats.losses++;
    sportStats.set(bet.sport, stats);
  });

  let sportBreakdown = '';
  sportStats.forEach((stats, sport) => {
    const sportWR = stats.losses > 0 ? ((stats.wins / (stats.wins + stats.losses)) * 100).toFixed(1) : '0';
    sportBreakdown += `\n  ${sport}: ${stats.bets} bets, ${sportWR}% win rate, ${stats.pl >= 0 ? '+' : ''}$${stats.pl.toFixed(0)} P/L`;
  });

  return `
Current Bankroll: $${bankroll.toFixed(2)}
Total Bets: ${totalBets}
Win Rate: ${winRate}%
Total P/L: ${totalPL >= 0 ? '+' : ''}$${totalPL.toFixed(2)}
ROI: ${roi}%
Average Stake: $${avgStake.toFixed(2)} (${((avgStake / bankroll) * 100).toFixed(1)}% of bankroll)
Average CLV: ${avgCLV}%
Recent Stake Pattern: ${recentStakeIncrease ? 'Increasing (potential chase)' : 'Stable'}

Sport Performance:${sportBreakdown}

Recent Bets (last 5):
${recent.slice(-5).map((b: EnhancedBet, i: number) => 
  `${i + 1}. ${b.sport} - ${b.description} - ${b.outcome.toUpperCase()} - $${b.stake} stake - ${b.profitLoss >= 0 ? '+' : ''}$${b.profitLoss.toFixed(2)}`
).join('\n')}
`;
}

function calculateTiltRisk(bets: EnhancedBet[]): number {
  if (bets.length < 5) return 0;

  let risk = 0;
  const recent = bets.slice(-10);

  // Check for stake escalation after losses
  for (let i = 1; i < recent.length; i++) {
    if (recent[i - 1].outcome === 'loss' && recent[i].stake > recent[i - 1].stake * 1.5) {
      risk += 0.15;
    }
  }

  // Check for rapid betting frequency
  if (recent.length >= 5) {
    const timeSpan = recent[recent.length - 1].placedAt - recent[0].placedAt;
    const hoursSpan = timeSpan / 3600000;
    if (hoursSpan < 2 && recent.length >= 8) { // 8+ bets in 2 hours
      risk += 0.25;
    }
  }

  // Check for late-night betting (potential emotional state)
  const lateNightBets = recent.filter((b: EnhancedBet) => {
    const hour = new Date(b.placedAt).getHours();
    return hour >= 23 || hour <= 4;
  });
  if (lateNightBets.length >= 3) {
    risk += 0.15;
  }

  return Math.min(risk, 1);
}

function generateEdgeAnalysis(bets: EnhancedBet[]): Array<{
  sport: string;
  roi: number;
  winRate: number;
  recommendation: string;
}> {
  const sportStats = new Map<string, { pl: number; staked: number; wins: number; losses: number }>();
  
  bets.forEach((bet: EnhancedBet) => {
    const stats = sportStats.get(bet.sport) || { pl: 0, staked: 0, wins: 0, losses: 0 };
    stats.pl += bet.profitLoss;
    stats.staked += bet.stake;
    if (bet.outcome === 'win') stats.wins++;
    if (bet.outcome === 'loss') stats.losses++;
    sportStats.set(bet.sport, stats);
  });

  const analysis: Array<{
    sport: string;
    roi: number;
    winRate: number;
    recommendation: string;
  }> = [];

  sportStats.forEach((stats, sport) => {
    if (stats.wins + stats.losses < 3) return; // Skip if not enough data

    const roi = (stats.pl / stats.staked) * 100;
    const winRate = (stats.wins / (stats.wins + stats.losses)) * 100;

    let recommendation = '';
    if (roi > 5 && winRate > 54) {
      recommendation = '✅ Strong edge - increase unit size';
    } else if (roi > 0 && winRate > 50) {
      recommendation = '👍 Slight edge - maintain or slightly increase';
    } else if (roi < -5) {
      recommendation = '⚠️ Losing edge - reduce stakes or avoid';
    } else {
      recommendation = '➖ Break-even - monitor closely';
    }

    analysis.push({
      sport,
      roi: parseFloat(roi.toFixed(2)),
      winRate: parseFloat(winRate.toFixed(2)),
      recommendation
    });
  });

  return analysis.sort((a, b) => b.roi - a.roi);
}
