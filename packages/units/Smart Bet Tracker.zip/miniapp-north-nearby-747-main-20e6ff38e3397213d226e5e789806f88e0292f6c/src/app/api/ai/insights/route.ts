import { NextRequest, NextResponse } from 'next/server';
import { perplexityResearch } from '@/perplexity-api';

/**
 * Real-time sports betting insights using Perplexity AI
 * 
 * POST /api/ai/insights
 * Body: { query: string, context?: string }
 * 
 * Returns: AI-powered research on line movements, injuries, sharp action, and betting angles
 */

interface InsightsRequest {
  query: string;
  context?: string;
  sport?: string;
  teams?: string;
}

interface InsightsResponse {
  answer: string;
  citations: string[];
  summary: string;
  timestamp: number;
}

export async function POST(request: NextRequest): Promise<NextResponse<InsightsResponse>> {
  try {
    const body: InsightsRequest = await request.json();
    const { query, context, sport, teams } = body;

    if (!query) {
      return NextResponse.json(
        {
          answer: 'Please provide a query to research.',
          citations: [],
          summary: 'No query provided',
          timestamp: Date.now()
        },
        { status: 400 }
      );
    }

    // Build enhanced query with sports betting context
    let enhancedQuery = query;
    if (sport || teams) {
      enhancedQuery = `${sport ? `${sport} ` : ''}${teams ? `${teams} ` : ''}${query}`;
    }

    if (context) {
      enhancedQuery += `\n\nContext: ${context}`;
    }

    // Add sports betting focus to the query
    const researchQuery = `${enhancedQuery}

Focus on:
- Recent line movements and why they occurred
- Injury reports and their impact on betting lines
- Sharp vs public money indicators
- Historical matchup data and trends
- Weather conditions if applicable
- Key betting angles and value opportunities

Provide a concise, actionable summary for sports bettors.`;

    // Call Perplexity for real-time research
    const research = await perplexityResearch(researchQuery, {
      temperature: 0.2,
      max_tokens: 2000
    });

    // Extract summary (first paragraph of answer)
    const paragraphs = research.answer.split('\n\n');
    const summary = paragraphs[0] || research.answer.substring(0, 200);

    return NextResponse.json({
      answer: research.answer,
      citations: research.citations,
      summary,
      timestamp: Date.now()
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error generating insights:', errorMessage);
    return NextResponse.json(
      {
        answer: 'Insights temporarily unavailable. Please try again.',
        citations: [],
        summary: 'Error generating insights',
        timestamp: Date.now()
      },
      { status: 200 }
    );
  }
}

/**
 * GET endpoint for predefined insight templates
 */
export async function GET(request: NextRequest): Promise<NextResponse> {
  const searchParams = request.nextUrl.searchParams;
  const type = searchParams.get('type');

  const templates: Record<string, string> = {
    'line-movement': 'Why did the line move? Explain the difference between sharp money and public betting patterns.',
    'injury-impact': 'How do recent injury reports impact betting lines and which positions have the most influence?',
    'weather': 'How does weather affect NFL totals betting and which conditions favor under bets?',
    'clv': 'What is Closing Line Value (CLV) and why is it the best predictor of long-term betting success?',
    'kelly': 'Explain the Kelly Criterion for sports betting stake sizing and when to use fractional Kelly.',
    'steam': 'What are steam moves in sports betting and how can bettors identify sharp action?'
  };

  if (type && templates[type]) {
    return NextResponse.json({
      query: templates[type],
      description: `Template query for ${type} insights`
    });
  }

  return NextResponse.json({
    templates: Object.keys(templates).map((key: string) => ({
      type: key,
      query: templates[key]
    }))
  });
}
