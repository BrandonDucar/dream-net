import { NextRequest, NextResponse } from 'next/server';
import { perplexityResearch } from '@/perplexity-api';
import { openaiChatCompletion } from '@/openai-api';

export async function POST(req: NextRequest): Promise<NextResponse> {
  try {
    const { question } = await req.json();

    if (!question || typeof question !== 'string') {
      return NextResponse.json(
        { error: 'Question is required' },
        { status: 400 }
      );
    }

    // Determine if the question requires real-time data (Perplexity) or analysis (OpenAI)
    const needsRealTimeData = /who|what|when|where|stats|injury|injuries|starting|lineup|weather|score|record|rank|stand|current|today|tonight|tomorrow|recent|latest/i.test(question);

    let answer = '';
    let citations: string[] = [];
    let source: 'perplexity' | 'openai' = 'openai';

    if (needsRealTimeData) {
      // Use Perplexity for real-time sports data with citations
      source = 'perplexity';
      
      const enhancedPrompt = `You are a knowledgeable sports analyst. Answer this question with accurate, up-to-date information: "${question}"
      
      Provide:
      - Current and accurate data
      - Relevant statistics if applicable
      - Injury reports if relevant
      - Be conversational but informative
      - If it's about betting, provide objective analysis without making definitive predictions`;

      const result = await perplexityResearch(enhancedPrompt, {
        temperature: 0.2,
        max_tokens: 1500
      });

      answer = result.answer;
      citations = result.citations || [];
    } else {
      // Use OpenAI for analysis, predictions, and recommendations
      source = 'openai';

      const systemPrompt = `You are an expert sports analyst and betting consultant. You provide:
- Detailed sports analysis and predictions
- Betting insights and recommendations
- Strategic advice for sports betting
- Risk assessment and value identification
- Be conversational, engaging, and helpful
- Use sports terminology naturally
- When discussing betting, always mention it's not guaranteed and users should bet responsibly`;

      const result = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          { role: 'system', content: systemPrompt },
          { role: 'user', content: question }
        ]
      });

      answer = result.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
    }

    return NextResponse.json({
      answer,
      citations,
      source
    });

  } catch (error) {
    console.error('Sports chat error:', error);
    return NextResponse.json(
      { 
        error: 'Failed to process your question. Please try again.',
        details: error instanceof Error ? error.message : 'Unknown error'
      },
      { status: 500 }
    );
  }
}
