import { NextRequest, NextResponse } from 'next/server';
import { perplexityChat } from '@/perplexity-api';
import type { ChatMessage } from '@/perplexity-api';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { message } = body;

    if (!message || typeof message !== 'string') {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }

    const messages: ChatMessage[] = [
      {
        role: 'system',
        content:
          'You are a helpful sports betting assistant. Provide clear, factual insights about sports, teams, players, odds, and betting strategies. Always cite your sources when providing statistics or recent information.',
      },
      {
        role: 'user',
        content: message,
      },
    ];

    const response = await perplexityChat({
      model: 'sonar-pro',
      messages,
      temperature: 0.2,
    });

    const answer = response.choices[0]?.message?.content || 'Sorry, I could not generate a response.';
    const citations = response.citations || [];

    return NextResponse.json({
      answer,
      citations,
    });
  } catch (error) {
    console.error('Error in chat API:', error);
    return NextResponse.json(
      { error: 'Failed to process chat request' },
      { status: 500 }
    );
  }
}
