import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { perplexityResearch } from '@/perplexity-api';
import { openaiChatCompletion } from '@/openai-api';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

interface AnalyticsRequest {
  gameId: string;
  homeTeam: string;
  awayTeam: string;
  sport: string;
  spread?: number;
  total?: number;
  moneyline?: { home: number; away: number };
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ gameId: string }> }
): Promise<NextResponse> {
  try {
    const resolvedParams = await params;
    const { gameId } = resolvedParams;

    // Fetch game data from matchups API
    const matchupsResponse = await fetch(`${request.nextUrl.origin}/api/matchups/today`);
    const matchupsData = await matchupsResponse.json();

    if (matchupsData.error || !matchupsData.matchups) {
      return NextResponse.json(
        {
          success: false,
          error: 'Failed to fetch matchup data'
        },
        { status: 500 }
      );
    }

    // Find the specific game
    const game = matchupsData.matchups.find((m: any) => m.id === gameId);
    
    if (!game) {
      return NextResponse.json(
        {
          success: false,
          error: 'Game not found'
        },
        { status: 404 }
      );
    }

    const homeTeam = game.homeTeam;
    const awayTeam = game.awayTeam;
    const sport = game.sport;

    // Get best odds from all bookmakers
    let spread: number | undefined;
    let total: number | undefined;
    let moneyline: { home: number; away: number } | undefined;

    if (game.allBooks && game.allBooks.length > 0) {
      const firstBook = game.allBooks[0];
      if (firstBook.spread) {
        spread = firstBook.spread.homePoint;
      }
      if (firstBook.total) {
        total = firstBook.total.overPoint;
      }
      if (firstBook.moneyline) {
        moneyline = {
          home: firstBook.moneyline.homeOdds,
          away: firstBook.moneyline.awayOdds
        };
      }
    }

    // Generate AI analysis
    const analysisResult = await generateAnalysis(gameId, homeTeam, awayTeam, sport, spread, total, moneyline);
    
    return NextResponse.json({
      success: true,
      analysis: analysisResult
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error generating game analytics:', errorMessage);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to generate analytics',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ gameId: string }> }
): Promise<NextResponse> {
  try {
    const resolvedParams = await params;
    const { gameId } = resolvedParams;
    const body: AnalyticsRequest = await request.json();
    const { homeTeam, awayTeam, sport, spread, total, moneyline } = body;

    const analysisResult = await generateAnalysis(gameId, homeTeam, awayTeam, sport, spread, total, moneyline);
    
    return NextResponse.json({
      success: true,
      analysis: analysisResult
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error generating game analytics:', errorMessage);
    return NextResponse.json(
      {
        success: false,
        error: 'Failed to generate analytics',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}

async function generateAnalysis(
  gameId: string,
  homeTeam: string,
  awayTeam: string,
  sport: string,
  spread?: number,
  total?: number,
  moneyline?: { home: number; away: number }
): Promise<any> {
  // Perplexity Research: Real-time sports intel
  const researchQuery = `Analyze the upcoming ${sport} game between ${awayTeam} at ${homeTeam}. Provide:
1. Current injury reports and their impact on the game
2. Recent performance trends for both teams (last 5 games)
3. Why betting lines have moved (sharp vs public money)
4. Weather conditions if outdoor sport
5. Key matchup advantages for each team
Be concise and focus on actionable betting insights.`;

  const perplexityResponse = await perplexityResearch(researchQuery, {
    temperature: 0.1,
    max_tokens: 2000
  });

  const answer = perplexityResponse.answer;
  const citations = perplexityResponse.citations || [];

  // Parse the response (simple split by sections)
  const sections = answer.split(/\d\.\s+/);
  
  const perplexityData = {
    injuries: sections[1]?.trim() || 'No significant injuries reported',
    recentForm: sections[2]?.trim() || 'Recent form data unavailable',
    lineMovement: sections[3]?.trim() || 'Line movement data unavailable',
    weather: sections[4]?.trim() || 'Weather conditions favorable',
    keyMatchups: sections[5]?.trim() || 'Key matchups analysis unavailable',
    citations
  };

  // OpenAI Analysis: Strategic betting insights
  const spreadInfo = spread !== undefined ? `Spread: ${homeTeam} ${spread > 0 ? '+' : ''}${spread}` : '';
  const totalInfo = total !== undefined ? `Total: ${total}` : '';
  const mlInfo = moneyline ? `Moneyline: ${homeTeam} ${moneyline.home}, ${awayTeam} ${moneyline.away}` : '';

  const openaiPrompt = `You are a professional sports betting analyst. Analyze this ${sport} matchup:

${awayTeam} at ${homeTeam}

Current Lines:
${spreadInfo}
${totalInfo}
${mlInfo}

Context:
${perplexityData.injuries}
${perplexityData.recentForm}
${perplexityData.lineMovement}

Provide:
1. Value Assessment (is there expected value in any bet?)
2. Trend Identification (key patterns to note)
3. Risk Factors (what could go wrong?)
4. 2-3 Recommended Bets with confidence scores (1-10)

Format your response as JSON:
{
  "valueAssessment": "string",
  "trendIdentification": "string",
  "riskFactors": "string",
  "recommendedBets": [
    {"type": "spread/total/moneyline", "selection": "team/over/under", "confidence": 7, "reasoning": "why"}
  ]
}`;

  const openaiResponse = await openaiChatCompletion({
    model: 'gpt-4o',
    messages: [
      {
        role: 'system',
        content: 'You are a professional sports betting analyst. Provide data-driven insights in JSON format.'
      },
      {
        role: 'user',
        content: openaiPrompt
      }
    ]
  });

  const content = openaiResponse.choices[0]?.message?.content;
  if (!content) {
    throw new Error('OpenAI returned empty response');
  }

  // Extract JSON from response (handle markdown code blocks)
  const jsonMatch = content.match(/\{[\s\S]*\}/);
  if (!jsonMatch) {
    throw new Error('OpenAI response did not contain valid JSON');
  }

  const openaiData: {
    valueAssessment: string;
    trendIdentification: string;
    riskFactors: string;
    recommendedBets: Array<{
      type: string;
      selection: string;
      confidence: number;
      reasoning: string;
    }>;
  } = JSON.parse(jsonMatch[0]);

  // Format for the frontend component
  return {
    overview: `${openaiData.valueAssessment} ${openaiData.trendIdentification}`,
    valueAssessment: openaiData.valueAssessment,
    trends: openaiData.trendIdentification.split('.').filter((t: string) => t.trim().length > 0).slice(0, 3),
    riskFactors: openaiData.riskFactors.split('.').filter((r: string) => r.trim().length > 0).slice(0, 3),
    recommendations: openaiData.recommendedBets.map((bet: any) => ({
      bet: `${bet.type.toUpperCase()}: ${bet.selection}`,
      confidence: bet.confidence,
      reasoning: bet.reasoning
    })),
    research: {
      injuries: perplexityData.injuries,
      recentForm: perplexityData.recentForm,
      lineMovement: perplexityData.lineMovement,
      weather: perplexityData.weather,
      keyMatchups: perplexityData.keyMatchups,
      citations: perplexityData.citations
    },
    // Also add these for compatibility with game-analytics-modal
    perplexityInsights: {
      injuries: perplexityData.injuries,
      recentForm: perplexityData.recentForm,
      lineMovement: perplexityData.lineMovement,
      weather: perplexityData.weather,
      keyMatchups: perplexityData.keyMatchups,
      citations: perplexityData.citations
    },
    openaiAnalysis: {
      valueAssessment: openaiData.valueAssessment,
      trendIdentification: openaiData.trendIdentification,
      riskFactors: openaiData.riskFactors,
      recommendedBets: openaiData.recommendedBets
    }
  };
}
