import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { SERVER_CONFIG, isOddsApiConfigured } from '@/lib/server-config';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

interface Bookmaker {
  key: string;
  title: string;
  markets: Array<{
    key: string;
    outcomes: Array<{
      name: string;
      price: number;
      point?: number;
    }>;
  }>;
}

interface Game {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: Bookmaker[];
}

interface ProcessedMatchup {
  id: string;
  sport: string;
  sportKey: string;
  league: string;
  startTime: string;
  homeTeam: string;
  awayTeam: string;
  odds: {
    spread: {
      homePoint: number;
      awayPoint: number;
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    moneyline: {
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    total: {
      overPoint: number;
      underPoint: number;
      overOdds: number;
      underOdds: number;
      bookmaker: string;
    } | null;
  };
  allBooks: Array<{
    bookmaker: string;
    spread?: { homePoint: number; awayPoint: number; homeOdds: number; awayOdds: number };
    moneyline?: { homeOdds: number; awayOdds: number };
    total?: { overPoint: number; underPoint: number; overOdds: number; underOdds: number };
  }>;
  lineMovement: {
    direction: 'up' | 'down' | 'stable';
    amount: number;
  };
}

async function fetchRealMatchups(sport?: string): Promise<ProcessedMatchup[]> {
  if (!isOddsApiConfigured()) {
    throw new Error('The Odds API key not configured. Add your key to src/lib/server-config.ts');
  }

  const sports = sport
    ? [sport]
    : ['americanfootball_nfl', 'basketball_nba', 'icehockey_nhl', 'baseball_mlb'];

  const allGames: ProcessedMatchup[] = [];

  for (const sportKey of sports) {
    const url = `https://api.the-odds-api.com/v4/sports/${sportKey}/odds/?apiKey=${SERVER_CONFIG.ODDS_API_KEY}&regions=us&markets=h2h,spreads,totals&oddsFormat=american`;

    const response = await fetch(url, {
      next: { revalidate: 30 }
    });

    if (!response.ok) {
      console.error(`Failed to fetch odds for ${sportKey}:`, response.statusText);
      continue;
    }

    const games: Game[] = await response.json();

    for (const game of games) {
      const processedGame: ProcessedMatchup = {
        id: game.id,
        sport: game.sport_title,
        sportKey: game.sport_key,
        league: game.sport_title,
        startTime: game.commence_time,
        homeTeam: game.home_team,
        awayTeam: game.away_team,
        odds: {
          spread: null,
          moneyline: null,
          total: null
        },
        allBooks: [],
        lineMovement: {
          direction: 'stable',
          amount: 0
        }
      };

      // Process each bookmaker
      for (const book of game.bookmakers) {
        const bookData: {
          bookmaker: string;
          spread?: { homePoint: number; awayPoint: number; homeOdds: number; awayOdds: number };
          moneyline?: { homeOdds: number; awayOdds: number };
          total?: { overPoint: number; underPoint: number; overOdds: number; underOdds: number };
        } = { bookmaker: book.title };

        for (const market of book.markets) {
          if (market.key === 'spreads' && market.outcomes.length === 2) {
            const homeOutcome = market.outcomes.find((o) => o.name === game.home_team);
            const awayOutcome = market.outcomes.find((o) => o.name === game.away_team);

            if (homeOutcome && awayOutcome && homeOutcome.point !== undefined && awayOutcome.point !== undefined) {
              bookData.spread = {
                homePoint: homeOutcome.point,
                awayPoint: awayOutcome.point,
                homeOdds: homeOutcome.price,
                awayOdds: awayOutcome.price
              };

              if (!processedGame.odds.spread) {
                processedGame.odds.spread = {
                  ...bookData.spread,
                  bookmaker: book.title
                };
              }
            }
          } else if (market.key === 'h2h' && market.outcomes.length === 2) {
            const homeOutcome = market.outcomes.find((o) => o.name === game.home_team);
            const awayOutcome = market.outcomes.find((o) => o.name === game.away_team);

            if (homeOutcome && awayOutcome) {
              bookData.moneyline = {
                homeOdds: homeOutcome.price,
                awayOdds: awayOutcome.price
              };

              if (!processedGame.odds.moneyline) {
                processedGame.odds.moneyline = {
                  ...bookData.moneyline,
                  bookmaker: book.title
                };
              }
            }
          } else if (market.key === 'totals' && market.outcomes.length === 2) {
            const overOutcome = market.outcomes.find((o) => o.name === 'Over');
            const underOutcome = market.outcomes.find((o) => o.name === 'Under');

            if (overOutcome && underOutcome && overOutcome.point !== undefined && underOutcome.point !== undefined) {
              bookData.total = {
                overPoint: overOutcome.point,
                underPoint: underOutcome.point,
                overOdds: overOutcome.price,
                underOdds: underOutcome.price
              };

              if (!processedGame.odds.total) {
                processedGame.odds.total = {
                  ...bookData.total,
                  bookmaker: book.title
                };
              }
            }
          }
        }

        processedGame.allBooks.push(bookData);
      }

      allGames.push(processedGame);
    }
  }

  if (allGames.length === 0) {
    throw new Error('No games found for the selected sports. Check if games are scheduled.');
  }

  return allGames;
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const sport = searchParams.get('sport') || undefined;

    const matchups = await fetchRealMatchups(sport);

    return NextResponse.json({
      success: true,
      matchups,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in matchups API:', errorMessage);
    
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: 'Add your The Odds API key to src/lib/server-config.ts'
      },
      { status: 503 }
    );
  }
}
