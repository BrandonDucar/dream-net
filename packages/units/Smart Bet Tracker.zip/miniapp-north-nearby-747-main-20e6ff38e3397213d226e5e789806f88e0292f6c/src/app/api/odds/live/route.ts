import { NextRequest, NextResponse } from 'next/server';
import type { LiveOddsResponse, GameOdds } from '@/types/odds';
import { SERVER_CONFIG, isOddsApiConfigured, getConfigurationError } from '@/lib/server-config';

/**
 * Real-time odds API endpoint using The Odds API
 * 
 * GET /api/odds/live?sport=americanfootball_nfl&markets=spreads,totals,h2h
 * 
 * Returns live odds from multiple sportsbooks for line shopping and CLV tracking.
 * All API keys are managed server-side only.
 * 
 * API key configured in src/lib/server-config.ts
 */

const ODDS_API_BASE = 'https://api.the-odds-api.com/v4';

// Popular bookmakers for US market
const DEFAULT_BOOKMAKERS = [
  'draftkings',
  'fanduel',
  'betmgm',
  'pointsbetsus',
  'williamhill_us',
  'barstool',
  'mybookieag',
  'bovada'
].join(',');

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const sport = searchParams.get('sport') || 'americanfootball_nfl';
    const markets = searchParams.get('markets') || 'h2h,spreads,totals';
    const regions = searchParams.get('regions') || 'us';
    const bookmakers = searchParams.get('bookmakers') || DEFAULT_BOOKMAKERS;

    // API key is REQUIRED for real-time data
    if (!isOddsApiConfigured()) {
      return NextResponse.json(getConfigurationError(), { status: 503 });
    }

    // Fetch live odds from The Odds API
    const url = new URL(`${ODDS_API_BASE}/sports/${sport}/odds`);
    url.searchParams.set('apiKey', SERVER_CONFIG.ODDS_API_KEY);
    url.searchParams.set('regions', regions);
    url.searchParams.set('markets', markets);
    url.searchParams.set('bookmakers', bookmakers);
    url.searchParams.set('oddsFormat', 'american');

    const response = await fetch(url.toString(), {
      next: { revalidate: 30 } // Cache for 30 seconds
    });

    if (!response.ok) {
      throw new Error(`The Odds API error: ${response.status} ${response.statusText}`);
    }

    const games: GameOdds[] = await response.json();

    return NextResponse.json<LiveOddsResponse>({
      games,
      timestamp: Date.now(),
      sport,
      region: regions
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error fetching live odds:', errorMessage);
    
    return NextResponse.json(
      {
        error: 'Failed to fetch live odds from The Odds API',
        details: errorMessage
      },
      { status: 500 }
    );
  }
}
