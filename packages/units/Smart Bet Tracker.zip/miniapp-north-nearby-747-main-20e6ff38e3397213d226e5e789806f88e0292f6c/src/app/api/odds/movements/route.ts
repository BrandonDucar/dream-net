import { NextRequest, NextResponse } from 'next/server';
import type { LineMovement, SteamMove } from '@/types/odds';

/**
 * Line movement tracking API
 * 
 * GET /api/odds/movements?gameId=123&lookback=3600000
 * 
 * Tracks line movements over time to detect steam moves (sharp action).
 * Returns historical line changes with timestamps and significance ratings.
 */

interface StoredLineData {
  gameId: string;
  bookmaker: string;
  marketType: string;
  line: number;
  odds: number;
  timestamp: number;
}

// In-memory storage (in production, use Redis or database)
const lineHistory: Map<string, StoredLineData[]> = new Map();

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const gameId = searchParams.get('gameId');
    const lookback = parseInt(searchParams.get('lookback') || '3600000', 10); // Default 1 hour

    if (!gameId) {
      return NextResponse.json(
        { error: 'gameId parameter is required' },
        { status: 400 }
      );
    }

    const key = `game:${gameId}`;
    const history = lineHistory.get(key) || [];
    const now = Date.now();
    const cutoff = now - lookback;

    // Filter to lookback window
    const recentHistory = history.filter((entry: StoredLineData) => entry.timestamp >= cutoff);

    // Detect line movements
    const movements: LineMovement[] = [];
    const steamMoves: SteamMove[] = [];

    // Group by bookmaker and market type
    const grouped = new Map<string, StoredLineData[]>();
    recentHistory.forEach((entry: StoredLineData) => {
      const groupKey = `${entry.bookmaker}:${entry.marketType}`;
      if (!grouped.has(groupKey)) {
        grouped.set(groupKey, []);
      }
      grouped.get(groupKey)!.push(entry);
    });

    // Analyze movements for each bookmaker/market
    grouped.forEach((entries: StoredLineData[], groupKey: string) => {
      if (entries.length < 2) return;

      // Sort by timestamp
      entries.sort((a: StoredLineData, b: StoredLineData) => a.timestamp - b.timestamp);

      for (let i = 1; i < entries.length; i++) {
        const prev = entries[i - 1];
        const curr = entries[i];

        const lineDiff = curr.line - prev.line;
        const oddsDiff = curr.odds - prev.odds;

        if (Math.abs(lineDiff) >= 0.5 || Math.abs(oddsDiff) >= 5) {
          const movement: LineMovement = {
            timestamp: curr.timestamp,
            bookmaker: curr.bookmaker,
            marketType: curr.marketType,
            previousLine: prev.line,
            currentLine: curr.line,
            previousOdds: prev.odds,
            currentOdds: curr.odds,
            movement: lineDiff > 0 ? 'up' : lineDiff < 0 ? 'down' : 'none',
            magnitude: Math.abs(lineDiff)
          };

          movements.push(movement);

          // Detect steam moves (significant rapid movements)
          const timeDiff = curr.timestamp - prev.timestamp;
          if (Math.abs(lineDiff) >= 1.0 && timeDiff < 900000) { // 1+ point move in < 15 min
            const significance: "low" | "medium" | "high" = 
              Math.abs(lineDiff) >= 2.0 ? 'high' :
              Math.abs(lineDiff) >= 1.5 ? 'medium' : 'low';

            steamMoves.push({
              gameId,
              teams: `Game ${gameId}`,
              marketType: curr.marketType,
              bookmaker: curr.bookmaker,
              movement,
              significance,
              reason: `Line moved ${Math.abs(lineDiff).toFixed(1)} points in ${Math.round(timeDiff / 60000)} minutes`,
              detected_at: curr.timestamp
            });
          }
        }
      }
    });

    return NextResponse.json({
      gameId,
      lookback,
      movements,
      steamMoves,
      dataPoints: recentHistory.length,
      timestamp: now
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error tracking line movements:', errorMessage);
    return NextResponse.json(
      { error: 'Failed to track line movements', details: errorMessage },
      { status: 500 }
    );
  }
}

/**
 * POST endpoint to record line data for tracking
 */
export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: StoredLineData = await request.json();

    if (!body.gameId || !body.bookmaker || !body.marketType) {
      return NextResponse.json(
        { error: 'Missing required fields: gameId, bookmaker, marketType' },
        { status: 400 }
      );
    }

    const key = `game:${body.gameId}`;
    const history = lineHistory.get(key) || [];
    
    history.push({
      ...body,
      timestamp: body.timestamp || Date.now()
    });

    // Keep only last 1000 entries per game (memory management)
    if (history.length > 1000) {
      history.splice(0, history.length - 1000);
    }

    lineHistory.set(key, history);

    return NextResponse.json({ 
      success: true, 
      dataPoints: history.length 
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error storing line data:', errorMessage);
    return NextResponse.json(
      { error: 'Failed to store line data', details: errorMessage },
      { status: 500 }
    );
  }
}
