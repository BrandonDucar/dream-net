import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';
import { SERVER_CONFIG, isOddsApiConfigured } from '@/lib/server-config';

export const dynamic = 'force-dynamic';
export const runtime = 'nodejs';

interface Score {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  completed: boolean;
  home_team: string;
  away_team: string;
  scores: Array<{
    name: string;
    score: string;
  }> | null;
  last_update: string | null;
}

interface ProcessedScore {
  id: string;
  sport: string;
  sportKey: string;
  startTime: string;
  completed: boolean;
  homeTeam: string;
  awayTeam: string;
  homeScore: number | null;
  awayScore: number | null;
  status: 'upcoming' | 'live' | 'final';
  lastUpdate: string | null;
}

async function fetchLiveScores(sport?: string): Promise<ProcessedScore[]> {
  if (!isOddsApiConfigured()) {
    throw new Error('The Odds API key not configured. Add your key to src/lib/server-config.ts');
  }

  const sports = sport
    ? [sport]
    : ['americanfootball_nfl', 'basketball_nba', 'icehockey_nhl', 'baseball_mlb'];

  const allScores: ProcessedScore[] = [];

  for (const sportKey of sports) {
    // Fetch scores from last 2 days and upcoming games
    const url = `https://api.the-odds-api.com/v4/sports/${sportKey}/scores/?apiKey=${SERVER_CONFIG.ODDS_API_KEY}&daysFrom=2`;

    try {
      const response = await fetch(url, {
        next: { revalidate: 10 } // Refresh every 10 seconds for live scores
      });

      if (!response.ok) {
        console.error(`Failed to fetch scores for ${sportKey}:`, response.statusText);
        continue;
      }

      const scores: Score[] = await response.json();

      for (const score of scores) {
        const now = new Date();
        const gameTime = new Date(score.commence_time);
        const timeDiff = now.getTime() - gameTime.getTime();
        
        // Determine game status
        let status: 'upcoming' | 'live' | 'final' = 'upcoming';
        if (score.completed) {
          status = 'final';
        } else if (timeDiff > 0 && !score.completed) {
          // Game has started but not completed = live
          status = 'live';
        }

        // Extract scores
        let homeScore: number | null = null;
        let awayScore: number | null = null;
        
        if (score.scores && Array.isArray(score.scores)) {
          const homeScoreData = score.scores.find((s) => s.name === score.home_team);
          const awayScoreData = score.scores.find((s) => s.name === score.away_team);
          
          homeScore = homeScoreData ? parseInt(homeScoreData.score, 10) : null;
          awayScore = awayScoreData ? parseInt(awayScoreData.score, 10) : null;
        }

        allScores.push({
          id: score.id,
          sport: score.sport_title,
          sportKey: score.sport_key,
          startTime: score.commence_time,
          completed: score.completed,
          homeTeam: score.home_team,
          awayTeam: score.away_team,
          homeScore,
          awayScore,
          status,
          lastUpdate: score.last_update
        });
      }
    } catch (error) {
      console.error(`Error fetching scores for ${sportKey}:`, error);
      continue;
    }
  }

  return allScores;
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const sport = searchParams.get('sport') || undefined;

    const scores = await fetchLiveScores(sport);

    return NextResponse.json({
      success: true,
      scores,
      timestamp: new Date().toISOString()
    });
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in scores API:', errorMessage);
    
    return NextResponse.json(
      {
        success: false,
        error: errorMessage,
        details: 'Add your The Odds API key to src/lib/server-config.ts'
      },
      { status: 503 }
    );
  }
}
