import { NextRequest, NextResponse } from 'next/server';
import { perplexityResearch } from '@/perplexity-api';

/**
 * Real-time sports news and line movement explanations
 * 
 * GET /api/sports/news?game=chiefs-bills&sport=nfl
 * 
 * Uses Perplexity AI to fetch breaking news, injury updates, and explain line movements
 */

interface NewsRequest {
  game?: string;
  sport?: string;
  team?: string;
  type?: 'injuries' | 'lineMovement' | 'general';
}

interface NewsResponse {
  headline: string;
  summary: string;
  details: string;
  sources: string[];
  timestamp: number;
  relevance: 'high' | 'medium' | 'low';
}

export async function GET(request: NextRequest): Promise<NextResponse<NewsResponse>> {
  try {
    const searchParams = request.nextUrl.searchParams;
    const game = searchParams.get('game') || '';
    const sport = searchParams.get('sport') || 'NFL';
    const team = searchParams.get('team') || '';
    const type = (searchParams.get('type') || 'general') as 'injuries' | 'lineMovement' | 'general';

    let query = '';
    
    switch (type) {
      case 'injuries':
        query = `${sport} ${team || game} latest injury report and impact on betting lines. Focus on key players and expected availability.`;
        break;
      case 'lineMovement':
        query = `${sport} ${game} why did the betting line move? Explain sharp vs public money, injury news, or other factors.`;
        break;
      default:
        query = `${sport} ${team || game} latest news relevant to sports betting. Include injury updates, lineup changes, weather, and recent performance.`;
    }

    // Fetch real-time news using Perplexity
    const research = await perplexityResearch(query, {
      temperature: 0.1,
      max_tokens: 1500
    });

    // Extract headline (first line or sentence)
    const sentences = research.answer.split(/[.!?]\s+/);
    const headline = sentences[0]?.substring(0, 100) || 'Breaking Sports News';

    // Extract summary (first paragraph)
    const paragraphs = research.answer.split('\n\n');
    const summary = paragraphs[0] || research.answer.substring(0, 250);

    // Determine relevance based on keywords
    const relevanceKeywords = {
      high: ['ruled out', 'questionable', 'doubtful', 'suspended', 'injured', 'sharp money', 'steam move', 'line moved'],
      medium: ['probable', 'limited practice', 'monitoring', 'trending']
    };

    let relevance: 'high' | 'medium' | 'low' = 'low';
    const lowerAnswer = research.answer.toLowerCase();
    
    if (relevanceKeywords.high.some((kw: string) => lowerAnswer.includes(kw))) {
      relevance = 'high';
    } else if (relevanceKeywords.medium.some((kw: string) => lowerAnswer.includes(kw))) {
      relevance = 'medium';
    }

    return NextResponse.json({
      headline: headline + '.',
      summary,
      details: research.answer,
      sources: research.citations,
      timestamp: Date.now(),
      relevance
    });

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error fetching sports news:', errorMessage);
    
    return NextResponse.json({
      headline: 'News temporarily unavailable',
      summary: 'Unable to fetch the latest sports news. Please try again.',
      details: 'Service temporarily unavailable.',
      sources: [],
      timestamp: Date.now(),
      relevance: 'low'
    });
  }
}
