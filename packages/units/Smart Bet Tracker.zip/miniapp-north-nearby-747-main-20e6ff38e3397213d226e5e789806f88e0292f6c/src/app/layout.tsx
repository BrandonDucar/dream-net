import type { Metadata } from "next";
import localFont from "next/font/local";
import "./globals.css";
import { ResponseLogger } from "@/components/response-logger";
import { cookies } from "next/headers";
import { ReadyNotifier } from "@/components/ready-notifier";
import FarcasterWrapper from "@/components/FarcasterWrapper";

const geistSans = localFont({
  src: "./fonts/GeistVF.woff",
  variable: "--font-geist-sans",
  weight: "100 900",
});
const geistMono = localFont({
  src: "./fonts/GeistMonoVF.woff",
  variable: "--font-geist-mono",
  weight: "100 900",
});

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const requestId = cookies().get("x-request-id")?.value;

  return (
        <html lang="en">
          <head>
            {requestId && <meta name="x-request-id" content={requestId} />}
            <meta name="base:app_id" content="693885c77118f1704dec2836" />
          </head>
          <body
            className={`${geistSans.variable} ${geistMono.variable} antialiased`}
          >
            {/* Do not remove this component, we use it to notify the parent that the mini-app is ready */}
            <ReadyNotifier />
            
      <FarcasterWrapper>
        {children}
      </FarcasterWrapper>
      
            <ResponseLogger />
          </body>
        </html>
      );
}

export const metadata: Metadata = {
        title: "Bankroll & Risk Dashboard | AI-Powered Betting Analytics & Tilt Guard",
        description: "Professional betting bankroll management with AI-powered insights, tilt detection, CLV tracking, Kelly criterion staking, and geofencing. Track P&L, ROI, variance, and identify profitable edges. The ultimate smart staking companion for disciplined bettors.",
        keywords: "betting bankroll, sports betting tracker, bankroll management, tilt detection, Kelly criterion, CLV tracking, betting analytics, ROI calculator, variance analysis, risk of ruin, sharp betting, line shopping, responsible gambling, betting dashboard, profit tracking, AI betting insights, geofencing sportsbooks",
        authors: [{ name: "Ohara" }],
        creator: "Ohara",
        publisher: "Ohara",
        robots: "index, follow",
        openGraph: {
          title: "Bankroll & Risk Dashboard | AI-Powered Betting Analytics",
          description: "Track your betting performance with AI-powered insights, tilt detection, and smart staking recommendations. Professional bankroll management for disciplined bettors.",
          type: "website",
          locale: "en_US",
          siteName: "Bankroll & Risk Dashboard"
        },
        twitter: {
          card: "summary_large_image",
          title: "Bankroll & Risk Dashboard | AI-Powered Betting Analytics",
          description: "Professional betting tracker with AI insights, tilt detection, and Kelly criterion staking. Manage your bankroll like a pro.",
          creator: "@ohara_ai"
        },
        viewport: "width=device-width, initial-scale=1",
        themeColor: "#22d3ee",
        other: { 
          "fc:frame": JSON.stringify({"version":"next","imageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/thumbnail_1f140650-0bfd-4a7c-86c2-6c6eea81a8e3-Q2cB2GcGvvKjIRFDp3RxAeM1Vg39SA","button":{"title":"Open with Ohara","action":{"type":"launch_frame","name":"Smart Bet Tracker","url":"https://north-nearby-747.app.ohara.ai","splashImageUrl":"https://usdozf7pplhxfvrl.public.blob.vercel-storage.com/farcaster/splash_images/splash_image1.svg","splashBackgroundColor":"#ffffff"}}}),
          "application-name": "Bankroll & Risk Dashboard",
          "apple-mobile-web-app-capable": "yes",
          "apple-mobile-web-app-status-bar-style": "default",
          "apple-mobile-web-app-title": "Bankroll Tracker",
          "format-detection": "telephone=no",
          "mobile-web-app-capable": "yes"
        }
    };
