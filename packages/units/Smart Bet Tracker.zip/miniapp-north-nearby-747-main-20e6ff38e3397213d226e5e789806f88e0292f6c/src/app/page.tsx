'use client'
import { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { MatchupsDashboard } from '@/components/matchups-dashboard';
import { InteractiveAnalytics } from '@/components/interactive-analytics';
import { SportsChat } from '@/components/sports-chat';
import { LiveOddsDisplay } from '@/components/live-odds-display';
import { CLVTracker } from '@/components/clv-tracker';
import { Activity, TrendingUp, MessageSquare, BarChart3, Target, Sparkles } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

interface BetSlipItem {
  id: string;
  description: string;
  sport: string;
  odds: number;
  bookmaker: string;
  stake: number;
}

export default function Home(): JSX.Element {
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster();
  useQuickAuth(isInFarcaster);

  const [activeTab, setActiveTab] = useState<string>('matchups');
  const [betSlip, setBetSlip] = useState<BetSlipItem[]>([]);
  const [mounted, setMounted] = useState<boolean>(false);

  useEffect(() => {
    const tryAddMiniApp = async (): Promise<void> => {
      try {
        await addMiniApp();
      } catch (error) {
        console.error('Failed to add mini app:', error);
      }
    };

    tryAddMiniApp();
  }, [addMiniApp]);

  useEffect(() => {
    const initializeFarcaster = async (): Promise<void> => {
      try {
        if (typeof window !== 'undefined') {
          const { sdk } = await import('@farcaster/miniapp-sdk');
          await sdk.actions.ready();
          console.log('Farcaster SDK initialized');
        }
      } catch (error) {
        console.log('Farcaster SDK not available or initialization failed');
      }
    };

    initializeFarcaster();
    setMounted(true);
  }, []);

  const handleSelectBet = (bet: { description: string; sport: string; odds: number; bookmaker: string }): void => {
    const newBet: BetSlipItem = {
      id: `${Date.now()}-${Math.random()}`,
      description: bet.description,
      sport: bet.sport,
      odds: bet.odds,
      bookmaker: bet.bookmaker,
      stake: 0
    };
    setBetSlip((prev: BetSlipItem[]) => [...prev, newBet]);
  };

  const handleRemoveBet = (id: string): void => {
    setBetSlip((prev: BetSlipItem[]) => prev.filter((bet: BetSlipItem) => bet.id !== id));
  };

  const handleUpdateStake = (id: string, stake: number): void => {
    setBetSlip((prev: BetSlipItem[]) =>
      prev.map((bet: BetSlipItem) => (bet.id === id ? { ...bet, stake } : bet))
    );
  };

  if (!mounted) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#0a0f1e] via-[#0f172a] to-[#020617] text-white">
      <div className="max-w-7xl mx-auto p-4 md:p-8 space-y-6 pt-12">
        {/* Header */}
        <div className="text-center space-y-2 mb-8">
          <div className="flex items-center justify-center gap-3 mb-2">
            <div className="p-3 bg-gradient-to-br from-[#22d3ee] to-[#06b6d4] rounded-xl">
              <Activity className="w-8 h-8 text-[#020617]" />
            </div>
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-[#22d3ee] via-[#3b82f6] to-[#8b5cf6] bg-clip-text text-transparent">
              Sports Betting Analytics
            </h1>
          </div>
          <p className="text-[#94a3b8] text-lg">
            Real-time odds, AI-powered insights, and smart betting recommendations
          </p>
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <Badge variant="outline" className="border-[#22d3ee] text-[#22d3ee]">
              <TrendingUp className="w-3 h-3 mr-1" />
              Live Odds
            </Badge>
            <Badge variant="outline" className="border-[#8b5cf6] text-[#8b5cf6]">
              <Sparkles className="w-3 h-3 mr-1" />
              AI Insights
            </Badge>
            <Badge variant="outline" className="border-[#3b82f6] text-[#3b82f6]">
              <Target className="w-3 h-3 mr-1" />
              CLV Tracking
            </Badge>
          </div>
        </div>

        {/* Main Navigation Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-2 md:grid-cols-5 bg-[#0f172a] border border-[#1e293b] p-1">
            <TabsTrigger
              value="matchups"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617] text-[#94a3b8]"
            >
              <Activity className="w-4 h-4 mr-2" />
              Matchups
            </TabsTrigger>
            <TabsTrigger
              value="live-odds"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617] text-[#94a3b8]"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Live Odds
            </TabsTrigger>
            <TabsTrigger
              value="analytics"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617] text-[#94a3b8]"
            >
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger
              value="clv"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617] text-[#94a3b8]"
            >
              <Target className="w-4 h-4 mr-2" />
              CLV
            </TabsTrigger>
            <TabsTrigger
              value="ai-chat"
              className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617] text-[#94a3b8]"
            >
              <MessageSquare className="w-4 h-4 mr-2" />
              AI Chat
            </TabsTrigger>
          </TabsList>

          {/* Matchups Tab */}
          <TabsContent value="matchups" className="space-y-6">
            <MatchupsDashboard onSelectBet={handleSelectBet} />
          </TabsContent>

          {/* Live Odds Tab */}
          <TabsContent value="live-odds" className="space-y-6">
            <LiveOddsDisplay onSelectBet={handleSelectBet} />
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <InteractiveAnalytics />
          </TabsContent>

          {/* CLV Tracker Tab */}
          <TabsContent value="clv" className="space-y-6">
            <CLVTracker bets={[]} />
          </TabsContent>

          {/* AI Chat Tab */}
          <TabsContent value="ai-chat" className="space-y-6">
            <SportsChat />
          </TabsContent>
        </Tabs>

        {/* Bet Slip Sidebar (Fixed on larger screens) */}
        {betSlip.length > 0 && (
          <div className="fixed bottom-4 right-4 w-80 max-h-[500px] z-50 hidden lg:block">
            <Card className="bg-[#0f172a] border-[#22d3ee] shadow-xl">
              <CardHeader className="pb-3">
                <CardTitle className="text-[#22d3ee] flex items-center justify-between">
                  <span>Bet Slip</span>
                  <Badge variant="secondary" className="bg-[#22d3ee] text-[#020617]">
                    {betSlip.length}
                  </Badge>
                </CardTitle>
                <CardDescription className="text-[#94a3b8]">
                  Your selected bets
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-3 overflow-y-auto max-h-[350px]">
                {betSlip.map((bet: BetSlipItem) => (
                  <Card key={bet.id} className="bg-[#020617] border-[#1e293b] p-3">
                    <div className="space-y-2">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <p className="text-sm font-medium text-[#e5e7eb]">{bet.description}</p>
                          <p className="text-xs text-[#94a3b8]">{bet.sport} • {bet.bookmaker}</p>
                        </div>
                        <Button
                          onClick={() => handleRemoveBet(bet.id)}
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 text-red-400 hover:text-red-300 hover:bg-red-950"
                        >
                          ×
                        </Button>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge className="bg-[#22d3ee] text-[#020617] border-0">
                          {bet.odds > 0 ? '+' : ''}{bet.odds}
                        </Badge>
                      </div>
                    </div>
                  </Card>
                ))}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}
