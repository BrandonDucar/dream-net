'use client'

import { useState, type FC, type FormEvent, type ChangeEvent } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Send, Loader2 } from 'lucide-react';
import { getPersonalizedAdvice } from '@/lib/ai-analysis';
import type { EnhancedBet, AdvancedAnalytics } from '@/lib/bankroll-enhanced';
import type { BankrollSnapshot } from '@/lib/bankroll';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
}

interface AIChatProps {
  bets: EnhancedBet[];
  snapshot: BankrollSnapshot;
  analytics: AdvancedAnalytics;
}

export const AIChat: FC<AIChatProps> = ({ bets, snapshot, analytics }) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hi! I\'m your bankroll AI assistant. Ask me anything about your betting strategy, risk management, or performance analysis. I can help identify edges, suggest improvements, and answer specific questions about your data.',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const suggestedQuestions: string[] = [
    'What are my strongest edges?',
    'Should I increase my unit size?',
    'Am I betting too aggressively?',
    'Which sports should I focus on?',
    'How can I improve my win rate?'
  ];

  const handleSubmit = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages([...messages, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response: string = await getPersonalizedAdvice(input, bets, snapshot, analytics);
      
      const assistantMessage: Message = {
        role: 'assistant',
        content: response,
        timestamp: Date.now()
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, I encountered an error processing your question. Please try again.',
        timestamp: Date.now()
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestedQuestion = async (question: string): Promise<void> => {
    if (isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: question,
      timestamp: Date.now()
    };

    setMessages([...messages, userMessage]);
    setIsLoading(true);

    try {
      const response: string = await getPersonalizedAdvice(question, bets, snapshot, analytics);
      
      const assistantMessage: Message = {
        role: 'assistant',
        content: response,
        timestamp: Date.now()
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try again.',
        timestamp: Date.now()
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-[#020617] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          AI Bankroll Assistant
        </CardTitle>
        <CardDescription className="text-[#94a3b8]">
          Get personalized advice and insights powered by AI
        </CardDescription>
      </CardHeader>
      <CardContent>
        {/* Suggested Questions */}
        {messages.length <= 1 && (
          <div className="mb-4">
            <p className="text-sm text-[#94a3b8] mb-2">Suggested questions:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question: string) => (
                <Badge
                  key={question}
                  variant="outline"
                  className="cursor-pointer border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
                  onClick={() => handleSuggestedQuestion(question)}
                >
                  {question}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="space-y-4 mb-4 max-h-[400px] overflow-y-auto">
          {messages.map((message: Message, index: number) => (
            <div
              key={index}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[80%] rounded-lg p-3 ${
                  message.role === 'user'
                    ? 'bg-[#22d3ee] text-[#020617]'
                    : 'bg-[#0f172a] text-[#e5e7eb] border border-[#1e293b]'
                }`}
              >
                <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                <p className="text-xs opacity-60 mt-1">
                  {new Date(message.timestamp).toLocaleTimeString('en-US', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-[#0f172a] text-[#e5e7eb] border border-[#1e293b] rounded-lg p-3">
                <Loader2 className="w-5 h-5 animate-spin" />
              </div>
            </div>
          )}
        </div>

        {/* Input */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={input}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setInput(e.target.value)}
            placeholder="Ask about your betting strategy..."
            className="bg-[#0f172a] border-[#1e293b] text-[#e5e7eb]"
            disabled={isLoading}
          />
          <Button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};
