'use client'

import { useState, useEffect, type FC } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { 
  Sparkles, 
  TrendingUp, 
  AlertTriangle, 
  Target, 
  Lightbulb, 
  Loader2,
  RefreshCw 
} from 'lucide-react';
import {
  analyzeBettingPatterns,
  predictTiltRisk,
  identifyEdge,
  type AIInsight,
  type TiltPrediction,
  type EdgeAnalysis
} from '@/lib/ai-analysis';
import type { EnhancedBet, AdvancedAnalytics } from '@/lib/bankroll-enhanced';
import type { BankrollSnapshot } from '@/lib/bankroll';

interface AIInsightsProps {
  bets: EnhancedBet[];
  snapshot: BankrollSnapshot;
  analytics: AdvancedAnalytics;
}

export const AIInsights: FC<AIInsightsProps> = ({ bets, snapshot, analytics }) => {
  const [insights, setInsights] = useState<AIInsight[]>([]);
  const [tiltPrediction, setTiltPrediction] = useState<TiltPrediction | null>(null);
  const [edgeAnalysis, setEdgeAnalysis] = useState<EdgeAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [generalInsights, setGeneralInsights] = useState<string>('');
  const [isLoadingGeneral, setIsLoadingGeneral] = useState<boolean>(false);

  const generateGeneralInsights = async (): Promise<void> => {
    setIsLoadingGeneral(true);
    try {
      const response = await fetch('/api/matchups/today');
      const data = await response.json();
      
      if (data.error) {
        setGeneralInsights('Unable to load matchup data. Please configure The Odds API key.');
        return;
      }

      // Get AI analysis for today's top matchups
      const topMatchups = data.matchups?.slice(0, 3) || [];
      if (topMatchups.length === 0) {
        setGeneralInsights('No games scheduled for today.');
        return;
      }

      const analysisPromises = topMatchups.map(async (matchup: any) => {
        try {
          const res = await fetch(`/api/matchups/${matchup.id}/analytics`);
          const analytics = await res.json();
          return {
            game: `${matchup.awayTeam} @ ${matchup.homeTeam}`,
            insight: analytics.aiAnalysis?.valueAssessment || 'Analysis unavailable'
          };
        } catch {
          return null;
        }
      });

      const results = await Promise.all(analysisPromises);
      const validResults = results.filter(r => r !== null);
      
      if (validResults.length > 0) {
        const summary = validResults.map((r: any) => 
          `**${r.game}**\n${r.insight}`
        ).join('\n\n');
        setGeneralInsights(summary);
      } else {
        setGeneralInsights('AI analysis temporarily unavailable.');
      }
    } catch (error) {
      console.error('General insights error:', error);
      setGeneralInsights('Error loading matchup insights.');
    } finally {
      setIsLoadingGeneral(false);
    }
  };

  const generateAnalysis = async (): Promise<void> => {
    if (bets.length < 5) return;

    setIsLoading(true);

    try {
      const [patternsResult, tiltResult, edgeResult] = await Promise.all([
        analyzeBettingPatterns(bets, snapshot, analytics),
        predictTiltRisk(bets.slice(-10), analytics),
        identifyEdge(analytics, bets)
      ]);

      setInsights(patternsResult);
      setTiltPrediction(tiltResult);
      setEdgeAnalysis(edgeResult);
    } catch (error) {
      console.error('AI analysis error:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (bets.length >= 5) {
      generateAnalysis();
    } else {
      generateGeneralInsights();
    }
  }, []);

  const getInsightIcon = (type: string): JSX.Element => {
    switch (type) {
      case 'pattern':
        return <TrendingUp className="w-4 h-4" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4" />;
      case 'strength':
        return <Target className="w-4 h-4" />;
      case 'recommendation':
        return <Lightbulb className="w-4 h-4" />;
      default:
        return <Sparkles className="w-4 h-4" />;
    }
  };

  const getInsightColor = (type: string): string => {
    switch (type) {
      case 'warning':
        return 'border-[#ef4444] text-[#ef4444]';
      case 'strength':
        return 'border-[#22c55e] text-[#22c55e]';
      case 'recommendation':
        return 'border-[#22d3ee] text-[#22d3ee]';
      default:
        return 'border-[#f59e0b] text-[#f59e0b]';
    }
  };

  const getTiltColor = (level: string): string => {
    switch (level) {
      case 'critical':
        return 'border-[#ef4444] text-[#ef4444]';
      case 'high':
        return 'border-[#f59e0b] text-[#f59e0b]';
      case 'moderate':
        return 'border-[#22d3ee] text-[#22d3ee]';
      default:
        return 'border-[#22c55e] text-[#22c55e]';
    }
  };

  if (bets.length < 5) {
    return (
      <div className="space-y-6">
        {/* General Matchup Insights */}
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-[#22d3ee] flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Today's Game Insights
              </CardTitle>
              <Button
                onClick={generateGeneralInsights}
                disabled={isLoadingGeneral}
                variant="outline"
                size="sm"
                className="border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
              >
                {isLoadingGeneral ? (
                  <Loader2 className="w-4 h-4 animate-spin" />
                ) : (
                  <RefreshCw className="w-4 h-4" />
                )}
              </Button>
            </div>
            <CardDescription className="text-[#94a3b8]">
              AI-powered analysis of today's matchups across all sports
            </CardDescription>
          </CardHeader>
          <CardContent>
            {isLoadingGeneral ? (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="w-8 h-8 animate-spin text-[#22d3ee]" />
              </div>
            ) : generalInsights ? (
              <div className="prose prose-invert max-w-none">
                <div className="space-y-4">
                  {generalInsights.split('\n\n').map((section: string, idx: number) => (
                    <div key={idx} className="p-4 bg-[#0f172a] rounded-lg border border-[#1e293b]">
                      <p className="text-[#e5e7eb] text-sm whitespace-pre-line">{section}</p>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <p className="text-center text-[#94a3b8] py-4">No insights available yet.</p>
            )}
          </CardContent>
        </Card>

        {/* Personal Insights Locked */}
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardContent className="py-8 text-center">
            <Target className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-[#e5e7eb] mb-2">Personal Betting Analysis</h3>
            <p className="text-[#94a3b8] mb-4">
              Log at least 5 bets to unlock personalized pattern analysis, tilt detection, and edge identification.
            </p>
            <Badge variant="outline" className="border-[#22d3ee] text-[#22d3ee]">
              {bets.length} / 5 bets logged
            </Badge>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* AI Insights */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-[#22d3ee] flex items-center gap-2">
              <Sparkles className="w-5 h-5" />
              AI Insights
            </CardTitle>
            <Button
              onClick={generateAnalysis}
              disabled={isLoading}
              variant="outline"
              size="sm"
              className="border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <RefreshCw className="w-4 h-4" />
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-8">
              <Loader2 className="w-8 h-8 animate-spin text-[#22d3ee]" />
            </div>
          ) : insights.length > 0 ? (
            insights.map((insight: AIInsight, index: number) => (
              <div
                key={index}
                className="p-4 bg-[#0f172a] rounded-lg border border-[#1e293b]"
              >
                <div className="flex items-start gap-3">
                  <Badge
                    variant="outline"
                    className={`mt-1 ${getInsightColor(insight.type)}`}
                  >
                    {getInsightIcon(insight.type)}
                  </Badge>
                  <div className="flex-1">
                    <h4 className="text-[#e5e7eb] font-semibold mb-1">{insight.title}</h4>
                    <p className="text-[#94a3b8] text-sm">{insight.description}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <span className="text-xs text-[#94a3b8]">
                        Confidence: {(insight.confidence * 100).toFixed(0)}%
                      </span>
                      {insight.actionable && (
                        <Badge variant="outline" className="border-[#22d3ee] text-[#22d3ee] text-xs">
                          Actionable
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="text-center text-[#94a3b8] py-4">No insights available yet.</p>
          )}
        </CardContent>
      </Card>

      {/* Tilt Prediction */}
      {tiltPrediction && (
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-[#22d3ee] flex items-center gap-2">
              <AlertTriangle className="w-5 h-5" />
              Tilt Risk Assessment
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-[#94a3b8]">Current Risk Level</span>
              <Badge variant="outline" className={getTiltColor(tiltPrediction.riskLevel)}>
                {tiltPrediction.riskLevel.toUpperCase()} ({tiltPrediction.probability}%)
              </Badge>
            </div>

            {tiltPrediction.factors.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-[#e5e7eb] mb-2">Risk Factors</h4>
                <ul className="space-y-1">
                  {tiltPrediction.factors.map((factor: string, index: number) => (
                    <li key={index} className="text-sm text-[#94a3b8] flex items-start gap-2">
                      <span className="text-[#ef4444]">•</span>
                      {factor}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {tiltPrediction.nextActions.length > 0 && (
              <Alert className="bg-[#0f172a] border-[#22d3ee]">
                <Lightbulb className="w-4 h-4 text-[#22d3ee]" />
                <AlertDescription className="text-[#e5e7eb]">
                  <div className="font-semibold mb-2">Recommended Actions:</div>
                  <ul className="space-y-1">
                    {tiltPrediction.nextActions.map((action: string, index: number) => (
                      <li key={index} className="text-sm">• {action}</li>
                    ))}
                  </ul>
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}

      {/* Edge Analysis */}
      {edgeAnalysis && (
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader>
            <CardTitle className="text-[#22d3ee] flex items-center gap-2">
              <Target className="w-5 h-5" />
              Edge Analysis
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="text-sm font-semibold text-[#22c55e] mb-2">Strongest Edge</h4>
              <p className="text-[#e5e7eb] text-sm">{edgeAnalysis.strongestEdge}</p>
            </div>

            <div>
              <h4 className="text-sm font-semibold text-[#ef4444] mb-2">Weakest Area</h4>
              <p className="text-[#e5e7eb] text-sm">{edgeAnalysis.weakestArea}</p>
            </div>

            {edgeAnalysis.recommendations.length > 0 && (
              <div>
                <h4 className="text-sm font-semibold text-[#22d3ee] mb-2">Recommendations</h4>
                <ul className="space-y-1">
                  {edgeAnalysis.recommendations.map((rec: string, index: number) => (
                    <li key={index} className="text-sm text-[#94a3b8] flex items-start gap-2">
                      <Lightbulb className="w-4 h-4 mt-0.5 flex-shrink-0 text-[#22d3ee]" />
                      {rec}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <div className="grid grid-cols-2 gap-4 pt-4 border-t border-[#1e293b]">
              {edgeAnalysis.profitableTags.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-[#94a3b8] mb-2">Profitable Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {edgeAnalysis.profitableTags.map((tag: string) => (
                      <Badge
                        key={tag}
                        variant="outline"
                        className="border-[#22c55e] text-[#22c55e] text-xs"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              {edgeAnalysis.avoidTags.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold text-[#94a3b8] mb-2">Avoid Tags</h4>
                  <div className="flex flex-wrap gap-1">
                    {edgeAnalysis.avoidTags.map((tag: string) => (
                      <Badge
                        key={tag}
                        variant="outline"
                        className="border-[#ef4444] text-[#ef4444] text-xs"
                      >
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
