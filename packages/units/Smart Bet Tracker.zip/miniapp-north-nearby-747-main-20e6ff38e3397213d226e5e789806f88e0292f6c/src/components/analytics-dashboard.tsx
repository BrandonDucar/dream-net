'use client'

import { useState, useEffect, type FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { TrendingUp, TrendingDown, Target, Zap, Trophy, AlertTriangle, RefreshCw, Sparkles } from 'lucide-react';
import { Skeleton } from '@/components/ui/skeleton';

interface BetSlipItem {
  id: string;
  description: string;
  sport: string;
  odds: number;
  bookmaker: string;
  stake: number;
}

interface AnalyticsDashboardProps {
  betSlip: BetSlipItem[];
}

interface MockAnalytics {
  roi: number;
  profitFactor: number;
  sharpeRatio: number;
  currentStreak: { type: 'win' | 'loss' | 'none'; count: number };
  longestWinStreak: number;
  roiBySport: Array<{ sport: string; roi: number; bets: number }>;
  avgClv: number;
  expectancy: number;
  variance: number;
}

function generateMockAnalytics(): MockAnalytics {
  return {
    roi: Math.random() * 20 - 5,
    profitFactor: 1.2 + Math.random() * 1.5,
    sharpeRatio: 0.5 + Math.random() * 1.5,
    currentStreak: {
      type: Math.random() > 0.5 ? 'win' : 'loss',
      count: Math.floor(Math.random() * 5) + 1
    },
    longestWinStreak: Math.floor(Math.random() * 10) + 3,
    roiBySport: [
      { sport: 'NBA', roi: Math.random() * 15 - 3, bets: Math.floor(Math.random() * 50) + 10 },
      { sport: 'NFL', roi: Math.random() * 15 - 3, bets: Math.floor(Math.random() * 40) + 8 },
      { sport: 'MLB', roi: Math.random() * 12 - 2, bets: Math.floor(Math.random() * 60) + 15 },
      { sport: 'NHL', roi: Math.random() * 10 - 1, bets: Math.floor(Math.random() * 30) + 5 }
    ],
    avgClv: (Math.random() * 0.1 - 0.02),
    expectancy: Math.random() * 10 - 2,
    variance: Math.random() * 50 + 20
  };
}

export const AnalyticsDashboard: FC<AnalyticsDashboardProps> = ({ betSlip }) => {
  const [analytics, setAnalytics] = useState<MockAnalytics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);

  const loadAnalytics = (): void => {
    setLoading(true);
    setTimeout(() => {
      setAnalytics(generateMockAnalytics());
      setLoading(false);
    }, 800);
  };

  useEffect(() => {
    loadAnalytics();
  }, [betSlip]);

  const formatPercent = (value: number): string => {
    const sign: string = value >= 0 ? '+' : '';
    return `${sign}${value.toFixed(2)}%`;
  };

  const getStreakIcon = (): JSX.Element => {
    if (!analytics) return <Target className="w-4 h-4 text-[#94a3b8]" />;
    if (analytics.currentStreak.type === 'win') {
      return <TrendingUp className="w-4 h-4 text-[#22c55e]" />;
    }
    if (analytics.currentStreak.type === 'loss') {
      return <TrendingDown className="w-4 h-4 text-[#ef4444]" />;
    }
    return <Target className="w-4 h-4 text-[#94a3b8]" />;
  };

  const getProfitFactorColor = (pf: number): string => {
    if (pf >= 2.0) return 'text-[#22c55e]';
    if (pf >= 1.5) return 'text-[#22d3ee]';
    if (pf >= 1.0) return 'text-[#f59e0b]';
    return 'text-[#ef4444]';
  };

  if (loading || !analytics) {
    return (
      <div className="grid gap-6">
        <div className="grid md:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Card key={i} className="bg-[#020617] border-[#1e293b]">
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24 bg-[#1e293b]" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 bg-[#1e293b]" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-[#22d3ee] flex items-center gap-2">
                <Sparkles className="w-5 h-5" />
                Betting Analytics Dashboard
              </CardTitle>
              <CardDescription className="text-[#94a3b8]">
                AI-powered insights and performance metrics
              </CardDescription>
            </div>
            <Button
              onClick={loadAnalytics}
              variant="outline"
              size="sm"
              disabled={loading}
              className="border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
      </Card>

      {/* Key Metrics Row */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-[#94a3b8]">Overall ROI</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${analytics.roi >= 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
              {formatPercent(analytics.roi)}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-[#94a3b8]">Profit Factor</CardTitle>
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${getProfitFactorColor(analytics.profitFactor)}`}>
              {analytics.profitFactor.toFixed(2)}x
            </div>
            <p className="text-xs text-[#94a3b8] mt-1">
              {analytics.profitFactor >= 2.0 ? 'Excellent' : analytics.profitFactor >= 1.5 ? 'Good' : analytics.profitFactor >= 1.0 ? 'Break Even' : 'Needs Work'}
            </p>
          </CardContent>
        </Card>

        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-[#94a3b8]">Sharpe Ratio</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#22d3ee]">
              {analytics.sharpeRatio.toFixed(3)}
            </div>
            <p className="text-xs text-[#94a3b8] mt-1">Risk-adjusted return</p>
          </CardContent>
        </Card>

        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-[#94a3b8] flex items-center gap-2">
              {getStreakIcon()}
              Current Streak
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-[#e5e7eb]">
              {analytics.currentStreak.type === 'win' && `${analytics.currentStreak.count}W`}
              {analytics.currentStreak.type === 'loss' && `${analytics.currentStreak.count}L`}
              {analytics.currentStreak.type === 'none' && '—'}
            </div>
            <p className="text-xs text-[#94a3b8] mt-1">
              Best: {analytics.longestWinStreak}W
            </p>
          </CardContent>
        </Card>
      </div>

      {/* ROI by Sport */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#22d3ee] flex items-center gap-2">
            <Trophy className="w-5 h-5" />
            ROI by Sport
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {analytics.roiBySport.map((sport) => (
              <div key={sport.sport} className="space-y-2">
                <div className="flex justify-between items-center">
                  <div>
                    <span className="text-[#e5e7eb] font-medium">{sport.sport}</span>
                    <span className="text-[#94a3b8] text-sm ml-2">({sport.bets} bets)</span>
                  </div>
                  <Badge
                    variant="outline"
                    className={
                      sport.roi >= 5
                        ? 'border-[#22c55e] text-[#22c55e]'
                        : sport.roi >= 0
                        ? 'border-[#22d3ee] text-[#22d3ee]'
                        : 'border-[#ef4444] text-[#ef4444]'
                    }
                  >
                    {formatPercent(sport.roi)}
                  </Badge>
                </div>
                <Progress 
                  value={Math.min(Math.abs(sport.roi) * 2, 100)} 
                  className="h-2 bg-[#0f172a]"
                />
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CLV Tracking */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#22d3ee] flex items-center gap-2">
            <Target className="w-5 h-5" />
            Closing Line Value (CLV)
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="mb-4">
            <div className="flex justify-between items-center">
              <span className="text-[#94a3b8]">Average CLV</span>
              <span className={`text-xl font-bold ${analytics.avgClv >= 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                {analytics.avgClv >= 0 ? '+' : ''}{analytics.avgClv.toFixed(3)}
              </span>
            </div>
            <p className="text-xs text-[#94a3b8] mt-2">
              {analytics.avgClv > 0 && 'You\'re consistently beating closing lines! This indicates sharp play.'}
              {analytics.avgClv === 0 && 'Your bets are matching closing lines. Consider line shopping more.'}
              {analytics.avgClv < 0 && 'You\'re betting worse than closing lines. Focus on earlier entries or better timing.'}
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Additional Metrics */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <CardTitle className="text-[#22d3ee]">Additional Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <div className="text-[#94a3b8] text-sm">Expectancy (per bet)</div>
              <div className={`text-xl font-bold ${analytics.expectancy >= 0 ? 'text-[#22c55e]' : 'text-[#ef4444]'}`}>
                {analytics.expectancy >= 0 ? '+' : ''}${analytics.expectancy.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-[#94a3b8] text-sm">Variance (σ)</div>
              <div className="text-xl font-bold text-[#22d3ee]">
                ${analytics.variance.toFixed(2)}
              </div>
            </div>
            <div>
              <div className="text-[#94a3b8] text-sm">Bets in Slip</div>
              <div className="text-xl font-bold text-[#22d3ee]">
                {betSlip.length}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
