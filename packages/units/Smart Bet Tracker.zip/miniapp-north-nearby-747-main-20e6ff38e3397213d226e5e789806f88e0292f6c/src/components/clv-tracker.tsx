'use client';

import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { EnhancedBet } from '@/types/odds';

interface CLVTrackerProps {
  bets: EnhancedBet[];
}

interface SportCLV {
  sport: string;
  avgCLV: number;
  totalBets: number;
  positiveCount: number;
  negativeCount: number;
}

export function CLVTracker({ bets }: CLVTrackerProps): JSX.Element {
  const clvStats = useMemo(() => {
    const betsWithCLV = bets.filter((bet: EnhancedBet) => bet.clv);
    
    if (betsWithCLV.length === 0) {
      return {
        overall: 0,
        positive: 0,
        negative: 0,
        neutral: 0,
        bySport: [] as SportCLV[]
      };
    }

    const avgCLV = betsWithCLV.reduce(
      (sum: number, bet: EnhancedBet) => sum + (bet.clv?.clvPercent || 0),
      0
    ) / betsWithCLV.length;

    const positive = betsWithCLV.filter((b: EnhancedBet) => (b.clv?.clvPercent || 0) > 1).length;
    const negative = betsWithCLV.filter((b: EnhancedBet) => (b.clv?.clvPercent || 0) < -1).length;
    const neutral = betsWithCLV.length - positive - negative;

    // Calculate CLV by sport
    const sportMap = new Map<string, { total: number; count: number; positive: number; negative: number }>();
    
    betsWithCLV.forEach((bet: EnhancedBet) => {
      if (!bet.clv) return;
      
      const stats = sportMap.get(bet.sport) || { total: 0, count: 0, positive: 0, negative: 0 };
      stats.total += bet.clv.clvPercent;
      stats.count++;
      if (bet.clv.clvPercent > 1) stats.positive++;
      if (bet.clv.clvPercent < -1) stats.negative++;
      sportMap.set(bet.sport, stats);
    });

    const bySport: SportCLV[] = Array.from(sportMap.entries())
      .map(([sport, stats]) => ({
        sport,
        avgCLV: stats.total / stats.count,
        totalBets: stats.count,
        positiveCount: stats.positive,
        negativeCount: stats.negative
      }))
      .sort((a: SportCLV, b: SportCLV) => b.avgCLV - a.avgCLV);

    return { overall: avgCLV, positive, negative, neutral, bySport };
  }, [bets]);

  function getCLVColor(clv: number): string {
    if (clv > 2) return 'text-green-400';
    if (clv > 0) return 'text-green-500';
    if (clv < -2) return 'text-red-400';
    if (clv < 0) return 'text-red-500';
    return 'text-slate-400';
  }

  function getCLVBadge(clv: number): JSX.Element {
    if (clv > 2) return <Badge className="bg-green-500/20 text-green-400 border-green-500/50">Excellent</Badge>;
    if (clv > 0) return <Badge className="bg-green-500/20 text-green-500 border-green-500/50">Good</Badge>;
    if (clv < -2) return <Badge className="bg-red-500/20 text-red-400 border-red-500/50">Poor</Badge>;
    if (clv < 0) return <Badge className="bg-red-500/20 text-red-500 border-red-500/50">Below Average</Badge>;
    return <Badge variant="outline">Neutral</Badge>;
  }

  function getCLVIcon(clv: number): JSX.Element {
    if (clv > 1) return <TrendingUp className="h-4 w-4 text-green-400" />;
    if (clv < -1) return <TrendingDown className="h-4 w-4 text-red-400" />;
    return <Minus className="h-4 w-4 text-slate-400" />;
  }

  const totalBetsWithCLV = bets.filter((b: EnhancedBet) => b.clv).length;

  if (totalBetsWithCLV === 0) {
    return (
      <Card className="bg-slate-900 border-slate-800">
        <CardHeader>
          <CardTitle className="text-cyan-400">Closing Line Value (CLV) Tracker</CardTitle>
          <CardDescription>
            CLV measures how your lines compare to closing market lines - the best predictor of long-term success
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-slate-400">
            <p>Log bets with opening and closing lines to track your CLV performance.</p>
            <p className="text-sm mt-2">
              Positive CLV means you're getting better lines than the market closing price.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-cyan-400">Closing Line Value (CLV) Tracker</CardTitle>
        <CardDescription>
          Tracking {totalBetsWithCLV} bet{totalBetsWithCLV !== 1 ? 's' : ''} with CLV data
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Overall CLV */}
        <div className="p-4 border border-slate-800 rounded-lg">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-slate-400">Overall CLV</span>
            {getCLVBadge(clvStats.overall)}
          </div>
          <div className="flex items-center gap-3">
            {getCLVIcon(clvStats.overall)}
            <span className={`text-3xl font-bold ${getCLVColor(clvStats.overall)}`}>
              {clvStats.overall >= 0 ? '+' : ''}{clvStats.overall.toFixed(2)}%
            </span>
          </div>
          <div className="mt-3 grid grid-cols-3 gap-2 text-xs">
            <div>
              <div className="text-slate-500">Positive</div>
              <div className="text-green-400 font-semibold">{clvStats.positive}</div>
            </div>
            <div>
              <div className="text-slate-500">Neutral</div>
              <div className="text-slate-400 font-semibold">{clvStats.neutral}</div>
            </div>
            <div>
              <div className="text-slate-500">Negative</div>
              <div className="text-red-400 font-semibold">{clvStats.negative}</div>
            </div>
          </div>
          <Progress
            value={((clvStats.positive / totalBetsWithCLV) * 100)}
            className="mt-3 h-2 bg-slate-800"
          />
        </div>

        {/* CLV by Sport */}
        {clvStats.bySport.length > 0 && (
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-300">CLV by Sport</h3>
            {clvStats.bySport.map((sportData: SportCLV) => (
              <div
                key={sportData.sport}
                className="p-3 border border-slate-800 rounded-lg hover:border-slate-700 transition-colors"
              >
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-slate-200">{sportData.sport}</span>
                  <div className="flex items-center gap-2">
                    {getCLVIcon(sportData.avgCLV)}
                    <span className={`font-mono font-semibold ${getCLVColor(sportData.avgCLV)}`}>
                      {sportData.avgCLV >= 0 ? '+' : ''}{sportData.avgCLV.toFixed(2)}%
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between text-xs text-slate-500">
                  <span>{sportData.totalBets} bets</span>
                  <span>
                    {sportData.positiveCount} positive • {sportData.negativeCount} negative
                  </span>
                </div>
                <Progress
                  value={((sportData.positiveCount / sportData.totalBets) * 100)}
                  className="mt-2 h-1 bg-slate-800"
                />
              </div>
            ))}
          </div>
        )}

        {/* CLV Explanation */}
        <div className="p-3 bg-slate-800/50 border border-slate-700 rounded-lg text-xs text-slate-400">
          <p className="font-semibold text-slate-300 mb-1">💡 What is CLV?</p>
          <p>
            Closing Line Value measures how your bet price compares to the final market closing line.
            Positive CLV indicates you're getting better prices than the sharp market consensus - 
            the strongest predictor of long-term profitability.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}
