'use client'

import type { FC } from 'react';
import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  TrendingUp, 
  TrendingDown, 
  Target, 
  Sparkles, 
  Calculator,
  BarChart3,
  MessageSquare,
  Star,
  ArrowRight,
  Activity,
  Zap,
  AlertCircle
} from 'lucide-react';

interface FeaturedGame {
  id: string;
  sport: string;
  league: string;
  homeTeam: string;
  awayTeam: string;
  startTime: string;
  allBooks: Array<{
    bookmaker: string;
    spread?: { homePoint: number; awayPoint: number; homeOdds: number; awayOdds: number };
    moneyline?: { homeOdds: number; awayOdds: number };
    total?: { overPoint: number; underPoint: number; overOdds: number; underOdds: number };
  }>;
}

interface GameAnalysis {
  overview: string;
  valueAssessment: string;
  trends: string[];
  riskFactors: string[];
  recommendations: Array<{
    bet: string;
    confidence: number;
    reasoning: string;
  }>;
  research: {
    injuries: string;
    recentForm: string;
    lineMovement: string;
    weather?: string;
    keyMatchups: string;
    citations: string[];
  };
}

export const FeaturedGameAnalytics: FC = () => {
  const [featuredGames, setFeaturedGames] = useState<FeaturedGame[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedGame, setSelectedGame] = useState<FeaturedGame | null>(null);
  const [gameAnalysis, setGameAnalysis] = useState<GameAnalysis | null>(null);
  const [analyzingGame, setAnalyzingGame] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<string>('overview');
  const [simulatedStake, setSimulatedStake] = useState<string>('100');
  const [simulatedOdds, setSimulatedOdds] = useState<string>('-110');
  const [favoriteGames, setFavoriteGames] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchFeaturedGames();
  }, []);

  const fetchFeaturedGames = async (): Promise<void> => {
    try {
      setLoading(true);
      const response = await fetch('/api/matchups/today');
      const data = await response.json();
      
      if (data.matchups && Array.isArray(data.matchups)) {
        // Get 1-2 featured games per sport
        const sports = ['NFL', 'NBA', 'NHL', 'MLB'];
        const featured: FeaturedGame[] = [];
        
        sports.forEach((sport: string) => {
          const sportGames = data.matchups.filter((g: FeaturedGame) => 
            g.sport.toUpperCase().includes(sport)
          );
          // Take up to 2 games per sport
          featured.push(...sportGames.slice(0, 2));
        });
        
        setFeaturedGames(featured);
        
        // Auto-select first game
        if (featured.length > 0) {
          setSelectedGame(featured[0]);
          analyzeGame(featured[0]);
        }
      }
    } catch (error) {
      console.error('Error fetching featured games:', error);
    } finally {
      setLoading(false);
    }
  };

  const analyzeGame = async (game: FeaturedGame): Promise<void> => {
    try {
      setAnalyzingGame(true);
      const response = await fetch(`/api/matchups/${game.id}/analytics`);
      const data = await response.json();
      
      if (data.analysis) {
        setGameAnalysis(data.analysis);
      }
    } catch (error) {
      console.error('Error analyzing game:', error);
    } finally {
      setAnalyzingGame(false);
    }
  };

  const handleGameSelect = (game: FeaturedGame): void => {
    setSelectedGame(game);
    setGameAnalysis(null);
    analyzeGame(game);
  };

  const toggleFavorite = (gameId: string): void => {
    const newFavorites = new Set(favoriteGames);
    if (newFavorites.has(gameId)) {
      newFavorites.delete(gameId);
    } else {
      newFavorites.add(gameId);
    }
    setFavoriteGames(newFavorites);
  };

  const calculatePotentialProfit = (): { profit: number; toWin: number; risk: number } => {
    const stake = parseFloat(simulatedStake) || 0;
    const odds = parseFloat(simulatedOdds) || 0;
    
    let decimalOdds = 0;
    if (odds >= 100) {
      decimalOdds = (odds / 100) + 1;
    } else if (odds < 0) {
      decimalOdds = (100 / Math.abs(odds)) + 1;
    }
    
    const profit = stake * (decimalOdds - 1);
    return { profit, toWin: profit, risk: stake };
  };

  const getBestOdds = (game: FeaturedGame, market: 'moneyline' | 'spread' | 'total'): { odds: number; bookmaker: string } | null => {
    let bestOdds = -Infinity;
    let bestBookmaker = '';
    
    game.allBooks.forEach((book) => {
      let odds = 0;
      if (market === 'moneyline' && book.moneyline) {
        odds = book.moneyline.homeOdds;
      } else if (market === 'spread' && book.spread) {
        odds = book.spread.homeOdds;
      } else if (market === 'total' && book.total) {
        odds = book.total.overOdds;
      }
      
      if (odds > bestOdds) {
        bestOdds = odds;
        bestBookmaker = book.bookmaker;
      }
    });
    
    return bestOdds > -Infinity ? { odds: bestOdds, bookmaker: bestBookmaker } : null;
  };

  const formatDate = (dateString: string): string => {
    return new Date(dateString).toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const getValueIndicator = (confidence: number): { color: string; label: string } => {
    if (confidence >= 8) return { color: 'text-[#22c55e]', label: 'High Value' };
    if (confidence >= 6) return { color: 'text-[#22d3ee]', label: 'Good Value' };
    if (confidence >= 4) return { color: 'text-[#f59e0b]', label: 'Fair Value' };
    return { color: 'text-[#ef4444]', label: 'Low Value' };
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-48 w-full bg-[#0f172a]" />
        <Skeleton className="h-96 w-full bg-[#0f172a]" />
      </div>
    );
  }

  if (featuredGames.length === 0) {
    return (
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardContent className="py-12 text-center">
          <AlertCircle className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-[#e5e7eb] mb-2">No Featured Games Available</h3>
          <p className="text-[#94a3b8]">
            Check back soon for AI-powered analytics on today's top matchups.
          </p>
        </CardContent>
      </Card>
    );
  }

  const potentialProfit = calculatePotentialProfit();

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-[#0f172a] to-[#1e293b] border-[#22d3ee]">
        <CardHeader>
          <CardTitle className="text-2xl text-[#22d3ee] flex items-center gap-2">
            <Sparkles className="w-6 h-6" />
            Featured Game Analytics
          </CardTitle>
          <CardDescription className="text-[#94a3b8]">
            AI-powered insights on today's top matchups across all sports
          </CardDescription>
        </CardHeader>
      </Card>

      {/* Game Selection Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
        {featuredGames.map((game: FeaturedGame) => {
          const isFavorite = favoriteGames.has(game.id);
          const isSelected = selectedGame?.id === game.id;
          
          return (
            <Card
              key={game.id}
              className={`cursor-pointer transition-all hover:scale-105 ${
                isSelected
                  ? 'bg-[#0f172a] border-[#22d3ee] shadow-lg shadow-cyan-500/20'
                  : 'bg-[#020617] border-[#1e293b] hover:border-[#22d3ee]'
              }`}
              onClick={() => handleGameSelect(game)}
            >
              <CardHeader className="pb-3">
                <div className="flex justify-between items-start mb-2">
                  <Badge className="bg-[#22d3ee] text-[#020617]">
                    {game.sport}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    className="h-8 w-8 p-0"
                    onClick={(e: React.MouseEvent<HTMLButtonElement>) => {
                      e.stopPropagation();
                      toggleFavorite(game.id);
                    }}
                  >
                    <Star
                      className={`w-4 h-4 ${
                        isFavorite ? 'fill-[#f59e0b] text-[#f59e0b]' : 'text-[#94a3b8]'
                      }`}
                    />
                  </Button>
                </div>
                <CardTitle className="text-lg text-[#e5e7eb]">
                  {game.awayTeam} @ {game.homeTeam}
                </CardTitle>
                <p className="text-xs text-[#94a3b8]">{formatDate(game.startTime)}</p>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2 text-sm text-[#22d3ee]">
                  <Activity className="w-4 h-4" />
                  <span>{game.allBooks.length} books available</span>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Selected Game Analysis */}
      {selectedGame && (
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-2xl text-[#22d3ee] mb-2">
                  {selectedGame.awayTeam} @ {selectedGame.homeTeam}
                </CardTitle>
                <CardDescription className="text-[#94a3b8]">
                  {selectedGame.sport} • {formatDate(selectedGame.startTime)}
                </CardDescription>
              </div>
              <Button
                onClick={() => analyzeGame(selectedGame)}
                disabled={analyzingGame}
                className="bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
              >
                {analyzingGame ? (
                  <>
                    <div className="w-4 h-4 border-2 border-[#020617] border-t-transparent rounded-full animate-spin mr-2" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 mr-2" />
                    Refresh Analysis
                  </>
                )}
              </Button>
            </div>
          </CardHeader>

          <CardContent>
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="bg-[#0f172a] border border-[#1e293b] mb-6">
                <TabsTrigger value="overview" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                  <Target className="w-4 h-4 mr-2" />
                  Overview
                </TabsTrigger>
                <TabsTrigger value="research" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Research
                </TabsTrigger>
                <TabsTrigger value="recommendations" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                  <Zap className="w-4 h-4 mr-2" />
                  Recommendations
                </TabsTrigger>
                <TabsTrigger value="simulator" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                  <Calculator className="w-4 h-4 mr-2" />
                  Bet Simulator
                </TabsTrigger>
              </TabsList>

              {/* Overview Tab */}
              <TabsContent value="overview" className="space-y-4">
                {analyzingGame ? (
                  <div className="space-y-3">
                    <Skeleton className="h-24 w-full bg-[#0f172a]" />
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                  </div>
                ) : gameAnalysis ? (
                  <>
                    <div className="p-4 bg-[#0f172a] rounded-lg border border-[#1e293b]">
                      <h3 className="text-lg font-semibold text-[#22d3ee] mb-2 flex items-center gap-2">
                        <MessageSquare className="w-5 h-5" />
                        AI Overview
                      </h3>
                      <p className="text-[#e5e7eb] leading-relaxed">{gameAnalysis.overview}</p>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4">
                      <Card className="bg-[#0f172a] border-[#1e293b]">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-md text-[#22d3ee] flex items-center gap-2">
                            <TrendingUp className="w-4 h-4" />
                            Key Trends
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {gameAnalysis.trends.map((trend: string, idx: number) => (
                              <li key={idx} className="flex items-start gap-2 text-sm text-[#e5e7eb]">
                                <ArrowRight className="w-4 h-4 text-[#22c55e] mt-0.5 flex-shrink-0" />
                                <span>{trend}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>

                      <Card className="bg-[#0f172a] border-[#1e293b]">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-md text-[#22d3ee] flex items-center gap-2">
                            <AlertCircle className="w-4 h-4" />
                            Risk Factors
                          </CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-2">
                            {gameAnalysis.riskFactors.map((risk: string, idx: number) => (
                              <li key={idx} className="flex items-start gap-2 text-sm text-[#e5e7eb]">
                                <TrendingDown className="w-4 h-4 text-[#ef4444] mt-0.5 flex-shrink-0" />
                                <span>{risk}</span>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    </div>

                    <div className="p-4 bg-[#0f172a] rounded-lg border border-[#1e293b]">
                      <h3 className="text-lg font-semibold text-[#22d3ee] mb-2">Value Assessment</h3>
                      <p className="text-[#e5e7eb]">{gameAnalysis.valueAssessment}</p>
                    </div>
                  </>
                ) : (
                  <div className="text-center py-12">
                    <Sparkles className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
                    <p className="text-[#94a3b8]">Click "Refresh Analysis" to get AI insights for this game</p>
                  </div>
                )}
              </TabsContent>

              {/* Research Tab */}
              <TabsContent value="research" className="space-y-4">
                {analyzingGame ? (
                  <div className="space-y-3">
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                  </div>
                ) : gameAnalysis?.research ? (
                  <div className="space-y-4">
                    <Card className="bg-[#0f172a] border-[#1e293b]">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-md text-[#22d3ee]">Injury Reports</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-[#e5e7eb] text-sm">{gameAnalysis.research.injuries}</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-[#0f172a] border-[#1e293b]">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-md text-[#22d3ee]">Recent Form (Last 5 Games)</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-[#e5e7eb] text-sm">{gameAnalysis.research.recentForm}</p>
                      </CardContent>
                    </Card>

                    <Card className="bg-[#0f172a] border-[#1e293b]">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-md text-[#22d3ee]">Line Movement Analysis</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-[#e5e7eb] text-sm">{gameAnalysis.research.lineMovement}</p>
                      </CardContent>
                    </Card>

                    {gameAnalysis.research.weather && (
                      <Card className="bg-[#0f172a] border-[#1e293b]">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-md text-[#22d3ee]">Weather Conditions</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-[#e5e7eb] text-sm">{gameAnalysis.research.weather}</p>
                        </CardContent>
                      </Card>
                    )}

                    <Card className="bg-[#0f172a] border-[#1e293b]">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-md text-[#22d3ee]">Key Matchup Advantages</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-[#e5e7eb] text-sm">{gameAnalysis.research.keyMatchups}</p>
                      </CardContent>
                    </Card>

                    {gameAnalysis.research.citations.length > 0 && (
                      <Card className="bg-[#0f172a] border-[#1e293b]">
                        <CardHeader className="pb-3">
                          <CardTitle className="text-md text-[#22d3ee]">Sources</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <ul className="space-y-1">
                            {gameAnalysis.research.citations.map((citation: string, idx: number) => (
                              <li key={idx} className="text-xs text-[#22d3ee] hover:text-[#06b6d4]">
                                <a href={citation} target="_blank" rel="noopener noreferrer">
                                  {citation}
                                </a>
                              </li>
                            ))}
                          </ul>
                        </CardContent>
                      </Card>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BarChart3 className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
                    <p className="text-[#94a3b8]">Get AI-powered research insights for this matchup</p>
                  </div>
                )}
              </TabsContent>

              {/* Recommendations Tab */}
              <TabsContent value="recommendations" className="space-y-4">
                {analyzingGame ? (
                  <div className="space-y-3">
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                    <Skeleton className="h-32 w-full bg-[#0f172a]" />
                  </div>
                ) : gameAnalysis?.recommendations && gameAnalysis.recommendations.length > 0 ? (
                  <div className="space-y-4">
                    {gameAnalysis.recommendations.map((rec, idx: number) => {
                      const valueInfo = getValueIndicator(rec.confidence);
                      return (
                        <Card key={idx} className="bg-[#0f172a] border-[#1e293b]">
                          <CardHeader className="pb-3">
                            <div className="flex justify-between items-start">
                              <CardTitle className="text-lg text-[#e5e7eb]">{rec.bet}</CardTitle>
                              <Badge className={`${valueInfo.color} border-current`} variant="outline">
                                {rec.confidence}/10 • {valueInfo.label}
                              </Badge>
                            </div>
                          </CardHeader>
                          <CardContent>
                            <p className="text-[#e5e7eb] text-sm mb-4">{rec.reasoning}</p>
                            <Button
                              className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
                              onClick={() => {
                                setActiveTab('simulator');
                                setSimulatedOdds('-110');
                              }}
                            >
                              Simulate This Bet
                            </Button>
                          </CardContent>
                        </Card>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Zap className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
                    <p className="text-[#94a3b8]">AI betting recommendations will appear here</p>
                  </div>
                )}
              </TabsContent>

              {/* Bet Simulator Tab */}
              <TabsContent value="simulator" className="space-y-4">
                <Card className="bg-[#0f172a] border-[#1e293b]">
                  <CardHeader>
                    <CardTitle className="text-lg text-[#22d3ee] flex items-center gap-2">
                      <Calculator className="w-5 h-5" />
                      Betting Calculator
                    </CardTitle>
                    <CardDescription className="text-[#94a3b8]">
                      Calculate potential profits without logging a bet
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid md:grid-cols-2 gap-4">
                      <div className="grid gap-2">
                        <Label htmlFor="sim-stake" className="text-[#e5e7eb]">Stake Amount ($)</Label>
                        <Input
                          id="sim-stake"
                          type="number"
                          value={simulatedStake}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSimulatedStake(e.target.value)}
                          className="bg-[#020617] border-[#1e293b] text-[#e5e7eb]"
                          placeholder="100"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="sim-odds" className="text-[#e5e7eb]">American Odds</Label>
                        <Input
                          id="sim-odds"
                          type="number"
                          value={simulatedOdds}
                          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSimulatedOdds(e.target.value)}
                          className="bg-[#020617] border-[#1e293b] text-[#e5e7eb]"
                          placeholder="-110"
                        />
                      </div>
                    </div>

                    <div className="p-6 bg-[#020617] rounded-lg border border-[#22d3ee] space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-[#94a3b8]">Risk:</span>
                        <span className="text-2xl font-bold text-[#ef4444]">
                          ${potentialProfit.risk.toFixed(2)}
                        </span>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[#94a3b8]">To Win:</span>
                        <span className="text-2xl font-bold text-[#22c55e]">
                          ${potentialProfit.toWin.toFixed(2)}
                        </span>
                      </div>
                      <div className="pt-4 border-t border-[#1e293b]">
                        <div className="flex justify-between items-center">
                          <span className="text-[#94a3b8]">Total Payout:</span>
                          <span className="text-3xl font-bold text-[#22d3ee]">
                            ${(potentialProfit.risk + potentialProfit.toWin).toFixed(2)}
                          </span>
                        </div>
                      </div>
                    </div>

                    <Button
                      className="w-full bg-gradient-to-r from-[#22d3ee] to-[#06b6d4] hover:from-[#06b6d4] hover:to-[#22d3ee] text-[#020617] font-semibold"
                      onClick={() => {
                        // Navigate to dashboard tab to actually log the bet
                        const dashboardTab = document.querySelector('[value="dashboard"]') as HTMLElement;
                        dashboardTab?.click();
                      }}
                    >
                      Log This Bet to Dashboard
                    </Button>
                  </CardContent>
                </Card>

                {/* Best Odds Display */}
                <Card className="bg-[#0f172a] border-[#1e293b]">
                  <CardHeader>
                    <CardTitle className="text-lg text-[#22d3ee]">Best Available Odds</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {(['moneyline', 'spread', 'total'] as const).map((marketKey) => {
                      const best = getBestOdds(selectedGame, marketKey);
                      if (!best) return null;
                      
                      return (
                        <div key={marketKey} className="flex justify-between items-center p-3 bg-[#020617] rounded-lg">
                          <div>
                            <p className="text-[#e5e7eb] font-medium capitalize">
                              {marketKey}
                            </p>
                            <p className="text-xs text-[#94a3b8]">{best.bookmaker}</p>
                          </div>
                          <Badge className="bg-[#22d3ee] text-[#020617]">
                            {best.odds > 0 ? '+' : ''}{best.odds}
                          </Badge>
                        </div>
                      );
                    })}
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
