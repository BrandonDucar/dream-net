'use client'
import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertCircle, TrendingUp, Target, Activity, Sparkles, ExternalLink, AlertTriangle } from 'lucide-react';

interface Matchup {
  id: string;
  sport: string;
  sportKey: string;
  league: string;
  startTime: string;
  homeTeam: string;
  awayTeam: string;
  odds: {
    spread: {
      homePoint: number;
      awayPoint: number;
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    moneyline: {
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    total: {
      overPoint: number;
      underPoint: number;
      overOdds: number;
      underOdds: number;
      bookmaker: string;
    } | null;
  };
  allBooks: Array<{
    bookmaker: string;
    spread?: { homePoint: number; awayPoint: number; homeOdds: number; awayOdds: number };
    moneyline?: { homeOdds: number; awayOdds: number };
    total?: { overPoint: number; underPoint: number; overOdds: number; underOdds: number };
  }>;
}

interface GameAnalytics {
  perplexityInsights: {
    injuries: string;
    recentForm: string;
    lineMovement: string;
    weather: string;
    keyMatchups: string;
    citations: string[];
  };
  openaiAnalysis: {
    valueAssessment: string;
    trendIdentification: string;
    riskFactors: string;
    recommendedBets: Array<{
      type: string;
      selection: string;
      confidence: number;
      reasoning: string;
    }>;
  };
}

interface GameAnalyticsModalProps {
  game: Matchup;
  open: boolean;
  onClose: () => void;
  onAddToBetSlip: (
    matchup: Matchup,
    betType: 'spread' | 'moneyline' | 'total',
    selection: string,
    odds: number,
    bookmaker: string
  ) => void;
}

export function GameAnalyticsModal({ game, open, onClose, onAddToBetSlip }: GameAnalyticsModalProps): JSX.Element {
  const [analytics, setAnalytics] = useState<GameAnalytics | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open && game) {
      fetchAnalytics();
    }
  }, [open, game]);

  const fetchAnalytics = async (): Promise<void> => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/matchups/${game.id}/analytics`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          gameId: game.id,
          homeTeam: game.homeTeam,
          awayTeam: game.awayTeam,
          sport: game.sport,
          spread: game.odds.spread?.homePoint,
          total: game.odds.total?.overPoint,
          moneyline: game.odds.moneyline
            ? { home: game.odds.moneyline.homeOdds, away: game.odds.moneyline.awayOdds }
            : undefined
        })
      });

      const data = await response.json();

      if (data.success && data.analytics) {
        setAnalytics(data.analytics);
      } else {
        setError('Failed to load analytics');
      }
    } catch (err) {
      console.error('Error fetching analytics:', err);
      setError('Failed to load analytics');
    } finally {
      setLoading(false);
    }
  };

  const getConfidenceColor = (confidence: number): string => {
    if (confidence >= 8) return 'text-green-400';
    if (confidence >= 6) return 'text-cyan-400';
    if (confidence >= 4) return 'text-yellow-400';
    return 'text-red-400';
  };

  const getConfidenceBadge = (confidence: number): string => {
    if (confidence >= 8) return 'High';
    if (confidence >= 6) return 'Medium';
    return 'Low';
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-[#020617] border-[#1e293b] text-[#e5e7eb] max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-[#22d3ee] text-2xl flex items-center gap-2">
            <Sparkles className="w-6 h-6" />
            Game Analytics
          </DialogTitle>
          <DialogDescription className="text-[#94a3b8]">
            {game.awayTeam} @ {game.homeTeam}
          </DialogDescription>
        </DialogHeader>

        {loading ? (
          <div className="space-y-4 py-6">
            <Skeleton className="h-8 w-full bg-[#1e293b]" />
            <Skeleton className="h-32 w-full bg-[#1e293b]" />
            <Skeleton className="h-32 w-full bg-[#1e293b]" />
            <Skeleton className="h-24 w-full bg-[#1e293b]" />
          </div>
        ) : error ? (
          <div className="py-12 text-center">
            <AlertCircle className="w-12 h-12 text-[#ef4444] mx-auto mb-4" />
            <p className="text-[#94a3b8]">{error}</p>
            <Button onClick={fetchAnalytics} className="mt-4 bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]">
              Retry
            </Button>
          </div>
        ) : analytics ? (
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="bg-[#0f172a] border border-[#1e293b] w-full">
              <TabsTrigger value="overview" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                Overview
              </TabsTrigger>
              <TabsTrigger value="research" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                Research
              </TabsTrigger>
              <TabsTrigger value="bets" className="data-[state=active]:bg-[#22d3ee] data-[state=active]:text-[#020617]">
                Recommendations
              </TabsTrigger>
            </TabsList>

            {/* Overview Tab */}
            <TabsContent value="overview" className="space-y-4">
              <Card className="bg-[#0f172a] border-[#1e293b]">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-3">
                    <Target className="w-5 h-5 text-[#22d3ee]" />
                    <h3 className="font-semibold text-[#22d3ee]">Value Assessment</h3>
                  </div>
                  <p className="text-[#e5e7eb] leading-relaxed">{analytics.openaiAnalysis.valueAssessment}</p>
                </CardContent>
              </Card>

              <Card className="bg-[#0f172a] border-[#1e293b]">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-3">
                    <TrendingUp className="w-5 h-5 text-[#22d3ee]" />
                    <h3 className="font-semibold text-[#22d3ee]">Trend Identification</h3>
                  </div>
                  <p className="text-[#e5e7eb] leading-relaxed">{analytics.openaiAnalysis.trendIdentification}</p>
                </CardContent>
              </Card>

              <Card className="bg-[#0f172a] border-[#1e293b]">
                <CardContent className="pt-6">
                  <div className="flex items-center gap-2 mb-3">
                    <AlertTriangle className="w-5 h-5 text-[#ef4444]" />
                    <h3 className="font-semibold text-[#ef4444]">Risk Factors</h3>
                  </div>
                  <p className="text-[#e5e7eb] leading-relaxed">{analytics.openaiAnalysis.riskFactors}</p>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Research Tab */}
            <TabsContent value="research" className="space-y-4">
              <Card className="bg-[#0f172a] border-[#1e293b]">
                <CardContent className="pt-6 space-y-4">
                  <div>
                    <h3 className="font-semibold text-[#22d3ee] mb-2 flex items-center gap-2">
                      <Activity className="w-4 h-4" />
                      Injury Reports
                    </h3>
                    <p className="text-[#e5e7eb] text-sm leading-relaxed">{analytics.perplexityInsights.injuries}</p>
                  </div>

                  <div className="border-t border-[#1e293b] pt-4">
                    <h3 className="font-semibold text-[#22d3ee] mb-2 flex items-center gap-2">
                      <TrendingUp className="w-4 h-4" />
                      Recent Form
                    </h3>
                    <p className="text-[#e5e7eb] text-sm leading-relaxed">{analytics.perplexityInsights.recentForm}</p>
                  </div>

                  <div className="border-t border-[#1e293b] pt-4">
                    <h3 className="font-semibold text-[#22d3ee] mb-2">Line Movement Analysis</h3>
                    <p className="text-[#e5e7eb] text-sm leading-relaxed">{analytics.perplexityInsights.lineMovement}</p>
                  </div>

                  <div className="border-t border-[#1e293b] pt-4">
                    <h3 className="font-semibold text-[#22d3ee] mb-2">Weather Conditions</h3>
                    <p className="text-[#e5e7eb] text-sm leading-relaxed">{analytics.perplexityInsights.weather}</p>
                  </div>

                  <div className="border-t border-[#1e293b] pt-4">
                    <h3 className="font-semibold text-[#22d3ee] mb-2">Key Matchups</h3>
                    <p className="text-[#e5e7eb] text-sm leading-relaxed">{analytics.perplexityInsights.keyMatchups}</p>
                  </div>

                  {analytics.perplexityInsights.citations.length > 0 && (
                    <div className="border-t border-[#1e293b] pt-4">
                      <h3 className="font-semibold text-[#22d3ee] mb-2 text-sm">Sources</h3>
                      <div className="space-y-1">
                        {analytics.perplexityInsights.citations.slice(0, 5).map((citation, idx) => (
                          <a
                            key={idx}
                            href={citation}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-2 text-xs text-cyan-400 hover:text-cyan-300"
                          >
                            <ExternalLink className="w-3 h-3" />
                            {new URL(citation).hostname}
                          </a>
                        ))}
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {/* Recommendations Tab */}
            <TabsContent value="bets" className="space-y-4">
              {analytics.openaiAnalysis.recommendedBets.length > 0 ? (
                analytics.openaiAnalysis.recommendedBets.map((bet, idx) => (
                  <Card key={idx} className="bg-[#0f172a] border-[#1e293b]">
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-3">
                          <Badge variant="outline" className="border-[#22d3ee] text-[#22d3ee]">
                            {bet.type.toUpperCase()}
                          </Badge>
                          <span className="font-semibold text-[#e5e7eb]">{bet.selection}</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs text-[#94a3b8]">Confidence:</span>
                          <Badge
                            variant="outline"
                            className={`${
                              bet.confidence >= 8
                                ? 'border-green-400 text-green-400'
                                : bet.confidence >= 6
                                ? 'border-cyan-400 text-cyan-400'
                                : 'border-yellow-400 text-yellow-400'
                            }`}
                          >
                            {getConfidenceBadge(bet.confidence)} ({bet.confidence}/10)
                          </Badge>
                        </div>
                      </div>
                      <p className="text-[#e5e7eb] text-sm leading-relaxed mb-4">{bet.reasoning}</p>
                      <Button
                        onClick={() => {
                          // Find matching odds from game data
                          let odds = -110;
                          let bookmaker = 'DraftKings';
                          
                          if (bet.type === 'spread' && game.odds.spread) {
                            odds = bet.selection.includes(game.homeTeam)
                              ? game.odds.spread.homeOdds
                              : game.odds.spread.awayOdds;
                            bookmaker = game.odds.spread.bookmaker;
                          } else if (bet.type === 'total' && game.odds.total) {
                            odds = bet.selection.toLowerCase().includes('over')
                              ? game.odds.total.overOdds
                              : game.odds.total.underOdds;
                            bookmaker = game.odds.total.bookmaker;
                          } else if (bet.type === 'moneyline' && game.odds.moneyline) {
                            odds = bet.selection.includes(game.homeTeam)
                              ? game.odds.moneyline.homeOdds
                              : game.odds.moneyline.awayOdds;
                            bookmaker = game.odds.moneyline.bookmaker;
                          }

                          onAddToBetSlip(
                            game,
                            bet.type as 'spread' | 'moneyline' | 'total',
                            bet.selection,
                            odds,
                            bookmaker
                          );
                          onClose();
                        }}
                        className="w-full bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
                      >
                        Add to Bet Slip
                      </Button>
                    </CardContent>
                  </Card>
                ))
              ) : (
                <Card className="bg-[#0f172a] border-[#1e293b]">
                  <CardContent className="py-12 text-center">
                    <AlertCircle className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
                    <p className="text-[#94a3b8]">No specific bet recommendations at this time.</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
