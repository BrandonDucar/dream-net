'use client'

import { useState, useEffect, type FC } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { MapPin, Shield, ExternalLink, Loader2, CheckCircle2, XCircle } from 'lucide-react';
import { checkLegalJurisdiction, getLineShoppingRecommendations, getLocalPromos, type UserState } from '@/lib/geofencing';

export const GeofencingPanel: FC = () => {
  const [isChecking, setIsChecking] = useState<boolean>(false);
  const [state, setState] = useState<UserState | null>(null);
  const [isLegal, setIsLegal] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [hasChecked, setHasChecked] = useState<boolean>(false);

  const checkLocation = async (): Promise<void> => {
    setIsChecking(true);
    setError(null);

    try {
      const result = await checkLegalJurisdiction();
      setIsLegal(result.isLegal);
      setState(result.state);
      setHasChecked(true);

      if (!result.state) {
        setError('Unable to determine your location or you are not in a legal betting jurisdiction.');
      }
    } catch (err) {
      setError('Location services unavailable. Please enable location access.');
    } finally {
      setIsChecking(false);
    }
  };

  useEffect(() => {
    // Auto-check on mount
    checkLocation();
  }, []);

  return (
    <Card className="bg-[#020617] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] flex items-center gap-2">
          <MapPin className="w-5 h-5" />
          Location & Legal Info
        </CardTitle>
        <CardDescription className="text-[#94a3b8]">
          Verify legal betting status and find local sportsbooks
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Status Check */}
        {!hasChecked && (
          <div className="flex items-center justify-center py-8">
            <Button
              onClick={checkLocation}
              disabled={isChecking}
              className="bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
            >
              {isChecking ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Checking Location...
                </>
              ) : (
                <>
                  <MapPin className="w-4 h-4 mr-2" />
                  Check My Location
                </>
              )}
            </Button>
          </div>
        )}

        {/* Error State */}
        {error && (
          <Alert className="bg-[#0f172a] border-[#ef4444]">
            <XCircle className="w-4 h-4 text-[#ef4444]" />
            <AlertDescription className="text-[#ef4444]">{error}</AlertDescription>
          </Alert>
        )}

        {/* Legal State Detected */}
        {state && isLegal && (
          <>
            <Alert className="bg-[#0f172a] border-[#22c55e]">
              <CheckCircle2 className="w-4 h-4 text-[#22c55e]" />
              <AlertDescription className="text-[#22c55e]">
                Sports betting is legal in {state.name}
              </AlertDescription>
            </Alert>

            {/* Available Sportsbooks */}
            <div>
              <h3 className="text-sm font-semibold text-[#e5e7eb] mb-2">Legal Sportsbooks in {state.name}</h3>
              <div className="grid grid-cols-2 gap-2">
                {state.legalSportsbooks.map((book: string) => (
                  <Badge
                    key={book}
                    variant="outline"
                    className="border-[#22d3ee] text-[#22d3ee] justify-center py-2"
                  >
                    {book}
                  </Badge>
                ))}
              </div>
            </div>

            {/* Line Shopping Tips */}
            <div className="border-t border-[#1e293b] pt-4">
              <h3 className="text-sm font-semibold text-[#e5e7eb] mb-2 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Line Shopping Tips
              </h3>
              <div className="space-y-2 text-sm text-[#94a3b8]">
                {getLineShoppingRecommendations(state).map((tip: string, index: number) => (
                  <p key={index}>{tip}</p>
                ))}
              </div>
            </div>

            {/* Promotions */}
            <div className="border-t border-[#1e293b] pt-4">
              <h3 className="text-sm font-semibold text-[#e5e7eb] mb-2">Local Promotions</h3>
              <div className="space-y-2">
                {getLocalPromos(state).slice(0, 3).map((promo) => (
                  <div
                    key={promo.book}
                    className="flex justify-between items-center p-2 bg-[#0f172a] rounded"
                  >
                    <span className="text-[#e5e7eb] text-sm">{promo.book}</span>
                    <span className="text-[#94a3b8] text-xs">{promo.promo}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Responsible Gaming Resources */}
            <div className="border-t border-[#1e293b] pt-4">
              <h3 className="text-sm font-semibold text-[#e5e7eb] mb-2 flex items-center gap-2">
                <Shield className="w-4 h-4" />
                Responsible Gaming Resources
              </h3>
              <div className="space-y-2">
                {state.responsibleGamingResources.map((resource: string, index: number) => (
                  <div key={index} className="flex items-start gap-2 text-sm text-[#94a3b8]">
                    <ExternalLink className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    <span>{resource}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {/* Not Legal State */}
        {hasChecked && (!state || !isLegal) && !error && (
          <Alert className="bg-[#0f172a] border-[#f59e0b]">
            <AlertDescription className="text-[#f59e0b]">
              Sports betting may not be legal in your current location. Please verify local laws.
            </AlertDescription>
          </Alert>
        )}

        {/* Refresh Button */}
        {hasChecked && (
          <Button
            onClick={checkLocation}
            disabled={isChecking}
            variant="outline"
            className="w-full border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
          >
            {isChecking ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Checking...
              </>
            ) : (
              <>
                <MapPin className="w-4 h-4 mr-2" />
                Refresh Location
              </>
            )}
          </Button>
        )}
      </CardContent>
    </Card>
  );
};
