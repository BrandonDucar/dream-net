'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { RefreshCw, TrendingUp, TrendingDown } from 'lucide-react';
import type { GameOdds, BookmakerOdds } from '@/types/odds';

interface LiveOddsDisplayProps {
  onSelectBet?: (bet: {
    description: string;
    sport: string;
    odds: number;
    bookmaker: string;
  }) => void;
}

export function LiveOddsDisplay({ onSelectBet }: LiveOddsDisplayProps): JSX.Element {
  const [games, setGames] = useState<GameOdds[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [selectedSport, setSelectedSport] = useState<string>('americanfootball_nfl');
  const [lastUpdate, setLastUpdate] = useState<number>(Date.now());

  const sports = [
    { key: 'americanfootball_nfl', name: 'NFL' },
    { key: 'basketball_nba', name: 'NBA' },
    { key: 'icehockey_nhl', name: 'NHL' },
    { key: 'baseball_mlb', name: 'MLB' }
  ];

  useEffect(() => {
    fetchLiveOdds();
    const interval = setInterval(fetchLiveOdds, 30000); // Refresh every 30 seconds
    return () => clearInterval(interval);
  }, [selectedSport]);

  async function fetchLiveOdds(): Promise<void> {
    try {
      setLoading(true);
      const response = await fetch(
        `/api/odds/live?sport=${selectedSport}&markets=h2h,spreads,totals`
      );
      const data: { games: GameOdds[] } = await response.json();
      setGames(data.games || []);
      setLastUpdate(Date.now());
    } catch (error: unknown) {
      console.error('Error fetching live odds:', error);
    } finally {
      setLoading(false);
    }
  }

  function getBestLine(game: GameOdds, marketKey: string, teamName: string): {
    odds: number;
    point?: number;
    bookmaker: string;
  } | null {
    let bestOdds = -Infinity;
    let bestPoint: number | undefined = undefined;
    let bestBookmaker = '';

    game.bookmakers.forEach((bookmaker: BookmakerOdds) => {
      const market = bookmaker.markets.find((m: { key: string }) => m.key === marketKey);
      if (!market) return;

      const outcome = market.outcomes.find((o: { name: string }) => o.name === teamName);
      if (!outcome) return;

      if (outcome.price > bestOdds) {
        bestOdds = outcome.price;
        bestPoint = outcome.point;
        bestBookmaker = bookmaker.title;
      }
    });

    if (bestOdds === -Infinity) return null;
    return { odds: bestOdds, point: bestPoint, bookmaker: bestBookmaker };
  }

  function formatOdds(odds: number): string {
    return odds > 0 ? `+${odds}` : `${odds}`;
  }

  function getLineMovementIcon(opening?: number, current?: number): JSX.Element | null {
    if (!opening || !current) return null;
    if (current > opening) return <TrendingUp className="h-3 w-3 text-green-500" />;
    if (current < opening) return <TrendingDown className="h-3 w-3 text-red-500" />;
    return null;
  }

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="text-cyan-400">Live Odds - Line Shopping</CardTitle>
            <CardDescription>
              Best available lines across major sportsbooks • Updated{' '}
              {Math.floor((Date.now() - lastUpdate) / 1000)}s ago
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Select value={selectedSport} onValueChange={setSelectedSport}>
              <SelectTrigger className="w-32 bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {sports.map((sport: { key: string; name: string }) => (
                  <SelectItem key={sport.key} value={sport.key}>
                    {sport.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button
              variant="outline"
              size="icon"
              onClick={() => void fetchLiveOdds()}
              disabled={loading}
              className="bg-slate-800 border-slate-700"
            >
              <RefreshCw className={`h-4 w-4 ${loading ? 'animate-spin' : ''}`} />
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {loading && games.length === 0 ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i: number) => (
              <Skeleton key={i} className="h-32 w-full bg-slate-800" />
            ))}
          </div>
        ) : games.length === 0 ? (
          <div className="text-center py-8 text-slate-400">
            No upcoming games found. Try a different sport.
          </div>
        ) : (
          <div className="space-y-4">
            {games.slice(0, 5).map((game: GameOdds) => {
              const awaySpread = getBestLine(game, 'spreads', game.away_team);
              const homeSpread = getBestLine(game, 'spreads', game.home_team);
              const awayML = getBestLine(game, 'h2h', game.away_team);
              const homeML = getBestLine(game, 'h2h', game.home_team);

              return (
                <div
                  key={game.id}
                  className="p-4 border border-slate-800 rounded-lg hover:border-cyan-400/50 transition-colors"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <div className="font-semibold text-slate-100">
                        {game.away_team} @ {game.home_team}
                      </div>
                      <div className="text-sm text-slate-400">
                        {new Date(game.commence_time).toLocaleString('en-US', {
                          month: 'short',
                          day: 'numeric',
                          hour: 'numeric',
                          minute: '2-digit'
                        })}
                      </div>
                    </div>
                    <Badge variant="outline" className="text-cyan-400 border-cyan-400/50">
                      {game.bookmakers.length} books
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    {/* Away Team */}
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-slate-300">{game.away_team}</div>
                      
                      {awaySpread && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full justify-between bg-slate-800 border-slate-700 hover:bg-slate-700"
                          onClick={() =>
                            onSelectBet?.({
                              description: `${game.away_team} ${formatOdds(awaySpread.point || 0)}`,
                              sport: game.sport_title,
                              odds: awaySpread.odds,
                              bookmaker: awaySpread.bookmaker
                            })
                          }
                        >
                          <span className="text-xs text-slate-400">Spread</span>
                          <div className="flex items-center gap-1">
                            <span className="font-mono">
                              {awaySpread.point ? formatOdds(awaySpread.point) : ''}{' '}
                              {formatOdds(awaySpread.odds)}
                            </span>
                            {getLineMovementIcon(awaySpread.point, awaySpread.point)}
                          </div>
                        </Button>
                      )}

                      {awayML && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full justify-between bg-slate-800 border-slate-700 hover:bg-slate-700"
                          onClick={() =>
                            onSelectBet?.({
                              description: `${game.away_team} ML`,
                              sport: game.sport_title,
                              odds: awayML.odds,
                              bookmaker: awayML.bookmaker
                            })
                          }
                        >
                          <span className="text-xs text-slate-400">ML</span>
                          <span className="font-mono">{formatOdds(awayML.odds)}</span>
                        </Button>
                      )}

                      {awaySpread && (
                        <div className="text-xs text-slate-500 text-right">
                          Best: {awaySpread.bookmaker}
                        </div>
                      )}
                    </div>

                    {/* Home Team */}
                    <div className="space-y-2">
                      <div className="text-sm font-medium text-slate-300">{game.home_team}</div>
                      
                      {homeSpread && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full justify-between bg-slate-800 border-slate-700 hover:bg-slate-700"
                          onClick={() =>
                            onSelectBet?.({
                              description: `${game.home_team} ${formatOdds(homeSpread.point || 0)}`,
                              sport: game.sport_title,
                              odds: homeSpread.odds,
                              bookmaker: homeSpread.bookmaker
                            })
                          }
                        >
                          <span className="text-xs text-slate-400">Spread</span>
                          <div className="flex items-center gap-1">
                            <span className="font-mono">
                              {homeSpread.point ? formatOdds(homeSpread.point) : ''}{' '}
                              {formatOdds(homeSpread.odds)}
                            </span>
                            {getLineMovementIcon(homeSpread.point, homeSpread.point)}
                          </div>
                        </Button>
                      )}

                      {homeML && (
                        <Button
                          variant="outline"
                          size="sm"
                          className="w-full justify-between bg-slate-800 border-slate-700 hover:bg-slate-700"
                          onClick={() =>
                            onSelectBet?.({
                              description: `${game.home_team} ML`,
                              sport: game.sport_title,
                              odds: homeML.odds,
                              bookmaker: homeML.bookmaker
                            })
                          }
                        >
                          <span className="text-xs text-slate-400">ML</span>
                          <span className="font-mono">{formatOdds(homeML.odds)}</span>
                        </Button>
                      )}

                      {homeSpread && (
                        <div className="text-xs text-slate-500 text-right">
                          Best: {homeSpread.bookmaker}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
