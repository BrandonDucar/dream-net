'use client'
import { useState, useEffect, useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown, Minus, Clock, AlertCircle, Sparkles, Target, Activity, RefreshCw } from 'lucide-react';
import { GameAnalyticsModal } from './game-analytics-modal';

interface Score {
  id: string;
  sport: string;
  sportKey: string;
  startTime: string;
  completed: boolean;
  homeTeam: string;
  awayTeam: string;
  homeScore: number | null;
  awayScore: number | null;
  status: 'upcoming' | 'live' | 'final';
  lastUpdate: string | null;
}

interface Matchup {
  id: string;
  sport: string;
  sportKey: string;
  league: string;
  startTime: string;
  homeTeam: string;
  awayTeam: string;
  odds: {
    spread: {
      homePoint: number;
      awayPoint: number;
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    moneyline: {
      homeOdds: number;
      awayOdds: number;
      bookmaker: string;
    } | null;
    total: {
      overPoint: number;
      underPoint: number;
      overOdds: number;
      underOdds: number;
      bookmaker: string;
    } | null;
  };
  allBooks: Array<{
    bookmaker: string;
    spread?: { homePoint: number; awayPoint: number; homeOdds: number; awayOdds: number };
    moneyline?: { homeOdds: number; awayOdds: number };
    total?: { overPoint: number; underPoint: number; overOdds: number; underOdds: number };
  }>;
  lineMovement: {
    direction: 'up' | 'down' | 'stable';
    amount: number;
  };
  // Live score data
  score?: {
    homeScore: number | null;
    awayScore: number | null;
    status: 'upcoming' | 'live' | 'final';
    lastUpdate: string | null;
  };
}

interface MatchupsDashboardProps {
  onSelectBet: (bet: { description: string; sport: string; odds: number; bookmaker: string }) => void;
  initialSportFilter?: string;
}

export function MatchupsDashboard({ onSelectBet, initialSportFilter = 'all' }: MatchupsDashboardProps): JSX.Element {
  const [matchups, setMatchups] = useState<Matchup[]>([]);
  const [scores, setScores] = useState<Score[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [sportFilter, setSportFilter] = useState<string>(initialSportFilter);
  const [selectedGame, setSelectedGame] = useState<Matchup | null>(null);
  const [refreshing, setRefreshing] = useState<boolean>(false);

  // Update sport filter when initialSportFilter prop changes
  useEffect(() => {
    setSportFilter(initialSportFilter);
  }, [initialSportFilter]);

  const fetchScores = async (): Promise<void> => {
    try {
      const sport = sportFilter !== 'all' ? `?sport=${sportFilter}` : '';
      const response = await fetch(`/api/scores${sport}`);
      const data = await response.json();
      
      if (data.success && data.scores) {
        setScores(data.scores);
      }
    } catch (error) {
      console.error('Error fetching scores:', error);
    }
  };

  const fetchMatchups = async (): Promise<void> => {
    try {
      setRefreshing(true);
      const sport = sportFilter !== 'all' ? `?sport=${sportFilter}` : '';
      
      // Fetch both odds and scores in parallel
      const [oddsResponse, scoresResponse] = await Promise.all([
        fetch(`/api/matchups/today${sport}`),
        fetch(`/api/scores${sport}`)
      ]);
      
      const oddsData = await oddsResponse.json();
      const scoresData = await scoresResponse.json();
      
      if (oddsData.success && oddsData.matchups) {
        const matchupsWithScores = oddsData.matchups.map((matchup: Matchup) => {
          // Find matching score data
          const scoreData = scoresData.success && scoresData.scores
            ? scoresData.scores.find((s: Score) => s.id === matchup.id)
            : null;
          
          if (scoreData) {
            return {
              ...matchup,
              score: {
                homeScore: scoreData.homeScore,
                awayScore: scoreData.awayScore,
                status: scoreData.status,
                lastUpdate: scoreData.lastUpdate
              }
            };
          }
          
          return matchup;
        });
        
        setMatchups(matchupsWithScores);
      }
      
      if (scoresData.success && scoresData.scores) {
        setScores(scoresData.scores);
      }
    } catch (error) {
      console.error('Error fetching matchups:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchMatchups();
    
    // Auto-refresh every 15 seconds for live scores
    const interval = setInterval(() => {
      fetchMatchups();
    }, 15000);

    return () => clearInterval(interval);
  }, [sportFilter]);

  const filteredMatchups = useMemo(() => {
    if (sportFilter === 'all') return matchups;
    return matchups.filter((m) => m.sportKey === sportFilter);
  }, [matchups, sportFilter]);

  const uniqueSports = useMemo(() => {
    const sportsMap = new Map<string, string>();
    matchups.forEach((m) => {
      if (!sportsMap.has(m.sportKey)) {
        sportsMap.set(m.sportKey, m.sport);
      }
    });
    return Array.from(sportsMap.entries()).map(([key, title]) => ({ key, title }));
  }, [matchups]);

  const formatTime = (isoString: string): string => {
    const date = new Date(isoString);
    const now = new Date();
    const diffMs = date.getTime() - now.getTime();
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

    if (diffHours < 0) return 'Live';
    if (diffHours === 0) return `${diffMins}m`;
    if (diffHours < 24) return `${diffHours}h ${diffMins}m`;
    
    return date.toLocaleString('en-US', {
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
  };

  const formatOdds = (odds: number): string => {
    return odds > 0 ? `+${odds}` : `${odds}`;
  };

  const getLineMovementIcon = (direction: string): JSX.Element => {
    switch (direction) {
      case 'up':
        return <TrendingUp className="w-4 h-4 text-green-400" />;
      case 'down':
        return <TrendingDown className="w-4 h-4 text-red-400" />;
      default:
        return <Minus className="w-4 h-4 text-gray-400" />;
    }
  };

  const handleAddToBetSlip = (
    matchup: Matchup,
    betType: 'spread' | 'moneyline' | 'total',
    selection: string,
    odds: number,
    bookmaker: string
  ): void => {
    const description = `${matchup.awayTeam} @ ${matchup.homeTeam} - ${selection}`;
    onSelectBet({
      description,
      sport: matchup.sport,
      odds,
      bookmaker
    });
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardHeader>
            <Skeleton className="h-8 w-64 bg-[#1e293b]" />
          </CardHeader>
          <CardContent className="space-y-4">
            {[1, 2, 3].map((i) => (
              <Skeleton key={i} className="h-32 w-full bg-[#1e293b]" />
            ))}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-[#020617] border-[#1e293b]">
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-[#22d3ee] flex items-center gap-2">
                <Activity className="w-5 h-5" />
                Today's Matchups
              </CardTitle>
              <CardDescription className="text-[#94a3b8]">
                Live odds from 8+ sportsbooks with AI-powered analytics
              </CardDescription>
            </div>
            <Button
              onClick={() => fetchMatchups()}
              variant="outline"
              size="sm"
              disabled={refreshing}
              className="border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
            >
              <RefreshCw className={`w-4 h-4 mr-2 ${refreshing ? 'animate-spin' : ''}`} />
              Refresh
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 items-center">
            <Select value={sportFilter} onValueChange={setSportFilter}>
              <SelectTrigger className="bg-[#0f172a] border-[#1e293b] text-[#e5e7eb] w-[200px]">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#0f172a] border-[#1e293b]">
                <SelectItem value="all">All Sports</SelectItem>
                {uniqueSports.map((sport) => (
                  <SelectItem key={sport.key} value={sport.key}>
                    {sport.title}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="text-sm text-[#94a3b8]">
              {filteredMatchups.length} game{filteredMatchups.length !== 1 ? 's' : ''} available
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Matchup Cards */}
      <div className="grid gap-4">
        {filteredMatchups.map((matchup) => (
          <Card key={matchup.id} className="bg-[#020617] border-[#1e293b] hover:border-[#22d3ee] transition-colors">
            <CardContent className="p-6">
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <Badge variant="outline" className="border-[#22d3ee] text-[#22d3ee]">
                    {matchup.sport}
                  </Badge>
                  <span className="text-sm text-[#94a3b8]">{matchup.league}</span>
                </div>
                <div className="flex items-center gap-2 text-sm text-[#94a3b8]">
                  <Clock className="w-4 h-4" />
                  {formatTime(matchup.startTime)}
                </div>
              </div>

              {/* Teams & Scores */}
              <div className="grid grid-cols-3 gap-4 mb-4">
                <div className="col-span-2">
                  <div className="flex items-center justify-between mb-1">
                    <div className="text-lg font-semibold text-[#e5e7eb]">
                      {matchup.awayTeam}
                    </div>
                    {matchup.score && matchup.score.awayScore !== null && (
                      <div className="text-2xl font-bold text-[#22d3ee]">
                        {matchup.score.awayScore}
                      </div>
                    )}
                  </div>
                  <div className="flex items-center justify-between">
                    <div className="text-lg font-semibold text-[#e5e7eb]">
                      {matchup.homeTeam}
                    </div>
                    {matchup.score && matchup.score.homeScore !== null && (
                      <div className="text-2xl font-bold text-[#22d3ee]">
                        {matchup.score.homeScore}
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex flex-col items-end justify-center gap-2">
                  {matchup.score && matchup.score.status === 'live' && (
                    <Badge className="bg-red-500 text-black animate-pulse border-0">
                      LIVE
                    </Badge>
                  )}
                  {matchup.score && matchup.score.status === 'final' && (
                    <Badge variant="outline" className="border-[#94a3b8] text-[#94a3b8]">
                      FINAL
                    </Badge>
                  )}
                  {matchup.lineMovement.amount !== 0 && (
                    <div className="flex items-center gap-2">
                      {getLineMovementIcon(matchup.lineMovement.direction)}
                      <span className="text-sm text-[#94a3b8]">
                        {Math.abs(matchup.lineMovement.amount).toFixed(1)}
                      </span>
                    </div>
                  )}
                </div>
              </div>

              {/* Odds Grid */}
              <div className="grid md:grid-cols-3 gap-4 mb-4">
                {/* Spread */}
                {matchup.odds.spread && (
                  <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg p-3">
                    <div className="text-xs text-[#94a3b8] mb-2">
                      Spread ({matchup.odds.spread.bookmaker})
                    </div>
                    <div className="space-y-2">
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'spread',
                            `${matchup.awayTeam} ${matchup.odds.spread!.awayPoint > 0 ? '+' : ''}${matchup.odds.spread!.awayPoint}`,
                            matchup.odds.spread!.awayOdds,
                            matchup.odds.spread!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>{matchup.odds.spread.awayPoint > 0 ? '+' : ''}{matchup.odds.spread.awayPoint}</span>
                        <span>{formatOdds(matchup.odds.spread.awayOdds)}</span>
                      </Button>
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'spread',
                            `${matchup.homeTeam} ${matchup.odds.spread!.homePoint > 0 ? '+' : ''}${matchup.odds.spread!.homePoint}`,
                            matchup.odds.spread!.homeOdds,
                            matchup.odds.spread!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>{matchup.odds.spread.homePoint > 0 ? '+' : ''}{matchup.odds.spread.homePoint}</span>
                        <span>{formatOdds(matchup.odds.spread.homeOdds)}</span>
                      </Button>
                    </div>
                  </div>
                )}

                {/* Total */}
                {matchup.odds.total && (
                  <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg p-3">
                    <div className="text-xs text-[#94a3b8] mb-2">
                      Total ({matchup.odds.total.bookmaker})
                    </div>
                    <div className="space-y-2">
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'total',
                            `Over ${matchup.odds.total!.overPoint}`,
                            matchup.odds.total!.overOdds,
                            matchup.odds.total!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>O {matchup.odds.total.overPoint}</span>
                        <span>{formatOdds(matchup.odds.total.overOdds)}</span>
                      </Button>
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'total',
                            `Under ${matchup.odds.total!.underPoint}`,
                            matchup.odds.total!.underOdds,
                            matchup.odds.total!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>U {matchup.odds.total.underPoint}</span>
                        <span>{formatOdds(matchup.odds.total.underOdds)}</span>
                      </Button>
                    </div>
                  </div>
                )}

                {/* Moneyline */}
                {matchup.odds.moneyline && (
                  <div className="bg-[#0f172a] border border-[#1e293b] rounded-lg p-3">
                    <div className="text-xs text-[#94a3b8] mb-2">
                      Moneyline ({matchup.odds.moneyline.bookmaker})
                    </div>
                    <div className="space-y-2">
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'moneyline',
                            matchup.awayTeam,
                            matchup.odds.moneyline!.awayOdds,
                            matchup.odds.moneyline!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>Away</span>
                        <span>{formatOdds(matchup.odds.moneyline.awayOdds)}</span>
                      </Button>
                      <Button
                        onClick={() =>
                          handleAddToBetSlip(
                            matchup,
                            'moneyline',
                            matchup.homeTeam,
                            matchup.odds.moneyline!.homeOdds,
                            matchup.odds.moneyline!.bookmaker
                          )
                        }
                        variant="ghost"
                        size="sm"
                        className="w-full justify-between text-[#e5e7eb] hover:bg-[#1e293b]"
                      >
                        <span>Home</span>
                        <span>{formatOdds(matchup.odds.moneyline.homeOdds)}</span>
                      </Button>
                    </div>
                  </div>
                )}
              </div>

              {/* Actions */}
              <div className="flex gap-2">
                <Button
                  onClick={() => setSelectedGame(matchup)}
                  className="flex-1 bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
                >
                  <Sparkles className="w-4 h-4 mr-2" />
                  AI Analytics
                </Button>
                <Button
                  variant="outline"
                  className="border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a]"
                >
                  <Target className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Empty State */}
      {filteredMatchups.length === 0 && (
        <Card className="bg-[#020617] border-[#1e293b]">
          <CardContent className="py-12 text-center">
            <AlertCircle className="w-12 h-12 text-[#94a3b8] mx-auto mb-4" />
            <h3 className="text-xl font-semibold text-[#e5e7eb] mb-2">No Matchups Available</h3>
            <p className="text-[#94a3b8]">
              Check back later for today's games or try a different sport filter.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Game Analytics Modal */}
      {selectedGame && (
        <GameAnalyticsModal
          game={selectedGame}
          open={selectedGame !== null}
          onClose={() => setSelectedGame(null)}
          onAddToBetSlip={handleAddToBetSlip}
        />
      )}
    </div>
  );
}
