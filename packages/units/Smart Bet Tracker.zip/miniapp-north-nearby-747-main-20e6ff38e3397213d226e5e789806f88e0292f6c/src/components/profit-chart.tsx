'use client'

import type { FC } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend } from 'recharts';
import type { ProfitPoint } from '@/lib/bankroll-enhanced';

interface ProfitChartProps {
  data: ProfitPoint[];
  initialBankroll: number;
}

export const ProfitChart: FC<ProfitChartProps> = ({ data, initialBankroll }) => {
  const chartData = data.map((point: ProfitPoint) => ({
    bet: point.betNumber,
    bankroll: parseFloat(point.bankroll.toFixed(2)),
    pl: parseFloat(point.cumulativePL.toFixed(2)),
    date: new Date(point.timestamp).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }));

  return (
    <div className="w-full h-[400px]">
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
          <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
          <XAxis 
            dataKey="bet" 
            stroke="#94a3b8"
            label={{ value: 'Bet Number', position: 'insideBottom', offset: -5, fill: '#94a3b8' }}
          />
          <YAxis 
            stroke="#94a3b8"
            label={{ value: 'Bankroll ($)', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: '#0f172a',
              border: '1px solid #1e293b',
              borderRadius: '6px',
              color: '#e5e7eb'
            }}
            labelStyle={{ color: '#22d3ee' }}
            formatter={(value: number, name: string) => {
              if (name === 'bankroll') return [`$${value.toFixed(2)}`, 'Bankroll'];
              if (name === 'pl') return [`${value >= 0 ? '+' : ''}$${value.toFixed(2)}`, 'Cumulative P&L'];
              return [value, name];
            }}
          />
          <Legend 
            wrapperStyle={{ color: '#e5e7eb' }}
            iconType="line"
          />
          <Line 
            type="monotone" 
            dataKey="bankroll" 
            stroke="#22d3ee" 
            strokeWidth={2}
            dot={false}
            name="Bankroll"
          />
          <Line 
            type="monotone" 
            dataKey="pl" 
            stroke="#22c55e" 
            strokeWidth={2}
            dot={false}
            name="Cumulative P&L"
          />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
};
