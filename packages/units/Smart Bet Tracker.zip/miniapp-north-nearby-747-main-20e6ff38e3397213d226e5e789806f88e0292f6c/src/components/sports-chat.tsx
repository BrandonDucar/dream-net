'use client'

import { useState, useRef, useEffect, type FC, type FormEvent, type ChangeEvent } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Sparkles, Send, Loader2, ExternalLink } from 'lucide-react';

interface Message {
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  citations?: string[];
  source?: 'perplexity' | 'openai';
}

export const SportsChat: FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'assistant',
      content: 'Hey! I\'m your AI sports analyst. Ask me anything about games, players, stats, injuries, betting lines, or predictions. I have access to real-time sports data and can help you make informed decisions! 🏈🏀⚾🏒',
      timestamp: Date.now()
    }
  ]);
  const [input, setInput] = useState<string>('');
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const suggestedQuestions: string[] = [
    'Who\'s the starting QB for the 49ers tonight?',
    'What are the injury reports for tonight\'s games?',
    'Should I bet on the Lakers spread?',
    'Give me stats for Steph Curry this season',
    'Which team has the best defense in the NFL?',
    'What\'s the weather for outdoor games today?'
  ];

  const scrollToBottom = (): void => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSubmit = async (e: FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      role: 'user',
      content: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/ai/sports-chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: input })
      });

      const data = await response.json();

      if (data.error) {
        throw new Error(data.error);
      }

      const assistantMessage: Message = {
        role: 'assistant',
        content: data.answer,
        timestamp: Date.now(),
        citations: data.citations || [],
        source: data.source || 'openai'
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      const errorMessage: Message = {
        role: 'assistant',
        content: 'Sorry, I encountered an error. Please try asking your question again.',
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSuggestedQuestion = (question: string): void => {
    setInput(question);
  };

  return (
    <Card className="bg-[#020617] border-[#1e293b]">
      <CardHeader>
        <CardTitle className="text-[#22d3ee] flex items-center gap-2">
          <Sparkles className="w-5 h-5" />
          Sports AI Chat
        </CardTitle>
        <CardDescription className="text-[#94a3b8]">
          Ask anything about sports, players, stats, injuries, or betting insights
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Suggested Questions */}
        {messages.length <= 1 && (
          <div>
            <p className="text-sm text-[#94a3b8] mb-2">Try asking:</p>
            <div className="flex flex-wrap gap-2">
              {suggestedQuestions.map((question: string) => (
                <Badge
                  key={question}
                  variant="outline"
                  className="cursor-pointer border-[#1e293b] text-[#22d3ee] hover:bg-[#0f172a] text-xs"
                  onClick={() => handleSuggestedQuestion(question)}
                >
                  {question}
                </Badge>
              ))}
            </div>
          </div>
        )}

        {/* Messages */}
        <ScrollArea className="h-[500px] pr-4">
          <div className="space-y-4">
            {messages.map((message: Message, index: number) => (
              <div
                key={index}
                className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-lg p-4 ${
                    message.role === 'user'
                      ? 'bg-[#22d3ee] text-[#020617]'
                      : 'bg-[#0f172a] text-[#e5e7eb] border border-[#1e293b]'
                  }`}
                >
                  <p className="text-sm whitespace-pre-wrap leading-relaxed">{message.content}</p>
                  
                  {/* Citations */}
                  {message.citations && message.citations.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-[#1e293b]">
                      <p className="text-xs text-[#94a3b8] mb-2 font-semibold">Sources:</p>
                      <div className="space-y-1">
                        {message.citations.map((citation: string, idx: number) => (
                          <a
                            key={idx}
                            href={citation}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="flex items-center gap-1 text-xs text-[#22d3ee] hover:text-[#06b6d4] transition-colors"
                          >
                            <ExternalLink className="w-3 h-3" />
                            <span className="truncate max-w-[300px]">{citation}</span>
                          </a>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Source Badge */}
                  <div className="flex items-center justify-between mt-2 pt-2 border-t border-[#1e293b]">
                    <p className="text-xs opacity-60">
                      {new Date(message.timestamp).toLocaleTimeString('en-US', {
                        hour: '2-digit',
                        minute: '2-digit'
                      })}
                    </p>
                    {message.source && message.role === 'assistant' && (
                      <Badge variant="outline" className="border-[#1e293b] text-[#94a3b8] text-xs">
                        {message.source === 'perplexity' ? '🔍 Real-time Data' : '🤖 AI Analysis'}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-[#0f172a] text-[#e5e7eb] border border-[#1e293b] rounded-lg p-4">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-5 h-5 animate-spin text-[#22d3ee]" />
                    <span className="text-sm text-[#94a3b8]">Thinking...</span>
                  </div>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        </ScrollArea>

        {/* Input */}
        <form onSubmit={handleSubmit} className="flex gap-2">
          <Input
            value={input}
            onChange={(e: ChangeEvent<HTMLInputElement>) => setInput(e.target.value)}
            placeholder="Ask about any sport, player, team, or game..."
            className="bg-[#0f172a] border-[#1e293b] text-[#e5e7eb]"
            disabled={isLoading}
          />
          <Button
            type="submit"
            disabled={!input.trim() || isLoading}
            className="bg-[#22d3ee] hover:bg-[#06b6d4] text-[#020617]"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
          </Button>
        </form>

        {/* Helper Text */}
        <p className="text-xs text-[#94a3b8] text-center">
          💡 Tip: Be specific! Ask about players, teams, stats, injuries, weather, or betting lines.
        </p>
      </CardContent>
    </Card>
  );
};
