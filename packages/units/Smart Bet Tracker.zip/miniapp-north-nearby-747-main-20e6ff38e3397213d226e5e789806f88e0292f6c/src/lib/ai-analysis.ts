import { openaiChatCompletion } from '../openai-api';
import type { EnhancedBet, AdvancedAnalytics } from './bankroll-enhanced';
import type { BankrollSnapshot } from './bankroll';

export interface AIInsight {
  type: 'pattern' | 'warning' | 'strength' | 'recommendation';
  title: string;
  description: string;
  confidence: number;  // 0-1
  actionable: boolean;
}

export interface TiltPrediction {
  riskLevel: 'low' | 'moderate' | 'high' | 'critical';
  probability: number;  // 0-100
  factors: string[];
  nextActions: string[];
}

export interface EdgeAnalysis {
  strongestEdge: string;
  weakestArea: string;
  recommendations: string[];
  profitableTags: string[];
  avoidTags: string[];
}

/**
 * Analyze betting patterns and generate AI insights
 */
export async function analyzeBettingPatterns(
  bets: EnhancedBet[],
  snapshot: BankrollSnapshot,
  analytics: AdvancedAnalytics
): Promise<AIInsight[]> {
  const recentBets: EnhancedBet[] = bets.slice(-20);
  
  const prompt: string = `You are an expert betting analyst. Analyze this betting data and provide 3-5 actionable insights.

SNAPSHOT:
- Current Bankroll: $${snapshot.currentBankroll.toFixed(2)}
- Total P&L: ${snapshot.totalProfitLoss >= 0 ? '+' : ''}$${snapshot.totalProfitLoss.toFixed(2)}
- Win Rate: ${(snapshot.winRate * 100).toFixed(1)}%
- ROI: ${analytics.roi.toFixed(2)}%
- Current Win Streak: ${analytics.streaks.currentWinStreak}
- Current Loss Streak: ${analytics.streaks.currentLossStreak}
- Variance: ${analytics.variance.toFixed(2)}
- Sharpe Ratio: ${analytics.sharpeRatio.toFixed(3)}

RECENT BETS (last 20):
${recentBets.map((b: EnhancedBet) => 
  `- ${b.sport}: ${b.description} | Stake: $${b.stake} | Outcome: ${b.outcome} | P&L: ${b.profitLoss >= 0 ? '+' : ''}$${b.profitLoss.toFixed(2)} | Tags: ${b.tags.join(', ')}`
).join('\n')}

TOP PERFORMING SPORTS:
${analytics.roiBySport.slice(0, 3).map((s) => `- ${s.sport}: ${s.roi.toFixed(1)}% ROI (${s.bets} bets)`).join('\n')}

TOP TAGS:
${analytics.edgeByTag.slice(0, 3).map((t) => `- ${t.tag}: ${t.edge.toFixed(1)}% edge (${t.count} bets)`).join('\n')}

Respond with EXACTLY 3-5 insights in this JSON format:
[
  {
    "type": "pattern|warning|strength|recommendation",
    "title": "Brief title",
    "description": "Detailed explanation",
    "confidence": 0.85,
    "actionable": true
  }
]

Focus on: profitable patterns, risky behaviors, optimal bet sizing, sport/tag performance, and actionable improvements.`;

  try {
    const response = await openaiChatCompletion({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a professional betting analyst. Always respond with valid JSON only, no markdown or extra text.' },
        { role: 'user', content: prompt }
      ]
    });

    const content: string = response.choices[0]?.message?.content || '[]';
    const cleanContent: string = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const insights: AIInsight[] = JSON.parse(cleanContent);

    return insights;
  } catch (error) {
    console.error('AI analysis error:', error);
    return [
      {
        type: 'warning',
        title: 'AI Analysis Unavailable',
        description: 'Unable to generate AI insights at this time. Manual analysis recommended.',
        confidence: 1.0,
        actionable: false
      }
    ];
  }
}

/**
 * Predict tilt risk based on recent behavior
 */
export async function predictTiltRisk(
  recentBets: EnhancedBet[],
  analytics: AdvancedAnalytics
): Promise<TiltPrediction> {
  if (recentBets.length < 5) {
    return {
      riskLevel: 'low',
      probability: 0,
      factors: ['Insufficient data for tilt prediction'],
      nextActions: ['Continue logging bets for better analysis']
    };
  }

  const last10: EnhancedBet[] = recentBets.slice(-10);
  
  const prompt: string = `You are a behavioral betting analyst. Predict tilt risk based on this data.

RECENT ACTIVITY (last 10 bets):
${last10.map((b: EnhancedBet, i: number) => 
  `Bet ${i + 1}: ${b.outcome} | Stake: $${b.stake} | P&L: ${b.profitLoss >= 0 ? '+' : ''}$${b.profitLoss.toFixed(2)} | Time: ${new Date(b.placedAt).toLocaleTimeString()}`
).join('\n')}

CURRENT STATS:
- Win Streak: ${analytics.streaks.currentWinStreak}
- Loss Streak: ${analytics.streaks.currentLossStreak}
- Recent Variance: ${analytics.variance.toFixed(2)}

BEHAVIORAL INDICATORS:
- Stake escalation after losses
- Rapid bet frequency
- Late-night betting patterns
- Deviation from standard stakes

Respond with EXACTLY this JSON format:
{
  "riskLevel": "low|moderate|high|critical",
  "probability": 45,
  "factors": ["Loss streak of 3", "Stake increase of 40%"],
  "nextActions": ["Take a 24h break", "Review bet log"]
}`;

  try {
    const response = await openaiChatCompletion({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a behavioral analyst. Always respond with valid JSON only.' },
        { role: 'user', content: prompt }
      ]
    });

    const content: string = response.choices[0]?.message?.content || '{}';
    const cleanContent: string = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const prediction: TiltPrediction = JSON.parse(cleanContent);

    return prediction;
  } catch (error) {
    console.error('Tilt prediction error:', error);
    return {
      riskLevel: 'low',
      probability: 0,
      factors: ['Analysis unavailable'],
      nextActions: ['Continue monitoring manually']
    };
  }
}

/**
 * Identify profitable edges and weak areas
 */
export async function identifyEdge(
  analytics: AdvancedAnalytics,
  bets: EnhancedBet[]
): Promise<EdgeAnalysis> {
  const topSports = analytics.roiBySport
    .sort((a, b) => b.roi - a.roi)
    .slice(0, 5);

  const topTags = analytics.edgeByTag
    .sort((a, b) => b.edge - a.edge)
    .slice(0, 5);

  const weakTags = analytics.edgeByTag
    .sort((a, b) => a.edge - b.edge)
    .slice(0, 3);

  const prompt: string = `You are a professional sports betting strategist. Identify edges and weaknesses.

TOP PERFORMING SPORTS:
${topSports.map((s) => `- ${s.sport}: ${s.roi.toFixed(1)}% ROI (${s.bets} bets)`).join('\n')}

TOP PERFORMING TAGS:
${topTags.map((t) => `- ${t.tag}: ${t.edge.toFixed(1)}% edge (${t.count} bets)`).join('\n')}

WEAK AREAS (lowest ROI tags):
${weakTags.map((t) => `- ${t.tag}: ${t.edge.toFixed(1)}% (${t.count} bets)`).join('\n')}

OVERALL ROI: ${analytics.roi.toFixed(2)}%
PROFIT FACTOR: ${analytics.profitFactor.toFixed(2)}

Respond with EXACTLY this JSON format:
{
  "strongestEdge": "Describe your #1 profitable pattern",
  "weakestArea": "Describe biggest leak",
  "recommendations": ["Actionable advice 1", "Actionable advice 2", "Actionable advice 3"],
  "profitableTags": ["tag1", "tag2", "tag3"],
  "avoidTags": ["tag1", "tag2"]
}`;

  try {
    const response = await openaiChatCompletion({
      model: 'gpt-4o-mini',
      messages: [
        { role: 'system', content: 'You are a betting strategist. Always respond with valid JSON only.' },
        { role: 'user', content: prompt }
      ]
    });

    const content: string = response.choices[0]?.message?.content || '{}';
    const cleanContent: string = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim();
    const edgeAnalysis: EdgeAnalysis = JSON.parse(cleanContent);

    return edgeAnalysis;
  } catch (error) {
    console.error('Edge analysis error:', error);
    return {
      strongestEdge: 'Analysis unavailable',
      weakestArea: 'Analysis unavailable',
      recommendations: ['Continue tracking bets for better insights'],
      profitableTags: [],
      avoidTags: []
    };
  }
}

/**
 * Generate personalized bankroll recommendations
 */
export async function getPersonalizedAdvice(
  question: string,
  bets: EnhancedBet[],
  snapshot: BankrollSnapshot,
  analytics: AdvancedAnalytics
): Promise<string> {
  const prompt: string = `You are a professional bankroll management consultant. Answer this question based on the user's data.

USER QUESTION: "${question}"

BANKROLL DATA:
- Current: $${snapshot.currentBankroll.toFixed(2)}
- Total P&L: ${snapshot.totalProfitLoss >= 0 ? '+' : ''}$${snapshot.totalProfitLoss.toFixed(2)}
- ROI: ${analytics.roi.toFixed(2)}%
- Win Rate: ${(snapshot.winRate * 100).toFixed(1)}%
- Variance: ${analytics.variance.toFixed(2)}
- Sharpe Ratio: ${analytics.sharpeRatio.toFixed(3)}
- Profit Factor: ${analytics.profitFactor.toFixed(2)}

TOP SPORTS:
${analytics.roiBySport.slice(0, 3).map((s) => `- ${s.sport}: ${s.roi.toFixed(1)}% ROI`).join('\n')}

Provide a concise, actionable answer (2-3 paragraphs max).`;

  try {
    const response = await openaiChatCompletion({
      model: 'gpt-4o',
      messages: [
        { role: 'system', content: 'You are a professional bankroll consultant. Provide clear, actionable advice.' },
        { role: 'user', content: prompt }
      ]
    });

    return response.choices[0]?.message?.content || 'Unable to generate advice at this time.';
  } catch (error) {
    console.error('Personalized advice error:', error);
    return 'Unable to generate personalized advice at this time. Please try again later.';
  }
}
