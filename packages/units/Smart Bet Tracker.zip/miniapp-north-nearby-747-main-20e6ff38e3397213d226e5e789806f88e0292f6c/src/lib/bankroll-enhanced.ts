import type { LoggedBet, BankrollSnapshot } from './bankroll';

// Enhanced bet with additional tracking
export interface EnhancedBet extends LoggedBet {
  tags: string[];           // e.g. ["value", "underdog", "live"]
  closingOdds?: number;     // CLV tracking
  clv?: number;             // Closing Line Value (decimal odds difference)
  betType: 'straight' | 'parlay';
  parlayLegs?: ParlayLeg[];
  confidence?: number;      // 1-10 scale
  notes?: string;
}

export interface ParlayLeg {
  description: string;
  odds: number;
  outcome?: 'win' | 'loss' | 'pending';
}

// Time-based P&L breakdowns
export interface TimeframePL {
  daily: { date: string; pl: number }[];
  weekly: { week: string; pl: number }[];
  monthly: { month: string; pl: number }[];
}

// Advanced analytics
export interface AdvancedAnalytics {
  roi: number;                           // Return on Investment %
  roiByMonth: { month: string; roi: number }[];
  roiBySport: { sport: string; roi: number; bets: number }[];
  roiByBetType: { type: string; roi: number; bets: number }[];
  avgClv: number;                        // Average Closing Line Value
  clvBySport: { sport: string; clv: number }[];
  streaks: {
    currentWinStreak: number;
    currentLossStreak: number;
    longestWinStreak: number;
    longestLossStreak: number;
  };
  variance: number;                      // Standard deviation of P&L
  sharpeRatio: number;                   // Risk-adjusted return
  profitFactor: number;                  // Gross profit / Gross loss
  expectancy: number;                    // Average $ per bet
  edgeByTag: { tag: string; edge: number; count: number }[];
  bestTimeOfDay: { hour: number; roi: number }[];
}

// Profit curve data point
export interface ProfitPoint {
  betNumber: number;
  timestamp: number;
  bankroll: number;
  pl: number;
  cumulativePL: number;
}

/**
 * Calculate Return on Investment for a set of bets
 */
export function calculateROI(totalStaked: number, totalProfitLoss: number): number {
  if (totalStaked === 0) return 0;
  return (totalProfitLoss / totalStaked) * 100;
}

/**
 * Calculate Closing Line Value (how much better/worse than closing odds)
 */
export function calculateCLV(openingOdds: number, closingOdds: number): number {
  return closingOdds - openingOdds;
}

/**
 * Build profit curve data for charting
 */
export function buildProfitCurve(initialBankroll: number, bets: EnhancedBet[]): ProfitPoint[] {
  const points: ProfitPoint[] = [];
  let currentBankroll: number = initialBankroll;
  let cumulativePL: number = 0;

  const sorted: EnhancedBet[] = [...bets].sort((a: EnhancedBet, b: EnhancedBet) => a.placedAt - b.placedAt);

  sorted.forEach((bet: EnhancedBet, index: number) => {
    cumulativePL += bet.profitLoss;
    currentBankroll += bet.profitLoss;

    points.push({
      betNumber: index + 1,
      timestamp: bet.placedAt,
      bankroll: currentBankroll,
      pl: bet.profitLoss,
      cumulativePL
    });
  });

  return points;
}

/**
 * Calculate streak statistics
 */
export function calculateStreaks(bets: EnhancedBet[]): AdvancedAnalytics['streaks'] {
  const sorted: EnhancedBet[] = [...bets]
    .filter((b: EnhancedBet) => b.outcome !== 'push')
    .sort((a: EnhancedBet, b: EnhancedBet) => a.placedAt - b.placedAt);

  let currentWinStreak: number = 0;
  let currentLossStreak: number = 0;
  let longestWinStreak: number = 0;
  let longestLossStreak: number = 0;
  let tempWinStreak: number = 0;
  let tempLossStreak: number = 0;

  for (const bet of sorted) {
    if (bet.outcome === 'win') {
      tempWinStreak++;
      tempLossStreak = 0;
      if (tempWinStreak > longestWinStreak) longestWinStreak = tempWinStreak;
    } else if (bet.outcome === 'loss') {
      tempLossStreak++;
      tempWinStreak = 0;
      if (tempLossStreak > longestLossStreak) longestLossStreak = tempLossStreak;
    }
  }

  // Current streak is the last streak
  if (sorted.length > 0) {
    const lastBet: EnhancedBet = sorted[sorted.length - 1];
    currentWinStreak = lastBet.outcome === 'win' ? tempWinStreak : 0;
    currentLossStreak = lastBet.outcome === 'loss' ? tempLossStreak : 0;
  }

  return {
    currentWinStreak,
    currentLossStreak,
    longestWinStreak,
    longestLossStreak
  };
}

/**
 * Calculate variance (standard deviation of P&L)
 */
export function calculateVariance(bets: EnhancedBet[]): number {
  if (bets.length === 0) return 0;

  const pls: number[] = bets.map((b: EnhancedBet) => b.profitLoss);
  const mean: number = pls.reduce((sum: number, pl: number) => sum + pl, 0) / pls.length;
  const squaredDiffs: number[] = pls.map((pl: number) => Math.pow(pl - mean, 2));
  const variance: number = squaredDiffs.reduce((sum: number, sq: number) => sum + sq, 0) / pls.length;

  return Math.sqrt(variance);
}

/**
 * Calculate Sharpe Ratio (risk-adjusted return)
 */
export function calculateSharpeRatio(bets: EnhancedBet[]): number {
  if (bets.length === 0) return 0;

  const avgReturn: number = bets.reduce((sum: number, b: EnhancedBet) => sum + b.profitLoss, 0) / bets.length;
  const stdDev: number = calculateVariance(bets);

  if (stdDev === 0) return 0;
  return avgReturn / stdDev;
}

/**
 * Calculate profit factor (gross wins / gross losses)
 */
export function calculateProfitFactor(bets: EnhancedBet[]): number {
  const grossWins: number = bets
    .filter((b: EnhancedBet) => b.profitLoss > 0)
    .reduce((sum: number, b: EnhancedBet) => sum + b.profitLoss, 0);

  const grossLosses: number = Math.abs(
    bets
      .filter((b: EnhancedBet) => b.profitLoss < 0)
      .reduce((sum: number, b: EnhancedBet) => sum + b.profitLoss, 0)
  );

  if (grossLosses === 0) return grossWins > 0 ? Infinity : 0;
  return grossWins / grossLosses;
}

/**
 * Build comprehensive advanced analytics
 */
export function buildAdvancedAnalytics(
  snapshot: BankrollSnapshot,
  bets: EnhancedBet[]
): AdvancedAnalytics {
  const roi: number = calculateROI(snapshot.totalStaked, snapshot.totalProfitLoss);

  // ROI by sport
  const sportMap: Map<string, { pl: number; staked: number; bets: number }> = new Map();
  bets.forEach((bet: EnhancedBet) => {
    const existing = sportMap.get(bet.sport) || { pl: 0, staked: 0, bets: 0 };
    sportMap.set(bet.sport, {
      pl: existing.pl + bet.profitLoss,
      staked: existing.staked + bet.stake,
      bets: existing.bets + 1
    });
  });

  const roiBySport = Array.from(sportMap.entries()).map(([sport, data]) => ({
    sport,
    roi: calculateROI(data.staked, data.pl),
    bets: data.bets
  }));

  // ROI by bet type
  const typeMap: Map<string, { pl: number; staked: number; bets: number }> = new Map();
  bets.forEach((bet: EnhancedBet) => {
    const existing = typeMap.get(bet.betType) || { pl: 0, staked: 0, bets: 0 };
    typeMap.set(bet.betType, {
      pl: existing.pl + bet.profitLoss,
      staked: existing.staked + bet.stake,
      bets: existing.bets + 1
    });
  });

  const roiByBetType = Array.from(typeMap.entries()).map(([type, data]) => ({
    type,
    roi: calculateROI(data.staked, data.pl),
    bets: data.bets
  }));

  // Average CLV
  const betsWithClv: EnhancedBet[] = bets.filter((b: EnhancedBet) => b.clv !== undefined);
  const avgClv: number = betsWithClv.length > 0
    ? betsWithClv.reduce((sum: number, b: EnhancedBet) => sum + (b.clv || 0), 0) / betsWithClv.length
    : 0;

  // CLV by sport
  const clvSportMap: Map<string, { totalClv: number; count: number }> = new Map();
  betsWithClv.forEach((bet: EnhancedBet) => {
    const existing = clvSportMap.get(bet.sport) || { totalClv: 0, count: 0 };
    clvSportMap.set(bet.sport, {
      totalClv: existing.totalClv + (bet.clv || 0),
      count: existing.count + 1
    });
  });

  const clvBySport = Array.from(clvSportMap.entries()).map(([sport, data]) => ({
    sport,
    clv: data.count > 0 ? data.totalClv / data.count : 0
  }));

  // Edge by tag
  const tagMap: Map<string, { pl: number; staked: number; count: number }> = new Map();
  bets.forEach((bet: EnhancedBet) => {
    bet.tags.forEach((tag: string) => {
      const existing = tagMap.get(tag) || { pl: 0, staked: 0, count: 0 };
      tagMap.set(tag, {
        pl: existing.pl + bet.profitLoss,
        staked: existing.staked + bet.stake,
        count: existing.count + 1
      });
    });
  });

  const edgeByTag = Array.from(tagMap.entries()).map(([tag, data]) => ({
    tag,
    edge: calculateROI(data.staked, data.pl),
    count: data.count
  }));

  // ROI by month
  const monthMap: Map<string, { pl: number; staked: number }> = new Map();
  bets.forEach((bet: EnhancedBet) => {
    const month: string = new Date(bet.placedAt).toLocaleDateString('en-US', { year: 'numeric', month: 'short' });
    const existing = monthMap.get(month) || { pl: 0, staked: 0 };
    monthMap.set(month, {
      pl: existing.pl + bet.profitLoss,
      staked: existing.staked + bet.stake
    });
  });

  const roiByMonth = Array.from(monthMap.entries()).map(([month, data]) => ({
    month,
    roi: calculateROI(data.staked, data.pl)
  }));

  // Best time of day
  const hourMap: Map<number, { pl: number; staked: number }> = new Map();
  bets.forEach((bet: EnhancedBet) => {
    const hour: number = new Date(bet.placedAt).getHours();
    const existing = hourMap.get(hour) || { pl: 0, staked: 0 };
    hourMap.set(hour, {
      pl: existing.pl + bet.profitLoss,
      staked: existing.staked + bet.stake
    });
  });

  const bestTimeOfDay = Array.from(hourMap.entries())
    .map(([hour, data]) => ({
      hour,
      roi: calculateROI(data.staked, data.pl)
    }))
    .sort((a, b) => b.roi - a.roi);

  return {
    roi,
    roiByMonth,
    roiBySport,
    roiByBetType,
    avgClv,
    clvBySport,
    streaks: calculateStreaks(bets),
    variance: calculateVariance(bets),
    sharpeRatio: calculateSharpeRatio(bets),
    profitFactor: calculateProfitFactor(bets),
    expectancy: bets.length > 0 ? snapshot.totalProfitLoss / bets.length : 0,
    edgeByTag,
    bestTimeOfDay
  };
}

/**
 * Export bets to CSV format
 */
export function exportToCSV(bets: EnhancedBet[]): string {
  const headers: string[] = [
    'Date',
    'Sport',
    'League',
    'Description',
    'Odds Format',
    'Odds',
    'Stake',
    'Outcome',
    'P&L',
    'Bet Type',
    'Tags',
    'CLV',
    'Confidence',
    'Notes'
  ];

  const rows: string[][] = bets.map((bet: EnhancedBet) => [
    new Date(bet.placedAt).toLocaleString(),
    bet.sport,
    bet.league,
    bet.description,
    bet.oddsFormat,
    bet.inputOdds.toString(),
    bet.stake.toString(),
    bet.outcome,
    bet.profitLoss.toString(),
    bet.betType,
    bet.tags.join(';'),
    bet.clv?.toString() || '',
    bet.confidence?.toString() || '',
    bet.notes || ''
  ]);

  const csvContent: string = [
    headers.join(','),
    ...rows.map((row: string[]) => row.map((cell: string) => `"${cell}"`).join(','))
  ].join('\n');

  return csvContent;
}

/**
 * Download CSV file
 */
export function downloadCSV(bets: EnhancedBet[], filename: string = 'bankroll-data.csv'): void {
  const csv: string = exportToCSV(bets);
  const blob: Blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const link: HTMLAnchorElement = document.createElement('a');
  const url: string = URL.createObjectURL(blob);

  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
