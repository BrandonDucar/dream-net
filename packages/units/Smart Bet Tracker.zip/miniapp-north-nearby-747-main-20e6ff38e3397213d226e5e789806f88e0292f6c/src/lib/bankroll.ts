export type OddsFormat = "american" | "decimal";

export type BetOutcome = "win" | "loss" | "push";

export interface LoggedBet {
  id: string;
  placedAt: number;        // timestamp
  sport: string;           // e.g. "NFL", "NBA", "UFC"
  league: string;          // e.g. "AFC", "La Liga" (free text)
  description: string;     // "Lakers -3.5 vs Suns"
  oddsFormat: OddsFormat;
  inputOdds: number;       // -110 or 1.91
  decimalOdds: number;
  stake: number;           // in bankroll currency
  outcome: BetOutcome;
  profitLoss: number;      // +stake*(decimal-1) for wins, -stake for losses, 0 for push
}

export interface BankrollSnapshot {
  initialBankroll: number;
  currentBankroll: number;
  totalProfitLoss: number;
  maxDrawdown: number;      // negative number or % if you prefer
  totalStaked: number;
  totalBets: number;
  wins: number;
  losses: number;
  pushes: number;
  winRate: number;          // wins / (wins+losses)
  avgOddsDecimal: number;
  avgStake: number;
}

export interface RiskProfile {
  unitSize: number;        // recommended standard stake (1 unit)
  tinyUnit: number;        // small stake (0.25–0.5u)
  aggressiveUnit: number;  // high stake cap (2u or similar)
  stakePctStandard: number;
  stakePctTiny: number;
  stakePctAggressive: number;
  riskOfRuinEstimate: number; // 0–1 (very rough heuristic)
  tiltFlags: string[];        // human-readable issues
}

export function americanToDecimal(american: number): number {
  if (american > 0) return 1 + american / 100;
  return 1 + 100 / Math.abs(american);
}

export function normalizeDecimal(oddsFormat: OddsFormat, inputOdds: number): number {
  return oddsFormat === "american" ? americanToDecimal(inputOdds) : inputOdds;
}

// Profit/Loss calculation
export function calculateProfitLoss(decimalOdds: number, stake: number, outcome: BetOutcome): number {
  switch (outcome) {
    case "win":
      return stake * (decimalOdds - 1);
    case "loss":
      return -stake;
    case "push":
      return 0;
  }
}

// Build bankroll snapshot from list of bets and an initial bankroll
export function buildBankrollSnapshot(initialBankroll: number, bets: LoggedBet[]): BankrollSnapshot {
  let current: number = initialBankroll;
  let peak: number = initialBankroll;
  let trough: number = initialBankroll;

  let totalProfitLoss: number = 0;
  let totalStaked: number = 0;
  let totalBets: number = bets.length;
  let wins: number = 0;
  let losses: number = 0;
  let pushes: number = 0;
  let sumDecimalOdds: number = 0;
  let sumStake: number = 0;

  // Sort bets chronologically for drawdown calc
  const sorted: LoggedBet[] = [...bets].sort((a: LoggedBet, b: LoggedBet) => a.placedAt - b.placedAt);

  for (const bet of sorted) {
    totalProfitLoss += bet.profitLoss;
    totalStaked += bet.stake;
    sumDecimalOdds += bet.decimalOdds;
    sumStake += bet.stake;

    if (bet.outcome === "win") wins++;
    if (bet.outcome === "loss") losses++;
    if (bet.outcome === "push") pushes++;

    current += bet.profitLoss;
    if (current > peak) peak = current;
    if (current < trough) trough = current;
  }

  const currentBankroll: number = initialBankroll + totalProfitLoss;
  const maxDrawdown: number = trough - peak; // negative number

  const winRate: number = (wins + losses) > 0 ? wins / (wins + losses) : 0;
  const avgOddsDecimal: number = totalBets > 0 ? sumDecimalOdds / totalBets : 0;
  const avgStake: number = totalBets > 0 ? sumStake / totalBets : 0;

  return {
    initialBankroll,
    currentBankroll,
    totalProfitLoss,
    maxDrawdown,
    totalStaked,
    totalBets,
    wins,
    losses,
    pushes,
    winRate,
    avgOddsDecimal,
    avgStake
  };
}

// Simple Kelly-based unit size suggestion
export function suggestRiskProfile(snapshot: BankrollSnapshot): RiskProfile {
  const { currentBankroll, winRate, avgOddsDecimal }: BankrollSnapshot = snapshot;

  if (currentBankroll <= 0 || snapshot.totalBets === 0 || avgOddsDecimal <= 1) {
    return {
      unitSize: 0,
      tinyUnit: 0,
      aggressiveUnit: 0,
      stakePctStandard: 0,
      stakePctTiny: 0,
      stakePctAggressive: 0,
      riskOfRuinEstimate: 1,
      tiltFlags: ["Insufficient data to estimate risk."]
    };
  }

  const p: number = winRate || 0.5;
  const q: number = 1 - p;
  const b: number = avgOddsDecimal - 1;

  let kellyFrac: number = 0;
  if (b > 0) {
    const num: number = b * p - q;
    const denom: number = b;
    if (denom > 0) kellyFrac = Math.max(0, num / denom);
  }

  // Cap kelly to something sane (e.g. max 10%)
  const cappedKelly: number = Math.min(kellyFrac, 0.10);

  const stakePctStandard: number = cappedKelly || 0.01; // 1% if Kelly is tiny
  const stakePctTiny: number = stakePctStandard / 4;
  const stakePctAggressive: number = stakePctStandard * 2;

  const unitSize: number = currentBankroll * stakePctStandard;
  const tinyUnit: number = currentBankroll * stakePctTiny;
  const aggressiveUnit: number = currentBankroll * stakePctAggressive;

  // Rough risk of ruin heuristic: more drawdown & bigger stakes => higher risk
  const ddRatio: number = snapshot.maxDrawdown < 0
    ? Math.min(Math.abs(snapshot.maxDrawdown) / (snapshot.initialBankroll || 1), 1)
    : 0;

  const riskOfRuinEstimate: number = Math.min(1, ddRatio + (stakePctStandard * 5));

  const tiltFlags: string[] = [];

  // Tilt heuristics are computed elsewhere with bet history; stub here
  // We'll allow the UI layer to add tilt flags from patterns.

  return {
    unitSize,
    tinyUnit,
    aggressiveUnit,
    stakePctStandard: stakePctStandard * 100,
    stakePctTiny: stakePctTiny * 100,
    stakePctAggressive: stakePctAggressive * 100,
    riskOfRuinEstimate,
    tiltFlags
  };
}

// Basic tilt detection: bet frequency & stake escalation
export function detectTilt(bets: LoggedBet[]): string[] {
  const flags: string[] = [];
  if (bets.length < 5) return flags;

  // Sort bets by time
  const sorted: LoggedBet[] = [...bets].sort((a: LoggedBet, b: LoggedBet) => a.placedAt - b.placedAt);

  // Check last N bets for stake escalation after losses
  const tail: LoggedBet[] = sorted.slice(-10);
  let lossThenBiggerStakeCount: number = 0;

  for (let i = 1; i < tail.length; i++) {
    const prev: LoggedBet = tail[i - 1];
    const curr: LoggedBet = tail[i];
    if (prev.outcome === "loss" && curr.stake > prev.stake * 1.5) {
      lossThenBiggerStakeCount++;
    }
  }

  if (lossThenBiggerStakeCount >= 2) {
    flags.push("Stake size frequently increases sharply after losses (potential chase behavior).");
  }

  // Simple frequency spike: compare last 10 vs previous 10 (if exist)
  if (sorted.length >= 20) {
    const last10: LoggedBet[] = sorted.slice(-10);
    const prev10: LoggedBet[] = sorted.slice(-20, -10);
    const lastSpan: number = (last10[last10.length - 1].placedAt - last10[0].placedAt) || 1;
    const prevSpan: number = (prev10[prev10.length - 1].placedAt - prev10[0].placedAt) || 1;

    const lastRate: number = 10 / (lastSpan / 3600000); // bets per hour
    const prevRate: number = 10 / (prevSpan / 3600000);

    if (lastRate > prevRate * 2) {
      flags.push("Bet frequency has spiked significantly vs recent history.");
    }
  }

  return flags;
}
