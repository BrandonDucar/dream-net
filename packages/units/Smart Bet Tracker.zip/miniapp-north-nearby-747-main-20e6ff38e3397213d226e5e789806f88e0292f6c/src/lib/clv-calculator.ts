import type { CLVData } from '@/types/odds';

/**
 * Calculate Closing Line Value (CLV) for a bet
 * 
 * CLV = ((Closing Odds - User Odds) / |Opening Odds|) * 100
 * 
 * Positive CLV = User got better odds than market closing price (good)
 * Negative CLV = User got worse odds than market closing price (bad)
 */

export function calculateCLV(
  openingLine: number,
  userLine: number,
  closingLine: number
): CLVData | null {
  // Validate inputs
  if (!openingLine || !userLine || !closingLine) {
    return null;
  }

  // Calculate absolute difference
  const clvValue = closingLine - userLine;
  
  // Calculate percentage relative to opening line
  const clvPercent = (clvValue / Math.abs(openingLine)) * 100;

  return {
    betId: '', // Will be set by caller
    openingLine,
    userLine,
    closingLine,
    clvPercent,
    clvValue,
    isPositive: clvPercent > 0
  };
}

/**
 * Determine if a bet has positive CLV (beating the market)
 */
export function hasPositiveCLV(clv: CLVData | null | undefined): boolean {
  return clv ? clv.clvPercent > 0 : false;
}

/**
 * Get CLV rating based on percentage
 */
export function getCLVRating(clvPercent: number): 'excellent' | 'good' | 'neutral' | 'poor' | 'very-poor' {
  if (clvPercent > 3) return 'excellent';
  if (clvPercent > 0) return 'good';
  if (clvPercent > -2) return 'neutral';
  if (clvPercent > -5) return 'poor';
  return 'very-poor';
}

/**
 * Calculate average CLV for a set of bets
 */
export function calculateAverageCLV(clvData: (CLVData | null | undefined)[]): number {
  const validCLVs = clvData.filter((clv): clv is CLVData => clv !== null && clv !== undefined);
  
  if (validCLVs.length === 0) return 0;
  
  const sum = validCLVs.reduce((acc: number, clv: CLVData) => acc + clv.clvPercent, 0);
  return sum / validCLVs.length;
}

/**
 * Estimate expected value based on CLV
 * 
 * Studies show that bettors with positive CLV have positive expected value
 * This is a simplified model
 */
export function estimateEVFromCLV(
  clvPercent: number,
  stake: number,
  decimalOdds: number
): number {
  // Rough approximation: each 1% CLV adds ~0.5% to EV
  const evMultiplier = 1 + (clvPercent / 200);
  const potentialReturn = stake * (decimalOdds - 1);
  return potentialReturn * evMultiplier - stake;
}

/**
 * Convert American odds to decimal for CLV calculation
 */
export function americanToDecimal(american: number): number {
  if (american > 0) {
    return 1 + (american / 100);
  }
  return 1 + (100 / Math.abs(american));
}

/**
 * Convert decimal odds back to American
 */
export function decimalToAmerican(decimal: number): number {
  if (decimal >= 2) {
    return (decimal - 1) * 100;
  }
  return -100 / (decimal - 1);
}
