export interface Location {
  latitude: number;
  longitude: number;
  accuracy: number;
}

export interface UserState {
  name: string;
  code: string;
  isLegalBetting: boolean;
  legalSportsbooks: string[];
  responsibleGamingResources: string[];
}

// US states where sports betting is legal (as of 2025)
const LEGAL_BETTING_STATES: Record<string, UserState> = {
  AZ: {
    name: 'Arizona',
    code: 'AZ',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'Arizona Council on Compulsive Gambling: 1-800-522-4700',
      'https://www.arizonaproblemgambling.org'
    ]
  },
  CO: {
    name: 'Colorado',
    code: 'CO',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'PointsBet', 'Caesars'],
    responsibleGamingResources: [
      'Colorado Problem Gambling Hotline: 1-800-522-4700',
      'https://www.problemgamblingcolorado.org'
    ]
  },
  IL: {
    name: 'Illinois',
    code: 'IL',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'Illinois Gambling Helpline: 1-800-426-2537',
      'https://www.ilproblemgambling.org'
    ]
  },
  IN: {
    name: 'Indiana',
    code: 'IN',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'Indiana Problem Gambling Hotline: 1-800-994-8448',
      'https://www.in.gov/ips'
    ]
  },
  NJ: {
    name: 'New Jersey',
    code: 'NJ',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers', 'PointsBet'],
    responsibleGamingResources: [
      'New Jersey Council on Compulsive Gambling: 1-800-GAMBLER',
      'https://www.800gambler.org'
    ]
  },
  NY: {
    name: 'New York',
    code: 'NY',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers', 'PointsBet'],
    responsibleGamingResources: [
      'NY Problem Gambling Helpline: 1-877-8-HOPENY',
      'https://www.oasas.ny.gov/hopeline'
    ]
  },
  PA: {
    name: 'Pennsylvania',
    code: 'PA',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'PA Council on Compulsive Gambling: 1-800-522-4700',
      'https://www.pacouncil.com'
    ]
  },
  VA: {
    name: 'Virginia',
    code: 'VA',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'Virginia Problem Gambling Helpline: 1-888-532-3500',
      'https://www.vaproblemgambling.org'
    ]
  },
  TN: {
    name: 'Tennessee',
    code: 'TN',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars'],
    responsibleGamingResources: [
      'Tennessee RedLine: 1-800-889-9789',
      'https://www.tn.gov/behavioralhealth/need-help/gambling.html'
    ]
  },
  MI: {
    name: 'Michigan',
    code: 'MI',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars', 'BetRivers'],
    responsibleGamingResources: [
      'Michigan Problem Gambling Helpline: 1-800-270-7117',
      'https://www.michigan.gov/problemgambling'
    ]
  },
  WV: {
    name: 'West Virginia',
    code: 'WV',
    isLegalBetting: true,
    legalSportsbooks: ['DraftKings', 'FanDuel', 'BetMGM', 'Caesars'],
    responsibleGamingResources: [
      'WV Problem Gambling Helpline: 1-800-426-2537',
      'https://www.wvproblemgamblers.org'
    ]
  }
};

/**
 * Get user's current location using browser geolocation API
 */
export async function getUserLocation(): Promise<Location | null> {
  if (!navigator.geolocation) {
    console.error('Geolocation not supported');
    return null;
  }

  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position: GeolocationPosition) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy
        });
      },
      (error: GeolocationPositionError) => {
        console.error('Geolocation error:', error.message);
        resolve(null);
      },
      { timeout: 10000, maximumAge: 300000 }
    );
  });
}

/**
 * Reverse geocode coordinates to state (simplified - in production use Google Maps API)
 */
export async function getStateFromCoordinates(location: Location): Promise<string | null> {
  try {
    // Using a free geocoding service (in production, use Google Maps or similar)
    const response = await fetch(
      `https://nominatim.openstreetmap.org/reverse?format=json&lat=${location.latitude}&lon=${location.longitude}`
    );
    
    if (!response.ok) return null;
    
    const data: any = await response.json();
    const state: string | undefined = data.address?.state;
    
    if (!state) return null;
    
    // Convert state name to abbreviation (simplified mapping)
    const stateAbbreviations: Record<string, string> = {
      'Arizona': 'AZ',
      'Colorado': 'CO',
      'Illinois': 'IL',
      'Indiana': 'IN',
      'New Jersey': 'NJ',
      'New York': 'NY',
      'Pennsylvania': 'PA',
      'Virginia': 'VA',
      'Tennessee': 'TN',
      'Michigan': 'MI',
      'West Virginia': 'WV'
    };
    
    return stateAbbreviations[state as keyof typeof stateAbbreviations] || null;
  } catch (error) {
    console.error('Geocoding error:', error);
    return null;
  }
}

/**
 * Get betting legality and sportsbook info for a state
 */
export function getStateInfo(stateCode: string): UserState | null {
  const state = LEGAL_BETTING_STATES[stateCode as keyof typeof LEGAL_BETTING_STATES];
  return state || null;
}

/**
 * Get all legal betting states
 */
export function getAllLegalStates(): UserState[] {
  return Object.values(LEGAL_BETTING_STATES);
}

/**
 * Check if user is in a legal betting jurisdiction
 */
export async function checkLegalJurisdiction(): Promise<{
  isLegal: boolean;
  state: UserState | null;
  location: Location | null;
}> {
  const location: Location | null = await getUserLocation();
  
  if (!location) {
    return { isLegal: false, state: null, location: null };
  }
  
  const stateCode: string | null = await getStateFromCoordinates(location);
  
  if (!stateCode) {
    return { isLegal: false, state: null, location };
  }
  
  const state: UserState | null = getStateInfo(stateCode);
  
  return {
    isLegal: state?.isLegalBetting || false,
    state,
    location
  };
}

/**
 * Get line shopping recommendations based on location
 */
export function getLineShoppingRecommendations(state: UserState): string[] {
  const recommendations: string[] = [
    `Compare odds across these ${state.legalSportsbooks.length} legal books in ${state.name}:`,
    ...state.legalSportsbooks.map((book: string) => `• ${book}`)
  ];
  
  if (state.legalSportsbooks.length >= 3) {
    recommendations.push(
      '',
      'Pro tip: Even 0.5 point differences add up. Always shop for the best line before placing your bet.'
    );
  }
  
  return recommendations;
}

/**
 * Get promotional offers by state (mock data - in production, integrate with sportsbook APIs)
 */
export function getLocalPromos(state: UserState): Array<{ book: string; promo: string }> {
  // Mock promo data
  return state.legalSportsbooks.map((book: string) => ({
    book,
    promo: 'Check latest promotions on their app'
  }));
}
