/**
 * ================================================================================
 * Server-Side API Configuration - DO NOT EXPOSE TO CLIENT
 * ================================================================================
 * All API keys are managed server-side. End users never need to configure anything.
 * 
 * 🔑 HOW TO GET YOUR THE ODDS API KEY:
 * 1. Visit: https://the-odds-api.com
 * 2. Click "Sign Up" (no credit card required for free tier)
 * 3. Go to your dashboard after logging in
 * 4. Copy your API key from the account settings
 * 5. Paste it below, replacing 'YOUR_ODDS_API_KEY_HERE'
 * 
 * FREE TIER DETAILS:
 * - 500 requests per month
 * - Covers NFL, NBA, NHL, MLB, and 70+ other sports
 * - Access to 40+ bookmakers
 * - No credit card required
 * 
 * PAID TIERS (if you need more):
 * - $50-250/month for higher limits and production use
 */

export const SERVER_CONFIG = {
  /**
   * The Odds API Key - PASTE YOUR KEY HERE
   * Example: 'abc123def456ghi789jkl012mno345pq'
   */
  ODDS_API_KEY: '0f3f3161e2475b33ad47a25c85f61bd4',
  
  /**
   * OpenAI & Perplexity AI
   * ----------------------
   * Already configured via Ohara connections (server-side).
   * No additional setup needed - keys managed automatically.
   */
} as const;

/**
 * Check if The Odds API is configured
 */
export function isOddsApiConfigured(): boolean {
  return SERVER_CONFIG.ODDS_API_KEY !== 'YOUR_ODDS_API_KEY_HERE' && 
         SERVER_CONFIG.ODDS_API_KEY.length > 0;
}

/**
 * Get a user-friendly error message for missing configuration
 */
export function getConfigurationError(): { 
  error: string; 
  message: string; 
  setup: { 
    title: string; 
    steps: string[]; 
    file: string; 
    link: string;
  } 
} {
  return {
    error: 'The Odds API Key Not Configured',
    message: 'This sports betting analytics platform requires The Odds API to fetch real-time odds and game data.',
    setup: {
      title: 'Quick Setup (Free - No Credit Card Required)',
      steps: [
        '1. Visit https://the-odds-api.com and click "Sign Up"',
        '2. Verify your email and log in to your dashboard',
        '3. Copy your API key from the account settings page',
        '4. Open src/lib/server-config.ts in your code editor',
        '5. Replace \'YOUR_ODDS_API_KEY_HERE\' with your actual API key',
        '6. Save the file and refresh this page'
      ],
      file: 'src/lib/server-config.ts',
      link: 'https://the-odds-api.com'
    }
  };
}
