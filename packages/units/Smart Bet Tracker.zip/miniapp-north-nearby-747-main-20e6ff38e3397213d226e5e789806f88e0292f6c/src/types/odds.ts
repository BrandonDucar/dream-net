/**
 * Real-time odds data types for sports betting analytics
 */

export type OddsFormat = "american" | "decimal";
export type BetOutcome = "win" | "loss" | "push";
export type BetType = "spread" | "moneyline" | "total" | "prop";

export interface Sportsbook {
  key: string;
  name: string;
  title: string;
}

export interface BetMarket {
  key: string;
  name: string;
  last_update: string;
  outcomes: BetOutcome[];
}

export interface OddsOutcome {
  name: string;
  price: number; // American odds
  point?: number; // For spreads/totals
}

export interface BookmakerOdds {
  key: string;
  title: string;
  last_update: string;
  markets: Array<{
    key: string;
    last_update: string;
    outcomes: OddsOutcome[];
  }>;
}

export interface GameOdds {
  id: string;
  sport_key: string;
  sport_title: string;
  commence_time: string;
  home_team: string;
  away_team: string;
  bookmakers: BookmakerOdds[];
}

export interface LineMovement {
  timestamp: number;
  bookmaker: string;
  marketType: string;
  previousLine?: number;
  currentLine: number;
  previousOdds?: number;
  currentOdds: number;
  movement: "up" | "down" | "none";
  magnitude: number; // Points moved
}

export interface SteamMove {
  gameId: string;
  teams: string;
  marketType: string;
  bookmaker: string;
  movement: LineMovement;
  significance: "low" | "medium" | "high";
  reason: string;
  detected_at: number;
}

export interface CLVData {
  betId: string;
  openingLine: number;
  userLine: number;
  closingLine: number;
  clvPercent: number; // (userLine - closingLine) / abs(openingLine) * 100
  clvValue: number; // Absolute difference
  isPositive: boolean;
}

export interface EnhancedBet {
  id: string;
  placedAt: number;
  sport: string;
  league: string;
  description: string;
  betType: BetType;
  oddsFormat: OddsFormat;
  inputOdds: number;
  decimalOdds: number;
  stake: number;
  outcome: BetOutcome;
  profitLoss: number;
  tags: string[];
  confidence: number; // 1-10
  // Real-time odds data
  openingLine?: number;
  closingLine?: number;
  bestAvailableOdds?: number;
  bestAvailableBook?: string;
  clv?: CLVData;
  steamMove?: boolean;
  // Enhanced tracking
  timeOfDay?: string; // "morning" | "afternoon" | "evening" | "late-night"
  dayOfWeek?: string;
}

export interface LiveOddsRequest {
  sport: string;
  market?: string;
  bookmakers?: string[];
}

export interface LiveOddsResponse {
  games: GameOdds[];
  timestamp: number;
  sport: string;
  region: string;
}
