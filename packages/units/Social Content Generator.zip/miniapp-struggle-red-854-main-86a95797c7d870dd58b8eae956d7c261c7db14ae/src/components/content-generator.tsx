'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Sparkles, Copy, Download, Check } from 'lucide-react'
import { toast } from 'sonner'
import { generateContent } from '@/lib/content-generator'
import type { GeneratedContent } from '@/types/content'

interface ContentGeneratorProps {
  onGenerate: () => void
}

export function ContentGenerator({ onGenerate }: ContentGeneratorProps): JSX.Element {
  const [theme, setTheme] = useState<string>('')
  const [loading, setLoading] = useState<boolean>(false)
  const [content, setContent] = useState<GeneratedContent | null>(null)
  const [copiedIndex, setCopiedIndex] = useState<number>(-1)

  const handleGenerate = async (): Promise<void> => {
    if (!theme.trim()) {
      toast.error('Please enter a theme')
      return
    }

    setLoading(true)
    
    // Simulate generation delay for better UX
    await new Promise(resolve => setTimeout(resolve, 1000))
    
    const generated = generateContent(theme.trim())
    setContent(generated)
    
    // Save to history
    const history = JSON.parse(localStorage.getItem('contentHistory') || '[]') as GeneratedContent[]
    history.unshift(generated)
    localStorage.setItem('contentHistory', JSON.stringify(history.slice(0, 50))) // Keep last 50
    
    setLoading(false)
    onGenerate()
    toast.success('Content generated!')
  }

  const handleCopy = async (text: string, index: number): Promise<void> => {
    await navigator.clipboard.writeText(text)
    setCopiedIndex(index)
    toast.success('Copied to clipboard!')
    setTimeout(() => setCopiedIndex(-1), 2000)
  }

  const handleExportAll = async (): Promise<void> => {
    if (!content) return

    const exportText = `
🎯 THEME: ${content.theme}
⏰ Generated: ${new Date(content.timestamp).toLocaleString()}

💬 QUOTE:
${content.quote}

😂 MEME CAPTION:
${content.memeCaption}

🎨 AI IMAGE PROMPT:
${content.imagePrompt}

#️⃣ HASHTAGS:
${content.hashtags}

🎬 TIKTOK HOOK:
${content.tiktokHook}
    `.trim()

    await navigator.clipboard.writeText(exportText)
    toast.success('All content copied to clipboard!')
  }

  const handleDownload = (): void => {
    if (!content) return

    const exportText = `
🎯 THEME: ${content.theme}
⏰ Generated: ${new Date(content.timestamp).toLocaleString()}

💬 QUOTE:
${content.quote}

😂 MEME CAPTION:
${content.memeCaption}

🎨 AI IMAGE PROMPT:
${content.imagePrompt}

#️⃣ HASHTAGS:
${content.hashtags}

🎬 TIKTOK HOOK:
${content.tiktokHook}
    `.trim()

    const blob = new Blob([exportText], { type: 'text/plain' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `content-${content.theme.toLowerCase().replace(/\s+/g, '-')}-${Date.now()}.txt`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Content downloaded!')
  }

  const contentItems = content ? [
    { label: 'Quote', value: content.quote, icon: '💬', color: 'bg-blue-500' },
    { label: 'Meme Caption', value: content.memeCaption, icon: '😂', color: 'bg-green-500' },
    { label: 'AI Image Prompt', value: content.imagePrompt, icon: '🎨', color: 'bg-purple-500' },
    { label: 'Hashtags', value: content.hashtags, icon: '#️⃣', color: 'bg-pink-500' },
    { label: 'TikTok Hook', value: content.tiktokHook, icon: '🎬', color: 'bg-orange-500' },
  ] : []

  return (
    <Card className="shadow-xl border-2">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-600" />
          Generate Content
        </CardTitle>
        <CardDescription>
          Enter a theme and we'll create viral-ready content for you
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="Enter theme (e.g., crypto, hustle, mindset)"
            value={theme}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTheme(e.target.value)}
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                void handleGenerate()
              }
            }}
            className="flex-1"
          />
          <Button 
            onClick={() => void handleGenerate()} 
            disabled={loading}
            className="bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700"
          >
            {loading ? (
              <>
                <Sparkles className="w-4 h-4 mr-2 animate-spin" />
                Generating...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generate
              </>
            )}
          </Button>
        </div>

        {content && (
          <div className="space-y-3 mt-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="flex items-center justify-between mb-4">
              <Badge variant="outline" className="text-sm">
                Theme: {content.theme}
              </Badge>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => void handleExportAll()}
                >
                  <Copy className="w-4 h-4 mr-1" />
                  Copy All
                </Button>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={handleDownload}
                >
                  <Download className="w-4 h-4 mr-1" />
                  Download
                </Button>
              </div>
            </div>

            {contentItems.map((item, index) => (
              <Card key={index} className="border-l-4 hover:shadow-md transition-shadow" style={{ borderLeftColor: item.color.replace('bg-', '') }}>
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-2xl">{item.icon}</span>
                        <h3 className="font-semibold text-sm text-gray-700 dark:text-gray-300">
                          {item.label}
                        </h3>
                      </div>
                      <p className="text-sm text-gray-900 dark:text-gray-100 whitespace-pre-wrap">
                        {item.value}
                      </p>
                    </div>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => void handleCopy(item.value, index)}
                      className="shrink-0"
                    >
                      {copiedIndex === index ? (
                        <Check className="w-4 h-4 text-green-600" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        {!content && (
          <div className="text-center py-12 text-gray-500">
            <Sparkles className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p>Enter a theme to generate content</p>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
