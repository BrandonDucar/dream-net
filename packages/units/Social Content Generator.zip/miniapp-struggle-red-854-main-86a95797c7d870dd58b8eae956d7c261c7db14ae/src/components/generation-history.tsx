'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { History, Trash2, Eye, EyeOff } from 'lucide-react'
import { toast } from 'sonner'
import type { GeneratedContent } from '@/types/content'

export function GenerationHistory(): JSX.Element {
  const [history, setHistory] = useState<GeneratedContent[]>([])
  const [expandedIndex, setExpandedIndex] = useState<number>(-1)

  useEffect(() => {
    loadHistory()
  }, [])

  const loadHistory = (): void => {
    const stored = localStorage.getItem('contentHistory')
    if (stored) {
      setHistory(JSON.parse(stored) as GeneratedContent[])
    }
  }

  const clearHistory = (): void => {
    localStorage.removeItem('contentHistory')
    setHistory([])
    toast.success('History cleared')
  }

  const deleteItem = (index: number): void => {
    const newHistory = history.filter((_, i) => i !== index)
    localStorage.setItem('contentHistory', JSON.stringify(newHistory))
    setHistory(newHistory)
    toast.success('Item deleted')
  }

  const toggleExpand = (index: number): void => {
    setExpandedIndex(expandedIndex === index ? -1 : index)
  }

  return (
    <Card className="shadow-xl border-2 h-full">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5 text-purple-600" />
              Generation History
            </CardTitle>
            <CardDescription>
              Your recent content generations
            </CardDescription>
          </div>
          {history.length > 0 && (
            <Button
              size="sm"
              variant="outline"
              onClick={clearHistory}
              className="text-red-600 hover:text-red-700"
            >
              <Trash2 className="w-4 h-4 mr-1" />
              Clear
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent>
        {history.length === 0 ? (
          <div className="text-center py-12 text-gray-500">
            <History className="w-16 h-16 mx-auto mb-4 opacity-20" />
            <p>No history yet</p>
            <p className="text-sm mt-2">Generated content will appear here</p>
          </div>
        ) : (
          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2">
            {history.map((item, index) => (
              <Card key={index} className="border hover:shadow-md transition-shadow">
                <CardContent className="pt-4">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="secondary" className="text-xs">
                          {item.theme}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          {new Date(item.timestamp).toLocaleDateString()} {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                        </span>
                      </div>
                      
                      {expandedIndex === index ? (
                        <div className="space-y-2 text-sm">
                          <div>
                            <span className="font-semibold text-gray-700 dark:text-gray-300">Quote:</span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">{item.quote}</p>
                          </div>
                          <div>
                            <span className="font-semibold text-gray-700 dark:text-gray-300">Meme:</span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">{item.memeCaption}</p>
                          </div>
                          <div>
                            <span className="font-semibold text-gray-700 dark:text-gray-300">Image Prompt:</span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">{item.imagePrompt}</p>
                          </div>
                          <div>
                            <span className="font-semibold text-gray-700 dark:text-gray-300">Hashtags:</span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">{item.hashtags}</p>
                          </div>
                          <div>
                            <span className="font-semibold text-gray-700 dark:text-gray-300">TikTok Hook:</span>
                            <p className="text-gray-600 dark:text-gray-400 mt-1">{item.tiktokHook}</p>
                          </div>
                        </div>
                      ) : (
                        <p className="text-sm text-gray-600 dark:text-gray-400 truncate">
                          {item.quote}
                        </p>
                      )}
                    </div>
                    
                    <div className="flex gap-1 shrink-0">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => toggleExpand(index)}
                      >
                        {expandedIndex === index ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => deleteItem(index)}
                        className="text-red-600 hover:text-red-700"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  )
}
