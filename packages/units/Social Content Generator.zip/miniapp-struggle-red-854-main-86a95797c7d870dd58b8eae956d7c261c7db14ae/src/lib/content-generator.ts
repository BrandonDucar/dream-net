import type { GeneratedContent } from '@/types/content'

interface ContentTemplates {
  quotes: string[]
  memePrefixes: string[]
  memeSuffixes: string[]
  imageStyles: string[]
  hashtagCategories: Record<string, string[]>
  tiktokHooks: string[]
}

const templates: ContentTemplates = {
  quotes: [
    "The {theme} mindset isn't about being perfect, it's about being persistent.",
    "Success in {theme} comes to those who refuse to quit.",
    "Your {theme} journey starts with a single step forward.",
    "Master {theme} by doing, not by dreaming.",
    "In {theme}, consistency beats intensity every time.",
    "The best time to start your {theme} journey was yesterday. The second best time is now.",
    "Your {theme} breakthrough is hiding behind your next attempt.",
    "Don't wait for the perfect moment in {theme}. Create it.",
    "The {theme} game rewards the relentless, not the talented.",
    "{theme} success is the sum of small efforts repeated day in and day out.",
  ],
  memePrefixes: [
    "POV: You're crushing",
    "Nobody:",
    "That face when",
    "Me explaining",
    "When you realize",
    "How it started vs how it's going:",
    "Everyone else: sleeping | Me:",
    "My brain at 3am:",
    "Woke up and chose",
    "The duality of",
  ],
  memeSuffixes: [
    "and nobody can stop you",
    "like there's no tomorrow",
    "while everyone's watching",
    "to absolutely nobody",
    "and it hits different",
    "compilation",
    "researching {theme}",
    "violence in {theme}",
    "man",
    "king/queen behavior",
  ],
  imageStyles: [
    "minimalist digital art",
    "bold typography design",
    "neon cyberpunk aesthetic",
    "gradient abstract background",
    "retro vaporwave style",
    "modern geometric patterns",
    "3D rendered scene",
    "cinematic lighting",
    "watercolor illustration",
    "synthwave sunset",
  ],
  hashtagCategories: {
    general: ['motivation', 'success', 'grind', 'hustle', 'mindset', 'goals', 'viral', 'trending'],
    crypto: ['crypto', 'blockchain', 'bitcoin', 'ethereum', 'web3', 'defi', 'nft', 'btc', 'eth', 'cryptonews'],
    business: ['entrepreneur', 'business', 'startup', 'marketing', 'growth', 'sales', 'leadership', 'innovation'],
    fitness: ['fitness', 'workout', 'gym', 'health', 'wellness', 'fit', 'training', 'motivation'],
    mindset: ['mindset', 'selflove', 'positivity', 'inspiration', 'growth', 'personaldevelopment', 'selfcare'],
    tech: ['tech', 'technology', 'ai', 'coding', 'developer', 'startup', 'innovation', 'digital'],
  },
  tiktokHooks: [
    "Wait until you see what happens next...",
    "This changed everything I knew about {theme}",
    "Nobody talks about this side of {theme}",
    "Here's what they don't tell you about {theme}",
    "POV: You finally understand {theme}",
    "3 things I learned about {theme} that blew my mind",
    "This {theme} secret is actually insane",
    "Watch this if you're serious about {theme}",
    "The {theme} method nobody's using",
    "How I went from zero to hero in {theme}",
  ],
}

function randomChoice<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)]
}

function generateQuote(theme: string): string {
  const template = randomChoice(templates.quotes)
  return template.replace(/{theme}/g, theme)
}

function generateMemeCaption(theme: string): string {
  const prefix = randomChoice(templates.memePrefixes)
  const suffix = randomChoice(templates.memeSuffixes)
  return `${prefix} ${theme} ${suffix.replace(/{theme}/g, theme)}`
}

function generateImagePrompt(theme: string): string {
  const style = randomChoice(templates.imageStyles)
  const adjectives = ['inspirational', 'motivational', 'powerful', 'dynamic', 'bold', 'striking', 'energetic']
  const adjective = randomChoice(adjectives)
  
  return `A ${adjective} ${style} featuring ${theme} theme, professional quality, highly detailed, trending on social media, perfect for motivational content`
}

function generateHashtags(theme: string): string {
  const themeWords = theme.toLowerCase().split(' ')
  const category = Object.keys(templates.hashtagCategories).find(key => 
    themeWords.some(word => key.includes(word) || word.includes(key))
  ) || 'general'
  
  const categoryTags = templates.hashtagCategories[category]
  const generalTags = templates.hashtagCategories.general
  
  // Mix category-specific and general tags
  const selectedTags: string[] = []
  
  // Add theme-based tags
  themeWords.forEach(word => {
    if (word.length > 3) {
      selectedTags.push(word.replace(/[^a-z0-9]/g, ''))
    }
  })
  
  // Add random category tags
  for (let i = 0; i < 5; i++) {
    const tag = randomChoice(categoryTags)
    if (!selectedTags.includes(tag)) {
      selectedTags.push(tag)
    }
  }
  
  // Add some general tags
  for (let i = 0; i < 3; i++) {
    const tag = randomChoice(generalTags)
    if (!selectedTags.includes(tag)) {
      selectedTags.push(tag)
    }
  }
  
  return selectedTags.slice(0, 10).map(tag => `#${tag}`).join(' ')
}

function generateTikTokHook(theme: string): string {
  const template = randomChoice(templates.tiktokHooks)
  return template.replace(/{theme}/g, theme)
}

export function generateContent(theme: string): GeneratedContent {
  return {
    theme,
    quote: generateQuote(theme),
    memeCaption: generateMemeCaption(theme),
    imagePrompt: generateImagePrompt(theme),
    hashtags: generateHashtags(theme),
    tiktokHook: generateTikTokHook(theme),
    timestamp: Date.now(),
  }
}
