export interface GeneratedContent {
  theme: string
  quote: string
  memeCaption: string
  imagePrompt: string
  hashtags: string
  tiktokHook: string
  timestamp: number
}
