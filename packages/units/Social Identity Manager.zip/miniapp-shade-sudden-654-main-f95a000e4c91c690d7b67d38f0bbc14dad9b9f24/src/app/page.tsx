'use client'
import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Network, FileText, Copy, Filter, Brain, TrendingUp, DollarSign, Users, Shield, Zap, Download } from 'lucide-react';
import type { 
  PlatformAccount, 
  ContentStream, 
  RelayRoute,
  Platform,
  AccountStatus,
  PriorityLevel,
  ContentType,
  StreamStatus,
  AccountFilters,
  StreamFilters
} from '@/types/relay-matrix';
import { loadRelayData, getRoutesByAccountId, getRoutesByStreamId } from '@/lib/relay-storage';
import { getRelayMatrixSummary } from '@/lib/relay-logic';
import { AccountForm } from '@/components/relay-matrix/AccountForm';
import { StreamForm } from '@/components/relay-matrix/StreamForm';
import { RouteForm } from '@/components/relay-matrix/RouteForm';
import { AccountDetail } from '@/components/relay-matrix/AccountDetail';
import { StreamDetail } from '@/components/relay-matrix/StreamDetail';
import { RouteDetail } from '@/components/relay-matrix/RouteDetail';
import { AIRoutingDashboard } from '@/components/advanced/AIRoutingDashboard';
import { AnalyticsDashboard } from '@/components/advanced/AnalyticsDashboard';
import { CreatorEconomyDashboard } from '@/components/advanced/CreatorEconomyDashboard';
import { MultiAgentDashboard } from '@/components/advanced/MultiAgentDashboard';
import { CrisisDetectionPanel } from '@/components/advanced/CrisisDetectionPanel';
import { TrendSurfingDashboard } from '@/components/advanced/TrendSurfingDashboard';
import { AgentConfigExport } from '@/components/advanced/AgentConfigExport';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamNetRelayMatrix() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [accounts, setAccounts] = useState<PlatformAccount[]>([]);
  const [streams, setStreams] = useState<ContentStream[]>([]);
  const [routes, setRoutes] = useState<RelayRoute[]>([]);

  const [showAccountForm, setShowAccountForm] = useState<boolean>(false);
  const [showStreamForm, setShowStreamForm] = useState<boolean>(false);
  const [showRouteForm, setShowRouteForm] = useState<boolean>(false);
  const [showMatrixSummary, setShowMatrixSummary] = useState<boolean>(false);
  const [matrixSummary, setMatrixSummary] = useState<string>('');

  const [selectedAccount, setSelectedAccount] = useState<PlatformAccount | null>(null);
  const [selectedStream, setSelectedStream] = useState<ContentStream | null>(null);
  const [selectedRoute, setSelectedRoute] = useState<RelayRoute | null>(null);

  const [accountFilters, setAccountFilters] = useState<AccountFilters>({});
  const [streamFilters, setStreamFilters] = useState<StreamFilters>({});
  const [showFilters, setShowFilters] = useState<boolean>(false);

  const loadData = () => {
    const data = loadRelayData();
    setAccounts(data.platformAccounts);
    setStreams(data.contentStreams);
    setRoutes(data.relayRoutes);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleGenerateMatrixSummary = () => {
    const summary = getRelayMatrixSummary();
    setMatrixSummary(summary);
    setShowMatrixSummary(true);
  };

  const copyMatrixToClipboard = () => {
    navigator.clipboard.writeText(matrixSummary);
  };

  const getFilteredAccounts = (): PlatformAccount[] => {
    return accounts.filter((account: PlatformAccount) => {
      if (accountFilters.platform && account.platform !== accountFilters.platform) {
        return false;
      }
      if (accountFilters.status && account.status !== accountFilters.status) {
        return false;
      }
      if (accountFilters.priorityLevel && account.priorityLevel !== accountFilters.priorityLevel) {
        return false;
      }
      if (accountFilters.accountRole && !account.accountRole.toLowerCase().includes(accountFilters.accountRole.toLowerCase())) {
        return false;
      }
      return true;
    });
  };

  const getFilteredStreams = (): ContentStream[] => {
    return streams.filter((stream: ContentStream) => {
      if (streamFilters.type && stream.type !== streamFilters.type) {
        return false;
      }
      if (streamFilters.status && stream.status !== streamFilters.status) {
        return false;
      }
      if (streamFilters.sourceMiniApp && !stream.sourceMiniApp.toLowerCase().includes(streamFilters.sourceMiniApp.toLowerCase())) {
        return false;
      }
      if (streamFilters.tagSearch && !stream.tags.some((tag: string) => tag.toLowerCase().includes(streamFilters.tagSearch?.toLowerCase() || ''))) {
        return false;
      }
      return true;
    });
  };

  const clearAccountFilters = () => {
    setAccountFilters({});
  };

  const clearStreamFilters = () => {
    setStreamFilters({});
  };

  if (selectedAccount) {
    return (
      <div className="min-h-screen bg-white text-black p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <Button variant="outline" onClick={() => setSelectedAccount(null)} className="mb-4">
            ← Back to Matrix
          </Button>
          <AccountDetail
            account={selectedAccount}
            onClose={() => setSelectedAccount(null)}
            onUpdate={() => {
              loadData();
              const updated = accounts.find((a: PlatformAccount) => a.id === selectedAccount.id);
              if (updated) {
                setSelectedAccount(updated);
              }
            }}
          />
        </div>
      </div>
    );
  }

  if (selectedStream) {
    return (
      <div className="min-h-screen bg-white text-black p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <Button variant="outline" onClick={() => setSelectedStream(null)} className="mb-4">
            ← Back to Matrix
          </Button>
          <StreamDetail
            stream={selectedStream}
            onClose={() => setSelectedStream(null)}
            onUpdate={() => {
              loadData();
              const updated = streams.find((s: ContentStream) => s.id === selectedStream.id);
              if (updated) {
                setSelectedStream(updated);
              }
            }}
          />
        </div>
      </div>
    );
  }

  if (selectedRoute) {
    return (
      <div className="min-h-screen bg-white text-black p-4 md:p-8">
        <div className="max-w-6xl mx-auto">
          <Button variant="outline" onClick={() => setSelectedRoute(null)} className="mb-4">
            ← Back to Matrix
          </Button>
          <RouteDetail
            route={selectedRoute}
            onClose={() => setSelectedRoute(null)}
            onUpdate={() => {
              loadData();
              const updated = routes.find((r: RelayRoute) => r.id === selectedRoute.id);
              if (updated) {
                setSelectedRoute(updated);
              }
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white text-black p-4 md:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold">DreamNet Social Relay Matrix</h1>
            <p className="text-gray-500 mt-1">Orchestrate your social identity swarm across platforms</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <Button onClick={() => setShowFilters(!showFilters)} variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
            <Button onClick={handleGenerateMatrixSummary} variant="outline">
              <FileText className="h-4 w-4 mr-2" />
              Matrix Summary
            </Button>
          </div>
        </div>

        {showFilters && (
          <Card>
            <CardHeader>
              <CardTitle>Filters</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="accounts">
                <TabsList>
                  <TabsTrigger value="accounts">Account Filters</TabsTrigger>
                  <TabsTrigger value="streams">Stream Filters</TabsTrigger>
                </TabsList>
                <TabsContent value="accounts" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>Platform</Label>
                      <Select 
                        value={accountFilters.platform || ''} 
                        onValueChange={(value: string) => setAccountFilters({ ...accountFilters, platform: value ? value as Platform : undefined })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All platforms" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All platforms</SelectItem>
                          <SelectItem value="farcaster">Farcaster</SelectItem>
                          <SelectItem value="x">X (Twitter)</SelectItem>
                          <SelectItem value="warpcast">Warpcast</SelectItem>
                          <SelectItem value="zora">Zora</SelectItem>
                          <SelectItem value="lens">Lens</SelectItem>
                          <SelectItem value="base-feed">Base Feed</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select 
                        value={accountFilters.status || ''} 
                        onValueChange={(value: string) => setAccountFilters({ ...accountFilters, status: value ? value as AccountStatus : undefined })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All statuses" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All statuses</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="paused">Paused</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Priority</Label>
                      <Select 
                        value={accountFilters.priorityLevel || ''} 
                        onValueChange={(value: string) => setAccountFilters({ ...accountFilters, priorityLevel: value ? value as PriorityLevel : undefined })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All priorities" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All priorities</SelectItem>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="critical">Critical</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Role</Label>
                      <Input
                        placeholder="Search role..."
                        value={accountFilters.accountRole || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAccountFilters({ ...accountFilters, accountRole: e.target.value || undefined })}
                      />
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={clearAccountFilters}>
                    Clear Filters
                  </Button>
                </TabsContent>
                <TabsContent value="streams" className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="space-y-2">
                      <Label>Type</Label>
                      <Select 
                        value={streamFilters.type || ''} 
                        onValueChange={(value: string) => setStreamFilters({ ...streamFilters, type: value ? value as ContentType : undefined })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All types" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All types</SelectItem>
                          <SelectItem value="token">Token</SelectItem>
                          <SelectItem value="drop">Drop</SelectItem>
                          <SelectItem value="meme">Meme</SelectItem>
                          <SelectItem value="campaign">Campaign</SelectItem>
                          <SelectItem value="pickleball">Pickleball</SelectItem>
                          <SelectItem value="devlog">Devlog</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Status</Label>
                      <Select 
                        value={streamFilters.status || ''} 
                        onValueChange={(value: string) => setStreamFilters({ ...streamFilters, status: value ? value as StreamStatus : undefined })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="All statuses" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="">All statuses</SelectItem>
                          <SelectItem value="idea">Idea</SelectItem>
                          <SelectItem value="active">Active</SelectItem>
                          <SelectItem value="paused">Paused</SelectItem>
                          <SelectItem value="retired">Retired</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>Source Mini-App</Label>
                      <Input
                        placeholder="Search source..."
                        value={streamFilters.sourceMiniApp || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStreamFilters({ ...streamFilters, sourceMiniApp: e.target.value || undefined })}
                      />
                    </div>
                    <div className="space-y-2">
                      <Label>Tags</Label>
                      <Input
                        placeholder="Search tags..."
                        value={streamFilters.tagSearch || ''}
                        onChange={(e: React.ChangeEvent<HTMLInputElement>) => setStreamFilters({ ...streamFilters, tagSearch: e.target.value || undefined })}
                      />
                    </div>
                  </div>
                  <Button variant="outline" size="sm" onClick={clearStreamFilters}>
                    Clear Filters
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        )}

        <Tabs defaultValue="matrix" className="w-full">
          <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8">
            <TabsTrigger value="matrix">
              <Network className="h-4 w-4 mr-2" />
              Matrix
            </TabsTrigger>
            <TabsTrigger value="ai-routing">
              <Brain className="h-4 w-4 mr-2" />
              AI Routing
            </TabsTrigger>
            <TabsTrigger value="analytics">
              <TrendingUp className="h-4 w-4 mr-2" />
              Analytics
            </TabsTrigger>
            <TabsTrigger value="economy">
              <DollarSign className="h-4 w-4 mr-2" />
              Economy
            </TabsTrigger>
            <TabsTrigger value="agents">
              <Users className="h-4 w-4 mr-2" />
              Agents
            </TabsTrigger>
            <TabsTrigger value="crisis">
              <Shield className="h-4 w-4 mr-2" />
              Crisis
            </TabsTrigger>
            <TabsTrigger value="trends">
              <Zap className="h-4 w-4 mr-2" />
              Trends
            </TabsTrigger>
            <TabsTrigger value="export">
              <Download className="h-4 w-4 mr-2" />
              Export
            </TabsTrigger>
          </TabsList>

          <TabsContent value="matrix" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Platform Accounts</CardTitle>
                  <CardDescription>{getFilteredAccounts().length} of {accounts.length} accounts</CardDescription>
                </div>
                <Button size="sm" onClick={() => setShowAccountForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Register Account
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Account</TableHead>
                      <TableHead>Platform</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Priority</TableHead>
                      <TableHead>Routes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getFilteredAccounts().length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500">
                          No accounts found. Register your first account!
                        </TableCell>
                      </TableRow>
                    ) : (
                      getFilteredAccounts().map((account: PlatformAccount) => {
                        const routeCount = getRoutesByAccountId(account.id).length;
                        return (
                          <TableRow 
                            key={account.id} 
                            className="cursor-pointer hover:bg-gray-50"
                            onClick={() => setSelectedAccount(account)}
                          >
                            <TableCell>
                              <div>
                                <p className="font-medium">{account.displayName}</p>
                                <p className="text-xs text-gray-500">@{account.handle}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{account.platform}</Badge>
                            </TableCell>
                            <TableCell className="text-sm">{account.accountRole}</TableCell>
                            <TableCell>
                              <Badge variant={
                                account.priorityLevel === 'critical' ? 'destructive' :
                                account.priorityLevel === 'high' ? 'default' :
                                'secondary'
                              }>
                                {account.priorityLevel}
                              </Badge>
                            </TableCell>
                            <TableCell>
                              <Badge variant="outline">{routeCount}</Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Content Streams</CardTitle>
                  <CardDescription>{getFilteredStreams().length} of {streams.length} streams</CardDescription>
                </div>
                <Button size="sm" onClick={() => setShowStreamForm(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  Register Stream
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Type</TableHead>
                      <TableHead>Source</TableHead>
                      <TableHead>Cadence</TableHead>
                      <TableHead>Routes</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {getFilteredStreams().length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={5} className="text-center text-gray-500">
                          No streams found. Register your first stream!
                        </TableCell>
                      </TableRow>
                    ) : (
                      getFilteredStreams().map((stream: ContentStream) => {
                        const routeCount = getRoutesByStreamId(stream.id).length;
                        return (
                          <TableRow 
                            key={stream.id} 
                            className="cursor-pointer hover:bg-gray-50"
                            onClick={() => setSelectedStream(stream)}
                          >
                            <TableCell>
                              <div>
                                <p className="font-medium">{stream.name}</p>
                                <p className="text-xs text-gray-500">{stream.description.substring(0, 50)}{stream.description.length > 50 ? '...' : ''}</p>
                              </div>
                            </TableCell>
                            <TableCell>
                              <Badge>{stream.type}</Badge>
                            </TableCell>
                            <TableCell className="text-sm">{stream.sourceMiniApp}</TableCell>
                            <TableCell className="text-sm">{stream.cadenceHint}</TableCell>
                            <TableCell>
                              <Badge variant="outline">{routeCount}</Badge>
                            </TableCell>
                          </TableRow>
                        );
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Relay Routes</CardTitle>
                <CardDescription>{routes.length} routes configured</CardDescription>
              </div>
              <Button size="sm" onClick={() => setShowRouteForm(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Create Route
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Route Name</TableHead>
                    <TableHead>Stream → Account</TableHead>
                    <TableHead>Risk</TableHead>
                    <TableHead>Approval</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {routes.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={4} className="text-center text-gray-500">
                        No routes found. Create your first relay route!
                      </TableCell>
                    </TableRow>
                  ) : (
                    routes.map((route: RelayRoute) => {
                      const stream = streams.find((s: ContentStream) => s.id === route.contentStreamId);
                      const account = accounts.find((a: PlatformAccount) => a.id === route.platformAccountId);
                      return (
                        <TableRow 
                          key={route.id} 
                          className="cursor-pointer hover:bg-gray-50"
                          onClick={() => setSelectedRoute(route)}
                        >
                          <TableCell>
                            <p className="font-medium">{route.routeName}</p>
                            <p className="text-xs text-gray-500">{route.purpose.substring(0, 50)}{route.purpose.length > 50 ? '...' : ''}</p>
                          </TableCell>
                          <TableCell className="text-sm">
                            <div className="flex items-center gap-1">
                              <span className="text-gray-500">{stream?.name || 'Unknown'}</span>
                              <span>→</span>
                              <span>{account?.displayName || 'Unknown'}</span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <Badge variant={
                              route.riskLevel === 'high' ? 'destructive' :
                              route.riskLevel === 'medium' ? 'default' :
                              'secondary'
                            }>
                              {route.riskLevel}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {route.manualApprovalRequired ? (
                              <Badge variant="outline">Manual</Badge>
                            ) : (
                              <Badge variant="secondary">Auto</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Dialog open={showAccountForm} onOpenChange={setShowAccountForm}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Register Platform Account</DialogTitle>
              <DialogDescription>
                Add a new social media account to your relay matrix
              </DialogDescription>
            </DialogHeader>
            <AccountForm
              onSave={() => {
                setShowAccountForm(false);
                loadData();
              }}
              onCancel={() => setShowAccountForm(false)}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={showStreamForm} onOpenChange={setShowStreamForm}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Register Content Stream</DialogTitle>
              <DialogDescription>
                Add a new content stream to your relay matrix
              </DialogDescription>
            </DialogHeader>
            <StreamForm
              onSave={() => {
                setShowStreamForm(false);
                loadData();
              }}
              onCancel={() => setShowStreamForm(false)}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={showRouteForm} onOpenChange={setShowRouteForm}>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Relay Route</DialogTitle>
              <DialogDescription>
                Connect a content stream to a platform account
              </DialogDescription>
            </DialogHeader>
            <RouteForm
              onSave={() => {
                setShowRouteForm(false);
                loadData();
              }}
              onCancel={() => setShowRouteForm(false)}
            />
          </DialogContent>
        </Dialog>

        <Dialog open={showMatrixSummary} onOpenChange={setShowMatrixSummary}>
          <DialogContent className="max-w-4xl max-h-[90vh]">
            <DialogHeader>
              <DialogTitle>Relay Matrix Summary</DialogTitle>
              <DialogDescription>
                Complete overview of your social relay matrix configuration
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <Textarea
                value={matrixSummary}
                readOnly
                rows={25}
                className="font-mono text-xs"
              />
              <Button onClick={copyMatrixToClipboard} className="w-full">
                <Copy className="h-4 w-4 mr-2" />
                Copy to Clipboard
              </Button>
            </div>
          </DialogContent>
        </Dialog>
          </TabsContent>

          <TabsContent value="ai-routing">
            <AIRoutingDashboard />
          </TabsContent>

          <TabsContent value="analytics">
            <AnalyticsDashboard />
          </TabsContent>

          <TabsContent value="economy">
            <CreatorEconomyDashboard />
          </TabsContent>

          <TabsContent value="agents">
            <MultiAgentDashboard />
          </TabsContent>

          <TabsContent value="crisis">
            <CrisisDetectionPanel />
          </TabsContent>

          <TabsContent value="trends">
            <TrendSurfingDashboard />
          </TabsContent>

          <TabsContent value="export">
            <AgentConfigExport />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
