'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { loadAdvancedData, saveAdvancedData } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { analyzeContentForRouting, transformContentForTone } from '@/lib/advanced-logic';
import type { RoutingDecision } from '@/types/advanced-features';
import type { PlatformAccount } from '@/types/relay-matrix';
import { Sparkles, Brain, Zap, AlertTriangle } from 'lucide-react';

export function AIRoutingDashboard(): JSX.Element {
  const [testContent, setTestContent] = useState<string>('');
  const [decision, setDecision] = useState<RoutingDecision | null>(null);
  const [transformations, setTransformations] = useState<Record<string, string>>({});
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [config, setConfig] = useState(loadAdvancedData().routingAgentConfig);
  const [recentDecisions, setRecentDecisions] = useState<RoutingDecision[]>([]);

  useEffect(() => {
    setRecentDecisions(loadAdvancedData().routingDecisions.slice(-5).reverse());
  }, []);

  const handleAnalyze = async (): Promise<void> => {
    if (!testContent.trim()) return;

    setIsAnalyzing(true);
    
    setTimeout(() => {
      const relayData = loadRelayData();
      const newDecision = analyzeContentForRouting(
        testContent,
        relayData.relayRoutes,
        relayData.platformAccounts
      );
      
      setDecision(newDecision);
      
      // Get accounts for suggested routes
      const suggestedAccounts = newDecision.suggestedRoutes
        .map((routeId: string) => {
          const route = relayData.relayRoutes.find((r) => r.id === routeId);
          return route ? relayData.platformAccounts.find((a) => a.id === route.platformAccountId) : undefined;
        })
        .filter((a): a is PlatformAccount => a !== undefined);
      
      const toneTransform = transformContentForTone(testContent, suggestedAccounts);
      setTransformations(toneTransform.transformedVersions);
      
      // Save decision
      const advancedData = loadAdvancedData();
      advancedData.routingDecisions.push(newDecision);
      saveAdvancedData(advancedData);
      setRecentDecisions([newDecision, ...recentDecisions].slice(0, 5));
      
      setIsAnalyzing(false);
    }, 1500);
  };

  const updateConfig = (updates: Partial<typeof config>): void => {
    const newConfig = { ...config, ...updates };
    setConfig(newConfig);
    const advancedData = loadAdvancedData();
    advancedData.routingAgentConfig = newConfig;
    saveAdvancedData(advancedData);
  };

  const relayData = loadRelayData();

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Routing Agent Configuration
          </CardTitle>
          <CardDescription>
            Configure autonomous routing decisions and tone transformations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Enable AI Routing</Label>
              <p className="text-sm text-muted-foreground">
                Automatically suggest routes for content
              </p>
            </div>
            <Switch
              checked={config.enabled}
              onCheckedChange={(checked: boolean) => updateConfig({ enabled: checked })}
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Learning Mode</Label>
              <p className="text-sm text-muted-foreground">
                Learn from past routing decisions
              </p>
            </div>
            <Switch
              checked={config.learningEnabled}
              onCheckedChange={(checked: boolean) => updateConfig({ learningEnabled: checked })}
            />
          </div>

          <div className="space-y-2">
            <Label>Auto-Approve Threshold: {(config.autoApproveThreshold * 100).toFixed(0)}%</Label>
            <input
              type="range"
              min="0"
              max="100"
              value={config.autoApproveThreshold * 100}
              onChange={(e: React.ChangeEvent<HTMLInputElement>) => 
                updateConfig({ autoApproveThreshold: parseInt(e.target.value) / 100 })
              }
              className="w-full"
            />
            <p className="text-sm text-muted-foreground">
              Routes above this confidence will be auto-approved
            </p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Test AI Routing
          </CardTitle>
          <CardDescription>
            Analyze content and get routing suggestions with tone transformations
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Content to Analyze</Label>
            <Textarea
              placeholder="Enter content to test AI routing... (e.g., 'Just launched a new NFT collection!')"
              value={testContent}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setTestContent(e.target.value)}
              rows={4}
            />
          </div>

          <Button 
            onClick={handleAnalyze} 
            disabled={isAnalyzing || !testContent.trim()}
            className="w-full"
          >
            {isAnalyzing ? 'Analyzing...' : 'Analyze Content'}
            <Zap className="ml-2 h-4 w-4" />
          </Button>

          {decision && (
            <div className="space-y-4 border-t pt-4">
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Routing Decision</h4>
                <Badge variant={decision.autoApproved ? 'default' : 'secondary'}>
                  {decision.autoApproved ? 'Auto-Approved' : 'Needs Review'}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Confidence:</span>
                  <Badge variant="outline">
                    {(decision.confidence * 100).toFixed(0)}%
                  </Badge>
                  <span className="text-sm font-medium">Risk:</span>
                  <Badge variant={decision.riskScore > 0.6 ? 'destructive' : 'default'}>
                    {(decision.riskScore * 100).toFixed(0)}%
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{decision.reasoning}</p>
              </div>

              <div className="space-y-2">
                <h5 className="font-medium">Suggested Routes ({decision.suggestedRoutes.length})</h5>
                {decision.suggestedRoutes.map((routeId: string) => {
                  const route = relayData.relayRoutes.find((r) => r.id === routeId);
                  const account = route ? relayData.platformAccounts.find((a) => a.id === route.platformAccountId) : undefined;
                  const transformation = account ? transformations[account.id] : null;

                  return route && account ? (
                    <Card key={routeId}>
                      <CardContent className="pt-4">
                        <div className="space-y-2">
                          <div className="flex items-center justify-between">
                            <span className="font-medium">
                              {account.displayName} (@{account.handle})
                            </span>
                            <Badge>{account.platform}</Badge>
                          </div>
                          <p className="text-sm text-muted-foreground">
                            Route: {route.routeName}
                          </p>
                          {transformation && (
                            <div className="bg-muted p-3 rounded-md">
                              <p className="text-sm font-medium mb-1">Tone-Transformed:</p>
                              <p className="text-sm">{transformation}</p>
                            </div>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  ) : null;
                })}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Routing Decisions</CardTitle>
          <CardDescription>Last 5 AI-powered routing decisions</CardDescription>
        </CardHeader>
        <CardContent>
          {recentDecisions.length === 0 ? (
            <p className="text-sm text-muted-foreground">No decisions yet. Test some content above!</p>
          ) : (
            <div className="space-y-2">
              {recentDecisions.map((dec: RoutingDecision) => (
                <div key={dec.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">
                        {(dec.confidence * 100).toFixed(0)}% confidence
                      </Badge>
                      <Badge variant={dec.autoApproved ? 'default' : 'secondary'}>
                        {dec.autoApproved ? 'Auto' : 'Manual'}
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {new Date(dec.timestamp).toLocaleString()}
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{dec.suggestedRoutes.length} routes</p>
                    {dec.riskScore > 0.6 && (
                      <AlertTriangle className="h-4 w-4 text-destructive ml-auto" />
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
