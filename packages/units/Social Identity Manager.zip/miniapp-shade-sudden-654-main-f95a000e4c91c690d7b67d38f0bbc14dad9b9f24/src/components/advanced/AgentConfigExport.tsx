'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { loadRelayData } from '@/lib/relay-storage';
import { exportToAgentConfig } from '@/lib/advanced-logic';
import type { AgentConfigExport } from '@/types/advanced-features';
import { Download, Code, FileJson, Cpu, Copy, CheckCircle } from 'lucide-react';

export function AgentConfigExport(): JSX.Element {
  const [exportData, setExportData] = useState<AgentConfigExport | null>(null);
  const [format, setFormat] = useState<'json' | 'yaml' | 'python'>('json');
  const [copied, setCopied] = useState<boolean>(false);

  const generateExport = (): void => {
    const relayData = loadRelayData();
    const config = exportToAgentConfig(
      relayData.platformAccounts,
      relayData.contentStreams,
      relayData.relayRoutes
    );
    setExportData(config);
  };

  const copyToClipboard = (): void => {
    if (!exportData) return;

    let output = '';
    if (format === 'json') {
      output = JSON.stringify(exportData, null, 2);
    } else if (format === 'yaml') {
      output = convertToYAML(exportData);
    } else if (format === 'python') {
      output = convertToPython(exportData);
    }

    navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const downloadFile = (): void => {
    if (!exportData) return;

    let output = '';
    let filename = '';
    let mimeType = '';

    if (format === 'json') {
      output = JSON.stringify(exportData, null, 2);
      filename = 'relay-matrix-config.json';
      mimeType = 'application/json';
    } else if (format === 'yaml') {
      output = convertToYAML(exportData);
      filename = 'relay-matrix-config.yaml';
      mimeType = 'text/yaml';
    } else if (format === 'python') {
      output = convertToPython(exportData);
      filename = 'relay_matrix_config.py';
      mimeType = 'text/x-python';
    }

    const blob = new Blob([output], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Code className="h-5 w-5" />
            Agent Config Export
          </CardTitle>
          <CardDescription>
            Export your relay matrix as machine-readable config for autonomous agents
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={generateExport} className="flex-1">
              <FileJson className="h-4 w-4 mr-2" />
              Generate Config
            </Button>
            {exportData && (
              <>
                <Button onClick={copyToClipboard} variant="outline">
                  {copied ? (
                    <CheckCircle className="h-4 w-4 mr-2" />
                  ) : (
                    <Copy className="h-4 w-4 mr-2" />
                  )}
                  {copied ? 'Copied!' : 'Copy'}
                </Button>
                <Button onClick={downloadFile} variant="outline">
                  <Download className="h-4 w-4 mr-2" />
                  Download
                </Button>
              </>
            )}
          </div>

          {exportData && (
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <Badge variant="outline">Version: {exportData.version}</Badge>
                <Badge variant="outline">{exportData.relayMatrix.accounts.length} accounts</Badge>
                <Badge variant="outline">{exportData.relayMatrix.streams.length} streams</Badge>
                <Badge variant="outline">{exportData.relayMatrix.routes.length} routes</Badge>
              </div>

              <Tabs value={format} onValueChange={(v: string) => setFormat(v as 'json' | 'yaml' | 'python')}>
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="json">JSON</TabsTrigger>
                  <TabsTrigger value="yaml">YAML</TabsTrigger>
                  <TabsTrigger value="python">Python</TabsTrigger>
                </TabsList>

                <TabsContent value="json" className="space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <FileJson className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Standard JSON format for any agent
                    </span>
                  </div>
                  <Textarea
                    value={JSON.stringify(exportData, null, 2)}
                    readOnly
                    className="font-mono text-xs h-[400px]"
                  />
                </TabsContent>

                <TabsContent value="yaml" className="space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <FileJson className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      YAML format for Docker/K8s configs
                    </span>
                  </div>
                  <Textarea
                    value={convertToYAML(exportData)}
                    readOnly
                    className="font-mono text-xs h-[400px]"
                  />
                </TabsContent>

                <TabsContent value="python" className="space-y-2">
                  <div className="flex items-center gap-2 mb-2">
                    <Cpu className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm text-muted-foreground">
                      Python script template for automation
                    </span>
                  </div>
                  <Textarea
                    value={convertToPython(exportData)}
                    readOnly
                    className="font-mono text-xs h-[400px]"
                  />
                </TabsContent>
              </Tabs>
            </div>
          )}
        </CardContent>
      </Card>

      {exportData && (
        <Card>
          <CardHeader>
            <CardTitle>Quick Start Guide</CardTitle>
            <CardDescription>How to use this config with autonomous agents</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-3">
              <div className="border-l-4 border-primary pl-4">
                <h4 className="font-semibold mb-1">Option 1: OpenAI GPT-4 Agent</h4>
                <p className="text-sm text-muted-foreground">
                  Feed this JSON to GPT-4 with instructions: &quot;You are a social media agent. 
                  Use this config to route content to the right accounts with the right tone.&quot;
                </p>
              </div>

              <div className="border-l-4 border-primary pl-4">
                <h4 className="font-semibold mb-1">Option 2: Claude Agent</h4>
                <p className="text-sm text-muted-foreground">
                  Upload this config as a &quot;Project Knowledge&quot; file in Claude. 
                  It will automatically reference routing rules and tone presets.
                </p>
              </div>

              <div className="border-l-4 border-primary pl-4">
                <h4 className="font-semibold mb-1">Option 3: Custom Python Bot</h4>
                <p className="text-sm text-muted-foreground">
                  Use the Python export as a starting template. Add your API keys 
                  and implement the posting logic using the routing rules provided.
                </p>
              </div>

              <div className="border-l-4 border-primary pl-4">
                <h4 className="font-semibold mb-1">Option 4: AutoGPT / AgentGPT</h4>
                <p className="text-sm text-muted-foreground">
                  Load this config as a &quot;system prompt&quot; or &quot;memory&quot; file. 
                  The agent will learn your social strategy and execute autonomously.
                </p>
              </div>
            </div>

            <div className="bg-muted p-4 rounded-lg">
              <p className="text-sm font-medium mb-2">💡 Pro Tip:</p>
              <p className="text-sm text-muted-foreground">
                Combine this config with the Multi-Agent Dashboard. Register your autonomous 
                agent there so it can request posting permissions through the approval workflow.
              </p>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function convertToYAML(data: AgentConfigExport): string {
  return `version: "${data.version}"
exportedAt: "${data.exportedAt}"

accounts:
${data.relayMatrix.accounts.map((acc) => `  - id: "${acc.id}"
    platform: "${acc.platform}"
    handle: "${acc.handle}"
    role: "${acc.role}"
    capabilities: [${acc.capabilities.map((c) => `"${c}"`).join(', ')}]`).join('\n')}

streams:
${data.relayMatrix.streams.map((stream) => `  - id: "${stream.id}"
    name: "${stream.name}"
    type: "${stream.type}"
    source: "${stream.source}"`).join('\n')}

routes:
${data.relayMatrix.routes.map((route) => `  - id: "${route.id}"
    from: "${route.from}"
    to: "${route.to}"
    rules: [${route.rules.map((r) => `"${r}"`).join(', ')}]
    tone: [${route.tone.map((t) => `"${t}"`).join(', ')}]
    risk: "${route.risk}"`).join('\n')}
`;
}

function convertToPython(data: AgentConfigExport): string {
  return `"""
DreamNet Social Relay Matrix - Autonomous Agent Config
Generated: ${data.exportedAt}
Version: ${data.version}
"""

# Account configurations
ACCOUNTS = ${JSON.stringify(data.relayMatrix.accounts, null, 2)}

# Content streams
STREAMS = ${JSON.stringify(data.relayMatrix.streams, null, 2)}

# Routing rules
ROUTES = ${JSON.stringify(data.relayMatrix.routes, null, 2)}

# Tone presets
TONE_PRESETS = ${JSON.stringify(data.autonomousAgentConfig.tonePresets, null, 2)}

# Posting schedule
POSTING_SCHEDULE = ${JSON.stringify(data.autonomousAgentConfig.postingSchedule, null, 2)}


class RelayMatrixAgent:
    """Autonomous posting agent using relay matrix config"""
    
    def __init__(self):
        self.accounts = ACCOUNTS
        self.streams = STREAMS
        self.routes = ROUTES
        self.tone_presets = TONE_PRESETS
    
    def route_content(self, content_stream_id, content):
        """Find the best route for content"""
        matching_routes = [r for r in self.routes if r['from'] == content_stream_id]
        # Add your routing logic here
        return matching_routes
    
    def transform_tone(self, content, target_account_id):
        """Transform content tone for specific account"""
        account = next((a for a in self.accounts if a['id'] == target_account_id), None)
        if not account:
            return content
        # Add your tone transformation logic here
        return content
    
    def post(self, account_id, content):
        """Post content to account (implement with actual API calls)"""
        account = next((a for a in self.accounts if a['id'] == account_id), None)
        print(f"Posting to {account['handle']} on {account['platform']}: {content}")
        # Add actual posting logic with API calls


if __name__ == "__main__":
    agent = RelayMatrixAgent()
    # Example usage:
    # routes = agent.route_content("stream-123", "Check out our new drop!")
    # for route in routes:
    #     transformed = agent.transform_tone("Content...", route['to'])
    #     agent.post(route['to'], transformed)
`;
}
