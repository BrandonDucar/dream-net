'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { loadAdvancedData, addToAdvancedArray } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { calculateReputationScore, generateAudienceSegments, analyzeCadence } from '@/lib/advanced-logic';
import type { ReputationScore, AudienceSegment, CadenceRecommendation } from '@/types/advanced-features';
import type { PlatformAccount } from '@/types/relay-matrix';
import { TrendingUp, Users, Target, Activity, AlertCircle, CheckCircle } from 'lucide-react';

export function AnalyticsDashboard(): JSX.Element {
  const [selectedAccountId, setSelectedAccountId] = useState<string>('');
  const [reputationScores, setReputationScores] = useState<ReputationScore[]>([]);
  const [audienceSegments, setAudienceSegments] = useState<AudienceSegment[]>([]);
  const [cadenceRecs, setCadenceRecs] = useState<CadenceRecommendation[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);

  const relayData = loadRelayData();
  const advancedData = loadAdvancedData();

  useEffect(() => {
    setReputationScores(advancedData.reputationScores);
    setCadenceRecs(advancedData.cadenceRecommendations);
  }, []);

  const analyzeAccount = (accountId: string): void => {
    setIsAnalyzing(true);
    setSelectedAccountId(accountId);

    setTimeout(() => {
      const account = relayData.platformAccounts.find((a) => a.id === accountId);
      if (!account) return;

      // Calculate reputation
      const socialData = advancedData.socialGraphData.find((s) => s.accountId === accountId);
      const reputation = calculateReputationScore(account, socialData);
      
      // Generate audience segments
      const segments = generateAudienceSegments(account);
      
      // Analyze cadence
      const mockPostCount = Math.floor(Math.random() * 15) + 2;
      const mockEngagement = Math.random() * 0.1;
      const cadence = analyzeCadence(account, mockPostCount, mockEngagement);

      // Save to storage
      addToAdvancedArray('reputationScores', reputation);
      addToAdvancedArray('cadenceRecommendations', cadence);
      
      setReputationScores([...reputationScores, reputation]);
      setAudienceSegments(segments);
      setCadenceRecs([...cadenceRecs, cadence]);
      
      setIsAnalyzing(false);
    }, 1500);
  };

  const selectedAccount = relayData.platformAccounts.find((a) => a.id === selectedAccountId);
  const selectedReputation = reputationScores.find((r) => r.accountId === selectedAccountId);
  const selectedCadence = cadenceRecs.find((c) => c.accountId === selectedAccountId);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5" />
            Account Analytics & Reputation
          </CardTitle>
          <CardDescription>
            Analyze social graph, reputation scores, and audience insights
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label className="text-sm font-medium">Select Account to Analyze</label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {relayData.platformAccounts.map((account: PlatformAccount) => (
                <Button
                  key={account.id}
                  variant={selectedAccountId === account.id ? 'default' : 'outline'}
                  className="justify-start"
                  onClick={() => analyzeAccount(account.id)}
                  disabled={isAnalyzing}
                >
                  <div className="flex items-center gap-2 w-full">
                    <span className="flex-1 text-left">
                      {account.displayName}
                    </span>
                    <Badge variant="secondary">{account.platform}</Badge>
                  </div>
                </Button>
              ))}
            </div>
            {relayData.platformAccounts.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No accounts registered yet. Create an account first.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {selectedAccount && selectedReputation && (
        <Tabs defaultValue="reputation" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="reputation">Reputation</TabsTrigger>
            <TabsTrigger value="audience">Audience</TabsTrigger>
            <TabsTrigger value="cadence">Cadence</TabsTrigger>
          </TabsList>

          <TabsContent value="reputation" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Target className="h-5 w-5" />
                  Reputation Score: {selectedAccount.displayName}
                </CardTitle>
                <CardDescription>
                  Overall score: {(selectedReputation.overallScore * 100).toFixed(0)}/100
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Audience Quality</span>
                      <span className="text-sm text-muted-foreground">
                        {(selectedReputation.audienceQuality * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={selectedReputation.audienceQuality * 100} />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Engagement Consistency</span>
                      <span className="text-sm text-muted-foreground">
                        {(selectedReputation.engagementConsistency * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={selectedReputation.engagementConsistency * 100} />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Content Originality</span>
                      <span className="text-sm text-muted-foreground">
                        {(selectedReputation.contentOriginality * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={selectedReputation.contentOriginality * 100} />
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium">Network Influence</span>
                      <span className="text-sm text-muted-foreground">
                        {(selectedReputation.networkInfluence * 100).toFixed(0)}%
                      </span>
                    </div>
                    <Progress value={selectedReputation.networkInfluence * 100} />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <p className="text-sm text-muted-foreground">
                    Last calculated: {new Date(selectedReputation.calculatedAt).toLocaleString()}
                  </p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="audience" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Users className="h-5 w-5" />
                  Audience Segments
                </CardTitle>
                <CardDescription>
                  Who follows {selectedAccount.displayName} and what they want
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {audienceSegments.length === 0 ? (
                  <p className="text-sm text-muted-foreground">
                    No audience data yet. Analysis in progress...
                  </p>
                ) : (
                  audienceSegments.map((segment: AudienceSegment) => (
                    <Card key={segment.id}>
                      <CardContent className="pt-4">
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <h4 className="font-semibold">{segment.segmentName}</h4>
                            <Badge variant="outline">{segment.percentage}%</Badge>
                          </div>
                          
                          <div className="space-y-1">
                            <p className="text-sm font-medium">Characteristics:</p>
                            <div className="flex flex-wrap gap-1">
                              {segment.characteristics.map((char: string) => (
                                <Badge key={char} variant="secondary" className="text-xs">
                                  {char}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div className="space-y-1">
                            <p className="text-sm font-medium">Suggested Content:</p>
                            <div className="flex flex-wrap gap-1">
                              {segment.suggestedContentTypes.map((type: string) => (
                                <Badge key={type} className="text-xs">
                                  {type}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="cadence" className="space-y-4">
            {selectedCadence && (
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Activity className="h-5 w-5" />
                    Posting Cadence Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Current</p>
                          <p className="text-3xl font-bold">{selectedCadence.currentCadence}</p>
                          <p className="text-sm text-muted-foreground">posts/week</p>
                        </div>
                      </CardContent>
                    </Card>
                    
                    <Card>
                      <CardContent className="pt-6">
                        <div className="text-center">
                          <p className="text-sm text-muted-foreground">Recommended</p>
                          <p className="text-3xl font-bold">{selectedCadence.recommendedCadence}</p>
                          <p className="text-sm text-muted-foreground">posts/week</p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  <div className={`p-4 rounded-lg flex items-start gap-3 ${
                    selectedCadence.riskLevel === 'burnout' ? 'bg-destructive/10' :
                    selectedCadence.riskLevel === 'moderate' ? 'bg-yellow-500/10' :
                    'bg-green-500/10'
                  }`}>
                    {selectedCadence.riskLevel === 'burnout' ? (
                      <AlertCircle className="h-5 w-5 text-destructive flex-shrink-0 mt-0.5" />
                    ) : (
                      <CheckCircle className="h-5 w-5 text-green-600 flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium mb-1">
                        Risk Level: {selectedCadence.riskLevel.charAt(0).toUpperCase() + selectedCadence.riskLevel.slice(1)}
                      </p>
                      <p className="text-sm text-muted-foreground">
                        {selectedCadence.reasoning}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      )}

      {!selectedAccount && (
        <Card>
          <CardContent className="py-12 text-center">
            <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
            <p className="text-muted-foreground">
              Select an account above to view analytics
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
