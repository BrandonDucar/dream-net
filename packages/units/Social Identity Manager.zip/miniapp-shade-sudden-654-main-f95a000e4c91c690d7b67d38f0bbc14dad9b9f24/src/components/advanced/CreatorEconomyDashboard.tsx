'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { loadAdvancedData, addToAdvancedArray, updateInAdvancedArray } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { generateId } from '@/lib/relay-logic';
import type { PaymentTracking, BrandDeal, Deliverable, AttributionMetric } from '@/types/advanced-features';
import { DollarSign, Briefcase, TrendingUp, CheckCircle, XCircle, Clock } from 'lucide-react';

export function CreatorEconomyDashboard(): JSX.Element {
  const [payments, setPayments] = useState<PaymentTracking[]>([]);
  const [brandDeals, setBrandDeals] = useState<BrandDeal[]>([]);
  const [attribution, setAttribution] = useState<AttributionMetric[]>([]);
  const [newPaymentOpen, setNewPaymentOpen] = useState<boolean>(false);
  const [newDealOpen, setNewDealOpen] = useState<boolean>(false);

  const advancedData = loadAdvancedData();
  const relayData = loadRelayData();

  useEffect(() => {
    setPayments(advancedData.payments);
    setBrandDeals(advancedData.brandDeals);
    setAttribution(advancedData.attributionMetrics);
  }, []);

  const addPayment = (payment: Omit<PaymentTracking, 'id'>): void => {
    const newPayment: PaymentTracking = { ...payment, id: generateId() };
    addToAdvancedArray('payments', newPayment);
    setPayments([...payments, newPayment]);
    setNewPaymentOpen(false);
  };

  const updatePayment = (id: string, updates: Partial<PaymentTracking>): void => {
    const payment = payments.find((p) => p.id === id);
    if (payment) {
      const updated = { ...payment, ...updates };
      updateInAdvancedArray('payments', id, updated);
      setPayments(payments.map((p) => p.id === id ? updated : p));
    }
  };

  const addBrandDeal = (deal: Omit<BrandDeal, 'id'>): void => {
    const newDeal: BrandDeal = { ...deal, id: generateId() };
    addToAdvancedArray('brandDeals', newDeal);
    setBrandDeals([...brandDeals, newDeal]);
    setNewDealOpen(false);
  };

  const totalExpected = payments.reduce((sum: number, p: PaymentTracking) => sum + p.expectedAmount, 0);
  const totalReceived = payments.reduce((sum: number, p: PaymentTracking) => sum + p.receivedAmount, 0);
  const totalOutstanding = totalExpected - totalReceived;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <DollarSign className="h-4 w-4" />
              Total Expected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">${totalExpected.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <CheckCircle className="h-4 w-4 text-green-600" />
              Total Received
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-green-600">${totalReceived.toLocaleString()}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Clock className="h-4 w-4 text-yellow-600" />
              Outstanding
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-yellow-600">${totalOutstanding.toLocaleString()}</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Payment Tracking</CardTitle>
              <CardDescription>Track payments from campaigns and brand deals</CardDescription>
            </div>
            <Dialog open={newPaymentOpen} onOpenChange={setNewPaymentOpen}>
              <DialogTrigger asChild>
                <Button>Add Payment</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Track New Payment</DialogTitle>
                  <DialogDescription>Add a new campaign payment to track</DialogDescription>
                </DialogHeader>
                <PaymentForm onSubmit={addPayment} routes={relayData.relayRoutes} />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {payments.length === 0 ? (
            <p className="text-sm text-muted-foreground">No payments tracked yet.</p>
          ) : (
            <div className="space-y-2">
              {payments.map((payment: PaymentTracking) => (
                <Card key={payment.id}>
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h4 className="font-semibold">{payment.campaignName}</h4>
                        <p className="text-sm text-muted-foreground">
                          Route: {relayData.relayRoutes.find((r) => r.id === payment.routeId)?.routeName || 'Unknown'}
                        </p>
                        <div className="flex items-center gap-2 mt-2">
                          <span className="text-sm">Expected: ${payment.expectedAmount}</span>
                          <span className="text-sm text-muted-foreground">|</span>
                          <span className="text-sm">Received: ${payment.receivedAmount}</span>
                        </div>
                        <p className="text-xs text-muted-foreground mt-1">
                          Due: {new Date(payment.dueDate).toLocaleDateString()}
                        </p>
                      </div>
                      <Badge variant={
                        payment.status === 'received' ? 'default' :
                        payment.status === 'partial' ? 'secondary' :
                        payment.status === 'overdue' ? 'destructive' :
                        'outline'
                      }>
                        {payment.status}
                      </Badge>
                    </div>
                    {payment.status !== 'received' && (
                      <Button 
                        size="sm" 
                        variant="outline" 
                        className="w-full mt-3"
                        onClick={() => updatePayment(payment.id, { 
                          status: 'received', 
                          receivedAmount: payment.expectedAmount,
                          paidDate: new Date().toISOString()
                        })}
                      >
                        Mark as Received
                      </Button>
                    )}
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Briefcase className="h-5 w-5" />
                Brand Deals
              </CardTitle>
              <CardDescription>Manage brand partnerships and deliverables</CardDescription>
            </div>
            <Dialog open={newDealOpen} onOpenChange={setNewDealOpen}>
              <DialogTrigger asChild>
                <Button>New Deal</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>New Brand Deal</DialogTitle>
                  <DialogDescription>Track a new brand partnership</DialogDescription>
                </DialogHeader>
                <BrandDealForm onSubmit={addBrandDeal} accounts={relayData.platformAccounts} />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {brandDeals.length === 0 ? (
            <p className="text-sm text-muted-foreground">No brand deals yet.</p>
          ) : (
            <div className="space-y-3">
              {brandDeals.map((deal: BrandDeal) => (
                <Card key={deal.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{deal.brandName}</CardTitle>
                      <Badge>{deal.status}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Value:</span> ${deal.totalValue.toLocaleString()}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Accounts:</span> {deal.accountIds.length}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Start:</span> {new Date(deal.startDate).toLocaleDateString()}
                      </div>
                      <div>
                        <span className="text-muted-foreground">End:</span> {new Date(deal.endDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="space-y-2">
                      <p className="text-sm font-medium">
                        Deliverables ({deal.deliverables.filter((d: Deliverable) => d.completed).length}/{deal.deliverables.length})
                      </p>
                      {deal.deliverables.map((deliverable: Deliverable) => (
                        <div key={deliverable.id} className="flex items-center gap-2 text-sm">
                          {deliverable.completed ? (
                            <CheckCircle className="h-4 w-4 text-green-600" />
                          ) : (
                            <XCircle className="h-4 w-4 text-muted-foreground" />
                          )}
                          <span className={deliverable.completed ? 'line-through text-muted-foreground' : ''}>
                            {deliverable.description}
                          </span>
                          <span className="text-muted-foreground text-xs ml-auto">
                            {new Date(deliverable.dueDate).toLocaleDateString()}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function PaymentForm({ onSubmit, routes }: { onSubmit: (payment: Omit<PaymentTracking, 'id'>) => void; routes: Array<{ id: string; routeName: string }> }): JSX.Element {
  const [formData, setFormData] = useState({
    routeId: routes[0]?.id || '',
    campaignName: '',
    expectedAmount: '',
    currency: 'USD',
    dueDate: ''
  });

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      ...formData,
      expectedAmount: parseFloat(formData.expectedAmount),
      receivedAmount: 0,
      status: 'pending'
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Route</Label>
        <select
          className="w-full p-2 border rounded-md"
          value={formData.routeId}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => setFormData({ ...formData, routeId: e.target.value })}
        >
          {routes.map((route) => (
            <option key={route.id} value={route.id}>{route.routeName}</option>
          ))}
        </select>
      </div>
      <div>
        <Label>Campaign Name</Label>
        <Input
          value={formData.campaignName}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, campaignName: e.target.value })}
          required
        />
      </div>
      <div>
        <Label>Expected Amount</Label>
        <Input
          type="number"
          value={formData.expectedAmount}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, expectedAmount: e.target.value })}
          required
        />
      </div>
      <div>
        <Label>Due Date</Label>
        <Input
          type="date"
          value={formData.dueDate}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, dueDate: e.target.value })}
          required
        />
      </div>
      <Button type="submit" className="w-full">Add Payment</Button>
    </form>
  );
}

function BrandDealForm({ onSubmit, accounts }: { onSubmit: (deal: Omit<BrandDeal, 'id'>) => void; accounts: Array<{ id: string; displayName: string }> }): JSX.Element {
  const [formData, setFormData] = useState({
    brandName: '',
    totalValue: '',
    startDate: '',
    endDate: '',
    notes: ''
  });

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      ...formData,
      totalValue: parseFloat(formData.totalValue),
      accountIds: [],
      routeIds: [],
      deliverables: [],
      status: 'negotiating'
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Brand Name</Label>
        <Input
          value={formData.brandName}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, brandName: e.target.value })}
          required
        />
      </div>
      <div>
        <Label>Total Value ($)</Label>
        <Input
          type="number"
          value={formData.totalValue}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, totalValue: e.target.value })}
          required
        />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <div>
          <Label>Start Date</Label>
          <Input
            type="date"
            value={formData.startDate}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, startDate: e.target.value })}
            required
          />
        </div>
        <div>
          <Label>End Date</Label>
          <Input
            type="date"
            value={formData.endDate}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, endDate: e.target.value })}
            required
          />
        </div>
      </div>
      <div>
        <Label>Notes</Label>
        <Textarea
          value={formData.notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setFormData({ ...formData, notes: e.target.value })}
        />
      </div>
      <Button type="submit" className="w-full">Create Deal</Button>
    </form>
  );
}
