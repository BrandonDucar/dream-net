'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { loadAdvancedData, addToAdvancedArray, updateInAdvancedArray } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { analyzeSentiment } from '@/lib/advanced-logic';
import { generateId } from '@/lib/relay-logic';
import type { SentimentAlert, AutoModerationRule, CrisisEvent } from '@/types/advanced-features';
import { AlertTriangle, Shield, TrendingDown, CheckCircle, Activity } from 'lucide-react';

export function CrisisDetectionPanel(): JSX.Element {
  const [alerts, setAlerts] = useState<SentimentAlert[]>([]);
  const [rules, setRules] = useState<AutoModerationRule[]>([]);
  const [crises, setCrises] = useState<CrisisEvent[]>([]);
  const [monitoringEnabled, setMonitoringEnabled] = useState<boolean>(true);

  const advancedData = loadAdvancedData();
  const relayData = loadRelayData();

  useEffect(() => {
    setAlerts(advancedData.sentimentAlerts);
    setRules(advancedData.autoModerationRules);
    setCrises(advancedData.crisisEvents);
  }, []);

  const simulateSentimentCheck = (accountId: string): void => {
    // Mock comments for simulation
    const mockComments = [
      'Love this project!',
      'Great work team!',
      'This is terrible',
      'Complete scam',
      'Disappointed in this',
      'Amazing!',
      'Rug pull vibes',
      'Best thing ever'
    ];

    const alert = analyzeSentiment(mockComments);
    
    if (alert) {
      const newAlert: SentimentAlert = {
        ...alert,
        accountId,
        actionsTaken: monitoringEnabled ? ['Routes paused', 'Team notified'] : []
      };
      
      addToAdvancedArray('sentimentAlerts', newAlert);
      setAlerts([newAlert, ...alerts]);

      // If severe, create crisis event
      if (alert.alertLevel === 'critical') {
        const crisis: CrisisEvent = {
          id: generateId(),
          accountId,
          detectedAt: new Date().toISOString(),
          type: 'negative-spike',
          severity: 'high',
          description: 'Critical negative sentiment spike detected',
          mitigationSteps: ['Pause all posting', 'Review recent content', 'Prepare response'],
          resolved: false
        };
        addToAdvancedArray('crisisEvents', crisis);
        setCrises([crisis, ...crises]);
      }
    }
  };

  const resolveAlert = (alertId: string): void => {
    const alert = alerts.find((a) => a.id === alertId);
    if (alert) {
      const updated = { ...alert, resolved: true };
      updateInAdvancedArray('sentimentAlerts', alertId, updated);
      setAlerts(alerts.map((a) => a.id === alertId ? updated : a));
    }
  };

  const resolveCrisis = (crisisId: string): void => {
    const crisis = crises.find((c) => c.id === crisisId);
    if (crisis) {
      const updated = { ...crisis, resolved: true, resolvedAt: new Date().toISOString() };
      updateInAdvancedArray('crisisEvents', crisisId, updated);
      setCrises(crises.map((c) => c.id === crisisId ? updated : c));
    }
  };

  const activeAlerts = alerts.filter((a) => !a.resolved);
  const activeCrises = crises.filter((c) => !c.resolved);

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <AlertTriangle className="h-4 w-4 text-yellow-600" />
              Active Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{activeAlerts.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingDown className="h-4 w-4 text-destructive" />
              Active Crises
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold text-destructive">{activeCrises.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Shield className="h-4 w-4 text-green-600" />
              Auto-Moderation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <p className="text-sm">{monitoringEnabled ? 'Active' : 'Paused'}</p>
              <Switch
                checked={monitoringEnabled}
                onCheckedChange={setMonitoringEnabled}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Activity className="h-5 w-5" />
            Sentiment Monitoring
          </CardTitle>
          <CardDescription>
            Real-time sentiment analysis and auto-pause protection
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Test Sentiment Analysis on Account</Label>
            <div className="grid grid-cols-1 gap-2">
              {relayData.platformAccounts.map((account) => (
                <Button
                  key={account.id}
                  variant="outline"
                  onClick={() => simulateSentimentCheck(account.id)}
                  className="justify-between"
                >
                  <span>{account.displayName} (@{account.handle})</span>
                  <Badge variant="secondary">{account.platform}</Badge>
                </Button>
              ))}
            </div>
            {relayData.platformAccounts.length === 0 && (
              <p className="text-sm text-muted-foreground">
                No accounts to monitor yet.
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {activeAlerts.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              Active Sentiment Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeAlerts.map((alert: SentimentAlert) => {
                const account = relayData.platformAccounts.find((a) => a.id === alert.accountId);
                return (
                  <Card key={alert.id}>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <h4 className="font-semibold">
                              {account?.displayName || 'Unknown Account'}
                            </h4>
                            <Badge variant={
                              alert.alertLevel === 'critical' ? 'destructive' :
                              alert.alertLevel === 'warning' ? 'default' :
                              'secondary'
                            }>
                              {alert.alertLevel}
                            </Badge>
                          </div>
                          <span className="text-sm text-muted-foreground">
                            Sentiment: {(alert.sentimentScore * 100).toFixed(0)}%
                          </span>
                        </div>

                        <div className="bg-muted p-3 rounded-md">
                          <p className="text-sm font-medium mb-2">Sample Comments:</p>
                          {alert.samples.slice(0, 3).map((sample: string, idx: number) => (
                            <p key={idx} className="text-sm text-muted-foreground">
                              &quot;{sample}&quot;
                            </p>
                          ))}
                        </div>

                        {alert.actionsTaken.length > 0 && (
                          <div>
                            <p className="text-sm font-medium mb-1">Actions Taken:</p>
                            <div className="flex flex-wrap gap-1">
                              {alert.actionsTaken.map((action: string, idx: number) => (
                                <Badge key={idx} variant="outline">
                                  {action}
                                </Badge>
                              ))}
                            </div>
                          </div>
                        )}

                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => resolveAlert(alert.id)}
                          className="w-full"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Mark as Resolved
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {activeCrises.length > 0 && (
        <Card className="border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <TrendingDown className="h-5 w-5" />
              Active Crisis Events
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {activeCrises.map((crisis: CrisisEvent) => {
                const account = relayData.platformAccounts.find((a) => a.id === crisis.accountId);
                return (
                  <Card key={crisis.id} className="border-destructive/50">
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div>
                            <h4 className="font-semibold">
                              {account?.displayName || 'Unknown Account'}
                            </h4>
                            <p className="text-sm text-muted-foreground">
                              {crisis.type.replace(/-/g, ' ')}
                            </p>
                          </div>
                          <Badge variant="destructive">{crisis.severity}</Badge>
                        </div>

                        <p className="text-sm">{crisis.description}</p>

                        <div>
                          <p className="text-sm font-medium mb-2">Mitigation Steps:</p>
                          <ul className="space-y-1">
                            {crisis.mitigationSteps.map((step: string, idx: number) => (
                              <li key={idx} className="text-sm text-muted-foreground flex items-center gap-2">
                                <div className="h-1.5 w-1.5 rounded-full bg-destructive" />
                                {step}
                              </li>
                            ))}
                          </ul>
                        </div>

                        <Button
                          size="sm"
                          variant="default"
                          onClick={() => resolveCrisis(crisis.id)}
                          className="w-full"
                        >
                          <CheckCircle className="h-4 w-4 mr-2" />
                          Mark Crisis Resolved
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {activeAlerts.length === 0 && activeCrises.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Shield className="h-12 w-12 text-green-600 mx-auto mb-4" />
            <p className="text-lg font-semibold text-green-600">All Clear</p>
            <p className="text-muted-foreground">No active alerts or crisis events</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
