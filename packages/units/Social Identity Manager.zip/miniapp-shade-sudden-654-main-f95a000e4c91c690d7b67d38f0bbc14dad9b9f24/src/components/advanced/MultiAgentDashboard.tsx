'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { loadAdvancedData, addToAdvancedArray, updateInAdvancedArray } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { generateId } from '@/lib/relay-logic';
import type { AgentConfig, PostingRequest } from '@/types/advanced-features';
import { Bot, Users, CheckCircle, XCircle, Clock, AlertTriangle } from 'lucide-react';

export function MultiAgentDashboard(): JSX.Element {
  const [agents, setAgents] = useState<AgentConfig[]>([]);
  const [requests, setRequests] = useState<PostingRequest[]>([]);
  const [newAgentOpen, setNewAgentOpen] = useState<boolean>(false);

  const advancedData = loadAdvancedData();
  const relayData = loadRelayData();

  useEffect(() => {
    setAgents(advancedData.agentConfigs);
    setRequests(advancedData.postingRequests);
  }, []);

  const addAgent = (agent: Omit<AgentConfig, 'id' | 'trustScore' | 'requestCount' | 'approvalRate'>): void => {
    const newAgent: AgentConfig = {
      ...agent,
      id: generateId(),
      trustScore: 0.5,
      requestCount: 0,
      approvalRate: 0
    };
    addToAdvancedArray('agentConfigs', newAgent);
    setAgents([...agents, newAgent]);
    setNewAgentOpen(false);
  };

  const approveRequest = (requestId: string): void => {
    const request = requests.find((r) => r.id === requestId);
    if (request) {
      const updated = { ...request, status: 'approved' as const, reviewedAt: new Date().toISOString() };
      updateInAdvancedArray('postingRequests', requestId, updated);
      setRequests(requests.map((r) => r.id === requestId ? updated : r));

      // Update agent trust score
      const agent = agents.find((a) => a.id === request.agentId);
      if (agent) {
        const updatedAgent = {
          ...agent,
          approvalRate: ((agent.approvalRate * agent.requestCount) + 1) / (agent.requestCount + 1),
          requestCount: agent.requestCount + 1,
          trustScore: Math.min(agent.trustScore + 0.05, 1)
        };
        updateInAdvancedArray('agentConfigs', agent.id, updatedAgent);
        setAgents(agents.map((a) => a.id === agent.id ? updatedAgent : a));
      }
    }
  };

  const denyRequest = (requestId: string): void => {
    const request = requests.find((r) => r.id === requestId);
    if (request) {
      const updated = { ...request, status: 'denied' as const, reviewedAt: new Date().toISOString() };
      updateInAdvancedArray('postingRequests', requestId, updated);
      setRequests(requests.map((r) => r.id === requestId ? updated : r));

      // Update agent trust score
      const agent = agents.find((a) => a.id === request.agentId);
      if (agent) {
        const updatedAgent = {
          ...agent,
          requestCount: agent.requestCount + 1,
          trustScore: Math.max(agent.trustScore - 0.03, 0)
        };
        updateInAdvancedArray('agentConfigs', agent.id, updatedAgent);
        setAgents(agents.map((a) => a.id === agent.id ? updatedAgent : a));
      }
    }
  };

  const pendingRequests = requests.filter((r) => r.status === 'pending');

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Bot className="h-5 w-5" />
                Agent Swarm Management
              </CardTitle>
              <CardDescription>
                Coordinate multiple AI agents and mini-apps requesting posting rights
              </CardDescription>
            </div>
            <Dialog open={newAgentOpen} onOpenChange={setNewAgentOpen}>
              <DialogTrigger asChild>
                <Button>Register Agent</Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Register New Agent</DialogTitle>
                  <DialogDescription>Add a mini-app or AI agent to your swarm</DialogDescription>
                </DialogHeader>
                <AgentForm onSubmit={addAgent} accounts={relayData.platformAccounts} />
              </DialogContent>
            </Dialog>
          </div>
        </CardHeader>
        <CardContent>
          {agents.length === 0 ? (
            <p className="text-sm text-muted-foreground">No agents registered yet.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {agents.map((agent: AgentConfig) => (
                <Card key={agent.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">{agent.agentName}</CardTitle>
                      <Badge variant={
                        agent.trustScore > 0.7 ? 'default' :
                        agent.trustScore > 0.4 ? 'secondary' :
                        'destructive'
                      }>
                        Trust: {(agent.trustScore * 100).toFixed(0)}%
                      </Badge>
                    </div>
                    <CardDescription>{agent.sourceMiniApp}</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    <div className="grid grid-cols-2 gap-2 text-sm">
                      <div>
                        <span className="text-muted-foreground">Requests:</span> {agent.requestCount}
                      </div>
                      <div>
                        <span className="text-muted-foreground">Approval:</span> {(agent.approvalRate * 100).toFixed(0)}%
                      </div>
                    </div>
                    <Badge variant="outline">
                      {agent.permissionLevel}
                    </Badge>
                    <p className="text-xs text-muted-foreground">
                      {agent.allowedAccounts.length} accounts accessible
                    </p>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Posting Requests
            {pendingRequests.length > 0 && (
              <Badge variant="destructive">{pendingRequests.length} pending</Badge>
            )}
          </CardTitle>
          <CardDescription>
            Review and approve agent posting requests
          </CardDescription>
        </CardHeader>
        <CardContent>
          {requests.length === 0 ? (
            <p className="text-sm text-muted-foreground">No posting requests yet.</p>
          ) : (
            <div className="space-y-3">
              {requests.map((request: PostingRequest) => {
                const agent = agents.find((a) => a.id === request.agentId);
                const accounts = request.targetAccountIds.map((id) => 
                  relayData.platformAccounts.find((a) => a.id === id)
                ).filter((a) => a !== undefined);

                return (
                  <Card key={request.id}>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2">
                              <h4 className="font-semibold">{agent?.agentName || 'Unknown Agent'}</h4>
                              <Badge variant={
                                request.status === 'approved' ? 'default' :
                                request.status === 'denied' ? 'destructive' :
                                request.status === 'posted' ? 'default' :
                                'secondary'
                              }>
                                {request.status}
                              </Badge>
                              <Badge variant="outline">{request.priority} priority</Badge>
                            </div>
                            <p className="text-xs text-muted-foreground mt-1">
                              {new Date(request.requestedTime).toLocaleString()}
                            </p>
                          </div>
                        </div>

                        <div className="bg-muted p-3 rounded-md">
                          <p className="text-sm">{request.content}</p>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-1">Target Accounts:</p>
                          <div className="flex flex-wrap gap-1">
                            {accounts.map((account) => account && (
                              <Badge key={account.id} variant="secondary">
                                @{account.handle}
                              </Badge>
                            ))}
                          </div>
                        </div>

                        {request.status === 'pending' && (
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="default"
                              className="flex-1"
                              onClick={() => approveRequest(request.id)}
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="destructive"
                              className="flex-1"
                              onClick={() => denyRequest(request.id)}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Deny
                            </Button>
                          </div>
                        )}

                        {request.conflictsWith && request.conflictsWith.length > 0 && (
                          <div className="flex items-start gap-2 p-2 bg-yellow-500/10 rounded-md">
                            <AlertTriangle className="h-4 w-4 text-yellow-600 flex-shrink-0 mt-0.5" />
                            <p className="text-xs text-yellow-600">
                              Conflicts with {request.conflictsWith.length} other request(s)
                            </p>
                          </div>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

function AgentForm({ onSubmit, accounts }: { onSubmit: (agent: Omit<AgentConfig, 'id' | 'trustScore' | 'requestCount' | 'approvalRate'>) => void; accounts: Array<{ id: string; displayName: string }> }): JSX.Element {
  const [formData, setFormData] = useState({
    agentName: '',
    sourceMiniApp: '',
    apiKey: '',
    permissionLevel: 'request' as const
  });

  const handleSubmit = (e: React.FormEvent): void => {
    e.preventDefault();
    onSubmit({
      ...formData,
      allowedAccounts: [],
      lastActive: new Date().toISOString()
    });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label>Agent Name</Label>
        <Input
          value={formData.agentName}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, agentName: e.target.value })}
          placeholder="e.g., ThreadSmith Bot"
          required
        />
      </div>
      <div>
        <Label>Source Mini-App</Label>
        <Input
          value={formData.sourceMiniApp}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, sourceMiniApp: e.target.value })}
          placeholder="e.g., ThreadSmith"
          required
        />
      </div>
      <div>
        <Label>API Key</Label>
        <Input
          type="password"
          value={formData.apiKey}
          onChange={(e: React.ChangeEvent<HTMLInputElement>) => setFormData({ ...formData, apiKey: e.target.value })}
          placeholder="Generate a unique key"
          required
        />
      </div>
      <div>
        <Label>Permission Level</Label>
        <select
          className="w-full p-2 border rounded-md"
          value={formData.permissionLevel}
          onChange={(e: React.ChangeEvent<HTMLSelectElement>) => 
            setFormData({ ...formData, permissionLevel: e.target.value as 'request' | 'auto-approve' | 'restricted' })
          }
        >
          <option value="request">Request (needs approval)</option>
          <option value="auto-approve">Auto-approve (trusted)</option>
          <option value="restricted">Restricted (view only)</option>
        </select>
      </div>
      <Button type="submit" className="w-full">Register Agent</Button>
    </form>
  );
}
