'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { loadAdvancedData, addToAdvancedArray } from '@/lib/advanced-storage';
import { loadRelayData } from '@/lib/relay-storage';
import { generateContentSuggestion, predictViralPotential } from '@/lib/advanced-logic';
import { generateId } from '@/lib/relay-logic';
import type { TrendData, ContentSuggestion, ViralTracking } from '@/types/advanced-features';
import { TrendingUp, Flame, Zap, Target, AlertCircle } from 'lucide-react';

export function TrendSurfingDashboard(): JSX.Element {
  const [trends, setTrends] = useState<TrendData[]>([]);
  const [suggestions, setSuggestions] = useState<ContentSuggestion[]>([]);
  const [viralPosts, setViralPosts] = useState<ViralTracking[]>([]);
  const [isScanning, setIsScanning] = useState<boolean>(false);

  const advancedData = loadAdvancedData();
  const relayData = loadRelayData();

  useEffect(() => {
    setTrends(advancedData.trends);
    setSuggestions(advancedData.contentSuggestions);
    setViralPosts(advancedData.viralTracking);
  }, []);

  const scanTrends = async (): Promise<void> => {
    setIsScanning(true);

    setTimeout(() => {
      // Mock trend data (in production, fetch from X API, Farcaster, etc.)
      const mockTrends: TrendData[] = [
        {
          id: generateId(),
          keyword: 'Base',
          platform: 'farcaster',
          trendingScore: 0.9,
          volume: 1250,
          sentiment: 0.8,
          detectedAt: new Date().toISOString(),
          relatedTopics: ['onchain', 'L2', 'builder']
        },
        {
          id: generateId(),
          keyword: 'NFT Mint',
          platform: 'zora',
          trendingScore: 0.75,
          volume: 890,
          sentiment: 0.7,
          detectedAt: new Date().toISOString(),
          relatedTopics: ['art', 'collector', 'drop']
        },
        {
          id: generateId(),
          keyword: 'AI Agents',
          platform: 'x',
          trendingScore: 0.85,
          volume: 2100,
          sentiment: 0.75,
          detectedAt: new Date().toISOString(),
          relatedTopics: ['automation', 'AGI', 'crypto']
        }
      ];

      mockTrends.forEach((trend: TrendData) => {
        addToAdvancedArray('trends', trend);
        
        // Generate content suggestion
        const suggestion = generateContentSuggestion(trend, relayData.platformAccounts);
        addToAdvancedArray('contentSuggestions', suggestion);
        setSuggestions((prev: ContentSuggestion[]) => [suggestion, ...prev].slice(0, 10));
      });

      setTrends([...mockTrends, ...trends].slice(0, 10));
      setIsScanning(false);
    }, 2000);
  };

  const simulateViralPost = (): void => {
    const mockTracking = predictViralPotential(
      Math.floor(Math.random() * 500) + 100,
      Math.floor(Math.random() * 3) + 1
    );
    
    const tracking: ViralTracking = {
      ...mockTracking,
      routeId: relayData.relayRoutes[0]?.id || ''
    };
    
    addToAdvancedArray('viralTracking', tracking);
    setViralPosts([tracking, ...viralPosts]);
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4" />
              Active Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{trends.length}</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Flame className="h-4 w-4 text-orange-600" />
              Content Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">{suggestions.filter((s) => s.urgency === 'high').length}</p>
            <p className="text-sm text-muted-foreground">High priority</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Zap className="h-4 w-4 text-yellow-600" />
              Viral Posts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-3xl font-bold">
              {viralPosts.filter((v) => v.amplificationStatus === 'amplifying').length}
            </p>
            <p className="text-sm text-muted-foreground">Amplifying now</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Trend Scanner
              </CardTitle>
              <CardDescription>
                Scan Farcaster, X, Zora, and Lens for trending topics
              </CardDescription>
            </div>
            <Button onClick={scanTrends} disabled={isScanning}>
              {isScanning ? 'Scanning...' : 'Scan Trends'}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {trends.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No trends yet. Click Scan Trends to discover what&apos;s hot.
            </p>
          ) : (
            <div className="space-y-2">
              {trends.map((trend: TrendData) => (
                <Card key={trend.id}>
                  <CardContent className="pt-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">{trend.keyword}</h4>
                          <Badge variant="outline">{trend.platform}</Badge>
                          <Badge variant={
                            trend.trendingScore > 0.8 ? 'default' :
                            trend.trendingScore > 0.5 ? 'secondary' :
                            'outline'
                          }>
                            {(trend.trendingScore * 100).toFixed(0)}% hot
                          </Badge>
                        </div>
                        <div className="flex items-center gap-3 text-sm text-muted-foreground">
                          <span>{trend.volume.toLocaleString()} mentions</span>
                          <span>•</span>
                          <span>Sentiment: {(trend.sentiment * 100).toFixed(0)}%</span>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {trend.relatedTopics.map((topic: string) => (
                            <Badge key={topic} variant="secondary" className="text-xs">
                              {topic}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <Flame className={`h-5 w-5 flex-shrink-0 ${
                        trend.trendingScore > 0.8 ? 'text-orange-600' :
                        trend.trendingScore > 0.5 ? 'text-orange-400' :
                        'text-muted-foreground'
                      }`} />
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5" />
            AI Content Suggestions
          </CardTitle>
          <CardDescription>
            Trending-aware content ideas for your accounts
          </CardDescription>
        </CardHeader>
        <CardContent>
          {suggestions.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No suggestions yet. Scan trends first!
            </p>
          ) : (
            <div className="space-y-3">
              {suggestions.map((suggestion: ContentSuggestion) => {
                const trend = trends.find((t) => t.id === suggestion.trendId);
                return (
                  <Card key={suggestion.id}>
                    <CardContent className="pt-4">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <Badge variant={
                            suggestion.urgency === 'high' ? 'destructive' :
                            suggestion.urgency === 'medium' ? 'default' :
                            'secondary'
                          }>
                            {suggestion.urgency} priority
                          </Badge>
                          <span className="text-sm text-muted-foreground">
                            Viral potential: {(suggestion.viralPotential * 100).toFixed(0)}%
                          </span>
                        </div>

                        <div className="bg-muted p-3 rounded-md">
                          <p className="text-sm font-medium mb-1">Suggested Content:</p>
                          <p className="text-sm">{suggestion.suggestedContent}</p>
                        </div>

                        <div>
                          <p className="text-sm font-medium mb-1">Target Accounts:</p>
                          <div className="flex flex-wrap gap-1">
                            {suggestion.targetAccountIds.map((id: string) => {
                              const account = relayData.platformAccounts.find((a) => a.id === id);
                              return account ? (
                                <Badge key={id} variant="outline">
                                  @{account.handle}
                                </Badge>
                              ) : null;
                            })}
                          </div>
                        </div>

                        <p className="text-xs text-muted-foreground">{suggestion.reasoning}</p>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Viral Tracking
              </CardTitle>
              <CardDescription>
                Monitor posts going viral for amplification
              </CardDescription>
            </div>
            <Button onClick={simulateViralPost} variant="outline">
              Simulate Viral Post
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {viralPosts.length === 0 ? (
            <p className="text-sm text-muted-foreground">
              No viral posts tracked yet.
            </p>
          ) : (
            <div className="space-y-2">
              {viralPosts.map((post: ViralTracking) => (
                <Card key={post.postId}>
                  <CardContent className="pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          <h4 className="font-semibold">Post {post.postId.slice(0, 8)}</h4>
                          <Badge variant={
                            post.amplificationStatus === 'amplifying' ? 'default' :
                            post.amplificationStatus === 'completed' ? 'secondary' :
                            'outline'
                          }>
                            {post.amplificationStatus}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div>
                            <span className="text-muted-foreground">Engagement:</span> {post.currentEngagement}
                          </div>
                          <div>
                            <span className="text-muted-foreground">Growth Rate:</span> {post.growthRate.toFixed(1)}/hr
                          </div>
                          <div>
                            <span className="text-muted-foreground">Viral Coeff:</span> {post.viralCoefficient.toFixed(2)}x
                          </div>
                          <div>
                            <span className="text-muted-foreground">Predicted Peak:</span> {post.predictedPeak}
                          </div>
                        </div>
                      </div>
                      {post.viralCoefficient > 2 && (
                        <Flame className="h-6 w-6 text-orange-600 flex-shrink-0" />
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
