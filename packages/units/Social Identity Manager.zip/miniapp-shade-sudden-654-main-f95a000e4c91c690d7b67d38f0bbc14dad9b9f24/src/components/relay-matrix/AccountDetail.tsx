'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import { 
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Pencil, Trash2, Copy, FileText, Plus } from 'lucide-react';
import type { PlatformAccount, RelayRoute, ContentStream } from '@/types/relay-matrix';
import { 
  deletePlatformAccount, 
  getRoutesByAccountId, 
  getContentStreamById,
  savePlatformAccount 
} from '@/lib/relay-storage';
import { 
  exportAccountBrief, 
  generateSEOForAccount,
  generateAccountIntroLocalized,
  generateTagsLocalized
} from '@/lib/relay-logic';
import { AccountForm } from './AccountForm';
import { RouteForm } from './RouteForm';

interface AccountDetailProps {
  account: PlatformAccount;
  onClose: () => void;
  onUpdate: () => void;
}

export function AccountDetail({ account, onClose, onUpdate }: AccountDetailProps) {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isCreatingRoute, setIsCreatingRoute] = useState<boolean>(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);
  const [showBrief, setShowBrief] = useState<boolean>(false);
  const [brief, setBrief] = useState<string>('');

  const routes = getRoutesByAccountId(account.id);

  const handleDelete = () => {
    deletePlatformAccount(account.id);
    setShowDeleteDialog(false);
    onUpdate();
    onClose();
  };

  const handleRegenerateSEO = () => {
    const newSEO = generateSEOForAccount(
      account.platform,
      account.handle,
      account.displayName,
      account.accountRole,
      account.description
    );

    const updatedAccount: PlatformAccount = {
      ...account,
      seo: newSEO,
      updatedAt: new Date().toISOString()
    };

    savePlatformAccount(updatedAccount);
    onUpdate();
  };

  const handleGenerateGeoVariants = () => {
    if (account.primaryGeoTargets.length === 0) {
      alert('Please add geo-targets first.');
      return;
    }

    const accountIntroLocalized: Record<string, string> = {};
    const tagsLocalized: Record<string, string[]> = {};

    account.primaryGeoTargets.forEach((geo) => {
      accountIntroLocalized[geo.id] = generateAccountIntroLocalized(
        account.description,
        account.accountRole,
        account.platform,
        geo
      );
      tagsLocalized[geo.id] = generateTagsLocalized(
        account.platform,
        account.accountRole,
        geo
      );
    });

    const updatedAccount: PlatformAccount = {
      ...account,
      accountIntroLocalized,
      tagsLocalized,
      updatedAt: new Date().toISOString()
    };

    savePlatformAccount(updatedAccount);
    onUpdate();
  };

  const handleExportBrief = () => {
    const generatedBrief = exportAccountBrief(account.id);
    setBrief(generatedBrief);
    setShowBrief(true);
  };

  const copyBriefToClipboard = () => {
    navigator.clipboard.writeText(brief);
  };

  if (isEditing) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Edit Account</h2>
        <AccountForm
          account={account}
          onSave={() => {
            setIsEditing(false);
            onUpdate();
          }}
          onCancel={() => setIsEditing(false)}
        />
      </div>
    );
  }

  if (isCreatingRoute) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Create Route for {account.displayName}</h2>
        <RouteForm
          prefilledAccountId={account.id}
          onSave={() => {
            setIsCreatingRoute(false);
            onUpdate();
          }}
          onCancel={() => setIsCreatingRoute(false)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{account.displayName}</h2>
          <p className="text-gray-500">@{account.handle} • {account.platform}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => setIsEditing(true)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={handleExportBrief}>
            <FileText className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Identity</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Account Role</p>
              <p className="text-sm">{account.accountRole}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Ownership</p>
              <p className="text-sm">{account.ownership}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Priority</p>
              <Badge variant={
                account.priorityLevel === 'critical' ? 'destructive' :
                account.priorityLevel === 'high' ? 'default' :
                'secondary'
              }>
                {account.priorityLevel}
              </Badge>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Status</p>
              <Badge variant={account.status === 'active' ? 'default' : 'secondary'}>
                {account.status}
              </Badge>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Description</p>
            <p className="text-sm mt-1">{account.description}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Posting Style</p>
            <div className="flex flex-wrap gap-2 mt-1">
              {account.postingStyle.map((style: string) => (
                <Badge key={style} variant="outline">{style}</Badge>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Allowed Content Types</p>
            <div className="flex flex-wrap gap-2 mt-1">
              {account.allowedContentTypes.map((type: string) => (
                <Badge key={type} variant="outline">{type}</Badge>
              ))}
            </div>
          </div>
          {account.linkedMiniApps.length > 0 && (
            <div>
              <p className="text-sm font-medium text-gray-500">Linked Mini-Apps</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {account.linkedMiniApps.map((app: string) => (
                  <Badge key={app} variant="outline">{app}</Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>SEO & Metadata</CardTitle>
            <Button variant="outline" size="sm" onClick={handleRegenerateSEO}>
              Regenerate SEO
            </Button>
          </div>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="text-sm font-medium text-gray-500">Title</p>
            <p className="text-sm">{account.seo.seoTitle}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Description</p>
            <p className="text-sm">{account.seo.seoDescription}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Keywords</p>
            <p className="text-sm">{account.seo.seoKeywords.join(', ')}</p>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Hashtags</p>
            <p className="text-sm">{account.seo.seoHashtags.join(' ')}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Geo-Targeting</CardTitle>
            <Button variant="outline" size="sm" onClick={handleGenerateGeoVariants}>
              Generate Geo Variants
            </Button>
          </div>
          <CardDescription>
            {account.primaryGeoTargets.length} geo target(s) configured
          </CardDescription>
        </CardHeader>
        <CardContent>
          {account.primaryGeoTargets.length === 0 ? (
            <p className="text-sm text-gray-500">No geo-targets configured.</p>
          ) : (
            <div className="space-y-4">
              {account.primaryGeoTargets.map((geo) => (
                <div key={geo.id} className="border rounded-lg p-3 space-y-2">
                  <p className="font-medium text-sm">
                    {geo.region} / {geo.country} ({geo.language})
                  </p>
                  {account.accountIntroLocalized[geo.id] && (
                    <div>
                      <p className="text-xs text-gray-500">Localized Intro:</p>
                      <p className="text-sm">{account.accountIntroLocalized[geo.id]}</p>
                    </div>
                  )}
                  {account.tagsLocalized[geo.id] && (
                    <div>
                      <p className="text-xs text-gray-500">Tags:</p>
                      <div className="flex flex-wrap gap-1">
                        {account.tagsLocalized[geo.id].map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Relay Routes</CardTitle>
              <CardDescription>{routes.length} route(s) configured</CardDescription>
            </div>
            <Button size="sm" onClick={() => setIsCreatingRoute(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Route
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {routes.length === 0 ? (
            <p className="text-sm text-gray-500">No routes configured for this account.</p>
          ) : (
            <div className="space-y-3">
              {routes.map((route: RelayRoute) => {
                const stream = getContentStreamById(route.contentStreamId);
                return (
                  <div key={route.id} className="border rounded-lg p-3 space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium text-sm">{route.routeName}</p>
                        <p className="text-xs text-gray-500">
                          From: {stream?.name || 'Unknown'} ({stream?.type || 'N/A'})
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Badge variant={
                          route.riskLevel === 'high' ? 'destructive' :
                          route.riskLevel === 'medium' ? 'default' :
                          'secondary'
                        }>
                          {route.riskLevel}
                        </Badge>
                        {route.manualApprovalRequired && (
                          <Badge variant="outline">Manual</Badge>
                        )}
                      </div>
                    </div>
                    <p className="text-xs">{route.purpose}</p>
                    <div className="flex flex-wrap gap-1">
                      {route.toneGuidelines.slice(0, 3).map((tone: string) => (
                        <Badge key={tone} variant="outline" className="text-xs">{tone}</Badge>
                      ))}
                      {route.toneGuidelines.length > 3 && (
                        <Badge variant="outline" className="text-xs">+{route.toneGuidelines.length - 3}</Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Account?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the account &quot;{account.displayName}&quot; and all associated relay routes.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showBrief} onOpenChange={setShowBrief}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Account Brief</DialogTitle>
            <DialogDescription>
              Copy this brief to your documentation or automation config
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              value={brief}
              readOnly
              rows={20}
              className="font-mono text-xs"
            />
            <Button onClick={copyBriefToClipboard} className="w-full">
              <Copy className="h-4 w-4 mr-2" />
              Copy to Clipboard
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
