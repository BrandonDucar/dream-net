'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import type { Platform, PlatformAccount, Ownership, PriorityLevel, AccountStatus } from '@/types/relay-matrix';
import { generateId, generateSEOForAccount, getDefaultPostingStylesForPlatform } from '@/lib/relay-logic';
import { savePlatformAccount } from '@/lib/relay-storage';

interface AccountFormProps {
  account?: PlatformAccount;
  onSave: () => void;
  onCancel: () => void;
}

export function AccountForm({ account, onSave, onCancel }: AccountFormProps) {
  const [platform, setPlatform] = useState<Platform>(account?.platform || 'farcaster');
  const [handle, setHandle] = useState<string>(account?.handle || '');
  const [displayName, setDisplayName] = useState<string>(account?.displayName || '');
  const [accountRole, setAccountRole] = useState<string>(account?.accountRole || '');
  const [ownership, setOwnership] = useState<Ownership>(account?.ownership || 'primary-self');
  const [description, setDescription] = useState<string>(account?.description || '');
  const [priorityLevel, setPriorityLevel] = useState<PriorityLevel>(account?.priorityLevel || 'medium');
  const [status, setStatus] = useState<AccountStatus>(account?.status || 'active');
  const [postingStyle, setPostingStyle] = useState<string[]>(account?.postingStyle || []);
  const [allowedContentTypes, setAllowedContentTypes] = useState<string[]>(account?.allowedContentTypes || []);
  const [linkedMiniApps, setLinkedMiniApps] = useState<string[]>(account?.linkedMiniApps || []);
  const [newStyleTag, setNewStyleTag] = useState<string>('');
  const [newContentType, setNewContentType] = useState<string>('');
  const [newMiniApp, setNewMiniApp] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const seo = account?.seo || generateSEOForAccount(platform, handle, displayName, accountRole, description);
    const styles = postingStyle.length > 0 ? postingStyle : getDefaultPostingStylesForPlatform(platform, accountRole);

    const newAccount: PlatformAccount = {
      id: account?.id || generateId(),
      platform,
      handle,
      displayName,
      accountRole,
      ownership,
      description,
      priorityLevel,
      postingStyle: styles,
      allowedContentTypes,
      linkedMiniApps,
      status,
      seo,
      primaryGeoTargets: account?.primaryGeoTargets || [],
      accountIntroLocalized: account?.accountIntroLocalized || {},
      tagsLocalized: account?.tagsLocalized || {},
      createdAt: account?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    savePlatformAccount(newAccount);
    onSave();
  };

  const addStyleTag = () => {
    if (newStyleTag && !postingStyle.includes(newStyleTag)) {
      setPostingStyle([...postingStyle, newStyleTag]);
      setNewStyleTag('');
    }
  };

  const removeStyleTag = (tag: string) => {
    setPostingStyle(postingStyle.filter((t: string) => t !== tag));
  };

  const addContentType = () => {
    if (newContentType && !allowedContentTypes.includes(newContentType)) {
      setAllowedContentTypes([...allowedContentTypes, newContentType]);
      setNewContentType('');
    }
  };

  const removeContentType = (type: string) => {
    setAllowedContentTypes(allowedContentTypes.filter((t: string) => t !== type));
  };

  const addMiniApp = () => {
    if (newMiniApp && !linkedMiniApps.includes(newMiniApp)) {
      setLinkedMiniApps([...linkedMiniApps, newMiniApp]);
      setNewMiniApp('');
    }
  };

  const removeMiniApp = (app: string) => {
    setLinkedMiniApps(linkedMiniApps.filter((a: string) => a !== app));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="platform">Platform</Label>
          <Select value={platform} onValueChange={(value: string) => setPlatform(value as Platform)}>
            <SelectTrigger id="platform">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="farcaster">Farcaster</SelectItem>
              <SelectItem value="x">X (Twitter)</SelectItem>
              <SelectItem value="warpcast">Warpcast</SelectItem>
              <SelectItem value="zora">Zora</SelectItem>
              <SelectItem value="lens">Lens</SelectItem>
              <SelectItem value="base-feed">Base Feed</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="handle">Handle</Label>
          <Input
            id="handle"
            value={handle}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setHandle(e.target.value)}
            placeholder="@username"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="displayName">Display Name</Label>
          <Input
            id="displayName"
            value={displayName}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setDisplayName(e.target.value)}
            placeholder="Brandon Ducar"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="accountRole">Account Role</Label>
          <Input
            id="accountRole"
            value={accountRole}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setAccountRole(e.target.value)}
            placeholder="founder, project voice, meme alt..."
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="ownership">Ownership</Label>
          <Select value={ownership} onValueChange={(value: string) => setOwnership(value as Ownership)}>
            <SelectTrigger id="ownership">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="primary-self">Primary Self</SelectItem>
              <SelectItem value="shared">Shared</SelectItem>
              <SelectItem value="project">Project</SelectItem>
              <SelectItem value="bot-alt">Bot Alt</SelectItem>
              <SelectItem value="test">Test</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="priorityLevel">Priority Level</Label>
          <Select value={priorityLevel} onValueChange={(value: string) => setPriorityLevel(value as PriorityLevel)}>
            <SelectTrigger id="priorityLevel">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <Select value={status} onValueChange={(value: string) => setStatus(value as AccountStatus)}>
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="How this account should be used..."
          rows={3}
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Posting Style</Label>
        <div className="flex gap-2">
          <Input
            value={newStyleTag}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewStyleTag(e.target.value)}
            placeholder="e.g., serious, degen, educational..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addStyleTag();
              }
            }}
          />
          <Button type="button" onClick={addStyleTag}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {postingStyle.map((style: string) => (
            <Badge key={style} variant="secondary" className="flex items-center gap-1">
              {style}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeStyleTag(style)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Allowed Content Types</Label>
        <div className="flex gap-2">
          <Input
            value={newContentType}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewContentType(e.target.value)}
            placeholder="e.g., token, drop, meme, pickleball..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addContentType();
              }
            }}
          />
          <Button type="button" onClick={addContentType}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {allowedContentTypes.map((type: string) => (
            <Badge key={type} variant="secondary" className="flex items-center gap-1">
              {type}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeContentType(type)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Linked Mini-Apps</Label>
        <div className="flex gap-2">
          <Input
            value={newMiniApp}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewMiniApp(e.target.value)}
            placeholder="e.g., Threadsmith, PickleRank..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addMiniApp();
              }
            }}
          />
          <Button type="button" onClick={addMiniApp}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {linkedMiniApps.map((app: string) => (
            <Badge key={app} variant="secondary" className="flex items-center gap-1">
              {app}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeMiniApp(app)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {account ? 'Update Account' : 'Register Account'}
        </Button>
      </div>
    </form>
  );
}
