'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogHeader, 
  DialogTitle 
} from '@/components/ui/dialog';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Pencil, Trash2, Copy, FileText } from 'lucide-react';
import type { RelayRoute, PlatformAccount, ContentStream, GeoTarget } from '@/types/relay-matrix';
import { 
  deleteRelayRoute,
  getPlatformAccountById,
  getContentStreamById,
  saveRelayRoute
} from '@/lib/relay-storage';
import { 
  exportRelayRouteBrief,
  generateCaptionTemplateLocalized,
  generateRouteTagsLocalized
} from '@/lib/relay-logic';
import { RouteForm } from './RouteForm';

interface RouteDetailProps {
  route: RelayRoute;
  onClose: () => void;
  onUpdate: () => void;
}

export function RouteDetail({ route, onClose, onUpdate }: RouteDetailProps) {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);
  const [showBrief, setShowBrief] = useState<boolean>(false);
  const [brief, setBrief] = useState<string>('');

  const account = getPlatformAccountById(route.platformAccountId);
  const stream = getContentStreamById(route.contentStreamId);

  const handleDelete = () => {
    deleteRelayRoute(route.id);
    setShowDeleteDialog(false);
    onUpdate();
    onClose();
  };

  const handleGenerateGeoVariants = () => {
    if (route.routeGeoTargets.length === 0) {
      alert('Please add geo-targets first.');
      return;
    }

    if (!stream || !account) {
      alert('Stream or account not found.');
      return;
    }

    const captionTemplateLocalized: Record<string, string> = {};
    const tagsRouteLocalized: Record<string, string[]> = {};

    route.routeGeoTargets.forEach((geo: GeoTarget) => {
      captionTemplateLocalized[geo.id] = generateCaptionTemplateLocalized(
        stream.type,
        route.purpose,
        account.platform,
        geo
      );
      tagsRouteLocalized[geo.id] = generateRouteTagsLocalized(
        stream.type,
        account.platform,
        geo
      );
    });

    const updatedRoute: RelayRoute = {
      ...route,
      captionTemplateLocalized,
      tagsRouteLocalized,
      updatedAt: new Date().toISOString()
    };

    saveRelayRoute(updatedRoute);
    onUpdate();
  };

  const handleExportBrief = () => {
    const generatedBrief = exportRelayRouteBrief(route.id);
    setBrief(generatedBrief);
    setShowBrief(true);
  };

  const copyBriefToClipboard = () => {
    navigator.clipboard.writeText(brief);
  };

  if (isEditing) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Edit Route</h2>
        <RouteForm
          route={route}
          onSave={() => {
            setIsEditing(false);
            onUpdate();
          }}
          onCancel={() => setIsEditing(false)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{route.routeName}</h2>
          <p className="text-gray-500">Relay Route</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => setIsEditing(true)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={handleExportBrief}>
            <FileText className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Route Configuration</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Risk Level</p>
              <Badge variant={
                route.riskLevel === 'high' ? 'destructive' :
                route.riskLevel === 'medium' ? 'default' :
                'secondary'
              }>
                {route.riskLevel}
              </Badge>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Manual Approval</p>
              <Badge variant={route.manualApprovalRequired ? 'default' : 'secondary'}>
                {route.manualApprovalRequired ? 'Required' : 'Not Required'}
              </Badge>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Purpose</p>
            <p className="text-sm mt-1">{route.purpose}</p>
          </div>
          {route.notes && (
            <div>
              <p className="text-sm font-medium text-gray-500">Notes</p>
              <p className="text-sm mt-1">{route.notes}</p>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Content Stream</CardTitle>
        </CardHeader>
        <CardContent>
          {stream ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <p className="font-medium">{stream.name}</p>
                <Badge>{stream.type}</Badge>
              </div>
              <p className="text-sm text-gray-500">{stream.description}</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-500">Source:</span> {stream.sourceMiniApp}
                </div>
                <div>
                  <span className="text-gray-500">Cadence:</span> {stream.cadenceHint}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-500">Stream not found.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Target Account</CardTitle>
        </CardHeader>
        <CardContent>
          {account ? (
            <div className="space-y-2">
              <div className="flex items-center gap-2">
                <p className="font-medium">{account.displayName}</p>
                <Badge variant="outline">@{account.handle}</Badge>
                <Badge>{account.platform}</Badge>
              </div>
              <p className="text-sm text-gray-500">{account.description}</p>
              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-gray-500">Role:</span> {account.accountRole}
                </div>
                <div>
                  <span className="text-gray-500">Priority:</span> {account.priorityLevel}
                </div>
              </div>
            </div>
          ) : (
            <p className="text-sm text-gray-500">Account not found.</p>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Posting Rules</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm font-medium text-gray-500">Allowed Post Types</p>
            <div className="flex flex-wrap gap-2 mt-1">
              {route.allowedPostTypes.map((type: string) => (
                <Badge key={type} variant="outline">{type}</Badge>
              ))}
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Tone Guidelines</p>
            <div className="flex flex-wrap gap-2 mt-1">
              {route.toneGuidelines.map((tone: string) => (
                <Badge key={tone} variant="outline">{tone}</Badge>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Geo-Targeting</CardTitle>
            <Button variant="outline" size="sm" onClick={handleGenerateGeoVariants}>
              Generate Geo Variants
            </Button>
          </div>
          <CardDescription>
            {route.routeGeoTargets.length} geo target(s) configured
          </CardDescription>
        </CardHeader>
        <CardContent>
          {route.routeGeoTargets.length === 0 ? (
            <p className="text-sm text-gray-500">No geo-targets configured.</p>
          ) : (
            <div className="space-y-4">
              {route.routeGeoTargets.map((geo: GeoTarget) => (
                <div key={geo.id} className="border rounded-lg p-3 space-y-2">
                  <p className="font-medium text-sm">
                    {geo.region} / {geo.country} ({geo.language})
                  </p>
                  {route.captionTemplateLocalized[geo.id] && (
                    <div>
                      <p className="text-xs text-gray-500">Caption Template:</p>
                      <p className="text-sm">{route.captionTemplateLocalized[geo.id]}</p>
                    </div>
                  )}
                  {route.tagsRouteLocalized[geo.id] && (
                    <div>
                      <p className="text-xs text-gray-500">Tags:</p>
                      <div className="flex flex-wrap gap-1">
                        {route.tagsRouteLocalized[geo.id].map((tag: string) => (
                          <Badge key={tag} variant="outline" className="text-xs">{tag}</Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Route?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the relay route &quot;{route.routeName}&quot;.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={showBrief} onOpenChange={setShowBrief}>
        <DialogContent className="max-w-3xl max-h-[80vh]">
          <DialogHeader>
            <DialogTitle>Relay Route Brief</DialogTitle>
            <DialogDescription>
              Copy this brief to your documentation or automation config
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <Textarea
              value={brief}
              readOnly
              rows={20}
              className="font-mono text-xs"
            />
            <Button onClick={copyBriefToClipboard} className="w-full">
              <Copy className="h-4 w-4 mr-2" />
              Copy to Clipboard
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
