'use client';

import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { X } from 'lucide-react';
import type { RelayRoute, RiskLevel, PlatformAccount, ContentStream } from '@/types/relay-matrix';
import { generateId, suggestToneGuidelines } from '@/lib/relay-logic';
import { saveRelayRoute, loadRelayData, getPlatformAccountById, getContentStreamById } from '@/lib/relay-storage';

interface RouteFormProps {
  route?: RelayRoute;
  prefilledStreamId?: string;
  prefilledAccountId?: string;
  onSave: () => void;
  onCancel: () => void;
}

export function RouteForm({ route, prefilledStreamId, prefilledAccountId, onSave, onCancel }: RouteFormProps) {
  const [contentStreamId, setContentStreamId] = useState<string>(route?.contentStreamId || prefilledStreamId || '');
  const [platformAccountId, setPlatformAccountId] = useState<string>(route?.platformAccountId || prefilledAccountId || '');
  const [routeName, setRouteName] = useState<string>(route?.routeName || '');
  const [purpose, setPurpose] = useState<string>(route?.purpose || '');
  const [riskLevel, setRiskLevel] = useState<RiskLevel>(route?.riskLevel || 'medium');
  const [manualApprovalRequired, setManualApprovalRequired] = useState<boolean>(route?.manualApprovalRequired || false);
  const [notes, setNotes] = useState<string>(route?.notes || '');
  const [allowedPostTypes, setAllowedPostTypes] = useState<string[]>(route?.allowedPostTypes || []);
  const [toneGuidelines, setToneGuidelines] = useState<string[]>(route?.toneGuidelines || []);
  const [newPostType, setNewPostType] = useState<string>('');
  const [newToneGuideline, setNewToneGuideline] = useState<string>('');

  const [accounts, setAccounts] = useState<PlatformAccount[]>([]);
  const [streams, setStreams] = useState<ContentStream[]>([]);

  useEffect(() => {
    const data = loadRelayData();
    setAccounts(data.platformAccounts);
    setStreams(data.contentStreams);
  }, []);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const newRoute: RelayRoute = {
      id: route?.id || generateId(),
      contentStreamId,
      platformAccountId,
      routeName,
      purpose,
      allowedPostTypes,
      toneGuidelines,
      riskLevel,
      manualApprovalRequired,
      notes,
      routeGeoTargets: route?.routeGeoTargets || [],
      captionTemplateLocalized: route?.captionTemplateLocalized || {},
      tagsRouteLocalized: route?.tagsRouteLocalized || {},
      createdAt: route?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveRelayRoute(newRoute);
    onSave();
  };

  const addPostType = () => {
    if (newPostType && !allowedPostTypes.includes(newPostType)) {
      setAllowedPostTypes([...allowedPostTypes, newPostType]);
      setNewPostType('');
    }
  };

  const removePostType = (type: string) => {
    setAllowedPostTypes(allowedPostTypes.filter((t: string) => t !== type));
  };

  const addToneGuideline = () => {
    if (newToneGuideline && !toneGuidelines.includes(newToneGuideline)) {
      setToneGuidelines([...toneGuidelines, newToneGuideline]);
      setNewToneGuideline('');
    }
  };

  const removeToneGuideline = (tone: string) => {
    setToneGuidelines(toneGuidelines.filter((t: string) => t !== tone));
  };

  const autoSuggestTones = () => {
    const account = getPlatformAccountById(platformAccountId);
    const stream = getContentStreamById(contentStreamId);

    if (account && stream) {
      const suggested = suggestToneGuidelines(account.accountRole, account.postingStyle, stream.type);
      setToneGuidelines(Array.from(new Set([...toneGuidelines, ...suggested])));
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="contentStreamId">Content Stream</Label>
          <Select value={contentStreamId} onValueChange={setContentStreamId}>
            <SelectTrigger id="contentStreamId">
              <SelectValue placeholder="Select stream..." />
            </SelectTrigger>
            <SelectContent>
              {streams.map((stream: ContentStream) => (
                <SelectItem key={stream.id} value={stream.id}>
                  {stream.name} ({stream.type})
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="platformAccountId">Platform Account</Label>
          <Select value={platformAccountId} onValueChange={setPlatformAccountId}>
            <SelectTrigger id="platformAccountId">
              <SelectValue placeholder="Select account..." />
            </SelectTrigger>
            <SelectContent>
              {accounts.map((account: PlatformAccount) => (
                <SelectItem key={account.id} value={account.id}>
                  {account.displayName} (@{account.handle}) - {account.platform}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="routeName">Route Name</Label>
          <Input
            id="routeName"
            value={routeName}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setRouteName(e.target.value)}
            placeholder="High-signal lore posts"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="riskLevel">Risk Level</Label>
          <Select value={riskLevel} onValueChange={(value: string) => setRiskLevel(value as RiskLevel)}>
            <SelectTrigger id="riskLevel">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="purpose">Purpose</Label>
        <Textarea
          id="purpose"
          value={purpose}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setPurpose(e.target.value)}
          placeholder="What this route is for..."
          rows={2}
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Allowed Post Types</Label>
        <div className="flex gap-2">
          <Input
            value={newPostType}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewPostType(e.target.value)}
            placeholder="threads, memes, announcements..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addPostType();
              }
            }}
          />
          <Button type="button" onClick={addPostType}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {allowedPostTypes.map((type: string) => (
            <Badge key={type} variant="secondary" className="flex items-center gap-1">
              {type}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removePostType(type)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <Label>Tone Guidelines</Label>
          <Button type="button" variant="outline" size="sm" onClick={autoSuggestTones}>
            Auto-Suggest
          </Button>
        </div>
        <div className="flex gap-2">
          <Input
            value={newToneGuideline}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewToneGuideline(e.target.value)}
            placeholder="Visionary, playful, technical..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addToneGuideline();
              }
            }}
          />
          <Button type="button" onClick={addToneGuideline}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {toneGuidelines.map((tone: string) => (
            <Badge key={tone} variant="secondary" className="flex items-center gap-1">
              {tone}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeToneGuideline(tone)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="flex items-center space-x-2">
        <Switch
          id="manualApproval"
          checked={manualApprovalRequired}
          onCheckedChange={setManualApprovalRequired}
        />
        <Label htmlFor="manualApproval">Manual Approval Required</Label>
      </div>

      <div className="space-y-2">
        <Label htmlFor="notes">Notes</Label>
        <Textarea
          id="notes"
          value={notes}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setNotes(e.target.value)}
          placeholder="Additional notes..."
          rows={2}
        />
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {route ? 'Update Route' : 'Create Route'}
        </Button>
      </div>
    </form>
  );
}
