'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog';
import { Pencil, Trash2, Plus } from 'lucide-react';
import type { ContentStream, RelayRoute, PlatformAccount } from '@/types/relay-matrix';
import { 
  deleteContentStream, 
  getRoutesByStreamId,
  getPlatformAccountById
} from '@/lib/relay-storage';
import { StreamForm } from './StreamForm';
import { RouteForm } from './RouteForm';

interface StreamDetailProps {
  stream: ContentStream;
  onClose: () => void;
  onUpdate: () => void;
}

export function StreamDetail({ stream, onClose, onUpdate }: StreamDetailProps) {
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [isCreatingRoute, setIsCreatingRoute] = useState<boolean>(false);
  const [showDeleteDialog, setShowDeleteDialog] = useState<boolean>(false);

  const routes = getRoutesByStreamId(stream.id);

  const handleDelete = () => {
    deleteContentStream(stream.id);
    setShowDeleteDialog(false);
    onUpdate();
    onClose();
  };

  if (isEditing) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Edit Stream</h2>
        <StreamForm
          stream={stream}
          onSave={() => {
            setIsEditing(false);
            onUpdate();
          }}
          onCancel={() => setIsEditing(false)}
        />
      </div>
    );
  }

  if (isCreatingRoute) {
    return (
      <div className="space-y-4">
        <h2 className="text-2xl font-bold">Create Route for {stream.name}</h2>
        <RouteForm
          prefilledStreamId={stream.id}
          onSave={() => {
            setIsCreatingRoute(false);
            onUpdate();
          }}
          onCancel={() => setIsCreatingRoute(false)}
        />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">{stream.name}</h2>
          <p className="text-gray-500">{stream.type} • {stream.sourceMiniApp}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={() => setIsEditing(true)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button variant="outline" size="icon" onClick={() => setShowDeleteDialog(true)}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Stream Details</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm font-medium text-gray-500">Type</p>
              <Badge>{stream.type}</Badge>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Status</p>
              <Badge variant={stream.status === 'active' ? 'default' : 'secondary'}>
                {stream.status}
              </Badge>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Source Mini-App</p>
              <p className="text-sm">{stream.sourceMiniApp}</p>
            </div>
            <div>
              <p className="text-sm font-medium text-gray-500">Cadence</p>
              <p className="text-sm">{stream.cadenceHint}</p>
            </div>
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Description</p>
            <p className="text-sm mt-1">{stream.description}</p>
          </div>
          {stream.tags.length > 0 && (
            <div>
              <p className="text-sm font-medium text-gray-500">Tags</p>
              <div className="flex flex-wrap gap-2 mt-1">
                {stream.tags.map((tag: string) => (
                  <Badge key={tag} variant="outline">{tag}</Badge>
                ))}
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Relay Routes</CardTitle>
              <CardDescription>{routes.length} route(s) configured</CardDescription>
            </div>
            <Button size="sm" onClick={() => setIsCreatingRoute(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Route
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {routes.length === 0 ? (
            <p className="text-sm text-gray-500">No routes configured for this stream.</p>
          ) : (
            <div className="space-y-3">
              {routes.map((route: RelayRoute) => {
                const account = getPlatformAccountById(route.platformAccountId);
                return (
                  <div key={route.id} className="border rounded-lg p-3 space-y-2">
                    <div className="flex items-start justify-between">
                      <div>
                        <p className="font-medium text-sm">{route.routeName}</p>
                        <p className="text-xs text-gray-500">
                          To: {account?.displayName || 'Unknown'} (@{account?.handle || 'N/A'}) • {account?.platform || 'N/A'}
                        </p>
                      </div>
                      <div className="flex gap-1">
                        <Badge variant={
                          route.riskLevel === 'high' ? 'destructive' :
                          route.riskLevel === 'medium' ? 'default' :
                          'secondary'
                        }>
                          {route.riskLevel}
                        </Badge>
                        {route.manualApprovalRequired && (
                          <Badge variant="outline">Manual</Badge>
                        )}
                      </div>
                    </div>
                    <p className="text-xs">{route.purpose}</p>
                    <div className="flex flex-wrap gap-1">
                      {route.toneGuidelines.slice(0, 3).map((tone: string) => (
                        <Badge key={tone} variant="outline" className="text-xs">{tone}</Badge>
                      ))}
                      {route.toneGuidelines.length > 3 && (
                        <Badge variant="outline" className="text-xs">+{route.toneGuidelines.length - 3}</Badge>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Stream?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete the content stream &quot;{stream.name}&quot; and all associated relay routes.
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete}>Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
