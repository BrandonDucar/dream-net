'use client';

import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { X } from 'lucide-react';
import type { ContentStream, ContentType, StreamStatus } from '@/types/relay-matrix';
import { generateId } from '@/lib/relay-logic';
import { saveContentStream } from '@/lib/relay-storage';

interface StreamFormProps {
  stream?: ContentStream;
  onSave: () => void;
  onCancel: () => void;
}

export function StreamForm({ stream, onSave, onCancel }: StreamFormProps) {
  const [name, setName] = useState<string>(stream?.name || '');
  const [type, setType] = useState<ContentType>(stream?.type || 'other');
  const [description, setDescription] = useState<string>(stream?.description || '');
  const [sourceMiniApp, setSourceMiniApp] = useState<string>(stream?.sourceMiniApp || '');
  const [cadenceHint, setCadenceHint] = useState<string>(stream?.cadenceHint || '');
  const [status, setStatus] = useState<StreamStatus>(stream?.status || 'idea');
  const [tags, setTags] = useState<string[]>(stream?.tags || []);
  const [newTag, setNewTag] = useState<string>('');

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    const newStream: ContentStream = {
      id: stream?.id || generateId(),
      name,
      type,
      description,
      sourceMiniApp,
      cadenceHint,
      tags,
      status,
      seo: stream?.seo,
      createdAt: stream?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    saveContentStream(newStream);
    onSave();
  };

  const addTag = () => {
    if (newTag && !tags.includes(newTag)) {
      setTags([...tags, newTag]);
      setNewTag('');
    }
  };

  const removeTag = (tag: string) => {
    setTags(tags.filter((t: string) => t !== tag));
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Stream Name</Label>
          <Input
            id="name"
            value={name}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setName(e.target.value)}
            placeholder="DreamNet core lore"
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="type">Type</Label>
          <Select value={type} onValueChange={(value: string) => setType(value as ContentType)}>
            <SelectTrigger id="type">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="token">Token</SelectItem>
              <SelectItem value="drop">Drop</SelectItem>
              <SelectItem value="meme">Meme</SelectItem>
              <SelectItem value="campaign">Campaign</SelectItem>
              <SelectItem value="pickleball">Pickleball</SelectItem>
              <SelectItem value="devlog">Devlog</SelectItem>
              <SelectItem value="other">Other</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="sourceMiniApp">Source Mini-App</Label>
          <Input
            id="sourceMiniApp"
            value={sourceMiniApp}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSourceMiniApp(e.target.value)}
            placeholder="Threadsmith, PickleRank..."
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="cadenceHint">Cadence</Label>
          <Input
            id="cadenceHint"
            value={cadenceHint}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setCadenceHint(e.target.value)}
            placeholder="daily, 2x/week, event-based..."
            required
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="status">Status</Label>
          <Select value={status} onValueChange={(value: string) => setStatus(value as StreamStatus)}>
            <SelectTrigger id="status">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="idea">Idea</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="paused">Paused</SelectItem>
              <SelectItem value="retired">Retired</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={description}
          onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="What this content stream is about..."
          rows={3}
          required
        />
      </div>

      <div className="space-y-2">
        <Label>Tags</Label>
        <div className="flex gap-2">
          <Input
            value={newTag}
            onChange={(e: React.ChangeEvent<HTMLInputElement>) => setNewTag(e.target.value)}
            placeholder="Add tags..."
            onKeyDown={(e: React.KeyboardEvent<HTMLInputElement>) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                addTag();
              }
            }}
          />
          <Button type="button" onClick={addTag}>Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-2">
          {tags.map((tag: string) => (
            <Badge key={tag} variant="secondary" className="flex items-center gap-1">
              {tag}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeTag(tag)} />
            </Badge>
          ))}
        </div>
      </div>

      <div className="flex justify-end gap-2">
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancel
        </Button>
        <Button type="submit">
          {stream ? 'Update Stream' : 'Register Stream'}
        </Button>
      </div>
    </form>
  );
}
