import type { AdvancedRelayData } from '@/types/advanced-features';

const ADVANCED_STORAGE_KEY = 'dreamnet_advanced_relay_data';

function getDefaultAdvancedData(): AdvancedRelayData {
  return {
    credentials: [],
    scheduledPosts: [],
    routingDecisions: [],
    routingAgentConfig: {
      enabled: false,
      autoApproveThreshold: 0.8,
      riskTolerance: 'medium',
      learningEnabled: true,
      model: 'gpt-4'
    },
    socialGraphData: [],
    reputationScores: [],
    audienceSegments: [],
    payments: [],
    brandDeals: [],
    attributionMetrics: [],
    experiments: [],
    cadenceRecommendations: [],
    agentConfigs: [],
    postingRequests: [],
    agentReputations: [],
    sentimentAlerts: [],
    autoModerationRules: [],
    crisisEvents: [],
    tokenGates: [],
    daoGovernance: [],
    revenueShares: [],
    trends: [],
    contentSuggestions: [],
    viralTracking: []
  };
}

export function loadAdvancedData(): AdvancedRelayData {
  if (typeof window === 'undefined') {
    return getDefaultAdvancedData();
  }

  try {
    const stored = localStorage.getItem(ADVANCED_STORAGE_KEY);
    if (!stored) {
      return getDefaultAdvancedData();
    }
    return { ...getDefaultAdvancedData(), ...JSON.parse(stored) } as AdvancedRelayData;
  } catch (error) {
    console.error('Error loading advanced data:', error);
    return getDefaultAdvancedData();
  }
}

export function saveAdvancedData(data: AdvancedRelayData): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(ADVANCED_STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving advanced data:', error);
  }
}

// Helper functions for specific data types
export function updateAdvancedField<K extends keyof AdvancedRelayData>(
  field: K,
  data: AdvancedRelayData[K]
): void {
  const current = loadAdvancedData();
  current[field] = data;
  saveAdvancedData(current);
}

export function addToAdvancedArray<K extends keyof AdvancedRelayData>(
  field: K,
  item: AdvancedRelayData[K] extends Array<infer T> ? T : never
): void {
  const current = loadAdvancedData();
  const array = current[field] as unknown[];
  array.push(item);
  saveAdvancedData(current);
}

export function updateInAdvancedArray<K extends keyof AdvancedRelayData>(
  field: K,
  itemId: string,
  updatedItem: AdvancedRelayData[K] extends Array<infer T> ? T : never
): void {
  const current = loadAdvancedData();
  const array = current[field] as Array<{ id: string }>;
  const index = array.findIndex((item: { id: string }) => item.id === itemId);
  
  if (index >= 0) {
    array[index] = updatedItem as { id: string };
    saveAdvancedData(current);
  }
}

export function deleteFromAdvancedArray<K extends keyof AdvancedRelayData>(
  field: K,
  itemId: string
): void {
  const current = loadAdvancedData();
  const array = current[field] as Array<{ id: string }>;
  current[field] = array.filter((item: { id: string }) => item.id !== itemId) as AdvancedRelayData[K];
  saveAdvancedData(current);
}
