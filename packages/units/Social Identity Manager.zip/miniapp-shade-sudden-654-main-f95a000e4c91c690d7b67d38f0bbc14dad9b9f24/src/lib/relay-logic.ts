import type {
  Platform,
  PlatformAccount,
  ContentStream,
  RelayRoute,
  SEOMeta,
  GeoTarget,
  Ownership,
  PriorityLevel
} from '@/types/relay-matrix';
import {
  loadRelayData,
  getPlatformAccountById,
  getContentStreamById,
  getRoutesByAccountId,
  getRoutesByStreamId
} from './relay-storage';

export function generateId(): string {
  return `${Date.now()}-${Math.random().toString(36).substr(2, 9)}`;
}

export function getDefaultPostingStylesForPlatform(
  platform: Platform,
  role: string
): string[] {
  const platformDefaults: Record<Platform, string[]> = {
    'x': ['concise', 'engaging', 'thread-friendly'],
    'farcaster': ['technical', 'crypto-native', 'conversational'],
    'zora': ['artistic', 'culture-focused', 'collection-oriented'],
    'lens': ['decentralized', 'community-driven', 'web3-native'],
    'warpcast': ['casual', 'builder-focused', 'frame-aware'],
    'base-feed': ['onchain', 'builder', 'optimistic'],
    'other': ['adaptable', 'cross-platform']
  };

  const roleModifiers: Record<string, string[]> = {
    'founder': ['visionary', 'strategic'],
    'project voice': ['professional', 'informative'],
    'meme alt': ['humorous', 'irreverent', 'degen'],
    'experimental': ['exploratory', 'unfiltered']
  };

  const base = platformDefaults[platform] || platformDefaults['other'];
  const roleStyle = roleModifiers[role.toLowerCase()] || [];

  return [...base, ...roleStyle];
}

export function generateSEOForAccount(
  platform: Platform,
  handle: string,
  displayName: string,
  accountRole: string,
  description: string
): SEOMeta {
  const platformNames: Record<Platform, string> = {
    'x': 'X (Twitter)',
    'farcaster': 'Farcaster',
    'zora': 'Zora',
    'lens': 'Lens Protocol',
    'warpcast': 'Warpcast',
    'base-feed': 'Base Feed',
    'other': 'Social Media'
  };

  const platformName = platformNames[platform];

  return {
    seoTitle: `${displayName} (@${handle}) - ${accountRole} on ${platformName}`,
    seoDescription: `${description} | ${accountRole} | ${platformName}`,
    seoKeywords: [
      platform,
      accountRole.toLowerCase(),
      handle,
      displayName.toLowerCase(),
      'social media',
      'web3',
      'crypto'
    ],
    seoHashtags: [
      `#${platform}`,
      `#${accountRole.replace(/\s+/g, '')}`,
      '#web3',
      '#crypto',
      '#social'
    ],
    altText: `${displayName} profile on ${platformName} as ${accountRole}`
  };
}

export function generateAccountIntroLocalized(
  description: string,
  accountRole: string,
  platform: Platform,
  geoTarget: GeoTarget
): string {
  const greetings: Record<string, string> = {
    'en': 'Hey there!',
    'es': '¡Hola!',
    'pt-BR': 'Olá!',
    'de': 'Hallo!',
    'fr': 'Salut!'
  };

  const greeting = greetings[geoTarget.language] || greetings['en'];

  return `${greeting} ${description} [${accountRole} | ${platform} | ${geoTarget.region}]`;
}

export function generateTagsLocalized(
  platform: Platform,
  accountRole: string,
  geoTarget: GeoTarget
): string[] {
  const baseTags = [
    `#${platform}`,
    `#${accountRole.replace(/\s+/g, '')}`,
    `#${geoTarget.region}`
  ];

  const regionTags: Record<string, string[]> = {
    'US': ['#USA', '#American', '#NorthAmerica'],
    'LATAM': ['#LATAM', '#LatinAmerica', '#Latino'],
    'EU': ['#Europe', '#EU', '#European'],
    'ASIA': ['#Asia', '#APAC', '#Asian']
  };

  const langTags: Record<string, string[]> = {
    'en': ['#English'],
    'es': ['#Español', '#Spanish'],
    'pt-BR': ['#Português', '#Portuguese'],
    'de': ['#Deutsch', '#German'],
    'fr': ['#Français', '#French']
  };

  return [
    ...baseTags,
    ...(regionTags[geoTarget.region] || []),
    ...(langTags[geoTarget.language] || [])
  ];
}

export function generateCaptionTemplateLocalized(
  streamType: string,
  routePurpose: string,
  platform: Platform,
  geoTarget: GeoTarget
): string {
  const templates: Record<string, Record<string, string>> = {
    'en': {
      'token': `🪙 New token insight: [CONTENT] | ${routePurpose}`,
      'drop': `🎨 Fresh drop: [CONTENT] | ${routePurpose}`,
      'meme': `😂 [CONTENT] | ${routePurpose}`,
      'campaign': `📢 Campaign update: [CONTENT] | ${routePurpose}`,
      'pickleball': `🏓 Pickleball vibes: [CONTENT] | ${routePurpose}`,
      'devlog': `💻 Dev update: [CONTENT] | ${routePurpose}`,
      'other': `[CONTENT] | ${routePurpose}`
    },
    'es': {
      'token': `🪙 Nuevo token: [CONTENT] | ${routePurpose}`,
      'drop': `🎨 Nuevo drop: [CONTENT] | ${routePurpose}`,
      'meme': `😂 [CONTENT] | ${routePurpose}`,
      'campaign': `📢 Actualización: [CONTENT] | ${routePurpose}`,
      'pickleball': `🏓 Pickleball: [CONTENT] | ${routePurpose}`,
      'devlog': `💻 Actualización dev: [CONTENT] | ${routePurpose}`,
      'other': `[CONTENT] | ${routePurpose}`
    }
  };

  const langTemplates = templates[geoTarget.language] || templates['en'];
  return langTemplates[streamType] || langTemplates['other'];
}

export function generateRouteTagsLocalized(
  streamType: string,
  platform: Platform,
  geoTarget: GeoTarget
): string[] {
  const baseTags = generateTagsLocalized(platform, streamType, geoTarget);

  const typeTags: Record<string, string[]> = {
    'token': ['#Token', '#Crypto', '#DeFi'],
    'drop': ['#NFT', '#Drop', '#Art'],
    'meme': ['#Meme', '#Degen', '#Fun'],
    'campaign': ['#Campaign', '#Marketing', '#Launch'],
    'pickleball': ['#Pickleball', '#Sports', '#Community'],
    'devlog': ['#Dev', '#Building', '#Tech']
  };

  return [...baseTags, ...(typeTags[streamType] || [])];
}

export function getRelayMatrixSummary(): string {
  const data = loadRelayData();
  let summary = '# DREAMNET SOCIAL RELAY MATRIX - FULL SUMMARY\n\n';

  summary += `## Overview\n`;
  summary += `- Platform Accounts: ${data.platformAccounts.length}\n`;
  summary += `- Content Streams: ${data.contentStreams.length}\n`;
  summary += `- Relay Routes: ${data.relayRoutes.length}\n\n`;

  summary += `## CONTENT STREAMS → ACCOUNTS\n\n`;

  data.contentStreams.forEach((stream: ContentStream) => {
    const routes = getRoutesByStreamId(stream.id);
    summary += `### ${stream.name} (${stream.type})\n`;
    summary += `Source: ${stream.sourceMiniApp} | Status: ${stream.status}\n`;
    summary += `Cadence: ${stream.cadenceHint}\n\n`;

    if (routes.length === 0) {
      summary += `  ⚠️  No routes configured\n\n`;
    } else {
      routes.forEach((route: RelayRoute) => {
        const account = getPlatformAccountById(route.platformAccountId);
        if (account) {
          summary += `  → ${account.displayName} (@${account.handle}) on ${account.platform}\n`;
          summary += `     Route: "${route.routeName}"\n`;
          summary += `     Purpose: ${route.purpose}\n`;
          summary += `     Risk: ${route.riskLevel} | Manual Approval: ${route.manualApprovalRequired ? 'YES' : 'NO'}\n`;
          summary += `     Tone: ${route.toneGuidelines.join(', ')}\n\n`;
        }
      });
    }
  });

  summary += `\n## PLATFORM ACCOUNTS → STREAMS\n\n`;

  data.platformAccounts.forEach((account: PlatformAccount) => {
    const routes = getRoutesByAccountId(account.id);
    summary += `### ${account.displayName} (@${account.handle})\n`;
    summary += `Platform: ${account.platform} | Role: ${account.accountRole}\n`;
    summary += `Priority: ${account.priorityLevel} | Status: ${account.status}\n`;
    summary += `Posting Style: ${account.postingStyle.join(', ')}\n\n`;

    if (routes.length === 0) {
      summary += `  ⚠️  No incoming streams\n\n`;
    } else {
      routes.forEach((route: RelayRoute) => {
        const stream = getContentStreamById(route.contentStreamId);
        if (stream) {
          summary += `  ← ${stream.name} (${stream.type})\n`;
          summary += `     via "${route.routeName}"\n`;
          summary += `     Tone: ${route.toneGuidelines.join(', ')}\n\n`;
        }
      });
    }
  });

  return summary;
}

export function exportAccountBrief(accountId: string): string {
  const account = getPlatformAccountById(accountId);
  if (!account) {
    return 'Account not found.';
  }

  const routes = getRoutesByAccountId(accountId);

  let brief = `# ACCOUNT BRIEF: ${account.displayName} (@${account.handle})\n\n`;

  brief += `## Identity\n`;
  brief += `- Platform: ${account.platform}\n`;
  brief += `- Handle: @${account.handle}\n`;
  brief += `- Display Name: ${account.displayName}\n`;
  brief += `- Account Role: ${account.accountRole}\n`;
  brief += `- Ownership: ${account.ownership}\n`;
  brief += `- Status: ${account.status}\n`;
  brief += `- Priority Level: ${account.priorityLevel}\n\n`;

  brief += `## Description\n${account.description}\n\n`;

  brief += `## Posting Guidelines\n`;
  brief += `- Posting Style: ${account.postingStyle.join(', ')}\n`;
  brief += `- Allowed Content Types: ${account.allowedContentTypes.join(', ')}\n`;
  brief += `- Linked Mini-Apps: ${account.linkedMiniApps.join(', ') || 'None'}\n\n`;

  brief += `## SEO & Metadata\n`;
  brief += `- Title: ${account.seo.seoTitle}\n`;
  brief += `- Description: ${account.seo.seoDescription}\n`;
  brief += `- Keywords: ${account.seo.seoKeywords.join(', ')}\n`;
  brief += `- Hashtags: ${account.seo.seoHashtags.join(' ')}\n`;
  brief += `- Alt Text: ${account.seo.altText}\n\n`;

  if (account.primaryGeoTargets.length > 0) {
    brief += `## Geo-Targeting\n`;
    account.primaryGeoTargets.forEach((geo: GeoTarget) => {
      brief += `- ${geo.region} / ${geo.country} (${geo.language})\n`;
      if (account.accountIntroLocalized[geo.id]) {
        brief += `  Intro: ${account.accountIntroLocalized[geo.id]}\n`;
      }
      if (account.tagsLocalized[geo.id]) {
        brief += `  Tags: ${account.tagsLocalized[geo.id].join(' ')}\n`;
      }
    });
    brief += `\n`;
  }

  brief += `## Relay Routes (${routes.length})\n\n`;

  if (routes.length === 0) {
    brief += `No routes configured.\n`;
  } else {
    routes.forEach((route: RelayRoute) => {
      const stream = getContentStreamById(route.contentStreamId);
      brief += `### ${route.routeName}\n`;
      brief += `- Content Stream: ${stream?.name || 'Unknown'} (${stream?.type || 'N/A'})\n`;
      brief += `- Purpose: ${route.purpose}\n`;
      brief += `- Risk Level: ${route.riskLevel}\n`;
      brief += `- Manual Approval: ${route.manualApprovalRequired ? 'YES' : 'NO'}\n`;
      brief += `- Allowed Post Types: ${route.allowedPostTypes.join(', ')}\n`;
      brief += `- Tone Guidelines:\n`;
      route.toneGuidelines.forEach((tone: string) => {
        brief += `  • ${tone}\n`;
      });
      if (route.notes) {
        brief += `- Notes: ${route.notes}\n`;
      }
      brief += `\n`;
    });
  }

  brief += `\n---\n`;
  brief += `Generated: ${new Date().toISOString()}\n`;

  return brief;
}

export function exportRelayRouteBrief(routeId: string): string {
  const route = getRelayRouteById(routeId);
  if (!route) {
    return 'Route not found.';
  }

  const stream = getContentStreamById(route.contentStreamId);
  const account = getPlatformAccountById(route.platformAccountId);

  let brief = `# RELAY ROUTE BRIEF: ${route.routeName}\n\n`;

  brief += `## Route Configuration\n`;
  brief += `- Route ID: ${route.id}\n`;
  brief += `- Route Name: ${route.routeName}\n`;
  brief += `- Purpose: ${route.purpose}\n`;
  brief += `- Risk Level: ${route.riskLevel}\n`;
  brief += `- Manual Approval Required: ${route.manualApprovalRequired ? 'YES' : 'NO'}\n\n`;

  brief += `## Content Stream\n`;
  if (stream) {
    brief += `- Name: ${stream.name}\n`;
    brief += `- Type: ${stream.type}\n`;
    brief += `- Source: ${stream.sourceMiniApp}\n`;
    brief += `- Cadence: ${stream.cadenceHint}\n`;
    brief += `- Description: ${stream.description}\n`;
  } else {
    brief += `Stream not found.\n`;
  }
  brief += `\n`;

  brief += `## Target Account\n`;
  if (account) {
    brief += `- Display Name: ${account.displayName}\n`;
    brief += `- Handle: @${account.handle}\n`;
    brief += `- Platform: ${account.platform}\n`;
    brief += `- Role: ${account.accountRole}\n`;
    brief += `- Priority: ${account.priorityLevel}\n`;
  } else {
    brief += `Account not found.\n`;
  }
  brief += `\n`;

  brief += `## Posting Rules\n`;
  brief += `- Allowed Post Types: ${route.allowedPostTypes.join(', ')}\n`;
  brief += `- Tone Guidelines:\n`;
  route.toneGuidelines.forEach((tone: string) => {
    brief += `  • ${tone}\n`;
  });
  brief += `\n`;

  if (route.notes) {
    brief += `## Notes\n${route.notes}\n\n`;
  }

  if (route.routeGeoTargets.length > 0) {
    brief += `## Geo-Targeting\n`;
    route.routeGeoTargets.forEach((geo: GeoTarget) => {
      brief += `\n### ${geo.region} / ${geo.country} (${geo.language})\n`;
      const captionKey = geo.id;
      if (route.captionTemplateLocalized[captionKey]) {
        brief += `Caption Template:\n${route.captionTemplateLocalized[captionKey]}\n\n`;
      }
      if (route.tagsRouteLocalized[captionKey]) {
        brief += `Tags: ${route.tagsRouteLocalized[captionKey].join(' ')}\n`;
      }
    });
    brief += `\n`;
  }

  brief += `---\n`;
  brief += `Generated: ${new Date().toISOString()}\n`;

  return brief;
}

export function suggestToneGuidelines(
  accountRole: string,
  postingStyle: string[],
  streamType: string
): string[] {
  const roleTones: Record<string, string[]> = {
    'founder': ['Visionary', 'Strategic', 'Authentic'],
    'project voice': ['Professional', 'Clear', 'Informative'],
    'meme alt': ['Playful', 'Irreverent', 'Degen-friendly'],
    'experimental': ['Exploratory', 'Unfiltered', 'Honest']
  };

  const typeTones: Record<string, string[]> = {
    'token': ['Data-driven', 'Analytical', 'Confident'],
    'drop': ['Creative', 'Artistic', 'Collector-focused'],
    'meme': ['Humorous', 'Light', 'Viral-ready'],
    'campaign': ['Persuasive', 'Engaging', 'Action-oriented'],
    'pickleball': ['Energetic', 'Community-driven', 'Fun'],
    'devlog': ['Technical', 'Transparent', 'Builder-focused']
  };

  const suggested = [
    ...(roleTones[accountRole.toLowerCase()] || []),
    ...(typeTones[streamType.toLowerCase()] || []),
    ...postingStyle.map((s: string) => s.charAt(0).toUpperCase() + s.slice(1))
  ];

  return Array.from(new Set(suggested)).slice(0, 5);
}
