import type { 
  PlatformAccount, 
  ContentStream, 
  RelayRoute, 
  GeoTarget, 
  RelayMatrixData 
} from '@/types/relay-matrix';

const STORAGE_KEY = 'dreamnet_relay_matrix';

function getDefaultData(): RelayMatrixData {
  return {
    platformAccounts: [],
    contentStreams: [],
    relayRoutes: [],
    geoTargets: []
  };
}

export function loadRelayData(): RelayMatrixData {
  if (typeof window === 'undefined') {
    return getDefaultData();
  }

  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) {
      return getDefaultData();
    }
    return JSON.parse(stored) as RelayMatrixData;
  } catch (error) {
    console.error('Error loading relay data:', error);
    return getDefaultData();
  }
}

export function saveRelayData(data: RelayMatrixData): void {
  if (typeof window === 'undefined') {
    return;
  }

  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (error) {
    console.error('Error saving relay data:', error);
  }
}

export function savePlatformAccount(account: PlatformAccount): void {
  const data = loadRelayData();
  const index = data.platformAccounts.findIndex((a: PlatformAccount) => a.id === account.id);
  
  if (index >= 0) {
    data.platformAccounts[index] = account;
  } else {
    data.platformAccounts.push(account);
  }
  
  saveRelayData(data);
}

export function saveContentStream(stream: ContentStream): void {
  const data = loadRelayData();
  const index = data.contentStreams.findIndex((s: ContentStream) => s.id === stream.id);
  
  if (index >= 0) {
    data.contentStreams[index] = stream;
  } else {
    data.contentStreams.push(stream);
  }
  
  saveRelayData(data);
}

export function saveRelayRoute(route: RelayRoute): void {
  const data = loadRelayData();
  const index = data.relayRoutes.findIndex((r: RelayRoute) => r.id === route.id);
  
  if (index >= 0) {
    data.relayRoutes[index] = route;
  } else {
    data.relayRoutes.push(route);
  }
  
  saveRelayData(data);
}

export function saveGeoTarget(target: GeoTarget): void {
  const data = loadRelayData();
  const index = data.geoTargets.findIndex((t: GeoTarget) => t.id === target.id);
  
  if (index >= 0) {
    data.geoTargets[index] = target;
  } else {
    data.geoTargets.push(target);
  }
  
  saveRelayData(data);
}

export function deletePlatformAccount(id: string): void {
  const data = loadRelayData();
  data.platformAccounts = data.platformAccounts.filter((a: PlatformAccount) => a.id !== id);
  data.relayRoutes = data.relayRoutes.filter((r: RelayRoute) => r.platformAccountId !== id);
  saveRelayData(data);
}

export function deleteContentStream(id: string): void {
  const data = loadRelayData();
  data.contentStreams = data.contentStreams.filter((s: ContentStream) => s.id !== id);
  data.relayRoutes = data.relayRoutes.filter((r: RelayRoute) => r.contentStreamId !== id);
  saveRelayData(data);
}

export function deleteRelayRoute(id: string): void {
  const data = loadRelayData();
  data.relayRoutes = data.relayRoutes.filter((r: RelayRoute) => r.id !== id);
  saveRelayData(data);
}

export function getPlatformAccountById(id: string): PlatformAccount | undefined {
  const data = loadRelayData();
  return data.platformAccounts.find((a: PlatformAccount) => a.id === id);
}

export function getContentStreamById(id: string): ContentStream | undefined {
  const data = loadRelayData();
  return data.contentStreams.find((s: ContentStream) => s.id === id);
}

export function getRelayRouteById(id: string): RelayRoute | undefined {
  const data = loadRelayData();
  return data.relayRoutes.find((r: RelayRoute) => r.id === id);
}

export function getRoutesByAccountId(accountId: string): RelayRoute[] {
  const data = loadRelayData();
  return data.relayRoutes.filter((r: RelayRoute) => r.platformAccountId === accountId);
}

export function getRoutesByStreamId(streamId: string): RelayRoute[] {
  const data = loadRelayData();
  return data.relayRoutes.filter((r: RelayRoute) => r.contentStreamId === streamId);
}
