// Advanced Features Type Definitions for DreamNet Social Relay Matrix

// 1. POSTING AUTOMATION
export interface PostingCredentials {
  id: string;
  accountId: string;
  platform: string;
  apiKey?: string;
  accessToken?: string;
  walletAddress?: string;
  privateKey?: string; // Encrypted
  hubUrl?: string; // For Farcaster
  createdAt: string;
  lastUsed?: string;
}

export interface ScheduledPost {
  id: string;
  routeId: string;
  content: string;
  mediaUrls: string[];
  scheduledFor: string;
  status: 'pending' | 'posted' | 'failed' | 'cancelled';
  conditionalRules?: ConditionalRule[];
  postedAt?: string;
  postUrl?: string;
  error?: string;
}

export interface ConditionalRule {
  type: 'engagement' | 'sentiment' | 'time' | 'custom';
  condition: string; // e.g., "engagement > 100", "sentiment > 0.7"
  action: 'post' | 'hold' | 'escalate';
}

// 2. AI ROUTING AGENT
export interface RoutingDecision {
  id: string;
  contentId: string;
  timestamp: string;
  suggestedRoutes: string[]; // RouteIds
  reasoning: string;
  confidence: number;
  riskScore: number;
  autoApproved: boolean;
}

export interface ToneTransformation {
  originalContent: string;
  transformedVersions: Record<string, string>; // accountId → transformed content
  toneSettings: Record<string, string[]>; // accountId → tone descriptors
}

export interface RoutingAgentConfig {
  enabled: boolean;
  autoApproveThreshold: number; // confidence level 0-1
  riskTolerance: 'low' | 'medium' | 'high';
  learningEnabled: boolean;
  model: 'gpt-4' | 'claude' | 'custom';
}

// 3. ON-CHAIN REPUTATION & SOCIAL GRAPH
export interface SocialGraphData {
  accountId: string;
  platform: string;
  followers: number;
  following: number;
  engagementRate: number;
  topCollectors?: string[];
  topInteractors?: string[];
  lastUpdated: string;
}

export interface ReputationScore {
  accountId: string;
  overallScore: number;
  audienceQuality: number;
  engagementConsistency: number;
  contentOriginality: number;
  networkInfluence: number;
  calculatedAt: string;
}

export interface AudienceSegment {
  id: string;
  accountId: string;
  segmentName: string;
  percentage: number;
  characteristics: string[];
  suggestedContentTypes: string[];
}

// 4. CREATOR ECONOMY
export interface PaymentTracking {
  id: string;
  routeId: string;
  campaignName: string;
  expectedAmount: number;
  receivedAmount: number;
  currency: string;
  status: 'pending' | 'received' | 'partial' | 'overdue';
  dueDate: string;
  paidDate?: string;
  transactionHash?: string;
}

export interface BrandDeal {
  id: string;
  brandName: string;
  accountIds: string[];
  routeIds: string[];
  startDate: string;
  endDate: string;
  totalValue: number;
  deliverables: Deliverable[];
  status: 'negotiating' | 'active' | 'completed' | 'cancelled';
  notes: string;
}

export interface Deliverable {
  id: string;
  description: string;
  dueDate: string;
  completed: boolean;
  postUrl?: string;
}

export interface AttributionMetric {
  routeId: string;
  period: string;
  signUps: number;
  mints: number;
  onChainActions: number;
  revenue: number;
  source: string;
}

// 5. PERFORMANCE OPTIMIZATION
export interface RouteExperiment {
  id: string;
  name: string;
  routeIds: string[];
  variantConfigs: ExperimentVariant[];
  startDate: string;
  endDate?: string;
  status: 'draft' | 'running' | 'completed' | 'paused';
  results?: ExperimentResults;
}

export interface ExperimentVariant {
  id: string;
  name: string;
  config: Record<string, unknown>;
  traffic: number; // percentage
}

export interface ExperimentResults {
  variantPerformance: Record<string, PerformanceMetrics>;
  winner?: string;
  confidence: number;
}

export interface PerformanceMetrics {
  impressions: number;
  engagement: number;
  conversions: number;
  reach: number;
  sentiment: number;
}

export interface CadenceRecommendation {
  accountId: string;
  currentCadence: number; // posts per week
  recommendedCadence: number;
  reasoning: string;
  riskLevel: 'safe' | 'moderate' | 'burnout';
}

// 6. MULTI-AGENT SWARM
export interface AgentConfig {
  id: string;
  agentName: string;
  sourceMiniApp: string;
  apiKey: string;
  permissionLevel: 'request' | 'auto-approve' | 'restricted';
  allowedAccounts: string[];
  trustScore: number;
  requestCount: number;
  approvalRate: number;
  lastActive?: string;
}

export interface PostingRequest {
  id: string;
  agentId: string;
  content: string;
  targetAccountIds: string[];
  requestedTime: string;
  priority: 'low' | 'medium' | 'high';
  status: 'pending' | 'approved' | 'denied' | 'posted' | 'conflict';
  reviewedBy?: string;
  reviewedAt?: string;
  conflictsWith?: string[];
}

export interface AgentReputation {
  agentId: string;
  totalRequests: number;
  approvedRequests: number;
  engagementScore: number;
  complianceScore: number;
  historicalPerformance: PerformanceMetrics[];
}

// 7. CRISIS DETECTION
export interface SentimentAlert {
  id: string;
  accountId: string;
  detectedAt: string;
  sentimentScore: number;
  alertLevel: 'info' | 'warning' | 'critical';
  samples: string[]; // Sample comments/replies
  actionsTaken: string[];
  resolved: boolean;
}

export interface AutoModerationRule {
  id: string;
  name: string;
  condition: string;
  action: 'pause' | 'alert' | 'filter' | 'escalate';
  affectedAccounts: string[];
  enabled: boolean;
}

export interface CrisisEvent {
  id: string;
  accountId: string;
  detectedAt: string;
  type: 'negative-spike' | 'viral-negative' | 'reputation-threat';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  mitigationSteps: string[];
  resolved: boolean;
  resolvedAt?: string;
}

// 8. WEB3-NATIVE FEATURES
export interface TokenGate {
  id: string;
  name: string;
  tokenAddress: string;
  chain: string;
  minAmount: number;
  routeIds: string[];
  enabled: boolean;
}

export interface DAOGovernance {
  id: string;
  routeId: string;
  proposalThreshold: number;
  votingPeriod: number; // hours
  daoAddress: string;
  chain: string;
}

export interface RevenueShare {
  id: string;
  routeId: string;
  collaborators: Collaborator[];
  onChainSplitContract?: string;
  totalRevenue: number;
}

export interface Collaborator {
  address: string;
  name: string;
  sharePercentage: number;
}

// 9. VIRAL PREDICTION & TREND SURFING
export interface TrendData {
  id: string;
  keyword: string;
  platform: string;
  trendingScore: number;
  volume: number;
  sentiment: number;
  detectedAt: string;
  relatedTopics: string[];
}

export interface ContentSuggestion {
  id: string;
  trendId: string;
  suggestedContent: string;
  targetAccountIds: string[];
  urgency: 'low' | 'medium' | 'high';
  viralPotential: number;
  reasoning: string;
}

export interface ViralTracking {
  postId: string;
  routeId: string;
  initialEngagement: number;
  currentEngagement: number;
  growthRate: number;
  viralCoefficient: number;
  predictedPeak: number;
  amplificationStatus: 'monitoring' | 'amplifying' | 'completed';
}

// 10. AGENT CONFIG EXPORT
export interface AgentConfigExport {
  version: string;
  exportedAt: string;
  relayMatrix: {
    accounts: ExportedAccount[];
    streams: ExportedStream[];
    routes: ExportedRoute[];
  };
  autonomousAgentConfig: {
    routingRules: RoutingRule[];
    tonePresets: Record<string, TonePreset>;
    postingSchedule: ScheduleConfig[];
  };
}

export interface ExportedAccount {
  id: string;
  platform: string;
  handle: string;
  role: string;
  credentials: PostingCredentials | null;
  capabilities: string[];
}

export interface ExportedStream {
  id: string;
  name: string;
  type: string;
  source: string;
}

export interface ExportedRoute {
  id: string;
  from: string; // streamId
  to: string; // accountId
  rules: string[];
  tone: string[];
  risk: string;
}

export interface RoutingRule {
  condition: string;
  targetAccounts: string[];
  transformations: string[];
}

export interface TonePreset {
  name: string;
  descriptors: string[];
  examples: string[];
}

export interface ScheduleConfig {
  accountId: string;
  preferredTimes: string[];
  frequency: string;
  blackoutPeriods: string[];
}

// Combined advanced data model
export interface AdvancedRelayData {
  // Posting automation
  credentials: PostingCredentials[];
  scheduledPosts: ScheduledPost[];
  
  // AI routing
  routingDecisions: RoutingDecision[];
  routingAgentConfig: RoutingAgentConfig;
  
  // Social graph
  socialGraphData: SocialGraphData[];
  reputationScores: ReputationScore[];
  audienceSegments: AudienceSegment[];
  
  // Creator economy
  payments: PaymentTracking[];
  brandDeals: BrandDeal[];
  attributionMetrics: AttributionMetric[];
  
  // Performance
  experiments: RouteExperiment[];
  cadenceRecommendations: CadenceRecommendation[];
  
  // Multi-agent
  agentConfigs: AgentConfig[];
  postingRequests: PostingRequest[];
  agentReputations: AgentReputation[];
  
  // Crisis detection
  sentimentAlerts: SentimentAlert[];
  autoModerationRules: AutoModerationRule[];
  crisisEvents: CrisisEvent[];
  
  // Web3
  tokenGates: TokenGate[];
  daoGovernance: DAOGovernance[];
  revenueShares: RevenueShare[];
  
  // Viral tracking
  trends: TrendData[];
  contentSuggestions: ContentSuggestion[];
  viralTracking: ViralTracking[];
}
