export type Platform = 
  | "x" 
  | "farcaster" 
  | "zora" 
  | "lens" 
  | "warpcast" 
  | "base-feed" 
  | "other";

export type Ownership = 
  | "primary-self" 
  | "shared" 
  | "project" 
  | "bot-alt" 
  | "test";

export type PriorityLevel = "low" | "medium" | "high" | "critical";

export type AccountStatus = "active" | "paused" | "retired";

export type ContentType = 
  | "token" 
  | "drop" 
  | "meme" 
  | "campaign" 
  | "pickleball" 
  | "devlog" 
  | "other";

export type StreamStatus = "idea" | "active" | "paused" | "retired";

export type RiskLevel = "low" | "medium" | "high";

export interface GeoTarget {
  id: string;
  region: string;
  country: string;
  cityOrMarket: string;
  language: string;
}

export interface SEOMeta {
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string[];
  seoHashtags: string[];
  altText: string;
}

export interface PlatformAccount {
  id: string;
  platform: Platform;
  handle: string;
  displayName: string;
  accountRole: string;
  ownership: Ownership;
  description: string;
  priorityLevel: PriorityLevel;
  postingStyle: string[];
  allowedContentTypes: string[];
  linkedMiniApps: string[];
  status: AccountStatus;
  seo: SEOMeta;
  primaryGeoTargets: GeoTarget[];
  accountIntroLocalized: Record<string, string>;
  tagsLocalized: Record<string, string[]>;
  createdAt: string;
  updatedAt: string;
}

export interface ContentStream {
  id: string;
  name: string;
  type: ContentType;
  description: string;
  sourceMiniApp: string;
  cadenceHint: string;
  tags: string[];
  status: StreamStatus;
  seo?: Partial<SEOMeta>;
  createdAt: string;
  updatedAt: string;
}

export interface RelayRoute {
  id: string;
  contentStreamId: string;
  platformAccountId: string;
  routeName: string;
  purpose: string;
  allowedPostTypes: string[];
  toneGuidelines: string[];
  riskLevel: RiskLevel;
  manualApprovalRequired: boolean;
  notes: string;
  routeGeoTargets: GeoTarget[];
  captionTemplateLocalized: Record<string, string>;
  tagsRouteLocalized: Record<string, string[]>;
  createdAt: string;
  updatedAt: string;
}

export interface RelayMatrixData {
  platformAccounts: PlatformAccount[];
  contentStreams: ContentStream[];
  relayRoutes: RelayRoute[];
  geoTargets: GeoTarget[];
}

export interface AccountFilters {
  platform?: Platform;
  accountRole?: string;
  priorityLevel?: PriorityLevel;
  status?: AccountStatus;
}

export interface StreamFilters {
  type?: ContentType;
  status?: StreamStatus;
  sourceMiniApp?: string;
  tagSearch?: string;
}

export interface RouteFilters {
  contentStreamId?: string;
  platformAccountId?: string;
  riskLevel?: RiskLevel;
  manualApprovalRequired?: boolean;
}
