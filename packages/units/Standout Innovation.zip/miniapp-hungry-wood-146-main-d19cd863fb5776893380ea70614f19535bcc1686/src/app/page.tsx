'use client'
import { useState, useEffect } from 'react';
import { Book, Code2, Map, Trophy, FolderOpen, Moon, Sun, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ContentViewer } from '@/components/ContentViewer';
import { LearningPaths } from '@/components/LearningPaths';
import { QuizMode } from '@/components/QuizMode';
import { Collections } from '@/components/Collections';
import { useTheme } from '@/hooks/useTheme';
import { useProgress } from '@/hooks/useProgress';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamDevCookbook() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { theme, toggleTheme, isLoaded: themeLoaded } = useTheme();
  const { progress, isLoaded: progressLoaded } = useProgress();
  const [activeTab, setActiveTab] = useState('content');

  const stats = {
    completedRecipes: progress.completedRecipes.length,
    completedKnowledge: progress.completedKnowledge.length,
    completedQuizzes: progress.completedQuizzes.length,
    favorites: progress.favorites.length,
    collections: progress.collections.length
  };

  const totalCompleted = stats.completedRecipes + stats.completedKnowledge + stats.completedQuizzes;

  if (!themeLoaded || !progressLoaded) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Sparkles className="h-12 w-12 mx-auto animate-pulse text-purple-400" />
          <p className="text-gray-400">Loading DreamDev Cookbook...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={`min-h-screen transition-colors duration-300 ${
      theme === 'dark'
        ? 'bg-gradient-to-br from-gray-900 via-purple-900 to-gray-900'
        : 'bg-gradient-to-br from-gray-50 via-purple-50 to-gray-50'
    }`}>
      {/* Header */}
      <header className={`sticky top-0 z-50 border-b backdrop-blur-lg ${
        theme === 'dark'
          ? 'border-white/10 bg-gray-900/80'
          : 'border-gray-200 bg-white/80'
      }`}>
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-lg bg-gradient-to-br from-purple-500 to-cyan-500 flex items-center justify-center">
                <Sparkles className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className={`text-2xl font-bold ${
                  theme === 'dark' ? 'text-white' : 'text-gray-900'
                }`}>
                  DreamDev Cookbook
                </h1>
                <p className={`text-sm ${
                  theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
                }`}>
                  Your comprehensive developer knowledge base
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              {totalCompleted > 0 && (
                <div className={`hidden md:flex items-center gap-4 px-4 py-2 rounded-lg ${
                  theme === 'dark' ? 'bg-white/5' : 'bg-gray-100'
                }`}>
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${
                      theme === 'dark' ? 'text-purple-400' : 'text-purple-600'
                    }`}>
                      {totalCompleted}
                    </div>
                    <div className={`text-xs ${
                      theme === 'dark' ? 'text-gray-500' : 'text-gray-600'
                    }`}>
                      Completed
                    </div>
                  </div>
                  <div className={`h-8 w-px ${
                    theme === 'dark' ? 'bg-white/10' : 'bg-gray-300'
                  }`} />
                  <div className="text-center">
                    <div className={`text-2xl font-bold ${
                      theme === 'dark' ? 'text-cyan-400' : 'text-cyan-600'
                    }`}>
                      {stats.favorites}
                    </div>
                    <div className={`text-xs ${
                      theme === 'dark' ? 'text-gray-500' : 'text-gray-600'
                    }`}>
                      Favorites
                    </div>
                  </div>
                </div>
              )}

              <Button
                variant="outline"
                size="icon"
                onClick={toggleTheme}
                className={
                  theme === 'dark'
                    ? 'border-white/10 hover:bg-white/10'
                    : 'border-gray-300 hover:bg-gray-100'
                }
              >
                {theme === 'dark' ? (
                  <Sun className="h-5 w-5" />
                ) : (
                  <Moon className="h-5 w-5" />
                )}
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className={`grid w-full grid-cols-4 lg:grid-cols-5 mb-8 ${
            theme === 'dark' ? 'bg-white/5' : 'bg-gray-100'
          }`}>
            <TabsTrigger
              value="content"
              className="data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <Book className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Content</span>
            </TabsTrigger>
            <TabsTrigger
              value="paths"
              className="data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <Map className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Paths</span>
            </TabsTrigger>
            <TabsTrigger
              value="quiz"
              className="data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <Trophy className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Quiz</span>
            </TabsTrigger>
            <TabsTrigger
              value="collections"
              className="data-[state=active]:bg-purple-500 data-[state=active]:text-white"
            >
              <FolderOpen className="h-4 w-4 mr-2" />
              <span className="hidden sm:inline">Collections</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="content" className="mt-0">
            <ContentViewer />
          </TabsContent>

          <TabsContent value="paths" className="mt-0">
            <LearningPaths />
          </TabsContent>

          <TabsContent value="quiz" className="mt-0">
            <QuizMode />
          </TabsContent>

          <TabsContent value="collections" className="mt-0">
            <Collections />
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className={`border-t mt-16 ${
        theme === 'dark'
          ? 'border-white/10 bg-gray-900/50'
          : 'border-gray-200 bg-white/50'
      }`}>
        <div className="container mx-auto px-4 py-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className={`font-semibold mb-2 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>
                DreamDev Cookbook
              </h3>
              <p className={`text-sm ${
                theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
              }`}>
                A comprehensive, interactive developer knowledge base with recipes, patterns, and learning paths.
              </p>
            </div>

            <div>
              <h3 className={`font-semibold mb-2 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>
                Features
              </h3>
              <ul className={`text-sm space-y-1 ${
                theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
              }`}>
                <li>• Interactive code playground</li>
                <li>• Multi-language examples</li>
                <li>• Progress tracking</li>
                <li>• Learning paths</li>
                <li>• Quiz mode</li>
              </ul>
            </div>

            <div>
              <h3 className={`font-semibold mb-2 ${
                theme === 'dark' ? 'text-white' : 'text-gray-900'
              }`}>
                Your Stats
              </h3>
              <ul className={`text-sm space-y-1 ${
                theme === 'dark' ? 'text-gray-400' : 'text-gray-600'
              }`}>
                <li>• {stats.completedRecipes} recipes completed</li>
                <li>• {stats.completedKnowledge} knowledge packs completed</li>
                <li>• {stats.completedQuizzes} quizzes completed</li>
                <li>• {stats.favorites} favorites saved</li>
                <li>• {stats.collections} collections created</li>
              </ul>
            </div>
          </div>

          <div className={`mt-8 pt-8 border-t text-center text-sm ${
            theme === 'dark'
              ? 'border-white/10 text-gray-500'
              : 'border-gray-200 text-gray-600'
          }`}>
            <p>Built with Next.js, React, and TypeScript • DreamNet-inspired design</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
