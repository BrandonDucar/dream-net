'use client';

import { useState } from 'react';
import { Play, Copy, Check, Code2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import type { CodeExample } from '@/types/cookbook';

interface CodePlaygroundProps {
  examples: CodeExample[];
  title?: string;
}

const languageLabels: Record<string, string> = {
  typescript: 'TypeScript',
  python: 'Python',
  go: 'Go',
  rust: 'Rust'
};

export function CodePlayground({ examples, title }: CodePlaygroundProps) {
  const [copied, setCopied] = useState<Record<string, boolean>>({});
  const [output, setOutput] = useState<string>('');

  const copyCode = (code: string, id: string) => {
    navigator.clipboard.writeText(code);
    setCopied({ ...copied, [id]: true });
    setTimeout(() => {
      setCopied({ ...copied, [id]: false });
    }, 2000);
  };

  const runCode = (code: string, language: string) => {
    if (language === 'typescript' || language === 'javascript') {
      try {
        // Simple eval for demo - in production, use a sandboxed environment
        const logs: string[] = [];
        const customConsole = {
          log: (...args: any[]) => logs.push(args.join(' ')),
          error: (...args: any[]) => logs.push('Error: ' + args.join(' '))
        };
        
        const func = new Function('console', code);
        func(customConsole);
        
        setOutput(logs.join('\n') || 'Code executed successfully (no output)');
      } catch (error) {
        setOutput(`Error: ${(error as Error).message}`);
      }
    } else {
      setOutput(`Live execution is only available for TypeScript/JavaScript.\n\n${language} requires a server-side runtime.`);
    }
  };

  if (examples.length === 0) {
    return null;
  }

  return (
    <div className="space-y-4">
      {title && <h3 className="font-semibold text-lg">{title}</h3>}
      
      <Tabs defaultValue={examples[0].language} className="w-full">
        <div className="flex items-center justify-between mb-2">
          <TabsList className="bg-white/5">
            {examples.map((example) => (
              <TabsTrigger
                key={example.language}
                value={example.language}
                className="data-[state=active]:bg-purple-500/20"
              >
                <Code2 className="h-3 w-3 mr-1" />
                {languageLabels[example.language]}
              </TabsTrigger>
            ))}
          </TabsList>
        </div>

        {examples.map((example) => (
          <TabsContent key={example.language} value={example.language} className="mt-0">
            <div className="relative group">
              {example.filename && (
                <div className="flex items-center justify-between px-4 py-2 bg-white/5 border-b border-white/10 rounded-t-lg">
                  <span className="text-sm text-gray-400 font-mono">{example.filename}</span>
                  <Badge variant="outline" className="text-xs">
                    {languageLabels[example.language]}
                  </Badge>
                </div>
              )}
              
              <div className="relative">
                <pre className="p-4 bg-black/50 rounded-b-lg overflow-x-auto">
                  <code className="text-sm font-mono text-gray-300">{example.code}</code>
                </pre>
                
                <div className="absolute top-2 right-2 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  {(example.language === 'typescript' || example.language === 'javascript') && (
                    <Button
                      size="sm"
                      variant="secondary"
                      onClick={() => runCode(example.code, example.language)}
                      className="h-8 px-2 bg-green-500/20 hover:bg-green-500/30"
                    >
                      <Play className="h-3 w-3 mr-1" />
                      Run
                    </Button>
                  )}
                  
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => copyCode(example.code, example.language)}
                    className="h-8 px-2 bg-white/10 hover:bg-white/20"
                  >
                    {copied[example.language] ? (
                      <>
                        <Check className="h-3 w-3 mr-1" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="h-3 w-3 mr-1" />
                        Copy
                      </>
                    )}
                  </Button>
                </div>
              </div>
            </div>

            {output && (
              <div className="mt-4 p-4 bg-black/70 rounded-lg border border-green-500/30">
                <div className="flex items-center gap-2 mb-2">
                  <div className="h-2 w-2 bg-green-500 rounded-full animate-pulse" />
                  <span className="text-sm font-semibold text-green-400">Output</span>
                </div>
                <pre className="text-sm text-gray-300 font-mono whitespace-pre-wrap">{output}</pre>
              </div>
            )}
          </TabsContent>
        ))}
      </Tabs>
    </div>
  );
}
