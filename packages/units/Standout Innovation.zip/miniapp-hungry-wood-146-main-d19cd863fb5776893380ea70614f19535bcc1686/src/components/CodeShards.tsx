'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Copy, Check } from 'lucide-react';

interface CodeShardsProps {
  searchQuery: string;
}

interface CodeShard {
  id: string;
  title: string;
  description: string;
  language: string;
  category: string;
  code: string;
  usage: string;
}

const codeShards: CodeShard[] = [
  {
    id: 'cs1',
    title: 'Custom Hook: useLocalStorage',
    description: 'Persist state in localStorage with React hook',
    language: 'TypeScript',
    category: 'React Hooks',
    code: `function useLocalStorage<T>(key: string, initialValue: T) {
  const [storedValue, setStoredValue] = useState<T>(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = 
        value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };

  return [storedValue, setValue] as const;
}`,
    usage: 'const [name, setName] = useLocalStorage("name", "");'
  },
  {
    id: 'cs2',
    title: 'Debounce Function',
    description: 'Delay function execution until after wait period',
    language: 'TypeScript',
    category: 'Utilities',
    code: `function debounce<T extends (...args: any[]) => any>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;

  return function executedFunction(...args: Parameters<T>) {
    const later = () => {
      timeout = null;
      func(...args);
    };

    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
}`,
    usage: 'const debouncedSearch = debounce(handleSearch, 300);'
  },
  {
    id: 'cs3',
    title: 'API Error Handler',
    description: 'Standardized error handling for API calls',
    language: 'TypeScript',
    category: 'Error Handling',
    code: `async function handleApiError(error: unknown): Promise<string> {
  if (error instanceof Response) {
    const data = await error.json();
    return data.message || 'Server error occurred';
  }
  
  if (error instanceof Error) {
    return error.message;
  }
  
  return 'An unexpected error occurred';
}

// Usage in try-catch
try {
  const response = await fetch('/api/data');
  if (!response.ok) throw response;
  return await response.json();
} catch (error) {
  const message = await handleApiError(error);
  console.error(message);
}`,
    usage: 'const errorMsg = await handleApiError(error);'
  },
  {
    id: 'cs4',
    title: 'Format Currency',
    description: 'Format numbers as currency with locale support',
    language: 'TypeScript',
    category: 'Utilities',
    code: `function formatCurrency(
  amount: number,
  currency: string = 'USD',
  locale: string = 'en-US'
): string {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(amount);
}`,
    usage: 'formatCurrency(1234.56) // "$1,234.56"'
  },
  {
    id: 'cs5',
    title: 'Deep Clone Object',
    description: 'Create a deep copy of an object',
    language: 'TypeScript',
    category: 'Utilities',
    code: `function deepClone<T>(obj: T): T {
  if (obj === null || typeof obj !== 'object') {
    return obj;
  }

  if (obj instanceof Date) {
    return new Date(obj.getTime()) as T;
  }

  if (obj instanceof Array) {
    return obj.map(item => deepClone(item)) as T;
  }

  if (obj instanceof Object) {
    const clonedObj = {} as T;
    for (const key in obj) {
      if (obj.hasOwnProperty(key)) {
        clonedObj[key] = deepClone(obj[key]);
      }
    }
    return clonedObj;
  }

  return obj;
}`,
    usage: 'const copy = deepClone(originalObject);'
  },
  {
    id: 'cs6',
    title: 'Fetch with Timeout',
    description: 'Add timeout functionality to fetch requests',
    language: 'TypeScript',
    category: 'Network',
    code: `async function fetchWithTimeout(
  url: string,
  options: RequestInit = {},
  timeout: number = 5000
): Promise<Response> {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    clearTimeout(id);
    return response;
  } catch (error) {
    clearTimeout(id);
    throw error;
  }
}`,
    usage: 'const data = await fetchWithTimeout("/api", {}, 3000);'
  },
  {
    id: 'cs7',
    title: 'Retry Logic',
    description: 'Retry failed async operations with exponential backoff',
    language: 'TypeScript',
    category: 'Utilities',
    code: `async function retry<T>(
  fn: () => Promise<T>,
  maxAttempts: number = 3,
  delay: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;
      if (attempt < maxAttempts) {
        await new Promise(resolve => 
          setTimeout(resolve, delay * attempt)
        );
      }
    }
  }

  throw lastError!;
}`,
    usage: 'const result = await retry(() => fetchData(), 3, 1000);'
  },
  {
    id: 'cs8',
    title: 'Intersection Observer Hook',
    description: 'React hook for detecting element visibility',
    language: 'TypeScript',
    category: 'React Hooks',
    code: `function useIntersectionObserver(
  ref: RefObject<Element>,
  options: IntersectionObserverInit = {}
): boolean {
  const [isIntersecting, setIsIntersecting] = useState(false);

  useEffect(() => {
    const element = ref.current;
    if (!element) return;

    const observer = new IntersectionObserver(([entry]) => {
      setIsIntersecting(entry.isIntersecting);
    }, options);

    observer.observe(element);
    return () => observer.disconnect();
  }, [ref, options]);

  return isIntersecting;
}`,
    usage: 'const isVisible = useIntersectionObserver(elementRef);'
  }
];

export default function CodeShards({ searchQuery }: CodeShardsProps): JSX.Element {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const filteredShards = useMemo(() => {
    if (!searchQuery) return codeShards;
    
    const query = searchQuery.toLowerCase();
    return codeShards.filter(shard =>
      shard.title.toLowerCase().includes(query) ||
      shard.description.toLowerCase().includes(query) ||
      shard.category.toLowerCase().includes(query) ||
      shard.code.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  const copyToClipboard = async (code: string, id: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(code);
      setCopiedId(id);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
    }
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-purple-100 mb-2">💎 Code Shards</h2>
        <p className="text-purple-300/70 text-sm">
          Reusable code patterns and utilities you can copy and adapt
        </p>
      </div>

      {filteredShards.length === 0 ? (
        <Card className="bg-purple-950/30 border-purple-500/30">
          <CardContent className="pt-6">
            <p className="text-purple-300/60 text-center">No code shards found matching "{searchQuery}"</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredShards.map((shard) => (
            <Card key={shard.id} className="bg-purple-950/30 border-purple-500/30 hover:border-purple-400/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-2">
                  <div className="flex-1">
                    <CardTitle className="text-purple-100 text-lg mb-2">{shard.title}</CardTitle>
                    <CardDescription className="text-purple-300/70 mb-3">
                      {shard.description}
                    </CardDescription>
                    <div className="flex flex-wrap gap-2">
                      <Badge variant="outline" className="text-xs border-purple-400/30 text-purple-300">
                        {shard.language}
                      </Badge>
                      <Badge variant="outline" className="text-xs border-cyan-400/30 text-cyan-300">
                        {shard.category}
                      </Badge>
                    </div>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={() => copyToClipboard(shard.code, shard.id)}
                    className="shrink-0 text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
                  >
                    {copiedId === shard.id ? (
                      <Check className="h-4 w-4" />
                    ) : (
                      <Copy className="h-4 w-4" />
                    )}
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="bg-slate-950/60 rounded-lg p-4 border border-purple-500/20">
                  <pre className="text-sm text-purple-100 overflow-x-auto">
                    <code>{shard.code}</code>
                  </pre>
                </div>
                <div className="bg-cyan-950/30 border border-cyan-500/30 rounded-lg p-3">
                  <p className="text-xs text-cyan-300 font-semibold mb-1">Usage Example:</p>
                  <code className="text-sm text-cyan-100 font-mono">{shard.usage}</code>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
