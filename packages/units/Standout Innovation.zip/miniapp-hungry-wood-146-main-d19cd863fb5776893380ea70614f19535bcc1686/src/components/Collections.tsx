'use client';

import { useState } from 'react';
import { FolderOpen, Plus, Trash2, Heart } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { useProgress } from '@/hooks/useProgress';

export function Collections() {
  const { progress, createCollection, deleteCollection, isFavorited } = useProgress();
  const [isCreating, setIsCreating] = useState(false);
  const [newCollectionName, setNewCollectionName] = useState('');
  const [newCollectionDesc, setNewCollectionDesc] = useState('');

  const handleCreateCollection = () => {
    if (newCollectionName.trim()) {
      createCollection(newCollectionName.trim(), newCollectionDesc.trim());
      setNewCollectionName('');
      setNewCollectionDesc('');
      setIsCreating(false);
    }
  };

  const favoriteCount = progress.favorites.length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            Your Collections
          </h2>
          <p className="text-gray-400">
            Organize your favorite recipes and patterns
          </p>
        </div>

        <Dialog open={isCreating} onOpenChange={setIsCreating}>
          <DialogTrigger asChild>
            <Button className="bg-purple-500 hover:bg-purple-600">
              <Plus className="h-4 w-4 mr-2" />
              New Collection
            </Button>
          </DialogTrigger>
          <DialogContent className="bg-gray-900 border-white/10">
            <DialogHeader>
              <DialogTitle>Create New Collection</DialogTitle>
              <DialogDescription>
                Group related recipes and patterns together
              </DialogDescription>
            </DialogHeader>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Collection Name</label>
                <Input
                  placeholder="e.g., React Performance"
                  value={newCollectionName}
                  onChange={(e) => setNewCollectionName(e.target.value)}
                  className="bg-white/5 border-white/10"
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Description (optional)</label>
                <Textarea
                  placeholder="What's this collection about?"
                  value={newCollectionDesc}
                  onChange={(e) => setNewCollectionDesc(e.target.value)}
                  className="bg-white/5 border-white/10"
                  rows={3}
                />
              </div>
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateCollection} disabled={!newCollectionName.trim()}>
                Create Collection
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      <Card className="border-pink-500/30 bg-pink-500/10">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Heart className="h-5 w-5 text-pink-400 fill-pink-400" />
            <CardTitle>Favorites</CardTitle>
          </div>
          <CardDescription>
            {favoriteCount} item{favoriteCount !== 1 ? 's' : ''} marked as favorite
          </CardDescription>
        </CardHeader>
        <CardContent>
          {favoriteCount === 0 ? (
            <p className="text-sm text-gray-400">
              Click the heart icon on any recipe, pattern, or shard to save it here
            </p>
          ) : (
            <Button variant="outline" className="w-full">
              View All Favorites
            </Button>
          )}
        </CardContent>
      </Card>

      {progress.collections.length === 0 ? (
        <Card className="border-white/10 bg-white/5">
          <CardContent className="p-12 text-center">
            <FolderOpen className="h-16 w-16 mx-auto mb-4 text-gray-600" />
            <h3 className="text-xl font-semibold mb-2">No collections yet</h3>
            <p className="text-gray-400 mb-4">
              Create your first collection to organize related recipes and patterns
            </p>
            <Button onClick={() => setIsCreating(true)}>
              <Plus className="h-4 w-4 mr-2" />
              Create Collection
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {progress.collections.map((collection) => (
            <Card
              key={collection.id}
              className="border-white/10 bg-white/5 hover:bg-white/10 transition-all group"
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <FolderOpen className="h-5 w-5 text-purple-400" />
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 opacity-0 group-hover:opacity-100 transition-opacity"
                    onClick={() => deleteCollection(collection.id)}
                  >
                    <Trash2 className="h-4 w-4 text-red-400" />
                  </Button>
                </div>
                <CardTitle className="text-lg">{collection.name}</CardTitle>
                {collection.description && (
                  <CardDescription className="text-sm line-clamp-2">
                    {collection.description}
                  </CardDescription>
                )}
              </CardHeader>
              
              <CardContent className="space-y-3">
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="bg-white/5 border-white/10">
                    {collection.items.length} items
                  </Badge>
                  <span className="text-xs text-gray-500">
                    {new Date(collection.createdAt).toLocaleDateString()}
                  </span>
                </div>

                <Button variant="outline" className="w-full">
                  View Collection
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
