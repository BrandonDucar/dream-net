'use client';

import { useState, useMemo } from 'react';
import { Heart, Clock, TrendingUp, CheckCircle2, Tag, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CodePlayground } from './CodePlayground';
import { EnhancedSearch, type SearchFilters } from './EnhancedSearch';
import { useProgress } from '@/hooks/useProgress';
import { recipes, knowledgePacks, codeShards } from '@/lib/cookbookData';
import type { Recipe, KnowledgePack, CodeShard, DifficultyLevel } from '@/types/cookbook';

const difficultyColors: Record<DifficultyLevel, string> = {
  beginner: 'bg-green-500/20 text-green-300 border-green-500/30',
  intermediate: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  advanced: 'bg-red-500/20 text-red-300 border-red-500/30'
};

export function ContentViewer() {
  const { toggleFavorite, isFavorited, markCompleted, isCompleted } = useProgress();
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<SearchFilters>({ tags: [] });

  const handleSearch = (query: string, newFilters: SearchFilters) => {
    setSearchQuery(query);
    setFilters(newFilters);
  };

  const filterContent = <T extends { title: string; description: string; category: string; difficulty: DifficultyLevel; tags: string[] }>(
    items: T[]
  ): T[] => {
    return items.filter((item) => {
      const matchesQuery =
        !searchQuery ||
        item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.description.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesDifficulty = !filters.difficulty || item.difficulty === filters.difficulty;
      const matchesCategory = !filters.category || item.category === filters.category;

      return matchesQuery && matchesDifficulty && matchesCategory;
    });
  };

  const filteredRecipes = useMemo(() => filterContent(recipes), [searchQuery, filters]);
  const filteredKnowledge = useMemo(() => filterContent(knowledgePacks), [searchQuery, filters]);
  const filteredShards = useMemo(() => filterContent(codeShards), [searchQuery, filters]);

  const RecipeCard = ({ recipe }: { recipe: Recipe }) => (
    <Card className="border-white/10 bg-white/5 hover:bg-white/10 transition-all group">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className={difficultyColors[recipe.difficulty]}>
                {recipe.difficulty}
              </Badge>
              <Badge variant="outline" className="bg-white/5 border-white/10 text-xs">
                <Clock className="h-3 w-3 mr-1" />
                {recipe.timeEstimate}
              </Badge>
            </div>
            <CardTitle className="text-lg group-hover:text-purple-400 transition-colors">
              {recipe.title}
            </CardTitle>
            <CardDescription className="mt-2">{recipe.description}</CardDescription>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => toggleFavorite(recipe.id)}
            className="flex-shrink-0"
          >
            <Heart
              className={`h-5 w-5 ${
                isFavorited(recipe.id) ? 'fill-pink-500 text-pink-500' : 'text-gray-400'
              }`}
            />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {recipe.prerequisites.length > 0 && (
          <div className="text-sm">
            <span className="font-semibold text-gray-400">Prerequisites: </span>
            <span className="text-gray-500">{recipe.prerequisites.join(', ')}</span>
          </div>
        )}

        <div className="flex flex-wrap gap-1">
          {recipe.tags.map((tag) => (
            <Badge key={tag} variant="outline" className="text-xs bg-white/5">
              <Tag className="h-2 w-2 mr-1" />
              {tag}
            </Badge>
          ))}
        </div>

        <CodePlayground examples={recipe.examples} />

        {recipe.explanation && (
          <div className="p-3 bg-blue-500/10 border border-blue-500/30 rounded-lg">
            <p className="text-sm text-gray-300">{recipe.explanation}</p>
          </div>
        )}

        {recipe.useCases.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-semibold">Use Cases:</p>
            <ul className="text-sm text-gray-400 space-y-1">
              {recipe.useCases.map((useCase, index) => (
                <li key={index} className="flex items-start gap-2">
                  <ArrowRight className="h-4 w-4 mt-0.5 text-purple-400 flex-shrink-0" />
                  <span>{useCase}</span>
                </li>
              ))}
            </ul>
          </div>
        )}

        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3" />
              {recipe.votes} votes
            </span>
            <span>{recipe.saves} saves</span>
          </div>
          
          <Button
            size="sm"
            variant={isCompleted('recipe', recipe.id) ? 'outline' : 'default'}
            onClick={() => markCompleted('recipe', recipe.id)}
          >
            {isCompleted('recipe', recipe.id) ? (
              <>
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Completed
              </>
            ) : (
              'Mark Complete'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const KnowledgeCard = ({ pack }: { pack: KnowledgePack }) => (
    <Card className="border-white/10 bg-white/5 hover:bg-white/10 transition-all group">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <Badge variant="outline" className={difficultyColors[pack.difficulty]}>
                {pack.difficulty}
              </Badge>
              <Badge variant="outline" className="bg-white/5 border-white/10 text-xs">
                <Clock className="h-3 w-3 mr-1" />
                {pack.timeEstimate}
              </Badge>
            </div>
            <CardTitle className="text-lg group-hover:text-purple-400 transition-colors">
              {pack.title}
            </CardTitle>
            <CardDescription className="mt-2">{pack.description}</CardDescription>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => toggleFavorite(pack.id)}
            className="flex-shrink-0"
          >
            <Heart
              className={`h-5 w-5 ${
                isFavorited(pack.id) ? 'fill-pink-500 text-pink-500' : 'text-gray-400'
              }`}
            />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <p className="text-sm font-semibold">What You'll Learn:</p>
          <ul className="text-sm text-gray-400 space-y-1">
            {pack.content.map((item, index) => (
              <li key={index} className="flex items-start gap-2">
                <CheckCircle2 className="h-4 w-4 mt-0.5 text-green-400 flex-shrink-0" />
                <span>{item}</span>
              </li>
            ))}
          </ul>
        </div>

        <CodePlayground examples={pack.examples} />

        <div className="p-3 bg-purple-500/10 border border-purple-500/30 rounded-lg space-y-2">
          <p className="text-sm font-semibold text-purple-300">Key Takeaways</p>
          <ul className="text-sm text-gray-300 space-y-1">
            {pack.keyTakeaways.map((takeaway, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-purple-400">•</span>
                <span>{takeaway}</span>
              </li>
            ))}
          </ul>
        </div>

        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <div className="flex items-center gap-1 text-xs text-gray-500">
            <TrendingUp className="h-3 w-3" />
            <span>{pack.votes} votes</span>
          </div>
          
          <Button
            size="sm"
            variant={isCompleted('knowledge', pack.id) ? 'outline' : 'default'}
            onClick={() => markCompleted('knowledge', pack.id)}
          >
            {isCompleted('knowledge', pack.id) ? (
              <>
                <CheckCircle2 className="h-4 w-4 mr-1" />
                Completed
              </>
            ) : (
              'Mark Complete'
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );

  const ShardCard = ({ shard }: { shard: CodeShard }) => (
    <Card className="border-white/10 bg-white/5 hover:bg-white/10 transition-all group">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-lg group-hover:text-purple-400 transition-colors">
              {shard.title}
            </CardTitle>
            <CardDescription className="mt-2">{shard.description}</CardDescription>
          </div>
          
          <Button
            variant="ghost"
            size="icon"
            onClick={() => toggleFavorite(shard.id)}
            className="flex-shrink-0"
          >
            <Heart
              className={`h-5 w-5 ${
                isFavorited(shard.id) ? 'fill-pink-500 text-pink-500' : 'text-gray-400'
              }`}
            />
          </Button>
        </div>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <CodePlayground examples={shard.examples} />

        {shard.useCases.length > 0 && (
          <div className="space-y-2">
            <p className="text-sm font-semibold">Perfect For:</p>
            <div className="flex flex-wrap gap-2">
              {shard.useCases.map((useCase, index) => (
                <Badge key={index} variant="outline" className="bg-white/5">
                  {useCase}
                </Badge>
              ))}
            </div>
          </div>
        )}

        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <div className="flex items-center gap-4 text-xs text-gray-500">
            <span className="flex items-center gap-1">
              <TrendingUp className="h-3 w-3" />
              {shard.votes} votes
            </span>
            <span>{shard.saves} saves</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <EnhancedSearch onSearch={handleSearch} />

      <Tabs defaultValue="recipes" className="w-full">
        <TabsList className="bg-white/5 grid w-full grid-cols-3">
          <TabsTrigger value="recipes">Recipes ({filteredRecipes.length})</TabsTrigger>
          <TabsTrigger value="knowledge">Knowledge ({filteredKnowledge.length})</TabsTrigger>
          <TabsTrigger value="shards">Code Shards ({filteredShards.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="recipes" className="space-y-6 mt-6">
          {filteredRecipes.length === 0 ? (
            <Card className="border-white/10 bg-white/5">
              <CardContent className="p-12 text-center">
                <p className="text-gray-400">No recipes found matching your search</p>
              </CardContent>
            </Card>
          ) : (
            filteredRecipes.map((recipe) => <RecipeCard key={recipe.id} recipe={recipe} />)
          )}
        </TabsContent>

        <TabsContent value="knowledge" className="space-y-6 mt-6">
          {filteredKnowledge.length === 0 ? (
            <Card className="border-white/10 bg-white/5">
              <CardContent className="p-12 text-center">
                <p className="text-gray-400">No knowledge packs found matching your search</p>
              </CardContent>
            </Card>
          ) : (
            filteredKnowledge.map((pack) => <KnowledgeCard key={pack.id} pack={pack} />)
          )}
        </TabsContent>

        <TabsContent value="shards" className="space-y-6 mt-6">
          {filteredShards.length === 0 ? (
            <Card className="border-white/10 bg-white/5">
              <CardContent className="p-12 text-center">
                <p className="text-gray-400">No code shards found matching your search</p>
              </CardContent>
            </Card>
          ) : (
            filteredShards.map((shard) => <ShardCard key={shard.id} shard={shard} />)
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
