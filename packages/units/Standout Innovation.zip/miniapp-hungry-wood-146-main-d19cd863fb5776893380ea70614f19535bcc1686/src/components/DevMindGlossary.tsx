'use client';

import { useMemo, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface DevMindGlossaryProps {
  searchQuery: string;
}

interface GlossaryTerm {
  id: string;
  term: string;
  category: string;
  definition: string;
  example?: string;
  relatedTerms: string[];
}

const glossaryTerms: GlossaryTerm[] = [
  {
    id: 'g1',
    term: 'API (Application Programming Interface)',
    category: 'Backend',
    definition: 'A set of rules and protocols that allows different software applications to communicate with each other. Think of it as a waiter in a restaurant - you tell the waiter what you want, and they bring it from the kitchen.',
    example: 'When you use a weather app, it calls a weather API to get current conditions.',
    relatedTerms: ['REST', 'GraphQL', 'Endpoint']
  },
  {
    id: 'g2',
    term: 'Asynchronous (Async)',
    category: 'JavaScript',
    definition: 'Code that doesn\'t block execution while waiting for an operation to complete. Like ordering food delivery - you don\'t wait by the door, you do other things until it arrives.',
    example: 'fetch() is asynchronous - your code continues running while waiting for the server response.',
    relatedTerms: ['Promise', 'async/await', 'Callback']
  },
  {
    id: 'g3',
    term: 'Component',
    category: 'React',
    definition: 'A reusable, self-contained piece of UI. Like LEGO blocks - you build complex interfaces by combining simple components.',
    example: 'A Button component can be reused throughout your app with different text and actions.',
    relatedTerms: ['Props', 'State', 'JSX']
  },
  {
    id: 'g4',
    term: 'CRUD',
    category: 'Backend',
    definition: 'Create, Read, Update, Delete - the four basic operations for persistent storage. Every database-driven app implements these.',
    example: 'A blog app: Create posts, Read posts, Update posts, Delete posts.',
    relatedTerms: ['REST', 'Database', 'API']
  },
  {
    id: 'g5',
    term: 'Debounce',
    category: 'Performance',
    definition: 'Delaying execution of a function until after a period of inactivity. Prevents excessive function calls.',
    example: 'Search suggestions appear 300ms after you stop typing, not on every keystroke.',
    relatedTerms: ['Throttle', 'Performance', 'Event Handler']
  },
  {
    id: 'g6',
    term: 'Dependency',
    category: 'Development',
    definition: 'External code (libraries, packages) that your project relies on. Managed via package.json and npm/yarn.',
    example: 'React, Axios, and Lodash are dependencies if you use them in your project.',
    relatedTerms: ['npm', 'package.json', 'node_modules']
  },
  {
    id: 'g7',
    term: 'Hook',
    category: 'React',
    definition: 'Functions that let you "hook into" React features from function components. Always start with "use".',
    example: 'useState lets you add state to function components.',
    relatedTerms: ['useState', 'useEffect', 'Custom Hooks']
  },
  {
    id: 'g8',
    term: 'Middleware',
    category: 'Backend',
    definition: 'Code that runs between receiving a request and sending a response. Like security checkpoints at an airport.',
    example: 'Authentication middleware checks if user is logged in before allowing access.',
    relatedTerms: ['Express', 'Authentication', 'Request Pipeline']
  },
  {
    id: 'g9',
    term: 'Promise',
    category: 'JavaScript',
    definition: 'An object representing the eventual completion or failure of an asynchronous operation. Like a receipt for something that hasn\'t been delivered yet.',
    example: 'fetch() returns a Promise that resolves when the server responds.',
    relatedTerms: ['async/await', 'then/catch', 'Asynchronous']
  },
  {
    id: 'g10',
    term: 'Props',
    category: 'React',
    definition: 'Short for "properties" - data passed from parent to child components. Read-only and unidirectional.',
    example: '<Button color="blue" text="Click me" /> passes two props.',
    relatedTerms: ['Component', 'State', 'Children']
  },
  {
    id: 'g11',
    term: 'REST (Representational State Transfer)',
    category: 'Backend',
    definition: 'An architectural style for APIs using HTTP methods (GET, POST, PUT, DELETE) to perform operations on resources.',
    example: 'GET /users retrieves users, POST /users creates a new user.',
    relatedTerms: ['API', 'HTTP Methods', 'Endpoint']
  },
  {
    id: 'g12',
    term: 'State',
    category: 'React',
    definition: 'Data that changes over time in a component. When state changes, React re-renders the component.',
    example: 'A counter value that increments when you click a button is state.',
    relatedTerms: ['useState', 'Props', 'Re-render']
  },
  {
    id: 'g13',
    term: 'Type Safety',
    category: 'TypeScript',
    definition: 'Ensuring variables and functions only work with compatible data types, catching errors at compile time.',
    example: 'TypeScript prevents you from passing a string to a function expecting a number.',
    relatedTerms: ['TypeScript', 'Interface', 'Type Checking']
  },
  {
    id: 'g14',
    term: 'Webpack',
    category: 'Build Tools',
    definition: 'A module bundler that takes your code and dependencies and packages them for the browser.',
    example: 'Webpack combines all your JS files into one optimized bundle.js.',
    relatedTerms: ['Bundler', 'Build Process', 'Module']
  },
  {
    id: 'g15',
    term: 'JWT (JSON Web Token)',
    category: 'Security',
    definition: 'A compact, URL-safe token format for securely transmitting information between parties. Commonly used for authentication.',
    example: 'After login, server sends JWT that client includes in subsequent requests.',
    relatedTerms: ['Authentication', 'Authorization', 'Token']
  },
  {
    id: 'g16',
    term: 'SSR (Server-Side Rendering)',
    category: 'React',
    definition: 'Rendering React components on the server and sending HTML to the client, improving initial load time and SEO.',
    example: 'Next.js uses SSR to generate pages on each request.',
    relatedTerms: ['Next.js', 'CSR', 'SEO']
  },
  {
    id: 'g17',
    term: 'Closure',
    category: 'JavaScript',
    definition: 'A function that has access to variables from its outer scope, even after the outer function has returned.',
    example: 'Event handlers often use closures to remember component state.',
    relatedTerms: ['Scope', 'Function', 'Lexical Environment']
  },
  {
    id: 'g18',
    term: 'ORM (Object-Relational Mapping)',
    category: 'Database',
    definition: 'A technique that lets you query and manipulate database data using objects instead of SQL.',
    example: 'Prisma is an ORM that lets you write User.create() instead of INSERT INTO users.',
    relatedTerms: ['Database', 'Prisma', 'SQL']
  }
];

export default function DevMindGlossary({ searchQuery }: DevMindGlossaryProps): JSX.Element {
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = useMemo(() => {
    const cats = Array.from(new Set(glossaryTerms.map(t => t.category)));
    return ['All', ...cats.sort()];
  }, []);

  const filteredTerms = useMemo(() => {
    let filtered = glossaryTerms;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(term => term.category === selectedCategory);
    }

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(term =>
        term.term.toLowerCase().includes(query) ||
        term.definition.toLowerCase().includes(query) ||
        term.category.toLowerCase().includes(query) ||
        term.relatedTerms.some(rt => rt.toLowerCase().includes(query))
      );
    }

    return filtered.sort((a, b) => a.term.localeCompare(b.term));
  }, [searchQuery, selectedCategory]);

  const getCategoryColor = (category: string): string => {
    const colors: Record<string, string> = {
      'React': 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
      'JavaScript': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
      'Backend': 'bg-green-500/20 text-green-300 border-green-500/30',
      'Database': 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      'Security': 'bg-red-500/20 text-red-300 border-red-500/30',
      'TypeScript': 'bg-blue-400/20 text-blue-200 border-blue-400/30',
      'Performance': 'bg-orange-500/20 text-orange-300 border-orange-500/30',
      'Build Tools': 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      'Development': 'bg-pink-500/20 text-pink-300 border-pink-500/30'
    };
    return colors[category] || 'bg-gray-500/20 text-gray-300 border-gray-500/30';
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-purple-100 mb-2">📖 DevMind Glossary</h2>
        <p className="text-purple-300/70 text-sm mb-4">
          Essential terms every developer should know, explained simply
        </p>

        {/* Category Filter */}
        <div className="flex flex-wrap gap-2">
          {categories.map((category) => (
            <Badge
              key={category}
              variant={selectedCategory === category ? 'default' : 'outline'}
              className={`cursor-pointer transition-colors ${
                selectedCategory === category
                  ? 'bg-purple-600 text-white border-purple-500'
                  : 'border-purple-400/30 text-purple-300 hover:bg-purple-600/20'
              }`}
              onClick={() => setSelectedCategory(category)}
            >
              {category}
            </Badge>
          ))}
        </div>
      </div>

      {filteredTerms.length === 0 ? (
        <Card className="bg-purple-950/30 border-purple-500/30">
          <CardContent className="pt-6">
            <p className="text-purple-300/60 text-center">
              No terms found matching "{searchQuery}"
              {selectedCategory !== 'All' && ` in category "${selectedCategory}"`}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Accordion type="single" collapsible className="space-y-2">
          {filteredTerms.map((term) => (
            <AccordionItem
              key={term.id}
              value={term.id}
              className="bg-purple-950/30 border border-purple-500/30 rounded-lg px-4 data-[state=open]:border-purple-400/50"
            >
              <AccordionTrigger className="hover:no-underline">
                <div className="flex items-center gap-3 text-left">
                  <Badge className={`${getCategoryColor(term.category)} text-xs shrink-0`}>
                    {term.category}
                  </Badge>
                  <span className="text-purple-100 font-semibold">{term.term}</span>
                </div>
              </AccordionTrigger>
              <AccordionContent>
                <div className="space-y-3 pt-2 pb-2">
                  <div>
                    <p className="text-purple-300/90 text-sm leading-relaxed">
                      {term.definition}
                    </p>
                  </div>

                  {term.example && (
                    <div className="bg-cyan-950/30 border border-cyan-500/30 rounded-lg p-3">
                      <p className="text-xs text-cyan-300 font-semibold mb-1">Example:</p>
                      <p className="text-cyan-100/90 text-sm">{term.example}</p>
                    </div>
                  )}

                  {term.relatedTerms.length > 0 && (
                    <div>
                      <p className="text-xs text-purple-400 font-semibold mb-2">Related Terms:</p>
                      <div className="flex flex-wrap gap-1">
                        {term.relatedTerms.map((related, idx) => (
                          <Badge
                            key={idx}
                            variant="outline"
                            className="text-xs border-purple-400/20 text-purple-300/70"
                          >
                            {related}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      )}

      <div className="text-center text-purple-400/60 text-xs mt-8">
        {filteredTerms.length} {filteredTerms.length === 1 ? 'term' : 'terms'} 
        {selectedCategory !== 'All' && ` in ${selectedCategory}`}
      </div>
    </div>
  );
}
