'use client';

import { useState, useMemo } from 'react';
import { Search, Filter, X } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import type { DifficultyLevel, ContentCategory } from '@/types/cookbook';

interface EnhancedSearchProps {
  onSearch: (query: string, filters: SearchFilters) => void;
  placeholder?: string;
}

export interface SearchFilters {
  difficulty?: DifficultyLevel;
  category?: ContentCategory;
  tags: string[];
}

const categories: ContentCategory[] = [
  'react',
  'backend',
  'database',
  'performance',
  'security',
  'testing',
  'devops',
  'patterns'
];

const difficulties: DifficultyLevel[] = ['beginner', 'intermediate', 'advanced'];

export function EnhancedSearch({ onSearch, placeholder = 'Search recipes, patterns, concepts...' }: EnhancedSearchProps) {
  const [query, setQuery] = useState('');
  const [showFilters, setShowFilters] = useState(false);
  const [filters, setFilters] = useState<SearchFilters>({
    tags: []
  });

  const handleSearch = (newQuery: string, newFilters: SearchFilters = filters) => {
    setQuery(newQuery);
    onSearch(newQuery, newFilters);
  };

  const updateFilter = (key: keyof SearchFilters, value: any) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    handleSearch(query, newFilters);
  };

  const clearFilters = () => {
    const newFilters: SearchFilters = { tags: [] };
    setFilters(newFilters);
    handleSearch(query, newFilters);
  };

  const hasActiveFilters = filters.difficulty || filters.category || filters.tags.length > 0;

  return (
    <div className="w-full space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            type="text"
            placeholder={placeholder}
            value={query}
            onChange={(e) => handleSearch(e.target.value)}
            className="pl-10 bg-white/5 border-white/10 focus:border-purple-500"
          />
        </div>
        <Button
          variant={showFilters ? 'default' : 'outline'}
          size="icon"
          onClick={() => setShowFilters(!showFilters)}
          className="relative"
        >
          <Filter className="h-4 w-4" />
          {hasActiveFilters && (
            <span className="absolute -top-1 -right-1 h-3 w-3 bg-purple-500 rounded-full" />
          )}
        </Button>
      </div>

      {showFilters && (
        <div className="p-4 bg-white/5 border border-white/10 rounded-lg space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-sm">Filters</h3>
            {hasActiveFilters && (
              <Button
                variant="ghost"
                size="sm"
                onClick={clearFilters}
                className="h-auto py-1 px-2 text-xs"
              >
                <X className="h-3 w-3 mr-1" />
                Clear all
              </Button>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Difficulty</label>
              <Select
                value={filters.difficulty}
                onValueChange={(value) =>
                  updateFilter('difficulty', value === 'all' ? undefined : value)
                }
              >
                <SelectTrigger className="bg-white/5 border-white/10">
                  <SelectValue placeholder="All levels" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All levels</SelectItem>
                  {difficulties.map((diff) => (
                    <SelectItem key={diff} value={diff}>
                      {diff.charAt(0).toUpperCase() + diff.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Category</label>
              <Select
                value={filters.category}
                onValueChange={(value) =>
                  updateFilter('category', value === 'all' ? undefined : value)
                }
              >
                <SelectTrigger className="bg-white/5 border-white/10">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat.charAt(0).toUpperCase() + cat.slice(1)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {hasActiveFilters && (
            <div className="flex flex-wrap gap-2 pt-2 border-t border-white/10">
              {filters.difficulty && (
                <Badge variant="secondary" className="bg-purple-500/20 text-purple-300">
                  {filters.difficulty}
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => updateFilter('difficulty', undefined)}
                  />
                </Badge>
              )}
              {filters.category && (
                <Badge variant="secondary" className="bg-cyan-500/20 text-cyan-300">
                  {filters.category}
                  <X
                    className="h-3 w-3 ml-1 cursor-pointer"
                    onClick={() => updateFilter('category', undefined)}
                  />
                </Badge>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
