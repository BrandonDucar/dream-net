'use client';

import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';

interface KnowledgePacksProps {
  searchQuery: string;
}

interface KnowledgePack {
  id: string;
  title: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  category: string;
  description: string;
  concepts: string[];
  keyPoints: string[];
}

const knowledgePacks: KnowledgePack[] = [
  {
    id: 'kp1',
    title: 'State Management Fundamentals',
    level: 'Beginner',
    category: 'React',
    description: 'Understanding how to manage state in React applications',
    concepts: ['Component State', 'Props vs State', 'Lifting State Up', 'useState Hook'],
    keyPoints: [
      'State is data that changes over time',
      'Props flow down, events flow up',
      'Keep state as close to where it\'s used as possible',
      'useState returns [value, setter] pair'
    ]
  },
  {
    id: 'kp2',
    title: 'RESTful API Design Patterns',
    level: 'Intermediate',
    category: 'Backend',
    description: 'Best practices for designing scalable REST APIs',
    concepts: ['Resource Naming', 'HTTP Methods', 'Status Codes', 'Versioning'],
    keyPoints: [
      'Use nouns for resources, not verbs (e.g., /users not /getUsers)',
      'GET for reading, POST for creating, PUT/PATCH for updating, DELETE for removing',
      'Return appropriate status codes (200, 201, 400, 404, 500)',
      'Version your API (e.g., /api/v1/users)'
    ]
  },
  {
    id: 'kp3',
    title: 'Async/Await Pattern',
    level: 'Intermediate',
    category: 'JavaScript',
    description: 'Modern asynchronous programming in JavaScript',
    concepts: ['Promises', 'async Functions', 'await Keyword', 'Error Handling'],
    keyPoints: [
      'async functions always return a Promise',
      'await pauses execution until Promise resolves',
      'Use try/catch for error handling with async/await',
      'Can\'t use await in non-async functions'
    ]
  },
  {
    id: 'kp4',
    title: 'Component Composition',
    level: 'Beginner',
    category: 'React',
    description: 'Building complex UIs from simple components',
    concepts: ['Children Prop', 'Component Hierarchy', 'Reusability', 'Single Responsibility'],
    keyPoints: [
      'Break UI into small, focused components',
      'Use children prop for flexible composition',
      'Each component should do one thing well',
      'Prefer composition over inheritance'
    ]
  },
  {
    id: 'kp5',
    title: 'Database Indexing Strategy',
    level: 'Advanced',
    category: 'Database',
    description: 'Optimizing database queries with proper indexing',
    concepts: ['Index Types', 'Query Performance', 'Write Trade-offs', 'Composite Indexes'],
    keyPoints: [
      'Indexes speed up reads but slow down writes',
      'Index columns used in WHERE, JOIN, ORDER BY',
      'Composite indexes: order matters (left-to-right)',
      'Monitor query performance and adjust indexes accordingly'
    ]
  },
  {
    id: 'kp6',
    title: 'TypeScript Generics',
    level: 'Advanced',
    category: 'TypeScript',
    description: 'Writing reusable, type-safe code with generics',
    concepts: ['Type Parameters', 'Constraints', 'Generic Functions', 'Generic Types'],
    keyPoints: [
      'Generics let you write code that works with multiple types',
      'Use <T> syntax to define type parameters',
      'Constraints limit what types can be used (extends)',
      'Inferred types make generics ergonomic'
    ]
  },
  {
    id: 'kp7',
    title: 'CSS Grid vs Flexbox',
    level: 'Beginner',
    category: 'CSS',
    description: 'Choosing the right layout system',
    concepts: ['Grid Layout', 'Flex Layout', 'Use Cases', 'Responsive Design'],
    keyPoints: [
      'Flexbox for 1D layouts (rows OR columns)',
      'Grid for 2D layouts (rows AND columns)',
      'Flexbox excels at distributing space in a line',
      'Grid excels at aligning items in rows and columns'
    ]
  },
  {
    id: 'kp8',
    title: 'Authentication vs Authorization',
    level: 'Intermediate',
    category: 'Security',
    description: 'Understanding the difference and implementation',
    concepts: ['Authentication', 'Authorization', 'JWT', 'Session Management'],
    keyPoints: [
      'Authentication: "Who are you?" (login)',
      'Authorization: "What can you do?" (permissions)',
      'JWTs are stateless tokens for auth',
      'Always validate permissions on the server'
    ]
  }
];

export default function KnowledgePacks({ searchQuery }: KnowledgePacksProps): JSX.Element {
  const filteredPacks = useMemo(() => {
    if (!searchQuery) return knowledgePacks;
    
    const query = searchQuery.toLowerCase();
    return knowledgePacks.filter(pack =>
      pack.title.toLowerCase().includes(query) ||
      pack.description.toLowerCase().includes(query) ||
      pack.category.toLowerCase().includes(query) ||
      pack.concepts.some(c => c.toLowerCase().includes(query)) ||
      pack.keyPoints.some(k => k.toLowerCase().includes(query))
    );
  }, [searchQuery]);

  const getLevelColor = (level: string): string => {
    switch (level) {
      case 'Beginner': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'Intermediate': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'Advanced': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-purple-100 mb-2">📦 Knowledge Packs</h2>
        <p className="text-purple-300/70 text-sm">
          Core concepts and patterns organized by difficulty level
        </p>
      </div>

      {filteredPacks.length === 0 ? (
        <Card className="bg-purple-950/30 border-purple-500/30">
          <CardContent className="pt-6">
            <p className="text-purple-300/60 text-center">No knowledge packs found matching "{searchQuery}"</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredPacks.map((pack) => (
            <Card key={pack.id} className="bg-purple-950/30 border-purple-500/30 hover:border-purple-400/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <CardTitle className="text-purple-100 text-lg">{pack.title}</CardTitle>
                  <Badge className={`${getLevelColor(pack.level)} text-xs shrink-0`}>
                    {pack.level}
                  </Badge>
                </div>
                <CardDescription className="text-purple-300/70">
                  <Badge variant="outline" className="text-xs mb-2 border-purple-400/30 text-purple-300">
                    {pack.category}
                  </Badge>
                  <p className="mt-2">{pack.description}</p>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <Accordion type="single" collapsible className="w-full">
                  <AccordionItem value="concepts" className="border-purple-500/30">
                    <AccordionTrigger className="text-purple-200 text-sm hover:text-purple-100">
                      Core Concepts ({pack.concepts.length})
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="space-y-1 text-purple-300/80 text-sm">
                        {pack.concepts.map((concept, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="text-purple-400 mr-2">•</span>
                            {concept}
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                  
                  <AccordionItem value="keypoints" className="border-purple-500/30">
                    <AccordionTrigger className="text-purple-200 text-sm hover:text-purple-100">
                      Key Points ({pack.keyPoints.length})
                    </AccordionTrigger>
                    <AccordionContent>
                      <ul className="space-y-2 text-purple-300/80 text-sm">
                        {pack.keyPoints.map((point, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="text-cyan-400 mr-2">→</span>
                            {point}
                          </li>
                        ))}
                      </ul>
                    </AccordionContent>
                  </AccordionItem>
                </Accordion>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
