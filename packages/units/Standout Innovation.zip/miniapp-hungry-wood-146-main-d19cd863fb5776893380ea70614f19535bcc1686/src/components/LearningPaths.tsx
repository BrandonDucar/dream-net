'use client';

import { useState } from 'react';
import { MapPin, Clock, CheckCircle2, Circle, Play, Trophy } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { learningPaths } from '@/lib/cookbookData';
import { useProgress } from '@/hooks/useProgress';
import type { LearningPath } from '@/types/cookbook';

const difficultyColors = {
  beginner: 'bg-green-500/20 text-green-300 border-green-500/30',
  intermediate: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  advanced: 'bg-red-500/20 text-red-300 border-red-500/30'
};

export function LearningPaths() {
  const { progress, updatePathProgress } = useProgress();
  const [selectedPath, setSelectedPath] = useState<LearningPath | null>(null);

  const getPathProgress = (path: LearningPath): number => {
    const completed = progress.pathProgress[path.id] || 0;
    return Math.round((completed / path.items.length) * 100);
  };

  const getCompletedItems = (path: LearningPath): number => {
    return progress.pathProgress[path.id] || 0;
  };

  if (selectedPath) {
    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedPath(null)}
              className="mb-2"
            >
              ← Back to all paths
            </Button>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              {selectedPath.title}
            </h2>
            <p className="text-gray-400">{selectedPath.description}</p>
            
            <div className="flex flex-wrap gap-3 mt-4">
              <Badge variant="outline" className={difficultyColors[selectedPath.difficulty]}>
                {selectedPath.difficulty}
              </Badge>
              <Badge variant="outline" className="bg-white/5 border-white/10">
                <Clock className="h-3 w-3 mr-1" />
                {selectedPath.estimatedHours}h
              </Badge>
              <Badge variant="outline" className="bg-white/5 border-white/10">
                {getCompletedItems(selectedPath)}/{selectedPath.items.length} completed
              </Badge>
            </div>
          </div>
          
          {getPathProgress(selectedPath) === 100 && (
            <Trophy className="h-12 w-12 text-yellow-500" />
          )}
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">Overall Progress</span>
            <span className="font-semibold">{getPathProgress(selectedPath)}%</span>
          </div>
          <Progress value={getPathProgress(selectedPath)} className="h-2" />
        </div>

        <div className="space-y-4">
          <h3 className="text-xl font-semibold">Learning Journey</h3>
          
          <div className="space-y-3">
            {selectedPath.items.map((item, index) => {
              const isCompleted = index < getCompletedItems(selectedPath);
              const isCurrent = index === getCompletedItems(selectedPath);
              
              return (
                <Card
                  key={`${item.type}-${item.id}`}
                  className={`border-white/10 ${
                    isCompleted
                      ? 'bg-green-500/10 border-green-500/30'
                      : isCurrent
                      ? 'bg-purple-500/10 border-purple-500/30'
                      : 'bg-white/5'
                  }`}
                >
                  <CardContent className="p-4">
                    <div className="flex items-center gap-4">
                      <div className="flex-shrink-0">
                        {isCompleted ? (
                          <CheckCircle2 className="h-6 w-6 text-green-400" />
                        ) : isCurrent ? (
                          <Play className="h-6 w-6 text-purple-400" />
                        ) : (
                          <Circle className="h-6 w-6 text-gray-600" />
                        )}
                      </div>
                      
                      <div className="flex-1 space-y-1">
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">
                            {item.type}
                          </Badge>
                          <span className="text-sm text-gray-400">Step {index + 1}</span>
                        </div>
                        <p className="font-medium">
                          {item.type === 'recipe' && 'Recipe: '}
                          {item.type === 'knowledge' && 'Knowledge: '}
                          {item.type === 'shard' && 'Code Shard: '}
                          {item.type === 'quiz' && 'Quiz: '}
                          {item.id}
                        </p>
                      </div>
                      
                      {isCurrent && (
                        <Button
                          size="sm"
                          onClick={() => updatePathProgress(selectedPath.id, index + 1)}
                        >
                          Mark Complete
                        </Button>
                      )}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>

        {selectedPath.prerequisites.length > 0 && (
          <Card className="border-yellow-500/30 bg-yellow-500/5">
            <CardHeader>
              <CardTitle className="text-lg">Prerequisites</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="list-disc list-inside space-y-1 text-sm text-gray-300">
                {selectedPath.prerequisites.map((prereq, index) => (
                  <li key={index}>{prereq}</li>
                ))}
              </ul>
            </CardContent>
          </Card>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
          Learning Paths
        </h2>
        <p className="text-gray-400">
          Guided journeys through related content, from beginner to advanced
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {learningPaths.map((path) => (
          <Card
            key={path.id}
            className="border-white/10 bg-white/5 hover:bg-white/10 transition-all cursor-pointer group"
            onClick={() => setSelectedPath(path)}
          >
            <CardHeader>
              <div className="flex items-start justify-between">
                <MapPin className="h-5 w-5 text-purple-400 mt-1" />
                {getPathProgress(path) === 100 && (
                  <Trophy className="h-5 w-5 text-yellow-500" />
                )}
              </div>
              <CardTitle className="group-hover:text-purple-400 transition-colors">
                {path.title}
              </CardTitle>
              <CardDescription>{path.description}</CardDescription>
            </CardHeader>
            
            <CardContent className="space-y-4">
              <div className="flex flex-wrap gap-2">
                <Badge variant="outline" className={difficultyColors[path.difficulty]}>
                  {path.difficulty}
                </Badge>
                <Badge variant="outline" className="bg-white/5 border-white/10">
                  <Clock className="h-3 w-3 mr-1" />
                  {path.estimatedHours}h
                </Badge>
                <Badge variant="outline" className="bg-white/5 border-white/10">
                  {path.items.length} steps
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-400">Progress</span>
                  <span className="font-semibold">{getPathProgress(path)}%</span>
                </div>
                <Progress value={getPathProgress(path)} className="h-2" />
              </div>

              <Button variant="outline" className="w-full group-hover:bg-purple-500/20">
                Start Learning
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
