'use client';

import { useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Lightbulb, Zap, Target, Shield, Rocket, Brain } from 'lucide-react';

interface QuickTipsProps {
  searchQuery: string;
}

interface Tip {
  id: string;
  title: string;
  tip: string;
  category: 'Performance' | 'Best Practice' | 'Security' | 'Productivity' | 'Architecture' | 'Learning';
  icon: 'lightbulb' | 'zap' | 'target' | 'shield' | 'rocket' | 'brain';
}

const tips: Tip[] = [
  {
    id: 't1',
    title: 'Name Things Clearly',
    tip: 'Use descriptive names for variables and functions. "getUserById" is better than "get". Your code is read far more often than it\'s written.',
    category: 'Best Practice',
    icon: 'lightbulb'
  },
  {
    id: 't2',
    title: 'Fail Fast',
    tip: 'Validate inputs and handle errors early in your functions. Return or throw immediately if something is wrong instead of nesting logic.',
    category: 'Best Practice',
    icon: 'target'
  },
  {
    id: 't3',
    title: 'Avoid Premature Optimization',
    tip: 'Make it work first, then make it fast. Profile before optimizing - don\'t guess where the bottleneck is.',
    category: 'Performance',
    icon: 'zap'
  },
  {
    id: 't4',
    title: 'Never Trust User Input',
    tip: 'Always validate and sanitize data from users, URLs, and external sources. SQL injection and XSS attacks exploit trust in user input.',
    category: 'Security',
    icon: 'shield'
  },
  {
    id: 't5',
    title: 'Keep Functions Small',
    tip: 'A function should do one thing and do it well. If you struggle to name it without using "and", it probably does too much.',
    category: 'Best Practice',
    icon: 'target'
  },
  {
    id: 't6',
    title: 'Use Version Control Properly',
    tip: 'Commit often with meaningful messages. Each commit should represent one logical change. Future you will thank present you.',
    category: 'Productivity',
    icon: 'rocket'
  },
  {
    id: 't7',
    title: 'Lazy Load Resources',
    tip: 'Don\'t load everything upfront. Images, components, and data that aren\'t immediately visible should load on demand.',
    category: 'Performance',
    icon: 'zap'
  },
  {
    id: 't8',
    title: 'DRY (Don\'t Repeat Yourself)',
    tip: 'If you\'re copying and pasting code, you probably need a function or component. But don\'t over-abstract too early.',
    category: 'Best Practice',
    icon: 'lightbulb'
  },
  {
    id: 't9',
    title: 'Environment Variables for Secrets',
    tip: 'Never hardcode API keys, passwords, or tokens. Use environment variables and never commit .env files.',
    category: 'Security',
    icon: 'shield'
  },
  {
    id: 't10',
    title: 'Learn by Building',
    tip: 'Tutorial hell is real. After learning basics, build projects without following step-by-step guides. Struggle teaches you.',
    category: 'Learning',
    icon: 'brain'
  },
  {
    id: 't11',
    title: 'Memoize Expensive Calculations',
    tip: 'Use useMemo for expensive computations and useCallback for function references in React. But only when you measure a real performance issue.',
    category: 'Performance',
    icon: 'zap'
  },
  {
    id: 't12',
    title: 'Write Self-Documenting Code',
    tip: 'Good code explains what it does through clear naming and structure. Comments should explain WHY, not WHAT.',
    category: 'Best Practice',
    icon: 'lightbulb'
  },
  {
    id: 't13',
    title: 'Separate Concerns',
    tip: 'Keep business logic separate from UI. Data fetching separate from presentation. Makes testing and maintenance easier.',
    category: 'Architecture',
    icon: 'target'
  },
  {
    id: 't14',
    title: 'Use HTTPS Everywhere',
    tip: 'Always use HTTPS in production. It\'s not just for e-commerce - every site needs encryption now.',
    category: 'Security',
    icon: 'shield'
  },
  {
    id: 't15',
    title: 'Read Error Messages',
    tip: 'Actually read the full error message before Googling. It often tells you exactly what\'s wrong and where.',
    category: 'Productivity',
    icon: 'rocket'
  },
  {
    id: 't16',
    title: 'Test Edge Cases',
    tip: 'Test with empty arrays, null values, very long strings, and negative numbers. Edge cases are where bugs hide.',
    category: 'Best Practice',
    icon: 'target'
  },
  {
    id: 't17',
    title: 'Learn to Debug',
    tip: 'console.log is fine, but learn to use browser DevTools and debugger breakpoints. They\'re much more powerful.',
    category: 'Learning',
    icon: 'brain'
  },
  {
    id: 't18',
    title: 'Cache Strategically',
    tip: 'Cache data that changes infrequently and is expensive to fetch. Set appropriate TTLs. Stale data is better than no data.',
    category: 'Performance',
    icon: 'zap'
  },
  {
    id: 't19',
    title: 'Mobile-First Design',
    tip: 'Start with mobile layout, then enhance for larger screens. It\'s easier than starting big and cramming into small.',
    category: 'Best Practice',
    icon: 'lightbulb'
  },
  {
    id: 't20',
    title: 'Rate Limit Your APIs',
    tip: 'Protect your APIs from abuse with rate limiting. Even internal APIs benefit from it.',
    category: 'Security',
    icon: 'shield'
  },
  {
    id: 't21',
    title: 'Use TypeScript',
    tip: 'TypeScript catches bugs before runtime. The initial learning curve pays off quickly in confidence and productivity.',
    category: 'Productivity',
    icon: 'rocket'
  },
  {
    id: 't22',
    title: 'Understand Before Implementing',
    tip: 'Don\'t just copy-paste Stack Overflow solutions. Understand what the code does and why it works.',
    category: 'Learning',
    icon: 'brain'
  },
  {
    id: 't23',
    title: 'Composition Over Inheritance',
    tip: 'Favor composing small, focused pieces over building complex inheritance hierarchies. More flexible and easier to reason about.',
    category: 'Architecture',
    icon: 'target'
  },
  {
    id: 't24',
    title: 'Accessibility Matters',
    tip: 'Use semantic HTML, proper ARIA labels, and keyboard navigation. A11y isn\'t optional - it makes your app better for everyone.',
    category: 'Best Practice',
    icon: 'lightbulb'
  }
];

export default function QuickTips({ searchQuery }: QuickTipsProps): JSX.Element {
  const filteredTips = useMemo(() => {
    if (!searchQuery) return tips;
    
    const query = searchQuery.toLowerCase();
    return tips.filter(tip =>
      tip.title.toLowerCase().includes(query) ||
      tip.tip.toLowerCase().includes(query) ||
      tip.category.toLowerCase().includes(query)
    );
  }, [searchQuery]);

  const getIcon = (iconName: string): JSX.Element => {
    const iconProps = { className: 'h-5 w-5' };
    switch (iconName) {
      case 'lightbulb': return <Lightbulb {...iconProps} />;
      case 'zap': return <Zap {...iconProps} />;
      case 'target': return <Target {...iconProps} />;
      case 'shield': return <Shield {...iconProps} />;
      case 'rocket': return <Rocket {...iconProps} />;
      case 'brain': return <Brain {...iconProps} />;
      default: return <Lightbulb {...iconProps} />;
    }
  };

  const getCategoryColor = (category: string): string => {
    const colors: Record<string, string> = {
      'Performance': 'bg-orange-500/20 text-orange-300 border-orange-500/30',
      'Best Practice': 'bg-blue-500/20 text-blue-300 border-blue-500/30',
      'Security': 'bg-red-500/20 text-red-300 border-red-500/30',
      'Productivity': 'bg-green-500/20 text-green-300 border-green-500/30',
      'Architecture': 'bg-purple-500/20 text-purple-300 border-purple-500/30',
      'Learning': 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30'
    };
    return colors[category] || 'bg-gray-500/20 text-gray-300 border-gray-500/30';
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-purple-100 mb-2">⚡ Quick Tips</h2>
        <p className="text-purple-300/70 text-sm">
          Bite-sized wisdom for developers at any level
        </p>
      </div>

      {filteredTips.length === 0 ? (
        <Card className="bg-purple-950/30 border-purple-500/30">
          <CardContent className="pt-6">
            <p className="text-purple-300/60 text-center">No tips found matching "{searchQuery}"</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredTips.map((tip) => (
            <Card key={tip.id} className="bg-purple-950/30 border-purple-500/30 hover:border-purple-400/50 transition-colors hover:shadow-lg hover:shadow-purple-500/10">
              <CardHeader className="pb-3">
                <div className="flex items-start gap-3">
                  <div className="text-purple-400 shrink-0 mt-1">
                    {getIcon(tip.icon)}
                  </div>
                  <div className="flex-1">
                    <CardTitle className="text-purple-100 text-base mb-2">
                      {tip.title}
                    </CardTitle>
                    <Badge className={`${getCategoryColor(tip.category)} text-xs`}>
                      {tip.category}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <p className="text-purple-300/80 text-sm leading-relaxed">
                  {tip.tip}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <div className="text-center text-purple-400/60 text-xs mt-8">
        {filteredTips.length} {filteredTips.length === 1 ? 'tip' : 'tips'} available
      </div>
    </div>
  );
}
