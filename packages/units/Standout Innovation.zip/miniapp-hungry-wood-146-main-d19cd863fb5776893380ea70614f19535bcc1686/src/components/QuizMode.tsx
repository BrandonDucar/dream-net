'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { CheckCircle2, XCircle, Trophy, RotateCcw } from 'lucide-react';
import { quizzes } from '@/lib/cookbookData';
import { useProgress } from '@/hooks/useProgress';
import type { Quiz, QuizQuestion } from '@/types/cookbook';

const difficultyColors = {
  beginner: 'bg-green-500/20 text-green-300 border-green-500/30',
  intermediate: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
  advanced: 'bg-red-500/20 text-red-300 border-red-500/30'
};

export function QuizMode() {
  const { progress, markCompleted, isCompleted } = useProgress();
  const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [score, setScore] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);

  const startQuiz = (quiz: Quiz) => {
    setSelectedQuiz(quiz);
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setAnswers([]);
  };

  const handleAnswer = (answerIndex: number) => {
    if (showExplanation) return;
    
    setSelectedAnswer(answerIndex);
    setShowExplanation(true);
    
    const isCorrect = answerIndex === selectedQuiz!.questions[currentQuestion].correctAnswer;
    if (isCorrect) {
      setScore(score + 1);
    }
    
    setAnswers([...answers, answerIndex]);
  };

  const nextQuestion = () => {
    if (currentQuestion < selectedQuiz!.questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      // Quiz completed
      if (!isCompleted('quiz', selectedQuiz!.id)) {
        markCompleted('quiz', selectedQuiz!.id);
      }
    }
  };

  const retakeQuiz = () => {
    setCurrentQuestion(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setScore(0);
    setAnswers([]);
  };

  if (selectedQuiz && currentQuestion < selectedQuiz.questions.length) {
    const question = selectedQuiz.questions[currentQuestion];
    const progressPercent = ((currentQuestion + 1) / selectedQuiz.questions.length) * 100;

    return (
      <div className="space-y-6">
        <div className="flex items-start justify-between">
          <div className="space-y-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setSelectedQuiz(null)}
              className="mb-2"
            >
              ← Back to quizzes
            </Button>
            <h2 className="text-2xl font-bold">{selectedQuiz.title}</h2>
            <Badge variant="outline" className={difficultyColors[selectedQuiz.difficulty]}>
              {selectedQuiz.difficulty}
            </Badge>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-400">
              Question {currentQuestion + 1} of {selectedQuiz.questions.length}
            </span>
            <span className="font-semibold">Score: {score}/{selectedQuiz.questions.length}</span>
          </div>
          <Progress value={progressPercent} className="h-2" />
        </div>

        <Card className="border-white/10 bg-white/5">
          <CardHeader>
            <CardTitle className="text-lg">{question.question}</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {question.options.map((option, index) => {
              const isSelected = selectedAnswer === index;
              const isCorrect = index === question.correctAnswer;
              const showResult = showExplanation;

              return (
                <button
                  key={index}
                  onClick={() => handleAnswer(index)}
                  disabled={showExplanation}
                  className={`w-full p-4 text-left rounded-lg border transition-all ${
                    showResult
                      ? isCorrect
                        ? 'bg-green-500/20 border-green-500/50'
                        : isSelected
                        ? 'bg-red-500/20 border-red-500/50'
                        : 'bg-white/5 border-white/10'
                      : isSelected
                      ? 'bg-purple-500/20 border-purple-500/50'
                      : 'bg-white/5 border-white/10 hover:bg-white/10'
                  } ${showExplanation ? 'cursor-default' : 'cursor-pointer'}`}
                >
                  <div className="flex items-center justify-between">
                    <span>{option}</span>
                    {showResult && isCorrect && <CheckCircle2 className="h-5 w-5 text-green-400" />}
                    {showResult && isSelected && !isCorrect && <XCircle className="h-5 w-5 text-red-400" />}
                  </div>
                </button>
              );
            })}

            {showExplanation && (
              <Card className="bg-blue-500/10 border-blue-500/30 mt-4">
                <CardContent className="p-4">
                  <p className="text-sm font-semibold text-blue-300 mb-2">Explanation</p>
                  <p className="text-sm text-gray-300">{question.explanation}</p>
                </CardContent>
              </Card>
            )}

            {showExplanation && (
              <Button onClick={nextQuestion} className="w-full mt-4">
                {currentQuestion < selectedQuiz.questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
              </Button>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  if (selectedQuiz && currentQuestion >= selectedQuiz.questions.length) {
    const percentage = Math.round((score / selectedQuiz.questions.length) * 100);
    const passed = percentage >= 70;

    return (
      <div className="space-y-6">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setSelectedQuiz(null)}
          className="mb-2"
        >
          ← Back to quizzes
        </Button>

        <Card className={`border-2 ${passed ? 'border-green-500/50 bg-green-500/10' : 'border-yellow-500/50 bg-yellow-500/10'}`}>
          <CardHeader className="text-center">
            {passed ? (
              <Trophy className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            ) : (
              <RotateCcw className="h-16 w-16 text-yellow-500 mx-auto mb-4" />
            )}
            <CardTitle className="text-3xl">{passed ? 'Congratulations!' : 'Keep Learning!'}</CardTitle>
            <CardDescription className="text-lg">
              You scored {score} out of {selectedQuiz.questions.length}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-center">
              <span className="text-5xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                {percentage}%
              </span>
            </div>

            <Progress value={percentage} className="h-3" />

            <div className="flex gap-4">
              <Button onClick={retakeQuiz} variant="outline" className="flex-1">
                <RotateCcw className="h-4 w-4 mr-2" />
                Retake Quiz
              </Button>
              <Button onClick={() => setSelectedQuiz(null)} className="flex-1">
                Back to Quizzes
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <h2 className="text-3xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
          Quiz Mode
        </h2>
        <p className="text-gray-400">
          Test your knowledge and track your progress
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {quizzes.map((quiz) => {
          const completed = isCompleted('quiz', quiz.id);
          
          return (
            <Card
              key={quiz.id}
              className={`border-white/10 ${
                completed ? 'bg-green-500/10 border-green-500/30' : 'bg-white/5'
              } hover:bg-white/10 transition-all cursor-pointer group`}
              onClick={() => startQuiz(quiz)}
            >
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <CardTitle className="group-hover:text-purple-400 transition-colors">
                      {quiz.title}
                    </CardTitle>
                    <CardDescription className="mt-2">
                      {quiz.questions.length} questions
                    </CardDescription>
                  </div>
                  {completed && <Trophy className="h-5 w-5 text-yellow-500" />}
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge variant="outline" className={difficultyColors[quiz.difficulty]}>
                    {quiz.difficulty}
                  </Badge>
                  <Badge variant="outline" className="bg-white/5 border-white/10">
                    {quiz.category}
                  </Badge>
                </div>

                <Button variant="outline" className="w-full group-hover:bg-purple-500/20">
                  {completed ? 'Retake Quiz' : 'Start Quiz'}
                </Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
