'use client';

import { useMemo } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';

interface RecipeCardsProps {
  searchQuery: string;
}

interface Recipe {
  id: string;
  title: string;
  problem: string;
  solution: string;
  tags: string[];
  difficulty: string;
  steps: string[];
  considerations: string[];
}

const recipes: Recipe[] = [
  {
    id: 'r1',
    title: 'Debounce Search Input',
    problem: 'Making an API call on every keystroke causes performance issues and rate limiting',
    solution: 'Implement debouncing to delay API calls until user stops typing',
    tags: ['Performance', 'React', 'UX'],
    difficulty: 'Easy',
    steps: [
      'Import useEffect and useState hooks',
      'Create state for input value and debounced value',
      'Set up useEffect with cleanup to handle debounce',
      'Use debounced value for API calls'
    ],
    considerations: [
      'Choose appropriate delay (300-500ms typical)',
      'Clean up timeout on component unmount',
      'Show loading indicator during debounce'
    ]
  },
  {
    id: 'r2',
    title: 'Environment Variable Management',
    problem: 'Hardcoding API keys and secrets in code is insecure',
    solution: 'Use environment variables with proper naming conventions',
    tags: ['Security', 'DevOps', 'Best Practice'],
    difficulty: 'Easy',
    steps: [
      'Create .env file in project root',
      'Prefix public vars with NEXT_PUBLIC_ (Next.js)',
      'Add .env to .gitignore',
      'Access via process.env.VARIABLE_NAME',
      'Document required variables in README'
    ],
    considerations: [
      'Never commit .env files',
      'Use different .env files for dev/staging/prod',
      'Validate env vars on app startup'
    ]
  },
  {
    id: 'r3',
    title: 'Optimistic UI Updates',
    problem: 'Waiting for server response makes UI feel slow',
    solution: 'Update UI immediately, then sync with server',
    tags: ['UX', 'Performance', 'State Management'],
    difficulty: 'Medium',
    steps: [
      'Update local state immediately on user action',
      'Send request to server in background',
      'If request succeeds, keep the optimistic update',
      'If request fails, revert to previous state and show error'
    ],
    considerations: [
      'Always handle failure cases gracefully',
      'Show subtle indicators for pending changes',
      'Consider conflict resolution for concurrent updates'
    ]
  },
  {
    id: 'r4',
    title: 'Pagination vs Infinite Scroll',
    problem: 'Need to display large datasets efficiently',
    solution: 'Choose based on use case and user behavior',
    tags: ['UX', 'Performance', 'Design'],
    difficulty: 'Medium',
    steps: [
      'For goal-oriented browsing: use pagination',
      'For casual exploration: use infinite scroll',
      'Implement virtual scrolling for very large lists',
      'Add "Load More" button as hybrid approach'
    ],
    considerations: [
      'Pagination: better SEO, user control, navigation',
      'Infinite scroll: better for mobile, discovery',
      'Consider accessibility implications'
    ]
  },
  {
    id: 'r5',
    title: 'Error Boundary Implementation',
    problem: 'JavaScript errors crash entire React app',
    solution: 'Use Error Boundaries to catch and handle errors gracefully',
    tags: ['React', 'Error Handling', 'Resilience'],
    difficulty: 'Easy',
    steps: [
      'Create ErrorBoundary component class',
      'Implement componentDidCatch lifecycle method',
      'Implement static getDerivedStateFromError',
      'Wrap components that might error',
      'Show fallback UI when errors occur'
    ],
    considerations: [
      'Log errors to monitoring service',
      'Provide clear error messages to users',
      'Consider granular vs global error boundaries'
    ]
  },
  {
    id: 'r6',
    title: 'API Response Caching',
    problem: 'Repeated identical API calls waste bandwidth and slow down app',
    solution: 'Implement caching strategy with expiration',
    tags: ['Performance', 'Optimization', 'Backend'],
    difficulty: 'Medium',
    steps: [
      'Choose cache storage (memory, localStorage, Redis)',
      'Create cache key from request parameters',
      'Check cache before making request',
      'Set TTL (time-to-live) for cached data',
      'Implement cache invalidation strategy'
    ],
    considerations: [
      'Balance freshness vs performance',
      'Handle cache size limits',
      'Consider cache warming for critical data'
    ]
  },
  {
    id: 'r7',
    title: 'Form Validation Pattern',
    problem: 'Forms need consistent validation across fields',
    solution: 'Use validation library with schema definition',
    tags: ['Forms', 'Validation', 'UX'],
    difficulty: 'Easy',
    steps: [
      'Define validation schema (e.g., with Zod)',
      'Connect schema to form library (e.g., React Hook Form)',
      'Show errors inline near fields',
      'Validate on blur and submit',
      'Disable submit button during validation'
    ],
    considerations: [
      'Validate on client AND server',
      'Provide clear, helpful error messages',
      'Consider accessibility for error announcements'
    ]
  },
  {
    id: 'r8',
    title: 'Loading State Management',
    problem: 'Users don\'t know when async operations are in progress',
    solution: 'Implement consistent loading indicators',
    tags: ['UX', 'State Management', 'Feedback'],
    difficulty: 'Easy',
    steps: [
      'Create loading state boolean',
      'Set loading to true before async operation',
      'Set loading to false after completion/error',
      'Show appropriate loading UI (spinner, skeleton)',
      'Disable actions during loading'
    ],
    considerations: [
      'Use skeleton screens for better perceived performance',
      'Avoid blocking entire UI if possible',
      'Show progress for long operations'
    ]
  }
];

export default function RecipeCards({ searchQuery }: RecipeCardsProps): JSX.Element {
  const filteredRecipes = useMemo(() => {
    if (!searchQuery) return recipes;
    
    const query = searchQuery.toLowerCase();
    return recipes.filter(recipe =>
      recipe.title.toLowerCase().includes(query) ||
      recipe.problem.toLowerCase().includes(query) ||
      recipe.solution.toLowerCase().includes(query) ||
      recipe.tags.some(t => t.toLowerCase().includes(query))
    );
  }, [searchQuery]);

  const getDifficultyColor = (difficulty: string): string => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-500/20 text-green-300 border-green-500/30';
      case 'Medium': return 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30';
      case 'Hard': return 'bg-red-500/20 text-red-300 border-red-500/30';
      default: return 'bg-gray-500/20 text-gray-300 border-gray-500/30';
    }
  };

  return (
    <div className="space-y-4">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-purple-100 mb-2">🍳 Recipe Cards</h2>
        <p className="text-purple-300/70 text-sm">
          Practical solutions to common development problems
        </p>
      </div>

      {filteredRecipes.length === 0 ? (
        <Card className="bg-purple-950/30 border-purple-500/30">
          <CardContent className="pt-6">
            <p className="text-purple-300/60 text-center">No recipes found matching "{searchQuery}"</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredRecipes.map((recipe) => (
            <Card key={recipe.id} className="bg-purple-950/30 border-purple-500/30 hover:border-purple-400/50 transition-colors">
              <CardHeader>
                <div className="flex items-start justify-between gap-2 mb-2">
                  <CardTitle className="text-purple-100 text-lg">{recipe.title}</CardTitle>
                  <Badge className={`${getDifficultyColor(recipe.difficulty)} text-xs shrink-0`}>
                    {recipe.difficulty}
                  </Badge>
                </div>
                <CardDescription className="space-y-2">
                  <div className="flex flex-wrap gap-1">
                    {recipe.tags.map((tag, idx) => (
                      <Badge key={idx} variant="outline" className="text-xs border-purple-400/30 text-purple-300">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ScrollArea className="h-[300px] pr-4">
                  <div className="space-y-4">
                    <div>
                      <h4 className="text-sm font-semibold text-red-300 mb-1">❌ Problem</h4>
                      <p className="text-purple-300/80 text-sm">{recipe.problem}</p>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-green-300 mb-1">✓ Solution</h4>
                      <p className="text-purple-300/80 text-sm">{recipe.solution}</p>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-cyan-300 mb-2">Steps</h4>
                      <ol className="space-y-1 text-purple-300/80 text-sm">
                        {recipe.steps.map((step, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="text-cyan-400 mr-2 font-mono">{idx + 1}.</span>
                            {step}
                          </li>
                        ))}
                      </ol>
                    </div>

                    <div>
                      <h4 className="text-sm font-semibold text-yellow-300 mb-2">⚠️ Considerations</h4>
                      <ul className="space-y-1 text-purple-300/80 text-sm">
                        {recipe.considerations.map((consideration, idx) => (
                          <li key={idx} className="flex items-start">
                            <span className="text-yellow-400 mr-2">•</span>
                            {consideration}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </ScrollArea>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
