'use client';

import { useState, useEffect } from 'react';
import type { UserProgress, Collection } from '@/types/cookbook';

const STORAGE_KEY = 'dreamdev-cookbook-progress';

const defaultProgress: UserProgress = {
  completedRecipes: [],
  completedKnowledge: [],
  completedQuizzes: [],
  favorites: [],
  collections: [],
  pathProgress: {}
};

export function useProgress() {
  const [progress, setProgress] = useState<UserProgress>(defaultProgress);
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      try {
        setProgress(JSON.parse(stored));
      } catch (error) {
        console.error('Failed to parse progress:', error);
      }
    }
    setIsLoaded(true);
  }, []);

  const saveProgress = (newProgress: UserProgress) => {
    setProgress(newProgress);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newProgress));
  };

  const markCompleted = (type: 'recipe' | 'knowledge' | 'quiz', id: string) => {
    const key = `completed${type.charAt(0).toUpperCase() + type.slice(1)}s` as keyof Pick<
      UserProgress,
      'completedRecipes' | 'completedKnowledge' | 'completedQuizzes'
    >;
    const newProgress = {
      ...progress,
      [key]: [...progress[key], id]
    };
    saveProgress(newProgress);
  };

  const toggleFavorite = (id: string) => {
    const newFavorites = progress.favorites.includes(id)
      ? progress.favorites.filter((fav) => fav !== id)
      : [...progress.favorites, id];
    saveProgress({ ...progress, favorites: newFavorites });
  };

  const createCollection = (name: string, description: string): Collection => {
    const newCollection: Collection = {
      id: `collection-${Date.now()}`,
      name,
      description,
      items: [],
      createdAt: Date.now()
    };
    saveProgress({
      ...progress,
      collections: [...progress.collections, newCollection]
    });
    return newCollection;
  };

  const addToCollection = (
    collectionId: string,
    type: 'recipe' | 'knowledge' | 'shard',
    id: string
  ) => {
    const newCollections = progress.collections.map((col) =>
      col.id === collectionId
        ? { ...col, items: [...col.items, { type, id }] }
        : col
    );
    saveProgress({ ...progress, collections: newCollections });
  };

  const removeFromCollection = (collectionId: string, itemId: string) => {
    const newCollections = progress.collections.map((col) =>
      col.id === collectionId
        ? { ...col, items: col.items.filter((item) => item.id !== itemId) }
        : col
    );
    saveProgress({ ...progress, collections: newCollections });
  };

  const deleteCollection = (collectionId: string) => {
    const newCollections = progress.collections.filter((col) => col.id !== collectionId);
    saveProgress({ ...progress, collections: newCollections });
  };

  const updatePathProgress = (pathId: string, itemsCompleted: number) => {
    saveProgress({
      ...progress,
      pathProgress: { ...progress.pathProgress, [pathId]: itemsCompleted }
    });
  };

  const isCompleted = (type: 'recipe' | 'knowledge' | 'quiz', id: string): boolean => {
    const key = `completed${type.charAt(0).toUpperCase() + type.slice(1)}s` as keyof Pick<
      UserProgress,
      'completedRecipes' | 'completedKnowledge' | 'completedQuizzes'
    >;
    return progress[key].includes(id);
  };

  const isFavorited = (id: string): boolean => {
    return progress.favorites.includes(id);
  };

  return {
    progress,
    isLoaded,
    markCompleted,
    toggleFavorite,
    createCollection,
    addToCollection,
    removeFromCollection,
    deleteCollection,
    updatePathProgress,
    isCompleted,
    isFavorited
  };
}
