import type { Recipe, KnowledgePack, CodeShard, GlossaryTerm, LearningPath, Quiz } from '@/types/cookbook';

export const recipes: Recipe[] = [
  {
    id: 'recipe-debounce',
    title: 'Implementing Debounce for Search',
    description: 'Optimize search performance by delaying API calls until user stops typing',
    category: 'performance',
    difficulty: 'intermediate',
    timeEstimate: '10 min',
    prerequisites: ['React hooks', 'TypeScript basics'],
    tags: ['optimization', 'hooks', 'search', 'performance'],
    examples: [
      {
        language: 'typescript',
        code: `import { useState, useEffect } from 'react';

export function useDebounce<T>(value: T, delay: number = 500): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);

    return () => clearTimeout(handler);
  }, [value, delay]);

  return debouncedValue;
}

// Usage in component
function SearchComponent() {
  const [search, setSearch] = useState('');
  const debouncedSearch = useDebounce(search, 500);

  useEffect(() => {
    if (debouncedSearch) {
      // API call here
      fetch(\`/api/search?q=\${debouncedSearch}\`);
    }
  }, [debouncedSearch]);

  return <input onChange={(e) => setSearch(e.target.value)} />;
}`,
        filename: 'useDebounce.ts'
      },
      {
        language: 'python',
        code: `import time
from functools import wraps

def debounce(wait):
    def decorator(func):
        last_called = [0]
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            current_time = time.time()
            if current_time - last_called[0] >= wait:
                last_called[0] = current_time
                return func(*args, **kwargs)
        return wrapper
    return decorator

@debounce(wait=0.5)
def search_api(query):
    # API call here
    print(f"Searching for: {query}")`,
        filename: 'debounce.py'
      }
    ],
    explanation: 'Debouncing delays function execution until after a specified time has elapsed since the last invocation. This prevents excessive API calls during rapid user input, saving bandwidth and improving performance.',
    useCases: [
      'Search bars with auto-complete',
      'Form validation on keystroke',
      'Window resize handlers',
      'Scroll event listeners'
    ],
    relatedIds: ['recipe-throttle', 'knowledge-performance'],
    votes: 245,
    saves: 189
  },
  {
    id: 'recipe-throttle',
    title: 'Throttling Event Handlers',
    description: 'Limit function execution rate for scroll, resize, and high-frequency events',
    category: 'performance',
    difficulty: 'intermediate',
    timeEstimate: '8 min',
    prerequisites: ['JavaScript timing', 'Event handlers'],
    tags: ['optimization', 'events', 'performance'],
    examples: [
      {
        language: 'typescript',
        code: `export function throttle<T extends (...args: any[]) => any>(
  func: T,
  limit: number
): (...args: Parameters<T>) => void {
  let inThrottle: boolean;
  
  return function(this: any, ...args: Parameters<T>) {
    if (!inThrottle) {
      func.apply(this, args);
      inThrottle = true;
      setTimeout(() => inThrottle = false, limit);
    }
  };
}

// Usage
const handleScroll = throttle(() => {
  console.log('Scroll position:', window.scrollY);
}, 100);

window.addEventListener('scroll', handleScroll);`,
        filename: 'throttle.ts'
      },
      {
        language: 'python',
        code: `import time
from functools import wraps

def throttle(interval):
    def decorator(func):
        last_time = [0]
        
        @wraps(func)
        def wrapper(*args, **kwargs):
            current = time.time()
            if current - last_time[0] >= interval:
                last_time[0] = current
                return func(*args, **kwargs)
        return wrapper
    return decorator`,
        filename: 'throttle.py'
      }
    ],
    explanation: 'Throttling ensures a function executes at most once per specified time period, regardless of how many times the event fires. Unlike debounce which waits for inactivity, throttle maintains a steady execution rate.',
    useCases: [
      'Scroll event handlers',
      'Window resize listeners',
      'Button click prevention',
      'Game loop controls'
    ],
    relatedIds: ['recipe-debounce', 'knowledge-performance'],
    votes: 198,
    saves: 156
  },
  {
    id: 'recipe-form-validation',
    title: 'Type-Safe Form Validation with Zod',
    description: 'Build robust form validation with runtime type checking',
    category: 'patterns',
    difficulty: 'intermediate',
    timeEstimate: '15 min',
    prerequisites: ['React', 'TypeScript', 'Zod library'],
    tags: ['forms', 'validation', 'type-safety', 'zod'],
    examples: [
      {
        language: 'typescript',
        code: `import { z } from 'zod';
import { useState } from 'react';

const userSchema = z.object({
  email: z.string().email('Invalid email'),
  password: z.string().min(8, 'Password must be 8+ characters'),
  age: z.number().min(13, 'Must be 13 or older'),
});

type UserForm = z.infer<typeof userSchema>;

export function SignupForm() {
  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    
    const data = {
      email: formData.get('email') as string,
      password: formData.get('password') as string,
      age: Number(formData.get('age')),
    };

    const result = userSchema.safeParse(data);
    
    if (!result.success) {
      const fieldErrors: Record<string, string> = {};
      result.error.issues.forEach((issue) => {
        fieldErrors[issue.path[0]] = issue.message;
      });
      setErrors(fieldErrors);
      return;
    }

    // Submit validated data
    console.log('Valid data:', result.data);
  };

  return (
    <form onSubmit={handleSubmit}>
      <input name="email" />
      {errors.email && <span>{errors.email}</span>}
      <input name="password" type="password" />
      {errors.password && <span>{errors.password}</span>}
      <input name="age" type="number" />
      {errors.age && <span>{errors.age}</span>}
      <button type="submit">Submit</button>
    </form>
  );
}`,
        filename: 'SignupForm.tsx'
      }
    ],
    explanation: 'Zod provides runtime validation with TypeScript type inference, catching errors before they reach your API. The schema serves as both validator and type definition.',
    useCases: [
      'User registration forms',
      'API request validation',
      'Configuration file parsing',
      'Environment variable validation'
    ],
    relatedIds: ['knowledge-type-safety', 'recipe-error-handling'],
    votes: 312,
    saves: 278
  },
  {
    id: 'recipe-error-boundary',
    title: 'React Error Boundaries',
    description: 'Gracefully handle component errors without crashing the entire app',
    category: 'react',
    difficulty: 'intermediate',
    timeEstimate: '12 min',
    prerequisites: ['React class components', 'Error handling'],
    tags: ['error-handling', 'react', 'reliability'],
    examples: [
      {
        language: 'typescript',
        code: `import React, { Component, ReactNode } from 'react';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('Error caught:', error, errorInfo);
    // Log to error reporting service
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="p-4 bg-red-50 rounded">
          <h2 className="text-red-800">Something went wrong</h2>
          <details className="mt-2">
            <summary>Error details</summary>
            <pre className="text-sm">{this.state.error?.message}</pre>
          </details>
        </div>
      );
    }

    return this.props.children;
  }
}

// Usage
<ErrorBoundary fallback={<CustomErrorUI />}>
  <MyComponent />
</ErrorBoundary>`,
        filename: 'ErrorBoundary.tsx'
      }
    ],
    explanation: 'Error boundaries catch JavaScript errors in child components, log them, and display fallback UI instead of crashing. They work like try/catch for React component trees.',
    useCases: [
      'Wrapping third-party components',
      'Isolating risky features',
      'Production error recovery',
      'Preventing full app crashes'
    ],
    relatedIds: ['recipe-error-handling', 'knowledge-react'],
    votes: 267,
    saves: 221
  },
  {
    id: 'recipe-error-handling',
    title: 'Centralized API Error Handling',
    description: 'Create a unified approach to handling API errors across your app',
    category: 'backend',
    difficulty: 'intermediate',
    timeEstimate: '15 min',
    prerequisites: ['TypeScript', 'Fetch API', 'Error handling'],
    tags: ['api', 'error-handling', 'architecture'],
    examples: [
      {
        language: 'typescript',
        code: `export class ApiError extends Error {
  constructor(
    message: string,
    public statusCode: number,
    public code?: string
  ) {
    super(message);
    this.name = 'ApiError';
  }
}

export async function fetchApi<T>(
  url: string,
  options?: RequestInit
): Promise<T> {
  try {
    const response = await fetch(url, options);

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new ApiError(
        error.message || 'Request failed',
        response.status,
        error.code
      );
    }

    return await response.json();
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError('Network error', 0);
  }
}

// Usage with error handling
try {
  const data = await fetchApi<User>('/api/users/1');
  console.log(data);
} catch (error) {
  if (error instanceof ApiError) {
    if (error.statusCode === 404) {
      console.log('User not found');
    } else if (error.statusCode === 401) {
      // Redirect to login
    }
  }
}`,
        filename: 'apiClient.ts'
      }
    ],
    explanation: 'Centralized error handling creates consistent error management across your app, making debugging easier and improving user experience with meaningful error messages.',
    useCases: [
      'API client libraries',
      'Error logging services',
      'User feedback systems',
      'Retry logic implementation'
    ],
    relatedIds: ['recipe-error-boundary', 'knowledge-backend'],
    votes: 289,
    saves: 234
  },
  {
    id: 'recipe-cache-api',
    title: 'Simple In-Memory API Cache',
    description: 'Reduce redundant API calls with client-side caching',
    category: 'performance',
    difficulty: 'intermediate',
    timeEstimate: '10 min',
    prerequisites: ['JavaScript Maps', 'Async/await'],
    tags: ['caching', 'performance', 'api'],
    examples: [
      {
        language: 'typescript',
        code: `interface CacheEntry<T> {
  data: T;
  timestamp: number;
}

export class ApiCache {
  private cache = new Map<string, CacheEntry<any>>();
  private ttl: number;

  constructor(ttlSeconds: number = 300) {
    this.ttl = ttlSeconds * 1000;
  }

  async fetch<T>(
    key: string,
    fetcher: () => Promise<T>
  ): Promise<T> {
    const cached = this.cache.get(key);
    const now = Date.now();

    if (cached && now - cached.timestamp < this.ttl) {
      return cached.data;
    }

    const data = await fetcher();
    this.cache.set(key, { data, timestamp: now });
    return data;
  }

  invalidate(key: string): void {
    this.cache.delete(key);
  }

  clear(): void {
    this.cache.clear();
  }
}

// Usage
const cache = new ApiCache(300); // 5 minutes

const user = await cache.fetch('user:1', () =>
  fetch('/api/users/1').then(r => r.json())
);`,
        filename: 'apiCache.ts'
      }
    ],
    explanation: 'Client-side caching stores API responses temporarily, reducing server load and improving app responsiveness by avoiding redundant network requests.',
    useCases: [
      'User profile data',
      'Static reference data',
      'Search results',
      'Dashboard statistics'
    ],
    relatedIds: ['recipe-debounce', 'knowledge-performance'],
    votes: 223,
    saves: 198
  }
];

export const knowledgePacks: KnowledgePack[] = [
  {
    id: 'knowledge-react',
    title: 'React Component Patterns',
    description: 'Master modern React patterns for building scalable applications',
    category: 'react',
    difficulty: 'intermediate',
    timeEstimate: '30 min',
    prerequisites: ['React basics', 'Hooks fundamentals'],
    tags: ['react', 'patterns', 'components', 'best-practices'],
    content: [
      'Compound Components: Create flexible, composable component APIs',
      'Render Props: Share code between components using props',
      'Higher-Order Components: Wrap components with additional functionality',
      'Custom Hooks: Extract and reuse stateful logic',
      'Context + Reducer: Manage complex state without external libraries'
    ],
    examples: [
      {
        language: 'typescript',
        code: `// Compound Component Pattern
interface TabsContextType {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const TabsContext = React.createContext<TabsContextType | null>(null);

export function Tabs({ children }: { children: React.ReactNode }) {
  const [activeTab, setActiveTab] = useState('tab1');
  return (
    <TabsContext.Provider value={{ activeTab, setActiveTab }}>
      {children}
    </TabsContext.Provider>
  );
}

Tabs.List = function TabsList({ children }: { children: React.ReactNode }) {
  return <div className="flex gap-2">{children}</div>;
};

Tabs.Tab = function Tab({ id, children }: { id: string; children: React.ReactNode }) {
  const context = React.useContext(TabsContext);
  return (
    <button
      onClick={() => context?.setActiveTab(id)}
      className={context?.activeTab === id ? 'active' : ''}
    >
      {children}
    </button>
  );
};

Tabs.Panel = function Panel({ id, children }: { id: string; children: React.ReactNode }) {
  const context = React.useContext(TabsContext);
  if (context?.activeTab !== id) return null;
  return <div>{children}</div>;
};

// Usage
<Tabs>
  <Tabs.List>
    <Tabs.Tab id="tab1">First</Tabs.Tab>
    <Tabs.Tab id="tab2">Second</Tabs.Tab>
  </Tabs.List>
  <Tabs.Panel id="tab1">Content 1</Tabs.Panel>
  <Tabs.Panel id="tab2">Content 2</Tabs.Panel>
</Tabs>`,
        filename: 'Tabs.tsx'
      }
    ],
    keyTakeaways: [
      'Compound components create flexible, intuitive APIs',
      'Custom hooks extract reusable logic',
      'Context avoids prop drilling for shared state',
      'Patterns solve common architectural challenges'
    ],
    relatedIds: ['recipe-error-boundary', 'knowledge-type-safety'],
    votes: 445
  },
  {
    id: 'knowledge-performance',
    title: 'Web Performance Optimization',
    description: 'Techniques to make your web applications blazingly fast',
    category: 'performance',
    difficulty: 'intermediate',
    timeEstimate: '45 min',
    prerequisites: ['JavaScript', 'Browser APIs', 'Network basics'],
    tags: ['performance', 'optimization', 'web-vitals'],
    content: [
      'Code Splitting: Load only what users need, when they need it',
      'Image Optimization: Serve correctly sized, modern format images',
      'Lazy Loading: Defer loading of off-screen content',
      'Caching Strategies: Use browser and CDN caching effectively',
      'Debouncing & Throttling: Control expensive operation frequency',
      'Virtual Scrolling: Render only visible list items',
      'Web Workers: Offload heavy computations from main thread',
      'Resource Hints: Preload, prefetch, and preconnect strategically'
    ],
    examples: [
      {
        language: 'typescript',
        code: `// Virtual Scrolling Example
import { useState, useRef, useEffect } from 'react';

interface VirtualListProps<T> {
  items: T[];
  itemHeight: number;
  containerHeight: number;
  renderItem: (item: T, index: number) => React.ReactNode;
}

export function VirtualList<T>({
  items,
  itemHeight,
  containerHeight,
  renderItem
}: VirtualListProps<T>) {
  const [scrollTop, setScrollTop] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const startIndex = Math.floor(scrollTop / itemHeight);
  const endIndex = Math.min(
    startIndex + Math.ceil(containerHeight / itemHeight) + 1,
    items.length
  );

  const visibleItems = items.slice(startIndex, endIndex);
  const offsetY = startIndex * itemHeight;

  return (
    <div
      ref={containerRef}
      style={{ height: containerHeight, overflow: 'auto' }}
      onScroll={(e) => setScrollTop(e.currentTarget.scrollTop)}
    >
      <div style={{ height: items.length * itemHeight, position: 'relative' }}>
        <div style={{ transform: \`translateY(\${offsetY}px)\` }}>
          {visibleItems.map((item, i) => (
            <div key={startIndex + i} style={{ height: itemHeight }}>
              {renderItem(item, startIndex + i)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}`,
        filename: 'VirtualList.tsx'
      }
    ],
    keyTakeaways: [
      'Measure before optimizing - use real metrics',
      'Small improvements compound for better UX',
      'Balance performance with code maintainability',
      'Consider mobile and slow network scenarios'
    ],
    relatedIds: ['recipe-debounce', 'recipe-throttle', 'recipe-cache-api'],
    votes: 512
  },
  {
    id: 'knowledge-type-safety',
    title: 'TypeScript Type Safety Patterns',
    description: 'Leverage TypeScript for bulletproof code reliability',
    category: 'patterns',
    difficulty: 'advanced',
    timeEstimate: '40 min',
    prerequisites: ['TypeScript fundamentals', 'Generics'],
    tags: ['typescript', 'type-safety', 'patterns'],
    content: [
      'Discriminated Unions: Model state machines safely',
      'Branded Types: Prevent primitive type confusion',
      'Type Guards: Narrow types at runtime',
      'Utility Types: Transform types with Pick, Omit, Partial',
      'Template Literal Types: Create string patterns',
      'Conditional Types: Type-level logic',
      'Const Assertions: Maximum type narrowing'
    ],
    examples: [
      {
        language: 'typescript',
        code: `// Discriminated Union for API states
type ApiState<T> =
  | { status: 'idle' }
  | { status: 'loading' }
  | { status: 'success'; data: T }
  | { status: 'error'; error: string };

function handleState<T>(state: ApiState<T>) {
  switch (state.status) {
    case 'idle':
      return <div>Ready to load</div>;
    case 'loading':
      return <div>Loading...</div>;
    case 'success':
      return <div>Data: {JSON.stringify(state.data)}</div>;
    case 'error':
      return <div>Error: {state.error}</div>;
  }
}

// Branded Types
type UserId = string & { readonly brand: unique symbol };
type ProductId = string & { readonly brand: unique symbol };

function getUserId(id: string): UserId {
  return id as UserId;
}

function getUser(id: UserId) {
  // Can only accept UserId, not plain string
}

const userId = getUserId('123');
const productId = 'abc'; // plain string

getUser(userId); // ✅ OK
// getUser(productId); // ❌ Type error

// Template Literal Types
type HTTPMethod = 'GET' | 'POST' | 'PUT' | 'DELETE';
type Endpoint = '/users' | '/products' | '/orders';
type ApiRoute = \`\${HTTPMethod} \${Endpoint}\`;

const route: ApiRoute = 'GET /users'; // ✅
// const invalid: ApiRoute = 'GET /invalid'; // ❌`,
        filename: 'typePatterns.ts'
      }
    ],
    keyTakeaways: [
      'Type safety catches bugs at compile time',
      'Discriminated unions model state machines perfectly',
      'Branded types prevent primitive type confusion',
      'TypeScript types can encode business logic'
    ],
    relatedIds: ['recipe-form-validation', 'knowledge-react'],
    votes: 378
  }
];

export const codeShards: CodeShard[] = [
  {
    id: 'shard-use-local-storage',
    title: 'useLocalStorage Hook',
    description: 'Sync React state with localStorage automatically',
    category: 'react',
    tags: ['hooks', 'storage', 'state-management'],
    examples: [
      {
        language: 'typescript',
        code: `import { useState, useEffect } from 'react';

export function useLocalStorage<T>(
  key: string,
  initialValue: T
): [T, (value: T | ((val: T) => T)) => void] {
  const [storedValue, setStoredValue] = useState<T>(() => {
    if (typeof window === 'undefined') return initialValue;
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });

  const setValue = (value: T | ((val: T) => T)) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      if (typeof window !== 'undefined') {
        window.localStorage.setItem(key, JSON.stringify(valueToStore));
      }
    } catch (error) {
      console.error(error);
    }
  };

  return [storedValue, setValue];
}

// Usage
const [theme, setTheme] = useLocalStorage('theme', 'dark');`,
        filename: 'useLocalStorage.ts'
      }
    ],
    useCases: [
      'Theme preferences',
      'User settings',
      'Shopping cart data',
      'Form draft saving'
    ],
    relatedIds: ['shard-use-media-query', 'knowledge-react'],
    votes: 334,
    saves: 289
  },
  {
    id: 'shard-use-media-query',
    title: 'useMediaQuery Hook',
    description: 'React hook for responsive design with CSS media queries',
    category: 'react',
    tags: ['hooks', 'responsive', 'ui'],
    examples: [
      {
        language: 'typescript',
        code: `import { useState, useEffect } from 'react';

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState(false);

  useEffect(() => {
    const media = window.matchMedia(query);
    
    if (media.matches !== matches) {
      setMatches(media.matches);
    }

    const listener = (e: MediaQueryListEvent) => setMatches(e.matches);
    media.addEventListener('change', listener);
    
    return () => media.removeEventListener('change', listener);
  }, [matches, query]);

  return matches;
}

// Usage
const isMobile = useMediaQuery('(max-width: 768px)');
const prefersLight = useMediaQuery('(prefers-color-scheme: light)');`,
        filename: 'useMediaQuery.ts'
      }
    ],
    useCases: [
      'Responsive layouts',
      'Mobile vs desktop UI',
      'Dark mode detection',
      'Accessibility features'
    ],
    relatedIds: ['shard-use-local-storage', 'knowledge-react'],
    votes: 298,
    saves: 256
  },
  {
    id: 'shard-retry-fetch',
    title: 'Retry Fetch with Exponential Backoff',
    description: 'Automatically retry failed requests with increasing delays',
    category: 'backend',
    tags: ['api', 'reliability', 'networking'],
    examples: [
      {
        language: 'typescript',
        code: `export async function retryFetch<T>(
  url: string,
  options: RequestInit = {},
  maxRetries: number = 3,
  baseDelay: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(url, options);
      
      if (!response.ok) {
        throw new Error(\`HTTP \${response.status}: \${response.statusText}\`);
      }
      
      return await response.json();
    } catch (error) {
      lastError = error as Error;
      
      if (attempt === maxRetries) break;
      
      // Exponential backoff: 1s, 2s, 4s, 8s...
      const delay = baseDelay * Math.pow(2, attempt);
      const jitter = Math.random() * 200; // Add randomness
      
      await new Promise(resolve => setTimeout(resolve, delay + jitter));
    }
  }

  throw lastError!;
}

// Usage
const data = await retryFetch<User>('/api/users/1', {}, 3, 1000);`,
        filename: 'retryFetch.ts'
      }
    ],
    useCases: [
      'Flaky API calls',
      'Network reliability',
      'Third-party integrations',
      'Mobile apps with spotty connections'
    ],
    relatedIds: ['recipe-error-handling', 'shard-circuit-breaker'],
    votes: 267,
    saves: 223
  },
  {
    id: 'shard-circuit-breaker',
    title: 'Circuit Breaker Pattern',
    description: 'Prevent cascading failures by stopping requests to failing services',
    category: 'backend',
    tags: ['reliability', 'patterns', 'api'],
    examples: [
      {
        language: 'typescript',
        code: `type CircuitState = 'closed' | 'open' | 'half-open';

export class CircuitBreaker {
  private state: CircuitState = 'closed';
  private failureCount: number = 0;
  private lastFailTime: number = 0;
  private successCount: number = 0;

  constructor(
    private threshold: number = 5,
    private timeout: number = 60000,
    private resetCount: number = 2
  ) {}

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === 'open') {
      if (Date.now() - this.lastFailTime >= this.timeout) {
        this.state = 'half-open';
        this.successCount = 0;
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    
    if (this.state === 'half-open') {
      this.successCount++;
      if (this.successCount >= this.resetCount) {
        this.state = 'closed';
      }
    }
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailTime = Date.now();
    
    if (this.failureCount >= this.threshold) {
      this.state = 'open';
    }
  }

  getState(): CircuitState {
    return this.state;
  }
}

// Usage
const breaker = new CircuitBreaker(5, 60000, 2);

try {
  const data = await breaker.execute(() =>
    fetch('/api/unstable-service').then(r => r.json())
  );
} catch (error) {
  console.log('Service unavailable');
}`,
        filename: 'circuitBreaker.ts'
      }
    ],
    useCases: [
      'Microservice communication',
      'External API calls',
      'Database connections',
      'Payment processing'
    ],
    relatedIds: ['shard-retry-fetch', 'recipe-error-handling'],
    votes: 189,
    saves: 167
  }
];

export const glossaryTerms: GlossaryTerm[] = [
  {
    id: 'term-closure',
    term: 'Closure',
    definition: 'A function that captures and remembers variables from its outer scope, even after the outer function has finished executing.',
    category: 'patterns',
    examples: [
      'const makeCounter = () => { let count = 0; return () => ++count; }',
      'Event handlers that access component state',
      'Private variables in JavaScript modules'
    ],
    relatedTerms: ['Scope', 'Higher-Order Function', 'Lexical Environment'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-hoisting',
    term: 'Hoisting',
    definition: 'JavaScript\'s behavior of moving variable and function declarations to the top of their scope during compilation, before code execution.',
    category: 'patterns',
    examples: [
      'console.log(x); var x = 5; // undefined (not error)',
      'greeting(); function greeting() { console.log("Hi"); } // Works',
      'const and let are hoisted but not initialized (temporal dead zone)'
    ],
    relatedTerms: ['Scope', 'Temporal Dead Zone', 'var vs let/const'],
    difficulty: 'beginner'
  },
  {
    id: 'term-memoization',
    term: 'Memoization',
    definition: 'An optimization technique that caches the results of expensive function calls and returns the cached result when the same inputs occur again.',
    category: 'performance',
    examples: [
      'React.memo() for component memoization',
      'useMemo() hook for expensive calculations',
      'Fibonacci with caching: memo[n] = fib(n-1) + fib(n-2)'
    ],
    relatedTerms: ['Caching', 'React.memo', 'useMemo', 'Performance'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-idempotent',
    term: 'Idempotent',
    definition: 'An operation that produces the same result no matter how many times it\'s executed. Critical for API design and reliable systems.',
    category: 'backend',
    examples: [
      'GET /api/users/1 - always returns same user',
      'PUT /api/users/1 - updating user multiple times has same effect',
      'DELETE /api/users/1 - deleting already deleted resource is safe'
    ],
    relatedTerms: ['REST API', 'HTTP Methods', 'Side Effects'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-race-condition',
    term: 'Race Condition',
    definition: 'A situation where the behavior of software depends on the sequence or timing of uncontrollable events, leading to unpredictable bugs.',
    category: 'patterns',
    examples: [
      'Two requests updating the same database record simultaneously',
      'React state updates based on previous state without updater function',
      'File read/write operations without proper locking'
    ],
    relatedTerms: ['Concurrency', 'Async', 'Mutex', 'Atomic Operations'],
    difficulty: 'advanced'
  },
  {
    id: 'term-hydration',
    term: 'Hydration',
    definition: 'The process of attaching React event listeners and state to server-rendered HTML, making it interactive in the browser.',
    category: 'react',
    examples: [
      'Next.js server-side rendering followed by client-side hydration',
      'Static HTML becomes interactive React app',
      'Hydration errors occur when server/client HTML differs'
    ],
    relatedTerms: ['SSR', 'SSG', 'Next.js', 'React', 'Client-Side Rendering'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-cors',
    term: 'CORS (Cross-Origin Resource Sharing)',
    definition: 'A security mechanism that allows or restricts web pages from making requests to a domain different from the one serving the web page.',
    category: 'security',
    examples: [
      'API at api.example.com accessed from app.example.com',
      'Setting Access-Control-Allow-Origin header',
      'Preflight OPTIONS requests for complex requests'
    ],
    relatedTerms: ['Same-Origin Policy', 'Security', 'HTTP Headers', 'API'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-jwt',
    term: 'JWT (JSON Web Token)',
    definition: 'A compact, URL-safe token format for securely transmitting information between parties as a JSON object, commonly used for authentication.',
    category: 'security',
    examples: [
      'Authorization: Bearer eyJhbGciOiJIUzI1NiIs...',
      'Contains header, payload, and signature',
      'Stateless authentication in APIs'
    ],
    relatedTerms: ['Authentication', 'OAuth', 'Security', 'API'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-middleware',
    term: 'Middleware',
    definition: 'Software that acts as a bridge between different applications, systems, or components, often used to handle cross-cutting concerns like authentication, logging, or request processing.',
    category: 'backend',
    examples: [
      'Express.js middleware: app.use((req, res, next) => { ... })',
      'Next.js middleware for authentication checks',
      'Redux middleware for async actions'
    ],
    relatedTerms: ['Express', 'Next.js', 'API', 'Architecture'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-orm',
    term: 'ORM (Object-Relational Mapping)',
    definition: 'A technique that lets you query and manipulate data from a database using an object-oriented paradigm, abstracting away SQL.',
    category: 'database',
    examples: [
      'Prisma: const user = await prisma.user.findUnique({ where: { id: 1 } })',
      'TypeORM, Sequelize for Node.js',
      'SQLAlchemy for Python'
    ],
    relatedTerms: ['Database', 'SQL', 'Prisma', 'TypeORM'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-normalization',
    term: 'Database Normalization',
    definition: 'The process of organizing database tables to minimize redundancy and dependency by dividing large tables into smaller ones and defining relationships.',
    category: 'database',
    examples: [
      '1NF: Eliminate repeating groups',
      '2NF: Remove partial dependencies',
      '3NF: Remove transitive dependencies'
    ],
    relatedTerms: ['Database Design', 'Foreign Keys', 'Relational Database'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-caching',
    term: 'Caching',
    definition: 'Storing copies of frequently accessed data in a fast-access location to reduce latency and server load.',
    category: 'performance',
    examples: [
      'Browser cache for static assets',
      'Redis for session data',
      'CDN caching for images and videos',
      'React Query cache for API responses'
    ],
    relatedTerms: ['Performance', 'CDN', 'Redis', 'Memoization'],
    difficulty: 'beginner'
  },
  {
    id: 'term-debounce',
    term: 'Debounce',
    definition: 'A programming practice that delays function execution until after a specified time has passed since the last invocation.',
    category: 'performance',
    examples: [
      'Search input waiting for user to stop typing',
      'Window resize handlers',
      'Form validation on keystroke'
    ],
    relatedTerms: ['Throttle', 'Performance', 'Event Handling'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-throttle',
    term: 'Throttle',
    definition: 'A technique that ensures a function executes at most once per specified time period, regardless of how many times it\'s called.',
    category: 'performance',
    examples: [
      'Scroll event handlers',
      'API rate limiting',
      'Game loop controls'
    ],
    relatedTerms: ['Debounce', 'Performance', 'Event Handling'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-webhook',
    term: 'Webhook',
    definition: 'An HTTP callback that sends real-time data from one application to another when a specific event occurs, enabling event-driven integrations.',
    category: 'backend',
    examples: [
      'Stripe payment notifications',
      'GitHub push events',
      'Slack bot notifications'
    ],
    relatedTerms: ['API', 'Event-Driven', 'Integration', 'HTTP'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-ssr',
    term: 'SSR (Server-Side Rendering)',
    definition: 'Rendering web pages on the server instead of in the browser, sending fully rendered HTML to the client for faster initial page loads and better SEO.',
    category: 'react',
    examples: [
      'Next.js getServerSideProps',
      'Better SEO for dynamic content',
      'Faster perceived load times'
    ],
    relatedTerms: ['Next.js', 'Hydration', 'SSG', 'CSR'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-ssg',
    term: 'SSG (Static Site Generation)',
    definition: 'Pre-rendering pages at build time, generating static HTML files that can be served instantly without server computation.',
    category: 'react',
    examples: [
      'Next.js getStaticProps and getStaticPaths',
      'Blog posts and documentation sites',
      'Maximum performance with CDN caching'
    ],
    relatedTerms: ['Next.js', 'SSR', 'JAMstack', 'Performance'],
    difficulty: 'intermediate'
  },
  {
    id: 'term-rest',
    term: 'REST (Representational State Transfer)',
    definition: 'An architectural style for designing networked applications using HTTP requests to access and manipulate data using standard methods (GET, POST, PUT, DELETE).',
    category: 'backend',
    examples: [
      'GET /api/users - Retrieve users',
      'POST /api/users - Create user',
      'PUT /api/users/1 - Update user',
      'DELETE /api/users/1 - Delete user'
    ],
    relatedTerms: ['API', 'HTTP', 'GraphQL', 'Idempotent'],
    difficulty: 'beginner'
  }
];

export const learningPaths: LearningPath[] = [
  {
    id: 'path-react-mastery',
    title: 'React Mastery Path',
    description: 'From React basics to advanced patterns and performance optimization',
    difficulty: 'intermediate',
    estimatedHours: 8,
    items: [
      { type: 'knowledge', id: 'knowledge-react', order: 1 },
      { type: 'recipe', id: 'recipe-error-boundary', order: 2 },
      { type: 'shard', id: 'shard-use-local-storage', order: 3 },
      { type: 'shard', id: 'shard-use-media-query', order: 4 },
      { type: 'quiz', id: 'quiz-react-patterns', order: 5 },
      { type: 'recipe', id: 'recipe-form-validation', order: 6 }
    ],
    prerequisites: ['JavaScript ES6+', 'Basic React knowledge']
  },
  {
    id: 'path-performance',
    title: 'Performance Optimization Path',
    description: 'Master techniques to make your applications lightning fast',
    difficulty: 'intermediate',
    estimatedHours: 6,
    items: [
      { type: 'knowledge', id: 'knowledge-performance', order: 1 },
      { type: 'recipe', id: 'recipe-debounce', order: 2 },
      { type: 'recipe', id: 'recipe-throttle', order: 3 },
      { type: 'recipe', id: 'recipe-cache-api', order: 4 },
      { type: 'quiz', id: 'quiz-performance', order: 5 }
    ],
    prerequisites: ['JavaScript fundamentals', 'Understanding of async operations']
  },
  {
    id: 'path-type-safety',
    title: 'TypeScript Type Safety Path',
    description: 'Build bulletproof applications with advanced TypeScript patterns',
    difficulty: 'advanced',
    estimatedHours: 10,
    items: [
      { type: 'knowledge', id: 'knowledge-type-safety', order: 1 },
      { type: 'recipe', id: 'recipe-form-validation', order: 2 },
      { type: 'quiz', id: 'quiz-typescript', order: 3 }
    ],
    prerequisites: ['TypeScript basics', 'Generics understanding']
  },
  {
    id: 'path-api-design',
    title: 'API Design & Reliability Path',
    description: 'Create robust, scalable APIs with proper error handling',
    difficulty: 'intermediate',
    estimatedHours: 7,
    items: [
      { type: 'recipe', id: 'recipe-error-handling', order: 1 },
      { type: 'shard', id: 'shard-retry-fetch', order: 2 },
      { type: 'shard', id: 'shard-circuit-breaker', order: 3 },
      { type: 'recipe', id: 'recipe-cache-api', order: 4 },
      { type: 'quiz', id: 'quiz-api-design', order: 5 }
    ],
    prerequisites: ['HTTP fundamentals', 'Async JavaScript']
  }
];

export const quizzes: Quiz[] = [
  {
    id: 'quiz-react-patterns',
    title: 'React Patterns Quiz',
    category: 'react',
    difficulty: 'intermediate',
    relatedContentIds: ['knowledge-react', 'recipe-error-boundary'],
    questions: [
      {
        id: 'q1',
        question: 'What is the primary benefit of the Compound Component pattern?',
        options: [
          'Faster rendering performance',
          'Flexible, intuitive component APIs with implicit state sharing',
          'Smaller bundle size',
          'Better TypeScript support'
        ],
        correctAnswer: 1,
        explanation: 'Compound components create flexible APIs where child components implicitly share state through context, making them intuitive to use while maintaining flexibility.'
      },
      {
        id: 'q2',
        question: 'When should you use React Error Boundaries?',
        options: [
          'For every component',
          'Only in production',
          'To wrap risky components and prevent full app crashes',
          'To handle async errors'
        ],
        correctAnswer: 2,
        explanation: 'Error boundaries catch errors in component trees, display fallback UI, and prevent the entire app from crashing. They\'re especially useful around third-party components or risky features.'
      },
      {
        id: 'q3',
        question: 'What does React hydration do?',
        options: [
          'Adds water molecules to components',
          'Attaches event listeners to server-rendered HTML',
          'Optimizes image loading',
          'Caches API responses'
        ],
        correctAnswer: 1,
        explanation: 'Hydration is the process of attaching React event listeners and state to server-rendered HTML, making it interactive in the browser.'
      }
    ]
  },
  {
    id: 'quiz-performance',
    title: 'Performance Optimization Quiz',
    category: 'performance',
    difficulty: 'intermediate',
    relatedContentIds: ['knowledge-performance', 'recipe-debounce', 'recipe-throttle'],
    questions: [
      {
        id: 'q1',
        question: 'What\'s the key difference between debounce and throttle?',
        options: [
          'Debounce is faster than throttle',
          'Debounce waits for inactivity, throttle maintains steady execution rate',
          'Throttle is for user input, debounce is for scroll events',
          'They are the same thing with different names'
        ],
        correctAnswer: 1,
        explanation: 'Debounce delays execution until after a period of inactivity, while throttle ensures execution happens at most once per time period, regardless of how many times the event fires.'
      },
      {
        id: 'q2',
        question: 'When is virtual scrolling most beneficial?',
        options: [
          'Lists with less than 10 items',
          'Lists with thousands of items where rendering all would hurt performance',
          'Any list component',
          'Only for infinite scroll'
        ],
        correctAnswer: 1,
        explanation: 'Virtual scrolling renders only visible items in large lists (thousands of items), dramatically improving performance by not rendering off-screen elements.'
      },
      {
        id: 'q3',
        question: 'What is the purpose of caching API responses?',
        options: [
          'To make APIs slower',
          'To reduce redundant network requests and improve responsiveness',
          'To increase bundle size',
          'To prevent users from seeing data'
        ],
        correctAnswer: 1,
        explanation: 'Caching stores API responses temporarily to avoid redundant network requests, reducing server load and improving app responsiveness.'
      }
    ]
  },
  {
    id: 'quiz-typescript',
    title: 'TypeScript Type Safety Quiz',
    category: 'patterns',
    difficulty: 'advanced',
    relatedContentIds: ['knowledge-type-safety'],
    questions: [
      {
        id: 'q1',
        question: 'What are branded types used for?',
        options: [
          'Adding company logos to code',
          'Preventing primitive type confusion with compile-time distinctions',
          'Making code run faster',
          'Creating new primitive types'
        ],
        correctAnswer: 1,
        explanation: 'Branded types add a unique symbol to primitives (like string) to create distinct types at compile time, preventing accidental misuse (e.g., UserId vs ProductId).'
      },
      {
        id: 'q2',
        question: 'What problem do discriminated unions solve?',
        options: [
          'Slow performance',
          'Type-safe state machines with exhaustive switch checking',
          'Large bundle sizes',
          'Complex CSS'
        ],
        correctAnswer: 1,
        explanation: 'Discriminated unions use a common property (like "status") to create type-safe state machines where TypeScript can narrow types and ensure all cases are handled.'
      }
    ]
  },
  {
    id: 'quiz-api-design',
    title: 'API Design Quiz',
    category: 'backend',
    difficulty: 'intermediate',
    relatedContentIds: ['recipe-error-handling', 'shard-retry-fetch', 'shard-circuit-breaker'],
    questions: [
      {
        id: 'q1',
        question: 'What does idempotent mean for API operations?',
        options: [
          'The operation is very fast',
          'The operation produces the same result no matter how many times it executes',
          'The operation requires authentication',
          'The operation never fails'
        ],
        correctAnswer: 1,
        explanation: 'Idempotent operations produce the same result regardless of how many times they execute, making them safe to retry. GET, PUT, and DELETE are typically idempotent.'
      },
      {
        id: 'q2',
        question: 'When should you use a circuit breaker pattern?',
        options: [
          'For every API call',
          'To prevent cascading failures when a service is consistently failing',
          'Only in production',
          'Never, it\'s outdated'
        ],
        correctAnswer: 1,
        explanation: 'Circuit breakers prevent cascading failures by stopping requests to failing services, giving them time to recover while failing fast for consumers.'
      },
      {
        id: 'q3',
        question: 'What is exponential backoff in retry logic?',
        options: [
          'Retrying immediately after failure',
          'Increasing delay between retries (1s, 2s, 4s, 8s...)',
          'Never retrying',
          'Random retry intervals'
        ],
        correctAnswer: 1,
        explanation: 'Exponential backoff increases the delay between retries exponentially (1s, 2s, 4s, 8s), preventing overwhelming a recovering service while still attempting retries.'
      }
    ]
  }
];
