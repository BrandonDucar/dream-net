export type DifficultyLevel = 'beginner' | 'intermediate' | 'advanced';
export type ContentCategory = 'react' | 'backend' | 'database' | 'performance' | 'security' | 'testing' | 'devops' | 'patterns';
export type Language = 'typescript' | 'python' | 'go' | 'rust';

export interface CodeExample {
  language: Language;
  code: string;
  filename?: string;
}

export interface Recipe {
  id: string;
  title: string;
  description: string;
  category: ContentCategory;
  difficulty: DifficultyLevel;
  timeEstimate: string;
  prerequisites: string[];
  tags: string[];
  examples: CodeExample[];
  explanation: string;
  useCases: string[];
  relatedIds: string[];
  votes: number;
  saves: number;
}

export interface KnowledgePack {
  id: string;
  title: string;
  description: string;
  category: ContentCategory;
  difficulty: DifficultyLevel;
  timeEstimate: string;
  prerequisites: string[];
  tags: string[];
  content: string[];
  examples: CodeExample[];
  keyTakeaways: string[];
  relatedIds: string[];
  votes: number;
}

export interface CodeShard {
  id: string;
  title: string;
  description: string;
  category: ContentCategory;
  tags: string[];
  examples: CodeExample[];
  useCases: string[];
  relatedIds: string[];
  votes: number;
  saves: number;
}

export interface GlossaryTerm {
  id: string;
  term: string;
  definition: string;
  category: ContentCategory;
  examples: string[];
  relatedTerms: string[];
  difficulty: DifficultyLevel;
}

export interface LearningPath {
  id: string;
  title: string;
  description: string;
  difficulty: DifficultyLevel;
  estimatedHours: number;
  items: Array<{
    type: 'recipe' | 'knowledge' | 'shard' | 'quiz';
    id: string;
    order: number;
  }>;
  prerequisites: string[];
}

export interface Quiz {
  id: string;
  title: string;
  category: ContentCategory;
  difficulty: DifficultyLevel;
  questions: QuizQuestion[];
  relatedContentIds: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
}

export interface UserProgress {
  completedRecipes: string[];
  completedKnowledge: string[];
  completedQuizzes: string[];
  favorites: string[];
  collections: Collection[];
  currentPath?: string;
  pathProgress: Record<string, number>;
}

export interface Collection {
  id: string;
  name: string;
  description: string;
  items: Array<{
    type: 'recipe' | 'knowledge' | 'shard';
    id: string;
  }>;
  createdAt: number;
}
