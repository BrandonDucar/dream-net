import { NextRequest, NextResponse } from 'next/server';

interface RequestBody {
  contentType: string;
  text: string;
  tones: {
    funny: number;
    serious: number;
    inspirational: number;
    mysterious: number;
  };
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body: RequestBody = await request.json();
    const { contentType, text, tones } = body;

    // Build tone description
    const toneDescriptions: string[] = [];
    if (tones.funny > 60) toneDescriptions.push('playful and humorous');
    if (tones.serious > 60) toneDescriptions.push('professional and serious');
    if (tones.inspirational > 60) toneDescriptions.push('uplifting and motivational');
    if (tones.mysterious > 60) toneDescriptions.push('intriguing and mysterious');

    const toneContext = toneDescriptions.length > 0 
      ? `Apply these tones: ${toneDescriptions.join(', ')}.` 
      : '';

    // Generate improved versions using OpenAI
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.openai.com',
        path: '/v1/chat/completions',
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${process.env.OPENAI_API_KEY || ''}`,
          'Content-Type': 'application/json',
        },
        body: {
          model: 'gpt-4o-mini',
          messages: [
            {
              role: 'system',
              content: `You are a content optimization expert. Your job is to improve content to make it more engaging, shareable, and likely to reach people. Never mention AI, SEO, algorithms, or technical terms. Use friendly language like "visibility boost", "reach enhancer", or "optimized version". ${toneContext}`,
            },
            {
              role: 'user',
              content: `Generate improved versions of this ${contentType}:

"${text}"

Provide the following:
1. A CLEANER version (remove fluff, make it crisp)
2. A HIGH-ENGAGEMENT version (hooks, curiosity, shareability)
3. An EMOTIONAL version (connect deeply with feelings)
4. A BOLD/VIRAL version (controversial, attention-grabbing, memorable)
5. A SHORT PUNCHY version (ultra-concise, impactful)
6. An INSTAGRAM-OPTIMIZED version (emoji-friendly, visual, story-driven)
7. A TIKTOK-OPTIMIZED version (hook in first 3 words, trendy, relatable)
8. A YOUTUBE SHORTS-OPTIMIZED version (narrative hook, cliffhanger energy)
9. An X-OPTIMIZED version (concise, quote-worthy, conversation-starting)
10. 3 HOOK SUGGESTIONS (opening lines that grab attention)
11. A STRONG CALL-TO-ACTION
12. BETTER HASHTAGS (relevant and trending)
13. IDEAL POSTING TIME (in friendly, simple language)

Return ONLY valid JSON in this exact format:
{
  "versions": {
    "cleaner": "...",
    "engagement": "...",
    "emotional": "...",
    "viral": "...",
    "punchy": "...",
    "instagram": "...",
    "tiktok": "...",
    "youtube": "...",
    "x": "..."
  },
  "enhancements": {
    "hooks": ["...", "...", "..."],
    "cta": "...",
    "hashtags": "...",
    "postingTime": "..."
  }
}`,
            },
          ],
          temperature: 0.8,
          max_tokens: 2000,
        },
      }),
    });

    if (!response.ok) {
      throw new Error('Failed to generate content');
    }

    const data = await response.json();
    const content = data.choices[0].message.content;

    // Parse the JSON response
    const result = JSON.parse(content);

    return NextResponse.json(result);
  } catch (error) {
    console.error('Error generating content:', error);
    return NextResponse.json(
      { error: 'Failed to generate content. Please try again.' },
      { status: 500 }
    );
  }
}
