'use client'
import { useState, useEffect } from 'react';
import { ContentTypeSelector } from '@/components/ContentTypeSelector';
import { TextInputForm } from '@/components/TextInputForm';
import { ResultsDisplay } from '@/components/ResultsDisplay';
import { SocialProofCounter } from '@/components/SocialProofCounter';
import { Button } from '@/components/ui/button';
import { ArrowLeft, Sparkles } from 'lucide-react';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function DreamRankEngine(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [step, setStep] = useState<number>(1);
  const [contentType, setContentType] = useState<string>('');
  const [originalText, setOriginalText] = useState<string>('');
  const [toneSettings, setToneSettings] = useState({
    funny: 50,
    serious: 50,
    inspirational: 50,
    mysterious: 50,
  });
  const [results, setResults] = useState<Record<string, unknown> | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleContentTypeSelect = (type: string): void => {
    setContentType(type);
    setStep(2);
  };

  const handleTextSubmit = async (text: string, tones: Record<string, number>): Promise<void> => {
    setOriginalText(text);
    setToneSettings(tones);
    setIsLoading(true);

    try {
      const response = await fetch('/api/generate-content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contentType,
          text,
          tones,
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to generate content');
      }

      const data = await response.json();
      setResults(data);
      setStep(3);
    } catch (error) {
      console.error('Error generating content:', error);
      alert('Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleReset = (): void => {
    setStep(1);
    setContentType('');
    setOriginalText('');
    setResults(null);
    setToneSettings({
      funny: 50,
      serious: 50,
      inspirational: 50,
      mysterious: 50,
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-purple-950 to-slate-950 text-white">
      {/* Animated background glow */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-purple-500/20 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-blue-500/20 rounded-full blur-3xl animate-pulse delay-1000"></div>
      </div>

      {/* Header */}
      <header className="relative z-10 pt-8 pb-6 px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 mb-4">
            <Sparkles className="w-8 h-8 text-purple-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-purple-400 via-pink-400 to-blue-400 bg-clip-text text-transparent">
              DreamRank Engine — $RANK
            </h1>
          </div>
          <p className="text-lg text-purple-200/80 max-w-2xl mx-auto mb-6">
            Boost any piece of content to make it more engaging, more shareable, and more likely to reach people
          </p>
          <div className="flex justify-center">
            <SocialProofCounter />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="relative z-10 px-4 pb-12">
        <div className="max-w-4xl mx-auto">
          {/* Back Button */}
          {step > 1 && !isLoading && (
            <Button
              onClick={() => setStep(step - 1)}
              variant="ghost"
              className="mb-6 text-purple-300 hover:text-purple-100 hover:bg-purple-900/30"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back
            </Button>
          )}

          {/* Step 1: Content Type Selection */}
          {step === 1 && (
            <ContentTypeSelector onSelect={handleContentTypeSelect} />
          )}

          {/* Step 2: Text Input */}
          {step === 2 && (
            <TextInputForm
              contentType={contentType}
              onSubmit={handleTextSubmit}
              isLoading={isLoading}
            />
          )}

          {/* Step 3: Results */}
          {step === 3 && results && (
            <ResultsDisplay
              results={results}
              originalText={originalText}
              contentType={contentType}
              onReset={handleReset}
            />
          )}
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-10 py-6 text-center text-purple-300/60 text-sm">
        <p>DreamRank Engine — Make every word count</p>
      </footer>
    </div>
  );
}
