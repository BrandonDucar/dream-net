'use client';

import { Card } from '@/components/ui/card';
import { FileText, MessageSquare, Lightbulb, Megaphone, Video, Package, User, ScrollText } from 'lucide-react';

interface ContentTypeSelectorProps {
  onSelect: (type: string) => void;
}

const contentTypes = [
  { id: 'post', label: 'Social Post', icon: MessageSquare },
  { id: 'caption', label: 'Caption', icon: FileText },
  { id: 'idea', label: 'Idea', icon: Lightbulb },
  { id: 'headline', label: 'Headline', icon: Megaphone },
  { id: 'video-concept', label: 'Video Concept', icon: Video },
  { id: 'product-description', label: 'Product Description', icon: Package },
  { id: 'bio', label: 'Bio', icon: User },
  { id: 'script', label: 'Script', icon: ScrollText },
];

export function ContentTypeSelector({ onSelect }: ContentTypeSelectorProps): JSX.Element {
  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-2xl md:text-3xl font-bold text-white mb-3">
          What would you like to boost?
        </h2>
        <p className="text-purple-200/70">
          Choose the type of content you want to make more engaging
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {contentTypes.map((type) => {
          const Icon = type.icon;
          return (
            <Card
              key={type.id}
              onClick={() => onSelect(type.id)}
              className="group relative overflow-hidden bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30 hover:border-purple-400/60 transition-all duration-300 cursor-pointer hover:scale-105 hover:shadow-xl hover:shadow-purple-500/20"
            >
              {/* Glow effect on hover */}
              <div className="absolute inset-0 bg-gradient-to-br from-purple-500/0 to-blue-500/0 group-hover:from-purple-500/10 group-hover:to-blue-500/10 transition-all duration-300"></div>
              
              <div className="relative p-6 flex flex-col items-center text-center space-y-3">
                <div className="w-12 h-12 rounded-full bg-purple-500/20 flex items-center justify-center group-hover:bg-purple-500/30 transition-all duration-300">
                  <Icon className="w-6 h-6 text-purple-300 group-hover:text-purple-200" />
                </div>
                <h3 className="text-lg font-semibold text-white group-hover:text-purple-200 transition-colors">
                  {type.label}
                </h3>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
