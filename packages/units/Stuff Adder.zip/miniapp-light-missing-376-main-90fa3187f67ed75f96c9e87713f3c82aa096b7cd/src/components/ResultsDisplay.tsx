'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Copy, Check, RefreshCw, Clock, Hash, Target, Zap, Heart, CopyPlus } from 'lucide-react';
import { useState, useEffect } from 'react';
import Confetti from 'react-confetti';

interface ResultsDisplayProps {
  results: Record<string, unknown>;
  originalText: string;
  contentType: string;
  onReset: () => void;
}

const platformLimits: Record<string, number> = {
  instagram: 2200,
  tiktok: 2200,
  youtube: 5000,
  x: 280,
};

export function ResultsDisplay({ results, originalText, contentType, onReset }: ResultsDisplayProps): JSX.Element {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [favorites, setFavorites] = useState<Set<string>>(new Set());
  const [showConfetti, setShowConfetti] = useState<boolean>(false);
  const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });

  useEffect(() => {
    // Load favorites from localStorage
    const savedFavorites = localStorage.getItem('dreamrank-favorites');
    if (savedFavorites) {
      try {
        setFavorites(new Set(JSON.parse(savedFavorites)));
      } catch (error) {
        console.error('Failed to load favorites:', error);
      }
    }

    // Set window size for confetti
    setWindowSize({
      width: window.innerWidth,
      height: window.innerHeight,
    });

    const handleResize = (): void => {
      setWindowSize({
        width: window.innerWidth,
        height: window.innerHeight,
      });
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const handleCopy = async (text: string, id: string): Promise<void> => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(id);
      setShowConfetti(true);
      setTimeout(() => {
        setCopiedId(null);
        setShowConfetti(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const handleCopyAll = async (): Promise<void> => {
    const versions = results.versions as Record<string, string>;
    const enhancements = results.enhancements as Record<string, string | string[]>;
    
    let allContent = `🌟 DreamRank Engine — Boosted Versions 🌟\n\n`;
    allContent += `📝 ORIGINAL:\n${originalText}\n\n`;
    allContent += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    
    // Core versions
    allContent += `✨ CORE VERSIONS:\n\n`;
    Object.entries(versions).slice(0, 5).forEach(([key, value]) => {
      const title = key.charAt(0).toUpperCase() + key.slice(1);
      allContent += `${title.toUpperCase()}:\n${value}\n\n`;
    });
    
    // Platform versions
    allContent += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    allContent += `📱 PLATFORM-OPTIMIZED:\n\n`;
    ['instagram', 'tiktok', 'youtube', 'x'].forEach((platform) => {
      allContent += `${platform.toUpperCase()}:\n${versions[platform]}\n\n`;
    });
    
    // Enhancements
    allContent += `━━━━━━━━━━━━━━━━━━━━━━\n\n`;
    allContent += `💎 ENHANCEMENTS:\n\n`;
    allContent += `HOOKS:\n`;
    (enhancements.hooks as string[]).forEach((hook: string, i: number) => {
      allContent += `${i + 1}. ${hook}\n`;
    });
    allContent += `\nCALL-TO-ACTION:\n${enhancements.cta}\n\n`;
    allContent += `HASHTAGS:\n${enhancements.hashtags}\n\n`;
    allContent += `BEST TIME TO POST:\n${enhancements.postingTime}\n`;

    try {
      await navigator.clipboard.writeText(allContent);
      setCopiedId('copy-all');
      setShowConfetti(true);
      setTimeout(() => {
        setCopiedId(null);
        setShowConfetti(false);
      }, 3000);
    } catch (error) {
      console.error('Failed to copy all:', error);
    }
  };

  const toggleFavorite = (id: string): void => {
    const newFavorites = new Set(favorites);
    if (newFavorites.has(id)) {
      newFavorites.delete(id);
    } else {
      newFavorites.add(id);
    }
    setFavorites(newFavorites);
    localStorage.setItem('dreamrank-favorites', JSON.stringify(Array.from(newFavorites)));
  };

  const versions = results.versions as Record<string, string>;
  const enhancements = results.enhancements as Record<string, string | string[]>;

  const getCharacterCountColor = (count: number, limit: number): string => {
    const percentage = (count / limit) * 100;
    if (percentage > 100) return 'text-red-400';
    if (percentage > 90) return 'text-yellow-400';
    return 'text-purple-300/70';
  };

  return (
    <div className="space-y-6">
      {/* Confetti Effect */}
      {showConfetti && (
        <Confetti
          width={windowSize.width}
          height={windowSize.height}
          recycle={false}
          numberOfPieces={500}
          gravity={0.3}
        />
      )}

      {/* Header */}
      <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
        <CardHeader>
          <div className="flex items-start justify-between gap-4">
            <div>
              <CardTitle className="text-2xl text-white mb-2">
                Your Boosted Content is Ready!
              </CardTitle>
              <p className="text-purple-200/70">
                Pick the version that feels right, or mix and match ideas
              </p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleCopyAll}
                variant="outline"
                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
              >
                {copiedId === 'copy-all' ? (
                  <>
                    <Check className="w-4 h-4 mr-2" />
                    Copied All!
                  </>
                ) : (
                  <>
                    <CopyPlus className="w-4 h-4 mr-2" />
                    Copy All
                  </>
                )}
              </Button>
              <Button
                onClick={onReset}
                variant="outline"
                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20"
              >
                <RefreshCw className="w-4 h-4 mr-2" />
                Start Over
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="bg-slate-900/50 rounded-lg p-4 border border-purple-500/20">
            <p className="text-sm text-purple-300/70 mb-2">Original {contentType.replace('-', ' ')}:</p>
            <p className="text-white">{originalText}</p>
          </div>
        </CardContent>
      </Card>

      {/* Main Versions */}
      <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-white flex items-center gap-2">
            <Zap className="w-5 h-5 text-purple-400" />
            Optimized Versions
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="cleaner" className="w-full">
            <TabsList className="grid w-full grid-cols-3 lg:grid-cols-5 bg-slate-900/50 mb-6">
              <TabsTrigger value="cleaner" className="data-[state=active]:bg-purple-600">
                Cleaner
              </TabsTrigger>
              <TabsTrigger value="engagement" className="data-[state=active]:bg-purple-600">
                High-Reach
              </TabsTrigger>
              <TabsTrigger value="emotional" className="data-[state=active]:bg-purple-600">
                Emotional
              </TabsTrigger>
              <TabsTrigger value="viral" className="data-[state=active]:bg-purple-600">
                Bold
              </TabsTrigger>
              <TabsTrigger value="punchy" className="data-[state=active]:bg-purple-600">
                Punchy
              </TabsTrigger>
            </TabsList>

            {Object.entries(versions).slice(0, 5).map(([key, value]) => (
              <TabsContent key={key} value={key} className="space-y-4">
                <div className="bg-slate-900/50 rounded-lg p-6 border border-purple-500/20 relative">
                  <p className="text-white text-lg leading-relaxed whitespace-pre-wrap pr-24">{value}</p>
                  <div className="absolute top-4 right-4 flex gap-2">
                    <Button
                      onClick={() => toggleFavorite(key)}
                      variant="ghost"
                      size="sm"
                      className={`${
                        favorites.has(key)
                          ? 'text-pink-400 hover:text-pink-300'
                          : 'text-purple-300 hover:text-purple-100'
                      } hover:bg-purple-500/20`}
                    >
                      <Heart className={`w-4 h-4 ${favorites.has(key) ? 'fill-current' : ''}`} />
                    </Button>
                    <Button
                      onClick={() => handleCopy(value, key)}
                      variant="ghost"
                      size="sm"
                      className="text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
                    >
                      {copiedId === key ? (
                        <>
                          <Check className="w-4 h-4 mr-1" />
                          Copied!
                        </>
                      ) : (
                        <>
                          <Copy className="w-4 h-4 mr-1" />
                          Copy
                        </>
                      )}
                    </Button>
                  </div>
                </div>
              </TabsContent>
            ))}
          </Tabs>
        </CardContent>
      </Card>

      {/* Platform Specific */}
      <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-xl text-white">Platform-Optimized Versions</CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="instagram" className="w-full">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4 bg-slate-900/50 mb-6">
              <TabsTrigger value="instagram" className="data-[state=active]:bg-purple-600">
                Instagram
              </TabsTrigger>
              <TabsTrigger value="tiktok" className="data-[state=active]:bg-purple-600">
                TikTok
              </TabsTrigger>
              <TabsTrigger value="youtube" className="data-[state=active]:bg-purple-600">
                YouTube
              </TabsTrigger>
              <TabsTrigger value="x" className="data-[state=active]:bg-purple-600">
                X
              </TabsTrigger>
            </TabsList>

            {['instagram', 'tiktok', 'youtube', 'x'].map((platform) => {
              const content = versions[platform] as string;
              const charCount = content.length;
              const limit = platformLimits[platform];
              return (
                <TabsContent key={platform} value={platform} className="space-y-4">
                  <div className="flex items-center justify-between mb-2">
                    <span className={`text-sm ${getCharacterCountColor(charCount, limit)}`}>
                      {charCount} / {limit} characters
                      {charCount > limit && ' (over limit!)'}
                    </span>
                  </div>
                  <div className="bg-slate-900/50 rounded-lg p-6 border border-purple-500/20 relative">
                    <p className="text-white text-lg leading-relaxed whitespace-pre-wrap pr-24">
                      {content}
                    </p>
                    <div className="absolute top-4 right-4 flex gap-2">
                      <Button
                        onClick={() => toggleFavorite(`platform-${platform}`)}
                        variant="ghost"
                        size="sm"
                        className={`${
                          favorites.has(`platform-${platform}`)
                            ? 'text-pink-400 hover:text-pink-300'
                            : 'text-purple-300 hover:text-purple-100'
                        } hover:bg-purple-500/20`}
                      >
                        <Heart className={`w-4 h-4 ${favorites.has(`platform-${platform}`) ? 'fill-current' : ''}`} />
                      </Button>
                      <Button
                        onClick={() => handleCopy(content, `platform-${platform}`)}
                        variant="ghost"
                        size="sm"
                        className="text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
                      >
                        {copiedId === `platform-${platform}` ? (
                          <>
                            <Check className="w-4 h-4 mr-1" />
                            Copied!
                          </>
                        ) : (
                          <>
                            <Copy className="w-4 h-4 mr-1" />
                            Copy
                          </>
                        )}
                      </Button>
                    </div>
                  </div>
                </TabsContent>
              );
            })}
          </Tabs>
        </CardContent>
      </Card>

      {/* Enhancements */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Hooks */}
        <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Target className="w-5 h-5 text-purple-400" />
              Hook Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-3">
              {(enhancements.hooks as string[]).map((hook: string, index: number) => (
                <li key={index} className="flex items-start gap-3 group">
                  <Badge variant="outline" className="border-purple-500/50 text-purple-300 shrink-0">
                    {index + 1}
                  </Badge>
                  <div className="flex-1 bg-slate-900/50 rounded p-3 border border-purple-500/20 relative">
                    <p className="text-white text-sm pr-8">{hook}</p>
                    <Button
                      onClick={() => handleCopy(hook, `hook-${index}`)}
                      variant="ghost"
                      size="sm"
                      className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity h-6 w-6 p-0"
                    >
                      {copiedId === `hook-${index}` ? (
                        <Check className="w-3 h-3" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </Button>
                  </div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>

        {/* Call to Action */}
        <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-purple-400" />
              Strong Call-to-Action
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-900/50 rounded-lg p-4 border border-purple-500/20 relative group">
              <p className="text-white">{enhancements.cta as string}</p>
              <Button
                onClick={() => handleCopy(enhancements.cta as string, 'cta')}
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
              >
                {copiedId === 'cta' ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Hashtags */}
        <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Hash className="w-5 h-5 text-purple-400" />
              Better Hashtags
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-900/50 rounded-lg p-4 border border-purple-500/20 relative group">
              <p className="text-purple-300">{enhancements.hashtags as string}</p>
              <Button
                onClick={() => handleCopy(enhancements.hashtags as string, 'hashtags')}
                variant="ghost"
                size="sm"
                className="absolute top-2 right-2 text-purple-300 hover:text-purple-100 hover:bg-purple-500/20"
              >
                {copiedId === 'hashtags' ? (
                  <Check className="w-4 h-4" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Posting Time */}
        <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
          <CardHeader>
            <CardTitle className="text-lg text-white flex items-center gap-2">
              <Clock className="w-5 h-5 text-purple-400" />
              Best Time to Post
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-slate-900/50 rounded-lg p-4 border border-purple-500/20">
              <p className="text-white">{enhancements.postingTime as string}</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
