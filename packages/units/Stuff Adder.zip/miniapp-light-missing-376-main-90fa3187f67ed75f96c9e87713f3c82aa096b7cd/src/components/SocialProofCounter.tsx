'use client';

import { useState, useEffect } from 'react';
import { Users } from 'lucide-react';

export function SocialProofCounter(): JSX.Element {
  const [count, setCount] = useState<number>(0);

  useEffect(() => {
    // Generate a base number that changes daily
    const today = new Date();
    const dayOfYear = Math.floor((today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 1000 / 60 / 60 / 24);
    const baseCount = 1200 + (dayOfYear * 37); // Increments daily
    
    // Add some variation based on time of day
    const hourVariation = Math.floor((today.getHours() / 24) * 50);
    const targetCount = baseCount + hourVariation;

    // Animate counter from 0 to target
    let currentCount = 0;
    const increment = Math.ceil(targetCount / 50);
    
    const timer = setInterval(() => {
      currentCount += increment;
      if (currentCount >= targetCount) {
        setCount(targetCount);
        clearInterval(timer);
      } else {
        setCount(currentCount);
      }
    }, 30);

    return () => clearInterval(timer);
  }, []);

  return (
    <div className="inline-flex items-center gap-2 bg-purple-900/30 border border-purple-500/30 rounded-full px-4 py-2 backdrop-blur-sm">
      <Users className="w-4 h-4 text-purple-400" />
      <span className="text-purple-200 text-sm">
        <span className="font-bold text-purple-100">{count.toLocaleString()}</span> creators boosted today
      </span>
    </div>
  );
}
