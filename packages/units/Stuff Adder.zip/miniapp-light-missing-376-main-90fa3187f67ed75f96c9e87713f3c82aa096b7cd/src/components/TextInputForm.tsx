'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Sparkles, Smile, Briefcase, Heart, Eye, Shuffle, Lightbulb } from 'lucide-react';

interface TextInputFormProps {
  contentType: string;
  onSubmit: (text: string, tones: Record<string, number>) => Promise<void>;
  isLoading: boolean;
}

const quickExamples: Record<string, string> = {
  'social-post': "Just launched my new project! Excited to share this with the world 🚀",
  'caption': "Morning coffee hits different when you're chasing your dreams",
  'idea': "What if we created a platform that connects local artists with coffee shops?",
  'headline': "How This Simple Habit Changed My Productivity Forever",
  'video-concept': "Day in the life of a digital nomad working from Bali - the reality behind the Instagram posts",
  'product-description': "Handcrafted leather wallet with RFID protection. Minimalist design that ages beautifully.",
  'bio': "Creative designer & coffee enthusiast. Building things that matter. Based in NYC.",
  'script': "Hey everyone! Today I'm sharing 3 tips that completely transformed how I approach my morning routine..."
};

export function TextInputForm({ contentType, onSubmit, isLoading }: TextInputFormProps): JSX.Element {
  const [text, setText] = useState<string>('');
  const [tones, setTones] = useState({
    funny: 50,
    serious: 50,
    inspirational: 50,
    mysterious: 50,
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault();
    if (text.trim()) {
      await onSubmit(text, tones);
    }
  };

  const handleToneChange = (toneName: string, value: number[]): void => {
    setTones((prev) => ({
      ...prev,
      [toneName]: value[0],
    }));
  };

  const handleSurpriseMe = (): void => {
    setTones({
      funny: Math.floor(Math.random() * 100),
      serious: Math.floor(Math.random() * 100),
      inspirational: Math.floor(Math.random() * 100),
      mysterious: Math.floor(Math.random() * 100),
    });
  };

  const handleQuickExample = (): void => {
    const example = quickExamples[contentType] || quickExamples['social-post'];
    setText(example);
  };

  const toneControls = [
    { name: 'funny', label: 'Playful', icon: Smile, color: 'text-yellow-400' },
    { name: 'serious', label: 'Professional', icon: Briefcase, color: 'text-blue-400' },
    { name: 'inspirational', label: 'Uplifting', icon: Heart, color: 'text-pink-400' },
    { name: 'mysterious', label: 'Intriguing', icon: Eye, color: 'text-purple-400' },
  ];

  const characterCount = text.length;

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <Card className="bg-gradient-to-br from-purple-900/40 to-slate-900/40 border-purple-500/30">
        <CardHeader>
          <CardTitle className="text-2xl text-white flex items-center gap-2">
            <Sparkles className="w-6 h-6 text-purple-400" />
            Enter your {contentType.replace('-', ' ')}
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <Label htmlFor="content-text" className="text-purple-200 text-base">
                Your original content
              </Label>
              <div className="flex items-center gap-3">
                <span className="text-sm text-purple-300/70">
                  {characterCount} character{characterCount !== 1 ? 's' : ''}
                </span>
                <Button
                  type="button"
                  onClick={handleQuickExample}
                  variant="ghost"
                  size="sm"
                  className="text-purple-300 hover:text-purple-100 hover:bg-purple-500/20 h-7"
                >
                  <Lightbulb className="w-3 h-3 mr-1" />
                  Try Example
                </Button>
              </div>
            </div>
            <Textarea
              id="content-text"
              value={text}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => setText(e.target.value)}
              placeholder="Paste or type your content here..."
              className="min-h-[200px] bg-slate-900/50 border-purple-500/30 text-white placeholder:text-purple-300/40 focus:border-purple-400 text-base"
              required
            />
          </div>

          {/* Tone Sliders */}
          <div className="space-y-6 pt-4 border-t border-purple-500/20">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold text-purple-200">
                Customize the feel (optional)
              </h3>
              <Button
                type="button"
                onClick={handleSurpriseMe}
                variant="outline"
                size="sm"
                className="border-purple-500/50 text-purple-300 hover:bg-purple-500/20 hover:text-purple-100"
              >
                <Shuffle className="w-3 h-3 mr-1" />
                Surprise Me
              </Button>
            </div>
            {toneControls.map((tone) => {
              const Icon = tone.icon;
              return (
                <div key={tone.name} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <Label className="text-purple-200 flex items-center gap-2">
                      <Icon className={`w-4 h-4 ${tone.color}`} />
                      {tone.label}
                    </Label>
                    <span className="text-purple-300 text-sm">{tones[tone.name as keyof typeof tones]}%</span>
                  </div>
                  <Slider
                    value={[tones[tone.name as keyof typeof tones]]}
                    onValueChange={(value: number[]) => handleToneChange(tone.name, value)}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              );
            })}
          </div>

          <Button
            type="submit"
            disabled={isLoading || !text.trim()}
            className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-500 hover:to-blue-500 text-white text-lg py-6 shadow-lg shadow-purple-500/30 transition-all duration-300 hover:shadow-purple-500/50"
          >
            {isLoading ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin mr-2"></div>
                Creating your boosted versions...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5 mr-2" />
                Boost My Content
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </form>
  );
}
