export const ONCHAINKIT_PROJECT_ID = 'c1e0e46a-6e01-4baa-b1b5-2a4e0d71d59c';
export const ONCHAINKIT_API_KEY = 'J5y1rZRjPGgXH-PoCxmOYqZjoxQYAYp4';
