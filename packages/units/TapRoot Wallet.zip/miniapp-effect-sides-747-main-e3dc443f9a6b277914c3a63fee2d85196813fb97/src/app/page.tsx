'use client'
import { useEffect, useState, useMemo } from 'react';
import { sdk } from '@farcaster/miniapp-sdk';
import { Brain, Sparkles, MapPin, TrendingUp, Fuel, Bot, Search, Wallet, CheckCircle } from 'lucide-react';
import { TransactionList } from '@/components/wallet/transaction-list';
import { TrustRings } from '@/components/wallet/trust-rings';
import { PeopleNetwork } from '@/components/wallet/people-network';
import { AddressManager } from '@/components/wallet/address-manager';
import { AIChatAssistant } from '@/components/ai/ai-chat-assistant';
import { WalletHealth } from '@/components/ai/wallet-health';
import { AIInsights } from '@/components/ai/ai-insights';
import { NearbyMerchants } from '@/components/geofencing/nearby-merchants';
import { P2PTraders } from '@/components/geofencing/p2p-traders';
import { PortfolioOverview } from '@/components/analytics/portfolio-overview';
import { TaxSummaryCard } from '@/components/analytics/tax-summary';
import { GasOptimizer } from '@/components/analytics/gas-optimizer';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { AddressLabel } from '@/types/wallet';
import type { UserLocation } from '@/types/geofencing';
import { mockTransactions, mockLabels } from '@/lib/mock-data';
import { fetchWalletData, isValidAddress } from '@/lib/blockchain-service';
import type { Transaction } from '@/types/wallet';
import { 
  calculateWalletHealth,
  generateAIInsights,
  calculateTrustNetwork,
  calculateTaxSummary,
  calculateGasOptimization
} from '@/lib/ai-analysis';
import { 
  getUserLocation, 
  getMerchants, 
  getNearbyTraders 
} from '@/lib/geofencing-engine';
import {
  calculatePortfolio
} from '@/lib/analytics-engine';
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function TaprootWallet() {
  const [walletAddress, setWalletAddress] = useState<string>('');
  const [inputAddress, setInputAddress] = useState<string>('');
  const [error, setError] = useState<string>('');
  const [loading, setLoading] = useState<boolean>(false);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [realPortfolio, setRealPortfolio] = useState<any>(null);
  const [activeChains, setActiveChains] = useState<number>(0);
  const [farcasterUsername, setFarcasterUsername] = useState<string | null>(null);
  const [labels, setLabels] = useState<AddressLabel[]>([]);
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [locationEnabled, setLocationEnabled] = useState<boolean>(false);
  const { addMiniApp } = useAddMiniApp();
  const isInFarcaster = useIsInFarcaster();
  useQuickAuth(isInFarcaster);
  
  useEffect(() => {
    const tryAddMiniApp = async () => {
      try {
        await addMiniApp();
      } catch (error) {
        console.error('Failed to add mini app:', error);
      }
    };

    tryAddMiniApp();
  }, [addMiniApp]);
  
  // Load Farcaster context
  useEffect(() => {
    let cancelled = false;
    
    async function loadFarcasterContext() {
      try {
        await sdk.actions.ready();
        const context = await sdk.context;
        if (!cancelled) {
          setFarcasterUsername(context?.user?.username ?? null);
        }
      } catch (error) {
        if (!cancelled) {
          setFarcasterUsername(null);
        }
      }
    }
    
    loadFarcasterContext();
    return () => {
      cancelled = true;
    };
  }, []);
  
  // Get user location for geofencing
  useEffect(() => {
    const loadLocation = async () => {
      const location = await getUserLocation();
      if (location) {
        setUserLocation(location);
        setLocationEnabled(true);
      }
    };
    loadLocation();
  }, []);
  
  // Handle wallet submission
  const handleAnalyze = async () => {
    try {
      if (!inputAddress) {
        setError('Please enter a wallet address');
        return;
      }
      
      if (!isValidAddress(inputAddress) && !/\.eth$/.test(inputAddress)) {
        setError('Please enter a valid wallet address (0x... or ENS name)');
        return;
      }
      
      setError('');
      setLoading(true);
      setWalletAddress(inputAddress);
      
      try {
        // Fetch real blockchain data
        const walletData = await fetchWalletData(inputAddress);
        setTransactions(walletData.transactions);
        setRealPortfolio(walletData.portfolio);
        setActiveChains(walletData.activeChains);
        
        // If no transactions found, show message
        if (walletData.transactions.length === 0) {
          setError('No transactions found for this address. Showing demo data.');
          setTransactions(mockTransactions);
        }
      } catch (err: any) {
        console.error('Error fetching wallet data:', err);
        const errorMessage = err?.message || 'Failed to fetch wallet data. Showing demo data.';
        setError(errorMessage);
        // Fall back to mock data for demo
        setTransactions(mockTransactions);
      }
    } catch (outerErr) {
      console.error('Unexpected error in handleAnalyze:', outerErr);
      setError('An unexpected error occurred. Please try again.');
      setTransactions(mockTransactions);
    } finally {
      setLoading(false);
    }
  };
  
  // Use real transactions or fall back to mock
  const displayTransactions = transactions.length > 0 ? transactions : mockTransactions;
  
  // Calculate trust network from real transactions
  const trustNetwork = useMemo(() => {
    if (!walletAddress || displayTransactions.length === 0) {
      return { contacts: [], labels: [] };
    }
    return calculateTrustNetwork(displayTransactions);
  }, [walletAddress, displayTransactions]);
  
  const trustScores = useMemo(() => {
    return trustNetwork.contacts.map(contact => ({
      address: contact.address,
      score: contact.trustScore,
      ring: contact.trustRing,
      interactions: contact.interactions,
      totalValue: contact.totalValue,
      lastInteraction: contact.lastInteraction
    }));
  }, [trustNetwork]);
  
  const clusters = useMemo(() => {
    // Group contacts by trust ring
    const innerCircle = trustNetwork.contacts.filter(c => c.trustRing === 'inner');
    const regular = trustNetwork.contacts.filter(c => c.trustRing === 'regular');
    const acquaintances = trustNetwork.contacts.filter(c => c.trustRing === 'acquaintance');
    
    return [
      { name: 'Inner Circle', members: innerCircle.map(c => ({ address: c.address, label: c.label })) },
      { name: 'Regular Contacts', members: regular.map(c => ({ address: c.address, label: c.label })) },
      { name: 'Acquaintances', members: acquaintances.map(c => ({ address: c.address, label: c.label })) }
    ].filter(cluster => cluster.members.length > 0);
  }, [trustNetwork]);
  
  // AI and Analytics - using real blockchain data
  const walletHealth = useMemo(() => {
    if (!walletAddress || displayTransactions.length === 0) {
      return { overall: 0, diversification: 0, security: 0, activity: 0, networkQuality: 0, tips: [] };
    }
    return calculateWalletHealth(
      displayTransactions,
      realPortfolio || { totalValue: '0', change24h: '0', changePercent24h: 0, assets: [] },
      activeChains > 0 ? activeChains : new Set(displayTransactions.map(tx => tx.chain.id)).size
    );
  }, [walletAddress, displayTransactions, realPortfolio, activeChains]);
  
  const aiInsights = useMemo(() => {
    if (!walletAddress || displayTransactions.length === 0) {
      return [];
    }
    return generateAIInsights(displayTransactions, walletHealth);
  }, [walletAddress, displayTransactions, walletHealth]);
  
  const gasOptimization = useMemo(() => {
    if (!walletAddress || displayTransactions.length === 0) {
      return { totalGasSpent: '0', averageGasPerTx: '0', potentialSavings: '0', recommendations: [] };
    }
    return calculateGasOptimization(displayTransactions);
  }, [walletAddress, displayTransactions]);
  
  // Use real portfolio if available, otherwise calculate from transactions
  const portfolio = useMemo(() => {
    return realPortfolio || calculatePortfolio(displayTransactions);
  }, [realPortfolio, displayTransactions]);
  
  const taxSummary = useMemo(() => {
    if (!walletAddress || displayTransactions.length === 0) {
      return { totalGains: '0', totalLosses: '0', netGainLoss: '0', taxableEvents: 0, breakdown: [] };
    }
    return calculateTaxSummary(
      displayTransactions,
      realPortfolio || { totalValue: '0', change24h: '0', changePercent24h: 0, assets: [] }
    );
  }, [walletAddress, displayTransactions, realPortfolio]);
  
  // Geofencing
  const nearbyMerchants = useMemo(() => {
    if (!userLocation) return [];
    return getMerchants(userLocation, 5);
  }, [userLocation]);
  
  const nearbyTraders = useMemo(() => {
    if (!userLocation) return [];
    return getNearbyTraders(userLocation, 10);
  }, [userLocation]);
  
  // Merge user-added labels with AI-generated labels from trust network
  const allLabels = useMemo(() => {
    const userLabelMap = new Map(labels.map(l => [l.address, l]));
    const aiLabels = trustNetwork.labels.filter(l => !userLabelMap.has(l.address));
    return [...labels, ...aiLabels];
  }, [labels, trustNetwork]);
  
  const labelMap = useMemo(() => {
    const map = new Map<string, string>();
    allLabels.forEach(label => {
      map.set(label.address, label.label);
    });
    return map;
  }, [allLabels]);
  
  const handleAddLabel = (label: AddressLabel) => {
    setLabels([...labels, label]);
  };
  
  const handleUpdateLabel = (updatedLabel: AddressLabel) => {
    setLabels(labels.map(l => 
      l.address === updatedLabel.address ? updatedLabel : l
    ));
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      {/* Hero Header with Wallet Input */}
      <div className="bg-gradient-to-r from-blue-600 via-indigo-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 py-12">
          {/* Logo and Title */}
          <div className="flex items-center justify-center gap-3 mb-6">
            <div className="w-14 h-14 bg-white/20 backdrop-blur-sm rounded-2xl flex items-center justify-center border border-white/30">
              <Brain className="w-8 h-8 text-white" />
            </div>
            <div className="text-center">
              <h1 className="text-4xl font-bold">Taproot Wallet</h1>
              <p className="text-blue-100 text-sm">Your wallet that remembers everything for you</p>
            </div>
          </div>
          
          {/* Wallet Input */}
          <div className="max-w-2xl mx-auto">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-6 border border-white/20">
              <label className="block text-sm font-medium text-white mb-3 text-center">
                Enter any wallet address to analyze
              </label>
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Input
                    type="text"
                    placeholder="Enter EVM (0x...) or Solana address"
                    value={inputAddress}
                    onChange={(e) => {
                      setInputAddress(e.target.value);
                      setError('');
                    }}
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        handleAnalyze();
                      }
                    }}
                    className="h-14 text-base bg-white border-white/30 pr-12 text-gray-900"
                  />
                  <Search className="absolute right-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                </div>
                <Button 
                  onClick={handleAnalyze}
                  className="h-14 px-8 bg-white text-blue-600 hover:bg-blue-50 font-semibold"
                >
                  Analyze
                </Button>
              </div>
              {error && (
                <p className="text-sm text-red-200 mt-2 text-center">{error}</p>
              )}
              {loading && (
                <div className="flex items-center justify-center gap-2 mt-3 text-blue-200">
                  <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                  <span className="text-sm font-medium">
                    Fetching real blockchain data...
                  </span>
                </div>
              )}
              {walletAddress && !loading && (
                <div className="flex items-center justify-center gap-2 mt-3 text-green-200">
                  <CheckCircle className="w-4 h-4" />
                  <span className="text-sm font-medium">
                    Analyzing: {walletAddress.slice(0, 6)}...{walletAddress.slice(-4)}
                    {transactions.length > 0 ? ` (${transactions.length} real transactions)` : ' (demo data)'}
                  </span>
                </div>
              )}
            </div>
            
            {/* Feature Badges */}
            <div className="flex flex-wrap items-center justify-center gap-2 mt-4">
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                <Bot className="w-3 h-3 mr-1" />
                AI-Powered
              </Badge>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                <Sparkles className="w-3 h-3 mr-1" />
                Multi-Chain
              </Badge>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                <MapPin className="w-3 h-3 mr-1" />
                Geofencing
              </Badge>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                <TrendingUp className="w-3 h-3 mr-1" />
                Tax Reports
              </Badge>
              <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                <Fuel className="w-3 h-3 mr-1" />
                Gas Optimization
              </Badge>
            </div>
          </div>
          
          {/* User Info */}
          {(farcasterUsername || locationEnabled) && (
            <div className="flex items-center justify-center gap-3 mt-4">
              {farcasterUsername && (
                <Badge variant="secondary" className="bg-white/20 text-white border-white/30">
                  @{farcasterUsername}
                </Badge>
              )}
              {locationEnabled && (
                <Badge variant="secondary" className="bg-green-500/20 text-white border-green-400/30">
                  <MapPin className="w-3 h-3 mr-1" />
                  Location Active
                </Badge>
              )}
            </div>
          )}
        </div>
      </div>
      
      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8 pb-20">
        {/* Status Message */}
        {!walletAddress && (
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-6 mb-6 text-center">
            <Wallet className="w-12 h-12 text-blue-500 mx-auto mb-3" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">
              Enter a wallet address above to get started
            </h3>
            <p className="text-gray-600 text-sm">
              View AI insights, trust networks, transaction history, tax summaries, and more
            </p>
          </div>
        )}
        
        {/* Stats Overview */}
        {walletAddress && (
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4 mb-6">
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Health Score</span>
                <Brain className="w-4 h-4 text-blue-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{walletHealth.overall}</p>
              <p className="text-xs text-gray-500">AI-powered rating</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Portfolio</span>
                <TrendingUp className="w-4 h-4 text-green-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">${portfolio?.totalValue || '0.00'}</p>
              <p className={`text-xs ${(portfolio?.changePercent24h || 0) >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                {(portfolio?.changePercent24h || 0) >= 0 ? '+' : ''}{(portfolio?.changePercent24h || 0).toFixed(1)}% 24h
              </p>
            </div>
            
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Chains</span>
                <Sparkles className="w-4 h-4 text-purple-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">
                {activeChains > 0 ? activeChains : new Set(displayTransactions.map(tx => tx.chain.id)).size}
              </p>
              <p className="text-xs text-gray-500">Multi-chain</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Gas Saved</span>
                <Fuel className="w-4 h-4 text-yellow-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{gasOptimization.potentialSavings}</p>
              <p className="text-xs text-gray-500">Potential ETH</p>
            </div>
            
            <div className="bg-white rounded-xl p-4 border border-gray-200 shadow-sm">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-gray-600">Nearby</span>
                <MapPin className="w-4 h-4 text-blue-500" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{nearbyMerchants.length + nearbyTraders.length}</p>
              <p className="text-xs text-gray-500">Places & traders</p>
            </div>
          </div>
        )}
        
        {/* Tabs */}
        <Tabs defaultValue="ai" className="space-y-6">
          <TabsList className="bg-white border border-gray-200 p-1 grid grid-cols-4 md:grid-cols-8 gap-1">
            <TabsTrigger value="ai" className="data-[state=active]:bg-blue-100 text-xs">
              <Bot className="w-3 h-3 md:mr-1" />
              <span className="hidden md:inline">AI</span>
            </TabsTrigger>
            <TabsTrigger value="analytics" className="data-[state=active]:bg-green-100 text-xs">
              <TrendingUp className="w-3 h-3 md:mr-1" />
              <span className="hidden md:inline">Analytics</span>
            </TabsTrigger>
            <TabsTrigger value="location" className="data-[state=active]:bg-purple-100 text-xs">
              <MapPin className="w-3 h-3 md:mr-1" />
              <span className="hidden md:inline">Nearby</span>
            </TabsTrigger>
            <TabsTrigger value="transactions" className="data-[state=active]:bg-indigo-100 text-xs">
              Transactions
            </TabsTrigger>
            <TabsTrigger value="network" className="data-[state=active]:bg-cyan-100 text-xs">
              Network
            </TabsTrigger>
            <TabsTrigger value="trust" className="data-[state=active]:bg-pink-100 text-xs">
              Trust
            </TabsTrigger>
            <TabsTrigger value="memory" className="data-[state=active]:bg-yellow-100 text-xs">
              Memory
            </TabsTrigger>
            <TabsTrigger value="gas" className="data-[state=active]:bg-orange-100 text-xs">
              <Fuel className="w-3 h-3 md:mr-1" />
              <span className="hidden md:inline">Gas</span>
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="ai" className="space-y-4">
            {walletAddress ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <AIChatAssistant transactions={displayTransactions} trustScores={trustScores} />
                <div className="space-y-4">
                  <WalletHealth healthScore={walletHealth} />
                  <AIInsights insights={aiInsights} />
                </div>
              </div>
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Bot className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">AI Features</h3>
                <p className="text-gray-600">
                  Chat assistant, wallet health score, fraud detection, and smart recommendations
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="analytics" className="space-y-4">
            {walletAddress ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <PortfolioOverview portfolio={portfolio} />
                <TaxSummaryCard taxData={taxSummary} />
              </div>
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <TrendingUp className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Analytics & Portfolio</h3>
                <p className="text-gray-600">
                  Real-time portfolio tracking, tax summaries, and performance insights
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="location" className="space-y-4">
            {!locationEnabled && (
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-4">
                <p className="text-sm text-yellow-800">
                  Enable location services to discover crypto-accepting merchants and P2P traders near you.
                </p>
              </div>
            )}
            {walletAddress ? (
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                <NearbyMerchants merchants={nearbyMerchants} />
                <P2PTraders traders={nearbyTraders} />
              </div>
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <MapPin className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Geofencing Features</h3>
                <p className="text-gray-600">
                  Find nearby crypto merchants and P2P traders based on your location
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="transactions" className="space-y-4">
            {walletAddress ? (
              <TransactionList transactions={displayTransactions} labels={labelMap} />
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Wallet className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Transaction History</h3>
                <p className="text-gray-600">
                  Auto-categorized transactions with human-readable stories across all chains
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="network" className="space-y-4">
            {walletAddress ? (
              <PeopleNetwork clusters={clusters} />
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Sparkles className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">People Network</h3>
                <p className="text-gray-600">
                  Automatic clustering of addresses you interact with most
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="trust" className="space-y-4">
            {walletAddress ? (
              <TrustRings trustScores={trustScores} />
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Trust Rings</h3>
                <p className="text-gray-600">
                  Visual representation of your trust network with dynamic scoring
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="memory" className="space-y-4">
            {walletAddress ? (
              <AddressManager
                labels={labels}
                onAddLabel={handleAddLabel}
                onUpdateLabel={handleUpdateLabel}
              />
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Brain className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Memory Layer</h3>
                <p className="text-gray-600">
                  Add labels, notes, tags, reminders, and automations for every address
                </p>
              </div>
            )}
          </TabsContent>
          
          <TabsContent value="gas" className="space-y-4">
            {walletAddress ? (
              <GasOptimizer gasData={gasOptimization} />
            ) : (
              <div className="bg-white rounded-xl p-12 border border-gray-200 text-center">
                <Fuel className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-lg font-semibold text-gray-900 mb-2">Gas Optimization</h3>
                <p className="text-gray-600">
                  AI-powered recommendations to save on transaction costs
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>
      
      {/* Bottom Info */}
      <div className="fixed bottom-0 left-0 right-0 bg-gradient-to-r from-blue-600 to-indigo-600 text-white p-3 text-center">
        <p className="text-sm font-medium">
          ✨ AI-Powered • Multi-chain • Geofencing • Tax Reports • Gas Optimization • ERC-6900 Ready
        </p>
      </div>
    </div>
  );
}
