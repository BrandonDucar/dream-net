'use client'
import { AlertTriangle, Lightbulb, TrendingUp, Gift } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { AIInsight } from '@/types/ai';

type AIInsightsProps = {
  insights: AIInsight[];
};

export function AIInsights({ insights }: AIInsightsProps) {
  const getIcon = (type: AIInsight['type']) => {
    switch (type) {
      case 'warning':
        return AlertTriangle;
      case 'recommendation':
        return Lightbulb;
      case 'prediction':
        return TrendingUp;
      case 'opportunity':
        return Gift;
    }
  };

  const getColor = (type: AIInsight['type']) => {
    switch (type) {
      case 'warning':
        return 'text-red-600 bg-red-100';
      case 'recommendation':
        return 'text-blue-600 bg-blue-100';
      case 'prediction':
        return 'text-purple-600 bg-purple-100';
      case 'opportunity':
        return 'text-green-600 bg-green-100';
    }
  };

  const getPriorityColor = (priority: AIInsight['priority']) => {
    switch (priority) {
      case 'high':
        return 'bg-red-100 text-red-700';
      case 'medium':
        return 'bg-yellow-100 text-yellow-700';
      case 'low':
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <Card className="bg-white border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <h3 className="text-lg font-semibold text-gray-900">AI Insights</h3>
        <p className="text-xs text-gray-500 mt-1">Intelligent recommendations for your wallet</p>
      </div>

      <ScrollArea className="h-[400px] p-4">
        <div className="space-y-3">
          {insights.map(insight => {
            const Icon = getIcon(insight.type);
            const colorClass = getColor(insight.type);

            return (
              <div key={insight.id} className="p-3 rounded-lg border border-gray-200 hover:border-gray-300 transition-colors">
                <div className="flex items-start gap-3">
                  <div className={`p-2 rounded-lg ${colorClass}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <h4 className="text-sm font-semibold text-gray-900">{insight.title}</h4>
                      <Badge variant="secondary" className={`text-xs ${getPriorityColor(insight.priority)}`}>
                        {insight.priority}
                      </Badge>
                    </div>
                    <p className="text-xs text-gray-600 mb-2">{insight.description}</p>
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-gray-500">Confidence:</span>
                        <span className="text-xs font-semibold text-gray-700">
                          {Math.round(insight.confidence * 100)}%
                        </span>
                      </div>
                      {insight.actionable && (
                        <Badge variant="outline" className="text-xs">
                          Actionable
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>
    </Card>
  );
}
