'use client'
import { Shield, TrendingUp, Activity, Users } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import type { WalletHealthScore } from '@/types/ai';

type WalletHealthProps = {
  healthScore: WalletHealthScore;
};

export function WalletHealth({ healthScore }: WalletHealthProps) {
  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number): string => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  const metrics = [
    {
      label: 'Diversification',
      score: healthScore.diversification,
      icon: TrendingUp,
    },
    {
      label: 'Security',
      score: healthScore.security,
      icon: Shield,
    },
    {
      label: 'Activity',
      score: healthScore.activity,
      icon: Activity,
    },
    {
      label: 'Network',
      score: healthScore.networkQuality,
      icon: Users,
    },
  ];

  return (
    <Card className="bg-white border border-gray-200 shadow-sm p-6">
      <div className="text-center mb-6">
        <div className={`text-6xl font-bold ${getScoreColor(healthScore.overall)} mb-2`}>
          {healthScore.overall}
        </div>
        <h3 className="text-xl font-semibold text-gray-900">Wallet Health Score</h3>
        <p className="text-sm text-gray-500">Your onchain wellness rating</p>
      </div>

      <div className="space-y-6">
        {metrics.map(metric => {
          const Icon = metric.icon;
          return (
            <div key={metric.label}>
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-gray-600" />
                  <span className="text-sm font-medium text-gray-700">{metric.label}</span>
                </div>
                <span className={`text-sm font-bold ${getScoreColor(metric.score)}`}>
                  {metric.score}
                </span>
              </div>
              <Progress value={metric.score} className="h-2" />
            </div>
          );
        })}
      </div>

      <div className="mt-6 pt-6 border-t border-gray-200">
        <h4 className="text-sm font-semibold text-gray-900 mb-3">Health Tips</h4>
        <div className="space-y-2">
          {healthScore.breakdown.slice(0, 3).map((item, idx) => (
            <div key={idx} className="text-xs text-gray-600 flex items-start gap-2">
              <span className={`mt-0.5 w-1.5 h-1.5 rounded-full ${getScoreBgColor(item.score)}`} />
              <span>{item.tips[0]}</span>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
}
