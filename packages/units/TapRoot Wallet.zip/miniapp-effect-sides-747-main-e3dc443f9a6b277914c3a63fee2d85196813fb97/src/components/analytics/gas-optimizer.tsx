'use client'
import { Fuel, Lightbulb, TrendingDown } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { GasOptimization } from '@/types/ai';

type GasOptimizerProps = {
  gasData: GasOptimization;
};

export function GasOptimizer({ gasData }: GasOptimizerProps) {
  return (
    <Card className="bg-white border border-gray-200 shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Gas Optimization</h3>
          <p className="text-xs text-gray-500 mt-1">Reduce your transaction costs</p>
        </div>
        <Fuel className="w-5 h-5 text-gray-400" />
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-red-50 rounded-lg p-4">
          <p className="text-xs text-red-600 mb-1">Current Spending</p>
          <p className="text-2xl font-bold text-red-700">{gasData.currentGasSpent} ETH</p>
        </div>
        <div className="bg-green-50 rounded-lg p-4">
          <p className="text-xs text-green-600 mb-1">Potential Savings</p>
          <p className="text-2xl font-bold text-green-700">{gasData.potentialSavings} ETH</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center gap-2 mb-3">
          <Lightbulb className="w-4 h-4 text-yellow-500" />
          <h4 className="text-sm font-semibold text-gray-700">Recommendations</h4>
        </div>

        {gasData.recommendations.map((rec, idx) => (
          <div key={idx} className="p-3 bg-gray-50 rounded-lg">
            <div className="flex items-start justify-between gap-2 mb-2">
              <h5 className="text-sm font-semibold text-gray-900">{rec.title}</h5>
              <Badge variant="secondary" className="bg-green-100 text-green-700 text-xs">
                <TrendingDown className="w-3 h-3 mr-1" />
                {rec.estimatedSavings} ETH
              </Badge>
            </div>
            <p className="text-xs text-gray-600">{rec.description}</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
