'use client'
import { TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import type { PortfolioData } from '@/types/analytics';

type PortfolioOverviewProps = {
  portfolio: PortfolioData;
};

export function PortfolioOverview({ portfolio }: PortfolioOverviewProps) {
  const isPositiveChange = portfolio.changePercent24h >= 0;

  return (
    <Card className="bg-white border border-gray-200 shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">Portfolio Value</h3>
        <DollarSign className="w-5 h-5 text-gray-400" />
      </div>

      <div className="mb-6">
        <div className="text-3xl font-bold text-gray-900 mb-2">
          ${portfolio.totalValue}
        </div>
        <div className={`flex items-center gap-1 text-sm ${isPositiveChange ? 'text-green-600' : 'text-red-600'}`}>
          {isPositiveChange ? (
            <TrendingUp className="w-4 h-4" />
          ) : (
            <TrendingDown className="w-4 h-4" />
          )}
          <span className="font-semibold">
            {isPositiveChange ? '+' : ''}{portfolio.changePercent24h.toFixed(2)}%
          </span>
          <span className="text-gray-500">({isPositiveChange ? '+' : ''}${portfolio.change24h})</span>
        </div>
      </div>

      <div className="space-y-4">
        <h4 className="text-sm font-semibold text-gray-700">Asset Allocation</h4>
        {portfolio.assets.map(asset => (
          <div key={asset.token}>
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <span className="text-sm font-medium text-gray-700">{asset.token}</span>
                <span className="text-xs text-gray-500">{asset.amount}</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold text-gray-900">${asset.value}</span>
                <span className={`text-xs ${asset.change24h >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {asset.change24h >= 0 ? '+' : ''}{asset.change24h.toFixed(1)}%
                </span>
              </div>
            </div>
            <Progress value={asset.allocation} className="h-2" />
            <p className="text-xs text-gray-500 mt-1">{asset.allocation.toFixed(1)}% of portfolio</p>
          </div>
        ))}
      </div>
    </Card>
  );
}
