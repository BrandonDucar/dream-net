'use client'
import { FileText, TrendingUp, TrendingDown, Calculator } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import type { TaxSummary } from '@/types/analytics';

type TaxSummaryProps = {
  taxData: TaxSummary;
};

export function TaxSummaryCard({ taxData }: TaxSummaryProps) {
  const netIsPositive = parseFloat(taxData.netGainLoss) >= 0;

  return (
    <Card className="bg-white border border-gray-200 shadow-sm p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">Tax Summary</h3>
          <p className="text-xs text-gray-500 mt-1">Year {taxData.year}</p>
        </div>
        <FileText className="w-5 h-5 text-gray-400" />
      </div>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <TrendingUp className="w-4 h-4 text-green-600" />
            <span className="text-xs text-gray-600">Gains</span>
          </div>
          <p className="text-lg font-bold text-green-600">${taxData.totalGains}</p>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <TrendingDown className="w-4 h-4 text-red-600" />
            <span className="text-xs text-gray-600">Losses</span>
          </div>
          <p className="text-lg font-bold text-red-600">${taxData.totalLosses}</p>
        </div>

        <div className="text-center">
          <div className="flex items-center justify-center gap-1 mb-1">
            <Calculator className="w-4 h-4 text-blue-600" />
            <span className="text-xs text-gray-600">Net</span>
          </div>
          <p className={`text-lg font-bold ${netIsPositive ? 'text-green-600' : 'text-red-600'}`}>
            ${taxData.netGainLoss}
          </p>
        </div>
      </div>

      <Separator className="my-4" />

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Total Transactions</span>
          <Badge variant="secondary">{taxData.transactions}</Badge>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-sm text-gray-600">Taxable Events</span>
          <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
            {taxData.taxableEvents}
          </Badge>
        </div>
      </div>

      <Separator className="my-4" />

      <div className="space-y-2">
        <h4 className="text-sm font-semibold text-gray-700 mb-3">By Category</h4>
        {taxData.categories.map(cat => (
          <div key={cat.category} className="flex items-center justify-between text-xs">
            <span className="text-gray-600 capitalize">{cat.category}</span>
            <div className="flex items-center gap-2">
              <span className="text-green-600">+${cat.gains}</span>
              <span className="text-gray-400">/</span>
              <span className="text-red-600">-${cat.losses}</span>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}
