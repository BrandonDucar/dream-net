'use client'
import { MapPin, Star, Check } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { MerchantLocation } from '@/types/geofencing';

type NearbyMerchantsProps = {
  merchants: MerchantLocation[];
};

export function NearbyMerchants({ merchants }: NearbyMerchantsProps) {
  return (
    <Card className="bg-white border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Nearby Merchants</h3>
            <p className="text-xs text-gray-500 mt-1">Crypto-accepting stores near you</p>
          </div>
          <Badge variant="secondary" className="bg-green-100 text-green-700">
            {merchants.length} nearby
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[400px]">
        <div className="divide-y divide-gray-200">
          {merchants.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <MapPin className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">No merchants found nearby</p>
              <p className="text-xs text-gray-400 mt-1">Enable location to discover crypto-friendly stores</p>
            </div>
          ) : (
            merchants.map(merchant => (
              <div key={merchant.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-semibold text-gray-900">{merchant.name}</h4>
                      {merchant.verified && (
                        <Check className="w-4 h-4 text-green-500" />
                      )}
                    </div>
                    <p className="text-xs text-gray-600 mb-2">{merchant.address}</p>
                    <div className="flex items-center gap-2 mb-2">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-600">
                          {merchant.distance.toFixed(1)} km
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                        <span className="text-xs text-gray-600">{merchant.rating}</span>
                      </div>
                    </div>
                    <div className="flex flex-wrap gap-1">
                      {merchant.acceptedTokens.map(token => (
                        <Badge key={token} variant="secondary" className="text-xs">
                          {token}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs">
                    {merchant.category}
                  </Badge>
                </div>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
