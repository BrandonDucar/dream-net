'use client'
import { Users, MapPin, Star, Circle } from 'lucide-react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Button } from '@/components/ui/button';
import type { P2PTrader } from '@/types/geofencing';

type P2PTradersProps = {
  traders: P2PTrader[];
};

export function P2PTraders({ traders }: P2PTradersProps) {
  return (
    <Card className="bg-white border border-gray-200 shadow-sm">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Nearby P2P Traders</h3>
            <p className="text-xs text-gray-500 mt-1">Connect with verified traders for cash exchanges</p>
          </div>
          <Badge variant="secondary" className="bg-blue-100 text-blue-700">
            {traders.filter(t => t.online).length} online
          </Badge>
        </div>
      </div>

      <ScrollArea className="h-[400px]">
        <div className="divide-y divide-gray-200">
          {traders.length === 0 ? (
            <div className="p-8 text-center text-gray-500">
              <Users className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p className="text-sm">No traders found nearby</p>
              <p className="text-xs text-gray-400 mt-1">Enable location to find P2P traders</p>
            </div>
          ) : (
            traders.map(trader => (
              <div key={trader.id} className="p-4 hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between gap-3 mb-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="text-sm font-semibold text-gray-900">{trader.username}</h4>
                      <Circle
                        className={`w-2 h-2 ${
                          trader.online ? 'fill-green-500 text-green-500' : 'fill-gray-300 text-gray-300'
                        }`}
                      />
                    </div>
                    <p className="text-xs text-gray-600 font-mono mb-2">{trader.walletAddress}</p>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-gray-400" />
                        <span className="text-xs text-gray-600">
                          {trader.distance.toFixed(1)} km away
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                        <span className="text-xs text-gray-600">{trader.rating}</span>
                      </div>
                      <span className="text-xs text-gray-500">
                        {trader.completedTrades} trades
                      </span>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Preferred Tokens:</p>
                    <div className="flex flex-wrap gap-1">
                      {trader.preferredTokens.map(token => (
                        <Badge key={token} variant="secondary" className="text-xs">
                          {token}
                        </Badge>
                      ))}
                    </div>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Payment Methods:</p>
                    <div className="flex flex-wrap gap-1">
                      {trader.paymentMethods.map(method => (
                        <Badge key={method} variant="outline" className="text-xs">
                          {method}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-3 text-xs"
                  disabled={!trader.online}
                >
                  {trader.online ? 'Initiate Trade' : 'Offline'}
                </Button>
              </div>
            ))
          )}
        </div>
      </ScrollArea>
    </Card>
  );
}
