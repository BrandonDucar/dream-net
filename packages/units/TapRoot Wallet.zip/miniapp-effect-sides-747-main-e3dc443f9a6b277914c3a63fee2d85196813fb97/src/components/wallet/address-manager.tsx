'use client';

import { useState } from 'react';
import type { AddressLabel } from '@/types/wallet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label as UILabel } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Tag, Bell, Zap, Edit, Plus } from 'lucide-react';

type AddressManagerProps = {
  labels: AddressLabel[];
  onAddLabel: (label: AddressLabel) => void;
  onUpdateLabel: (label: AddressLabel) => void;
};

export function AddressManager({ labels, onAddLabel, onUpdateLabel }: AddressManagerProps) {
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedLabel, setSelectedLabel] = useState<AddressLabel | null>(null);
  
  const handleEdit = (label: AddressLabel) => {
    setSelectedLabel(label);
    setIsDialogOpen(true);
  };
  
  const handleNew = () => {
    setSelectedLabel(null);
    setIsDialogOpen(true);
  };
  
  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Tag className="w-5 h-5" />
            Address Memory
          </CardTitle>
          <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" onClick={handleNew}>
                <Plus className="w-4 h-4 mr-1" />
                Add Label
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>
                  {selectedLabel ? 'Edit Address' : 'Add New Address'}
                </DialogTitle>
              </DialogHeader>
              <AddressForm
                label={selectedLabel}
                onSave={(label) => {
                  if (selectedLabel) {
                    onUpdateLabel(label);
                  } else {
                    onAddLabel(label);
                  }
                  setIsDialogOpen(false);
                }}
              />
            </DialogContent>
          </Dialog>
        </div>
        <p className="text-sm text-gray-500">
          Labels, notes, reminders, and automations for your addresses
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {labels.map((label) => (
            <div
              key={label.address}
              className="p-4 rounded-lg border bg-white hover:bg-gray-50 transition-colors"
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-gray-900">{label.label}</h3>
                    {label.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                  <p className="text-xs font-mono text-gray-500 mb-2">
                    {label.address}
                  </p>
                  {label.notes && (
                    <p className="text-sm text-gray-600 mb-2">{label.notes}</p>
                  )}
                </div>
                <Button
                  size="sm"
                  variant="ghost"
                  onClick={() => handleEdit(label)}
                >
                  <Edit className="w-4 h-4" />
                </Button>
              </div>
              
              {label.reminders && label.reminders.length > 0 && (
                <div className="flex items-start gap-2 mb-2">
                  <Bell className="w-4 h-4 text-blue-500 mt-0.5" />
                  <div className="flex-1">
                    {label.reminders.map((reminder, i) => (
                      <p key={i} className="text-xs text-blue-600">
                        {reminder}
                      </p>
                    ))}
                  </div>
                </div>
              )}
              
              {label.automations && label.automations.length > 0 && (
                <div className="flex items-start gap-2">
                  <Zap className="w-4 h-4 text-yellow-500 mt-0.5" />
                  <div className="flex-1">
                    {label.automations.map((automation, i) => (
                      <p key={i} className="text-xs text-gray-600">
                        <span className="font-medium">{automation.type}:</span>{' '}
                        {automation.condition} → {automation.action}
                      </p>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}

function AddressForm({
  label,
  onSave,
}: {
  label: AddressLabel | null;
  onSave: (label: AddressLabel) => void;
}) {
  const [formData, setFormData] = useState<AddressLabel>(
    label || {
      address: '',
      label: '',
      notes: '',
      tags: [],
      reminders: [],
      automations: [],
    }
  );
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };
  
  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <UILabel htmlFor="address">Address</UILabel>
        <Input
          id="address"
          value={formData.address}
          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
          placeholder="0x..."
          required
        />
      </div>
      
      <div>
        <UILabel htmlFor="label">Label</UILabel>
        <Input
          id="label"
          value={formData.label}
          onChange={(e) => setFormData({ ...formData, label: e.target.value })}
          placeholder="Alice, Uniswap, etc."
          required
        />
      </div>
      
      <div>
        <UILabel htmlFor="notes">Notes</UILabel>
        <Textarea
          id="notes"
          value={formData.notes}
          onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
          placeholder="Add notes about this address..."
        />
      </div>
      
      <div>
        <UILabel htmlFor="tags">Tags (comma-separated)</UILabel>
        <Input
          id="tags"
          value={formData.tags.join(', ')}
          onChange={(e) =>
            setFormData({ ...formData, tags: e.target.value.split(',').map(t => t.trim()) })
          }
          placeholder="friend, defi, trusted"
        />
      </div>
      
      <Button type="submit" className="w-full">
        Save Address
      </Button>
    </form>
  );
}
