'use client';

import type { AddressCluster } from '@/types/wallet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Users, TrendingUp, Activity } from 'lucide-react';

type PeopleNetworkProps = {
  clusters: AddressCluster[];
};

export function PeopleNetwork({ clusters }: PeopleNetworkProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="w-5 h-5" />
          People Clusters
        </CardTitle>
        <p className="text-sm text-gray-500">
          Your contacts automatically organized by interaction patterns
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {clusters.map((cluster, index) => (
            <div
              key={index}
              className="p-4 rounded-lg border bg-gradient-to-br from-white to-gray-50 hover:shadow-md transition-shadow"
            >
              <div className="flex items-start justify-between mb-3">
                <div>
                  <h3 className="font-semibold text-lg text-gray-900">
                    {cluster.clusterName}
                  </h3>
                  <p className="text-sm text-gray-500">{cluster.category}</p>
                </div>
                <Badge variant="secondary" className="bg-blue-100 text-blue-700">
                  {cluster.addresses.length} addresses
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-3 mb-3">
                <div className="flex items-center gap-2 text-sm">
                  <Activity className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">
                    {cluster.totalInteractions} interactions
                  </span>
                </div>
                <div className="flex items-center gap-2 text-sm">
                  <TrendingUp className="w-4 h-4 text-gray-400" />
                  <span className="text-gray-600">
                    {Math.round(cluster.avgTrustScore)} avg trust
                  </span>
                </div>
              </div>
              
              <div className="flex flex-wrap gap-1">
                {cluster.addresses.slice(0, 5).map((addr, i) => (
                  <div
                    key={i}
                    className="px-2 py-1 bg-white rounded text-xs font-mono text-gray-600 border"
                  >
                    {addr.slice(0, 6)}...{addr.slice(-4)}
                  </div>
                ))}
                {cluster.addresses.length > 5 && (
                  <div className="px-2 py-1 bg-gray-200 rounded text-xs text-gray-600">
                    +{cluster.addresses.length - 5} more
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
