'use client';

import type { Transaction, AddressLabel } from '@/types/wallet';
import { getCategoryColor, getRelativeTime, formatAddress, generateTransactionStory } from '@/lib/wallet-utils';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ArrowUpRight, ArrowDownRight, CheckCircle } from 'lucide-react';

type TransactionListProps = {
  transactions: Transaction[];
  labels: Map<string, string>;
};

export function TransactionList({ transactions, labels }: TransactionListProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <span>Transaction History</span>
          <Badge variant="secondary">{transactions.length}</Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {transactions.map((tx) => {
            const story = generateTransactionStory(tx, labels);
            const isOutgoing = tx.from.toLowerCase().includes('742d35cc');
            
            return (
              <div
                key={tx.id}
                className="flex items-start gap-3 p-3 rounded-lg border bg-white hover:bg-gray-50 transition-colors"
              >
                <div className={`p-2 rounded-full ${isOutgoing ? 'bg-red-100' : 'bg-green-100'}`}>
                  {isOutgoing ? (
                    <ArrowUpRight className="w-4 h-4 text-red-600" />
                  ) : (
                    <ArrowDownRight className="w-4 h-4 text-green-600" />
                  )}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2 mb-1">
                    <p className="text-sm font-medium text-gray-900">{story}</p>
                    <Badge className={getCategoryColor(tx.category)} variant="secondary">
                      {tx.category}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-2 text-xs text-gray-500 flex-wrap">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-white text-[10px] font-medium ${tx.chain.color}`}>
                      {tx.chain.name}
                    </span>
                    <span className="flex items-center gap-1">
                      <CheckCircle className="w-3 h-3 text-green-600" />
                      {tx.status}
                    </span>
                    <span>•</span>
                    <span>{getRelativeTime(tx.timestamp)}</span>
                    <span>•</span>
                    <span className="font-mono">{formatAddress(tx.hash)}</span>
                  </div>
                  
                  <div className="mt-1 text-xs text-gray-400">
                    Gas: {tx.gasUsed} ETH
                  </div>
                </div>
                
                <div className="text-right">
                  <p className={`text-sm font-semibold ${isOutgoing ? 'text-red-600' : 'text-green-600'}`}>
                    {isOutgoing ? '-' : '+'}{tx.value} {tx.token?.symbol || 'ETH'}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
}
