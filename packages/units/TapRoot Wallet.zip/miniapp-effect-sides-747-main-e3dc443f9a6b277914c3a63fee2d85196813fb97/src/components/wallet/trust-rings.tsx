'use client';

import type { TrustScore } from '@/types/wallet';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { getRingColor, formatAddress } from '@/lib/wallet-utils';
import { Shield, TrendingUp, Calendar } from 'lucide-react';

type TrustRingsProps = {
  trustScores: TrustScore[];
};

export function TrustRings({ trustScores }: TrustRingsProps) {
  const innerCircle = trustScores.filter(ts => ts.ring === 'inner');
  const midCircle = trustScores.filter(ts => ts.ring === 'mid');
  const outerCircle = trustScores.filter(ts => ts.ring === 'outer');
  
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="w-5 h-5" />
          Trust Rings
        </CardTitle>
        <p className="text-sm text-gray-500">
          Your network organized by trust and interaction frequency
        </p>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Inner Circle */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-3 h-3 rounded-full ${getRingColor('inner')}`} />
              <h3 className="font-semibold text-sm">Inner Circle</h3>
              <Badge variant="secondary" className="bg-green-100 text-green-700">
                {innerCircle.length} addresses
              </Badge>
            </div>
            <div className="space-y-2 pl-5">
              {innerCircle.map((ts) => (
                <TrustScoreCard key={ts.address} trustScore={ts} />
              ))}
            </div>
          </div>
          
          {/* Mid Circle */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-3 h-3 rounded-full ${getRingColor('mid')}`} />
              <h3 className="font-semibold text-sm">Regular Contacts</h3>
              <Badge variant="secondary" className="bg-yellow-100 text-yellow-700">
                {midCircle.length} addresses
              </Badge>
            </div>
            <div className="space-y-2 pl-5">
              {midCircle.map((ts) => (
                <TrustScoreCard key={ts.address} trustScore={ts} />
              ))}
            </div>
          </div>
          
          {/* Outer Circle */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <div className={`w-3 h-3 rounded-full ${getRingColor('outer')}`} />
              <h3 className="font-semibold text-sm">Acquaintances</h3>
              <Badge variant="secondary" className="bg-gray-100 text-gray-700">
                {outerCircle.length} addresses
              </Badge>
            </div>
            <div className="space-y-2 pl-5">
              {outerCircle.slice(0, 3).map((ts) => (
                <TrustScoreCard key={ts.address} trustScore={ts} />
              ))}
              {outerCircle.length > 3 && (
                <p className="text-xs text-gray-400">
                  +{outerCircle.length - 3} more addresses
                </p>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function TrustScoreCard({ trustScore }: { trustScore: TrustScore }) {
  return (
    <div className="flex items-center justify-between p-2 rounded bg-gray-50 hover:bg-gray-100 transition-colors">
      <div className="flex items-center gap-2 flex-1 min-w-0">
        <div className={`w-2 h-2 rounded-full ${getRingColor(trustScore.ring)}`} />
        <span className="font-mono text-sm truncate">
          {formatAddress(trustScore.address)}
        </span>
      </div>
      
      <div className="flex items-center gap-3 text-xs text-gray-500">
        <div className="flex items-center gap-1">
          <TrendingUp className="w-3 h-3" />
          <span>{trustScore.score}</span>
        </div>
        <div className="flex items-center gap-1">
          <Calendar className="w-3 h-3" />
          <span>{trustScore.interactions}x</span>
        </div>
      </div>
    </div>
  );
}
