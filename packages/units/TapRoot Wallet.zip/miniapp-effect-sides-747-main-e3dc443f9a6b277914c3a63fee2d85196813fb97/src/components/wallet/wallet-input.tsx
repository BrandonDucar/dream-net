'use client'

import { useState } from 'react';
import { Search, Wallet } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

interface WalletInputProps {
  onSubmit: (address: string) => void;
}

export function WalletInput({ onSubmit }: WalletInputProps) {
  const [address, setAddress] = useState<string>('');
  const [error, setError] = useState<string>('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!address) {
      setError('Please enter a wallet address');
      return;
    }
    
    // Check if it looks like an Ethereum address
    if (!/^0x[a-fA-F0-9]{40}$/.test(address) && !/\.eth$/.test(address)) {
      setError('Please enter a valid wallet address (0x... or ENS name)');
      return;
    }
    
    setError('');
    onSubmit(address);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center p-4">
      <Card className="max-w-lg w-full">
        <CardContent className="pt-8 pb-8 px-6">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Wallet className="w-8 h-8 text-white" />
            </div>
            <h1 className="text-3xl font-bold text-gray-900 mb-2">Taproot Wallet</h1>
            <p className="text-gray-600">
              Your wallet that remembers everything for you
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label htmlFor="wallet-address" className="block text-sm font-medium text-gray-700 mb-2">
                Enter any wallet address
              </label>
              <div className="relative">
                <Input
                  id="wallet-address"
                  type="text"
                  placeholder="0x... or name.eth"
                  value={address}
                  onChange={(e) => {
                    setAddress(e.target.value);
                    setError('');
                  }}
                  className="pr-10 bg-white border-gray-300 h-12 text-base"
                />
                <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
              </div>
              {error && (
                <p className="text-sm text-red-600 mt-2">{error}</p>
              )}
            </div>

            <Button 
              type="submit" 
              className="w-full h-12 text-base bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              Analyze Wallet
            </Button>
          </form>

          <div className="mt-6 pt-6 border-t border-gray-200">
            <p className="text-xs text-gray-500 text-center">
              Works with all EVM chains: Ethereum, Base, Polygon, Arbitrum, Optimism, and more
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
