import type { Transaction, TrustScore } from '@/types/wallet';
import type { AIInsight, FraudDetection, WalletHealthScore, GasOptimization } from '@/types/ai';

// Fraud detection patterns
const SCAM_PATTERNS = ['phishing', 'honeypot', 'rugpull', 'fake', 'scam'];
const SUSPICIOUS_PROTOCOLS = ['unknown', 'unverified', 'new'];

export function detectFraud(address: string, transactions: Transaction[]): FraudDetection {
  const reasons: string[] = [];
  let riskScore = 0;
  
  const addressLower = address.toLowerCase();
  const txsWithAddress = transactions.filter(
    tx => tx.to.toLowerCase() === addressLower || tx.from.toLowerCase() === addressLower
  );
  
  // Check for suspicious patterns
  if (SCAM_PATTERNS.some(pattern => addressLower.includes(pattern))) {
    reasons.push('Address contains suspicious keywords');
    riskScore += 40;
  }
  
  // Check for unusual transaction patterns
  if (txsWithAddress.length === 0) {
    reasons.push('No transaction history found');
    riskScore += 20;
  }
  
  // Check for rapid high-value transactions
  const recentHighValue = txsWithAddress.filter(
    tx => parseFloat(tx.value) > 5 && Date.now() - tx.timestamp < 3600000
  );
  if (recentHighValue.length > 3) {
    reasons.push('Unusual high-value transaction velocity');
    riskScore += 30;
  }
  
  let riskLevel: 'high' | 'medium' | 'low' = 'low';
  if (riskScore >= 60) riskLevel = 'high';
  else if (riskScore >= 30) riskLevel = 'medium';
  
  if (reasons.length === 0) {
    reasons.push('No suspicious activity detected');
  }
  
  return {
    address,
    riskLevel,
    reasons,
    confidence: Math.min(riskScore, 100) / 100,
  };
}

export function generateAIInsights(
  transactions: Transaction[],
  trustScores: TrustScore[]
): AIInsight[] {
  const insights: AIInsight[] = [];
  const now = Date.now();
  
  // Analyze transaction patterns
  const swaps = transactions.filter(tx => tx.category === 'swap');
  if (swaps.length > 5) {
    insights.push({
      id: 'insight-1',
      type: 'recommendation',
      title: 'High Swap Activity Detected',
      description: `You've made ${swaps.length} swaps. Consider using limit orders to reduce slippage and gas costs.`,
      confidence: 0.85,
      priority: 'medium',
      actionable: true,
      timestamp: now,
    });
  }
  
  // Analyze gas spending
  const totalGas = transactions.reduce((sum, tx) => sum + parseFloat(tx.gasUsed), 0);
  if (totalGas > 0.1) {
    insights.push({
      id: 'insight-2',
      type: 'opportunity',
      title: 'Gas Optimization Opportunity',
      description: `You've spent ${totalGas.toFixed(4)} ETH on gas. Batching transactions could save up to 40%.`,
      confidence: 0.92,
      priority: 'high',
      actionable: true,
      timestamp: now,
    });
  }
  
  // Analyze diversification
  const uniqueProtocols = new Set(transactions.map(tx => tx.to));
  if (uniqueProtocols.size < 3) {
    insights.push({
      id: 'insight-3',
      type: 'recommendation',
      title: 'Limited Protocol Diversity',
      description: 'Consider exploring more protocols to diversify your DeFi strategy and reduce risk.',
      confidence: 0.78,
      priority: 'low',
      actionable: true,
      timestamp: now,
    });
  }
  
  // Predict next action
  const recentCategories = transactions
    .slice(0, 5)
    .map(tx => tx.category);
  const mostCommon = recentCategories.reduce((a, b, i, arr) =>
    arr.filter(v => v === a).length >= arr.filter(v => v === b).length ? a : b
  );
  
  insights.push({
    id: 'insight-4',
    type: 'prediction',
    title: 'Predicted Next Action',
    description: `Based on your patterns, you're likely to perform a ${mostCommon} transaction next.`,
    confidence: 0.73,
    priority: 'low',
    actionable: false,
    timestamp: now,
  });
  
  // Security warning for high-value transfers
  const highValueTransfers = transactions.filter(
    tx => tx.category === 'transfer' && parseFloat(tx.value) > 10
  );
  if (highValueTransfers.length > 0) {
    insights.push({
      id: 'insight-5',
      type: 'warning',
      title: 'High-Value Transfer Alert',
      description: 'Always verify recipient addresses for large transfers. Consider using a hardware wallet.',
      confidence: 0.95,
      priority: 'high',
      actionable: true,
      timestamp: now,
    });
  }
  
  return insights.sort((a, b) => b.confidence - a.confidence);
}

export function calculateWalletHealth(
  transactions: Transaction[],
  trustScores: TrustScore[]
): WalletHealthScore {
  // Calculate diversification (0-100)
  const uniqueChains = new Set(transactions.map(tx => tx.chain.id)).size;
  const uniqueProtocols = new Set(transactions.map(tx => tx.to)).size;
  const diversification = Math.min(((uniqueChains * 10) + (uniqueProtocols * 5)) / 1.5, 100);
  
  // Calculate security (0-100)
  const hasHighValueTxs = transactions.some(tx => parseFloat(tx.value) > 10);
  const hasMultipleProtocols = uniqueProtocols > 5;
  const security = hasHighValueTxs && hasMultipleProtocols ? 75 : 90;
  
  // Calculate activity (0-100)
  const recentTxs = transactions.filter(
    tx => Date.now() - tx.timestamp < 30 * 24 * 60 * 60 * 1000
  ).length;
  const activity = Math.min((recentTxs / transactions.length) * 100, 100);
  
  // Calculate network quality (0-100)
  const innerCircle = trustScores.filter(ts => ts.ring === 'inner').length;
  const totalConnections = trustScores.length;
  const networkQuality = totalConnections > 0 
    ? ((innerCircle / totalConnections) * 100) + 20
    : 50;
  
  const overall = (diversification + security + activity + networkQuality) / 4;
  
  return {
    overall: Math.round(overall),
    diversification: Math.round(diversification),
    security: Math.round(security),
    activity: Math.round(activity),
    networkQuality: Math.round(networkQuality),
    breakdown: [
      {
        category: 'Diversification',
        score: Math.round(diversification),
        tips: [
          uniqueChains < 3 ? 'Try using more chains' : 'Great chain diversity!',
          uniqueProtocols < 5 ? 'Explore more DeFi protocols' : 'Excellent protocol coverage!',
        ],
      },
      {
        category: 'Security',
        score: Math.round(security),
        tips: [
          'Always verify addresses before sending',
          'Consider using a hardware wallet for large amounts',
        ],
      },
      {
        category: 'Activity',
        score: Math.round(activity),
        tips: [
          recentTxs < 5 ? 'Your wallet has been quiet lately' : 'Active wallet usage detected!',
        ],
      },
      {
        category: 'Network Quality',
        score: Math.round(networkQuality),
        tips: [
          innerCircle < 3 ? 'Build stronger connections with frequent contacts' : 'Strong trust network!',
        ],
      },
    ],
  };
}

export function optimizeGas(transactions: Transaction[]): GasOptimization {
  const totalGasSpent = transactions.reduce(
    (sum, tx) => sum + parseFloat(tx.gasUsed),
    0
  );
  
  // Estimate potential savings
  const batchableTxs = transactions.filter(
    tx => tx.category === 'swap' || tx.category === 'transfer'
  ).length;
  const potentialSavings = (totalGasSpent * 0.3).toFixed(4);
  
  const recommendations = [
    {
      title: 'Batch Transactions',
      description: `You have ${batchableTxs} transactions that could be batched, saving up to 40% on gas.`,
      estimatedSavings: (totalGasSpent * 0.4 * (batchableTxs / transactions.length)).toFixed(4),
    },
    {
      title: 'Use Layer 2 Solutions',
      description: 'Move frequent transactions to Base, Arbitrum, or Optimism for 10-100x lower fees.',
      estimatedSavings: (totalGasSpent * 0.9).toFixed(4),
    },
    {
      title: 'Time Your Transactions',
      description: 'Execute transactions during off-peak hours (late night UTC) for lower gas prices.',
      estimatedSavings: (totalGasSpent * 0.2).toFixed(4),
    },
  ];
  
  return {
    currentGasSpent: totalGasSpent.toFixed(4),
    potentialSavings,
    recommendations,
  };
}

// Natural language query processing
export function processNaturalLanguageQuery(
  query: string,
  transactions: Transaction[],
  trustScores: TrustScore[]
): string {
  const lowerQuery = query.toLowerCase();
  
  // Transaction queries
  if (lowerQuery.includes('how many') && lowerQuery.includes('transaction')) {
    return `You have ${transactions.length} total transactions across all chains.`;
  }
  
  if (lowerQuery.includes('swap')) {
    const swaps = transactions.filter(tx => tx.category === 'swap');
    return `You've made ${swaps.length} swaps with a total value of ${swaps.reduce((sum, tx) => sum + parseFloat(tx.value), 0).toFixed(2)} tokens.`;
  }
  
  if (lowerQuery.includes('gas') || lowerQuery.includes('fee')) {
    const totalGas = transactions.reduce((sum, tx) => sum + parseFloat(tx.gasUsed), 0);
    return `You've spent ${totalGas.toFixed(4)} ETH on gas fees across ${transactions.length} transactions.`;
  }
  
  if (lowerQuery.includes('trust') || lowerQuery.includes('friend')) {
    const inner = trustScores.filter(ts => ts.ring === 'inner').length;
    return `You have ${inner} addresses in your inner circle and ${trustScores.length} total trusted contacts.`;
  }
  
  if (lowerQuery.includes('chain')) {
    const chains = new Set(transactions.map(tx => tx.chain.name));
    return `You're active on ${chains.size} chains: ${Array.from(chains).join(', ')}.`;
  }
  
  // Default response
  return `I found ${transactions.length} transactions and ${trustScores.length} trusted addresses. Try asking about swaps, gas fees, trust scores, or chains!`;
}
