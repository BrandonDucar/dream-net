import type { Transaction } from '@/types/wallet';
import type { PortfolioData, TaxSummary, SmartMoneyTracker, TransactionPattern } from '@/types/analytics';

export function calculatePortfolio(transactions: Transaction[]): PortfolioData {
  const assetMap = new Map<string, { amount: number; value: number; change24h: number }>();
  
  transactions.forEach(tx => {
    const symbol = tx.token?.symbol || 'ETH';
    const amount = parseFloat(tx.value);
    const existing = assetMap.get(symbol) || { amount: 0, value: 0, change24h: 0 };
    
    assetMap.set(symbol, {
      amount: existing.amount + amount,
      value: existing.value + amount,
      change24h: Math.random() * 10 - 5, // Mock 24h change
    });
  });
  
  const totalValue = Array.from(assetMap.values()).reduce((sum, asset) => sum + asset.value, 0);
  const change24h = Array.from(assetMap.values()).reduce(
    (sum, asset) => sum + (asset.value * asset.change24h) / 100,
    0
  );
  
  // Prevent division by zero
  const safeTotal = totalValue || 1;
  
  const assets = Array.from(assetMap.entries()).map(([token, data]) => ({
    token,
    amount: data.amount.toFixed(4),
    value: data.value.toFixed(2),
    change24h: data.change24h,
    allocation: totalValue > 0 ? (data.value / safeTotal) * 100 : 0,
  }));
  
  return {
    totalValue: totalValue.toFixed(2),
    change24h: change24h.toFixed(2),
    changePercent24h: totalValue > 0 ? (change24h / totalValue) * 100 : 0,
    assets,
  };
}

export function generateTaxSummary(transactions: Transaction[], year: number): TaxSummary {
  const yearStart = new Date(year, 0, 1).getTime();
  const yearEnd = new Date(year, 11, 31, 23, 59, 59).getTime();
  
  const yearTxs = transactions.filter(
    tx => tx.timestamp >= yearStart && tx.timestamp <= yearEnd
  );
  
  // Simplified tax calculation (in production, this would be much more complex)
  let totalGains = 0;
  let totalLosses = 0;
  const categoryMap = new Map<string, { gains: number; losses: number }>();
  
  yearTxs.forEach(tx => {
    const value = parseFloat(tx.value);
    const mockGainLoss = (Math.random() - 0.5) * value * 0.2; // Mock gain/loss
    
    if (mockGainLoss > 0) {
      totalGains += mockGainLoss;
    } else {
      totalLosses += Math.abs(mockGainLoss);
    }
    
    const existing = categoryMap.get(tx.category) || { gains: 0, losses: 0 };
    categoryMap.set(tx.category, {
      gains: existing.gains + (mockGainLoss > 0 ? mockGainLoss : 0),
      losses: existing.losses + (mockGainLoss < 0 ? Math.abs(mockGainLoss) : 0),
    });
  });
  
  const categories = Array.from(categoryMap.entries()).map(([category, data]) => ({
    category,
    gains: data.gains.toFixed(2),
    losses: data.losses.toFixed(2),
  }));
  
  return {
    year,
    totalGains: totalGains.toFixed(2),
    totalLosses: totalLosses.toFixed(2),
    netGainLoss: (totalGains - totalLosses).toFixed(2),
    transactions: yearTxs.length,
    taxableEvents: yearTxs.filter(tx => tx.category !== 'transfer').length,
    categories,
  };
}

export function getSmartMoneyTrackers(): SmartMoneyTracker[] {
  // Mock smart money data (in production, this would come from chain analysis)
  return [
    {
      address: '0x1234...whale',
      label: 'Top ETH Whale',
      category: 'whale',
      recentActivity: 'Bought 500 ETH 2h ago',
      profitLoss: '+$2.4M (30d)',
      copiedBy: 1247,
    },
    {
      address: '0x5678...smart',
      label: 'DeFi Alpha Hunter',
      category: 'smart',
      recentActivity: 'Entered new yield farm',
      profitLoss: '+$180K (30d)',
      copiedBy: 532,
    },
    {
      address: '0x9abc...inst',
      label: 'Institutional Treasury',
      category: 'institutional',
      recentActivity: 'Accumulated stablecoins',
      profitLoss: '+$5.2M (30d)',
      copiedBy: 89,
    },
  ];
}

export function detectTransactionPatterns(transactions: Transaction[]): TransactionPattern[] {
  const patterns: TransactionPattern[] = [];
  const categoryMap = new Map<string, Transaction[]>();
  
  // Group by category
  transactions.forEach(tx => {
    const existing = categoryMap.get(tx.category) || [];
    categoryMap.set(tx.category, [...existing, tx]);
  });
  
  // Analyze patterns
  categoryMap.forEach((txs, category) => {
    if (txs.length < 2) return;
    
    const sortedTxs = [...txs].sort((a, b) => a.timestamp - b.timestamp);
    const avgValue = txs.reduce((sum, tx) => sum + parseFloat(tx.value), 0) / txs.length;
    const intervals = [];
    
    for (let i = 1; i < sortedTxs.length; i++) {
      intervals.push(sortedTxs[i].timestamp - sortedTxs[i - 1].timestamp);
    }
    
    const avgInterval = intervals.reduce((a, b) => a + b, 0) / intervals.length;
    const lastTx = sortedTxs[sortedTxs.length - 1];
    const nextPredicted = lastTx.timestamp + avgInterval;
    
    patterns.push({
      pattern: `Regular ${category} transactions`,
      frequency: txs.length,
      averageValue: avgValue.toFixed(4),
      lastOccurrence: lastTx.timestamp,
      prediction: {
        nextOccurrence: nextPredicted,
        confidence: Math.min(txs.length / 10, 0.95),
      },
    });
  });
  
  return patterns.sort((a, b) => b.frequency - a.frequency);
}
