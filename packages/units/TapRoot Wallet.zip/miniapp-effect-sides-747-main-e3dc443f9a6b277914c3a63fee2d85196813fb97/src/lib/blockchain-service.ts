import type { Transaction, TransactionCategory } from '@/types/wallet';
import type { PortfolioData } from '@/types/analytics';

// Chain configurations with their explorer APIs
const CHAIN_CONFIGS = {
  ethereum: {
    id: 1,
    name: 'Ethereum',
    color: 'bg-blue-500',
    apiUrl: 'https://api.etherscan.io/api',
    nativeToken: 'ETH',
  },
  base: {
    id: 8453,
    name: 'Base',
    color: 'bg-blue-600',
    apiUrl: 'https://api.basescan.org/api',
    nativeToken: 'ETH',
  },
  polygon: {
    id: 137,
    name: 'Polygon',
    color: 'bg-purple-600',
    apiUrl: 'https://api.polygonscan.com/api',
    nativeToken: 'MATIC',
  },
  arbitrum: {
    id: 42161,
    name: 'Arbitrum',
    color: 'bg-cyan-600',
    apiUrl: 'https://api.arbiscan.io/api',
    nativeToken: 'ETH',
  },
  optimism: {
    id: 10,
    name: 'Optimism',
    color: 'bg-red-500',
    apiUrl: 'https://api-optimistic.etherscan.io/api',
    nativeToken: 'ETH',
  },
  avalanche: {
    id: 43114,
    name: 'Avalanche',
    color: 'bg-red-600',
    apiUrl: 'https://api.snowtrace.io/api',
    nativeToken: 'AVAX',
  },
  bsc: {
    id: 56,
    name: 'BNB Chain',
    color: 'bg-yellow-500',
    apiUrl: 'https://api.bscscan.com/api',
    nativeToken: 'BNB',
  },
  solana: {
    id: 101,
    name: 'Solana',
    color: 'bg-gradient-to-r from-purple-500 to-pink-500',
    apiUrl: 'https://api.mainnet-beta.solana.com',
    nativeToken: 'SOL',
  },
} as const;

type ChainKey = keyof typeof CHAIN_CONFIGS;

// Protocol signatures for auto-categorization
const PROTOCOL_PATTERNS: Record<string, { category: TransactionCategory; keywords: string[] }> = {
  defi: {
    category: 'defi',
    keywords: ['aave', 'compound', 'curve', 'yearn', 'maker', 'lido', 'rocket', 'convex', 'marinade', 'solend', 'raydium'],
  },
  swap: {
    category: 'swap',
    keywords: ['uniswap', 'sushiswap', 'pancakeswap', '1inch', 'paraswap', 'cowswap', '0x', 'jupiter', 'orca', 'serum'],
  },
  nft: {
    category: 'nft',
    keywords: ['opensea', 'blur', 'looksrare', 'rarible', 'foundation', 'superrare', 'seaport', 'magic eden', 'solanart', 'tensor'],
  },
  bridge: {
    category: 'bridge',
    keywords: ['bridge', 'hop', 'stargate', 'synapse', 'across', 'celer', 'multichain', 'wormhole', 'allbridge', 'portal'],
  },
  social: {
    category: 'social',
    keywords: ['lens', 'farcaster', 'mirror', 'cyberconnect', 'guild', 'dialect', 'grape'],
  },
};

/**
 * Categorizes a transaction based on the `to` address or function signature
 */
function categorizeTransaction(to: string, functionName?: string): TransactionCategory {
  const toAddress = to.toLowerCase();
  const funcName = (functionName || '').toLowerCase();
  
  // Check protocol patterns
  for (const pattern of Object.values(PROTOCOL_PATTERNS)) {
    if (pattern.keywords.some(keyword => 
      toAddress.includes(keyword) || funcName.includes(keyword)
    )) {
      return pattern.category;
    }
  }
  
  // Check if it's a simple transfer (no input data or just basic transfer)
  if (!functionName || functionName === '' || functionName === 'transfer') {
    return 'transfer';
  }
  
  return 'unknown';
}

/**
 * Fetches native token balance for an address on a specific chain
 */
async function fetchBalance(
  address: string,
  chainKey: ChainKey
): Promise<string> {
  try {
    const config = CHAIN_CONFIGS[chainKey];
    const url = new URL(config.apiUrl);
    const queryString = `?module=account&action=balance&address=${address}&tag=latest`;
    
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: url.hostname,
        path: url.pathname + queryString,
        method: 'GET',
        headers: {},
      }),
      signal: AbortSignal.timeout(8000), // 8 second timeout
    });
    
    const data = await response.json();
    if (data.status === '1' && data.result) {
      // Convert from wei to ether (18 decimals)
      const balance = parseFloat(data.result) / 1e18;
      return balance.toFixed(6);
    }
    return '0';
  } catch (error) {
    console.error(`Error fetching balance for ${chainKey}:`, error);
    return '0';
  }
}

/**
 * Fetches transaction history for an address on a specific chain
 */
async function fetchTransactions(
  address: string,
  chainKey: ChainKey
): Promise<Transaction[]> {
  try {
    const config = CHAIN_CONFIGS[chainKey];
    const url = new URL(config.apiUrl);
    const queryString = `?module=account&action=txlist&address=${address}&startblock=0&endblock=99999999&page=1&offset=50&sort=desc`;
    
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: url.hostname,
        path: url.pathname + queryString,
        method: 'GET',
        headers: {},
      }),
      signal: AbortSignal.timeout(8000),
    });
    
    const data = await response.json();
    
    if (data.status === '1' && Array.isArray(data.result)) {
      return data.result.map((tx: any) => {
        const category = categorizeTransaction(tx.to, tx.functionName);
        const value = (parseFloat(tx.value) / 1e18).toFixed(6);
        
        return {
          id: tx.hash,
          hash: tx.hash,
          from: tx.from,
          to: tx.to,
          value,
          timestamp: parseInt(tx.timeStamp) * 1000,
          category,
          status: tx.txreceipt_status === '1' ? 'success' : 'failed',
          gasUsed: (parseFloat(tx.gasUsed) * parseFloat(tx.gasPrice) / 1e18).toFixed(6),
          chain: {
            name: config.name,
            id: config.id,
            color: config.color,
          },
          token: {
            symbol: config.nativeToken,
            name: config.nativeToken,
          },
        } as Transaction;
      });
    }
    
    return [];
  } catch (error) {
    console.error(`Error fetching transactions for ${chainKey}:`, error);
    return [];
  }
}

/**
 * Fetches ERC-20 token balances for an address on a specific chain
 */
async function fetchTokenBalances(
  address: string,
  chainKey: ChainKey
): Promise<Array<{ token: string; amount: string; contractAddress: string }>> {
  try {
    const config = CHAIN_CONFIGS[chainKey];
    const url = new URL(config.apiUrl);
    const queryString = `?module=account&action=tokentx&address=${address}&startblock=0&endblock=99999999&page=1&offset=100&sort=desc`;
    
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: url.hostname,
        path: url.pathname + queryString,
        method: 'GET',
        headers: {},
      }),
    });
    
    const data = await response.json();
    
    if (data.status === '1' && Array.isArray(data.result)) {
      // Group by token contract and get unique tokens
      const tokenMap = new Map<string, { symbol: string; decimals: string }>();
      
      data.result.forEach((tx: any) => {
        if (!tokenMap.has(tx.contractAddress)) {
          tokenMap.set(tx.contractAddress, {
            symbol: tx.tokenSymbol,
            decimals: tx.tokenDecimal,
          });
        }
      });
      
      // For now, return a sample of unique tokens found in transactions
      // In a production app, you'd fetch actual current balances via balanceOf calls
      return Array.from(tokenMap.entries()).slice(0, 5).map(([address, info]) => ({
        token: info.symbol,
        amount: '0', // Would need actual balance call
        contractAddress: address,
      }));
    }
    
    return [];
  } catch (error) {
    console.error(`Error fetching token balances for ${chainKey}:`, error);
    return [];
  }
}

/**
 * Fetches token prices from CoinGecko
 */
async function fetchTokenPrices(
  tokenSymbols: string[]
): Promise<Record<string, number>> {
  try {
    // CoinGecko coin IDs mapping
    const symbolToId: Record<string, string> = {
      'ETH': 'ethereum',
      'MATIC': 'matic-network',
      'AVAX': 'avalanche-2',
      'BNB': 'binancecoin',
      'SOL': 'solana',
    };
    
    const ids = tokenSymbols
      .map(symbol => symbolToId[symbol.toUpperCase()])
      .filter(Boolean)
      .join(',');
    
    if (!ids) return {};
    
    const queryString = `?ids=${ids}&vs_currencies=usd&include_24hr_change=true`;
    
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.coingecko.com',
        path: '/api/v3/simple/price' + queryString,
        method: 'GET',
        headers: {},
      }),
      signal: AbortSignal.timeout(8000),
    });
    
    const data = await response.json();
    const prices: Record<string, number> = {};
    
    // Map back to symbols
    Object.entries(symbolToId).forEach(([symbol, id]) => {
      if (data[id]?.usd) {
        prices[symbol] = data[id].usd;
      }
    });
    
    return prices;
  } catch (error) {
    console.error('Error fetching token prices:', error);
    return {};
  }
}

/**
 * Fetches Solana balance
 */
async function fetchSolanaBalance(address: string): Promise<string> {
  try {
    const response = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.mainnet-beta.solana.com',
        path: '',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: {
          jsonrpc: '2.0',
          id: 1,
          method: 'getBalance',
          params: [address]
        }
      }),
      signal: AbortSignal.timeout(8000),
    });
    
    const data = await response.json();
    if (data.result?.value !== undefined) {
      // Convert lamports to SOL (9 decimals)
      const balance = data.result.value / 1e9;
      return balance.toFixed(6);
    }
    return '0';
  } catch (error) {
    console.error('Error fetching Solana balance:', error);
    return '0';
  }
}

/**
 * Fetches Solana transaction history
 */
async function fetchSolanaTransactions(address: string): Promise<Transaction[]> {
  try {
    // First, get signatures for address
    const sigResponse = await fetch('/api/proxy', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        protocol: 'https',
        origin: 'api.mainnet-beta.solana.com',
        path: '',
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: {
          jsonrpc: '2.0',
          id: 1,
          method: 'getSignaturesForAddress',
          params: [address, { limit: 30 }]
        }
      }),
    });
    
    const sigData = await sigResponse.json();
    if (!sigData.result || !Array.isArray(sigData.result)) {
      return [];
    }
    
    // Fetch details for each transaction (limited to first 10 to avoid rate limits)
    const transactions: Transaction[] = [];
    const signatures = sigData.result.slice(0, 10);
    
    for (const sig of signatures) {
      try {
        const txResponse = await fetch('/api/proxy', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            protocol: 'https',
            origin: 'api.mainnet-beta.solana.com',
            path: '',
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: {
              jsonrpc: '2.0',
              id: 1,
              method: 'getTransaction',
              params: [
                sig.signature,
                {
                  encoding: 'jsonParsed',
                  maxSupportedTransactionVersion: 0
                }
              ]
            }
          }),
        });
        
        const txData = await txResponse.json();
        if (txData.result) {
          const tx = txData.result;
          const meta = tx.meta;
          const message = tx.transaction?.message;
          
          // Try to determine transaction type from instructions
          let category: TransactionCategory = 'transfer';
          const instructions = message?.instructions || [];
          
          // Check for known program IDs
          for (const instruction of instructions) {
            const programId = instruction.programId?.toString() || '';
            if (programId.includes('JUP') || programId.includes('Raydium') || programId.includes('Orca')) {
              category = 'swap';
              break;
            } else if (programId.includes('metaplex') || programId.includes('auction')) {
              category = 'nft';
              break;
            } else if (programId.includes('Marinade') || programId.includes('Solend')) {
              category = 'defi';
              break;
            }
          }
          
          // Calculate SOL amount transferred
          const preBalance = meta?.preBalances?.[0] || 0;
          const postBalance = meta?.postBalances?.[0] || 0;
          const value = Math.abs((postBalance - preBalance) / 1e9).toFixed(6);
          
          transactions.push({
            id: sig.signature,
            hash: sig.signature,
            from: message?.accountKeys?.[0]?.pubkey?.toString() || address,
            to: message?.accountKeys?.[1]?.pubkey?.toString() || 'N/A',
            value,
            timestamp: sig.blockTime ? sig.blockTime * 1000 : Date.now(),
            category,
            status: meta?.err ? 'failed' : 'success',
            gasUsed: ((meta?.fee || 0) / 1e9).toFixed(6),
            chain: {
              name: 'Solana',
              id: 101,
              color: 'bg-gradient-to-r from-purple-500 to-pink-500',
            },
            token: {
              symbol: 'SOL',
              name: 'Solana',
            },
          });
        }
      } catch (txError) {
        console.error('Error fetching Solana transaction details:', txError);
      }
    }
    
    return transactions;
  } catch (error) {
    console.error('Error fetching Solana transactions:', error);
    return [];
  }
}

/**
 * Detects if an address is Solana or EVM
 */
function detectAddressType(address: string): 'solana' | 'evm' | 'invalid' {
  // EVM addresses: 0x followed by 40 hex characters
  if (/^0x[a-fA-F0-9]{40}$/.test(address)) {
    return 'evm';
  }
  
  // Solana addresses: base58 encoded, typically 32-44 characters
  // Check for valid base58 characters (no 0, O, I, l)
  if (/^[1-9A-HJ-NP-Za-km-z]{32,44}$/.test(address)) {
    return 'solana';
  }
  
  return 'invalid';
}

/**
 * Main function to fetch all wallet data across multiple chains
 */
export async function fetchWalletData(address: string): Promise<{
  transactions: Transaction[];
  portfolio: PortfolioData;
  activeChains: number;
}> {
  try {
    // Detect address type
    const addressType = detectAddressType(address);
    
    if (addressType === 'invalid') {
      throw new Error('Invalid wallet address format. Please enter a valid EVM (0x...) or Solana address.');
    }
    
    let allTransactions: Transaction[] = [];
    let balances: Array<{ chain: string; balance: string; token: string }> = [];
  
  if (addressType === 'solana') {
    // Fetch Solana data only
    const [solTransactions, solBalance] = await Promise.all([
      fetchSolanaTransactions(address),
      fetchSolanaBalance(address),
    ]);
    
    allTransactions = solTransactions;
    if (parseFloat(solBalance) > 0) {
      balances.push({
        chain: 'solana',
        balance: solBalance,
        token: 'SOL',
      });
    }
  } else {
    // Fetch EVM data from all chains
    const evmChainKeys = (Object.keys(CHAIN_CONFIGS) as ChainKey[]).filter(k => k !== 'solana');
    
    const [transactionResults, balanceResults] = await Promise.all([
      Promise.all(evmChainKeys.map(chain => fetchTransactions(address, chain))),
      Promise.all(evmChainKeys.map(chain => fetchBalance(address, chain))),
    ]);
    
    // Flatten transactions from all EVM chains
    allTransactions = transactionResults.flat();
    
    // Build balances
    balances = evmChainKeys.map((chain, i) => ({
      chain,
      balance: balanceResults[i],
      token: CHAIN_CONFIGS[chain].nativeToken,
    })).filter(b => parseFloat(b.balance) > 0);
  }
  
  // Sort by timestamp (most recent first)
  allTransactions.sort((a, b) => b.timestamp - a.timestamp);
  
  // Fetch prices for tokens
  const uniqueTokens = [...new Set(balances.map(b => b.token))];
  const prices = await fetchTokenPrices(uniqueTokens);
  
  // Calculate portfolio
  let totalValue = 0;
  const assets = balances.map(b => {
    const price = prices[b.token] || 0;
    const value = parseFloat(b.balance) * price;
    totalValue += value;
    
    return {
      token: b.token,
      amount: b.balance,
      value: value.toFixed(2),
      change24h: 0, // Would come from price API
      allocation: 0, // Will calculate after total
    };
  });
  
  // Calculate allocations
  assets.forEach(asset => {
    asset.allocation = totalValue > 0 ? (parseFloat(asset.value) / totalValue) * 100 : 0;
  });
  
  const portfolio: PortfolioData = {
    totalValue: totalValue.toFixed(2),
    change24h: '0',
    changePercent24h: 0,
    assets,
  };
  
    return {
      transactions: allTransactions,
      portfolio,
      activeChains: balances.length,
    };
  } catch (error) {
    console.error('Error in fetchWalletData:', error);
    // Return empty but valid data structure
    return {
      transactions: [],
      portfolio: {
        totalValue: '0.00',
        change24h: '0.00',
        changePercent24h: 0,
        assets: [],
      },
      activeChains: 0,
    };
  }
}

/**
 * Checks if an address is valid (EVM or Solana)
 */
export function isValidAddress(address: string): boolean {
  return detectAddressType(address) !== 'invalid';
}

/**
 * Shortens an address for display
 */
export function shortenAddress(address: string): string {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}
