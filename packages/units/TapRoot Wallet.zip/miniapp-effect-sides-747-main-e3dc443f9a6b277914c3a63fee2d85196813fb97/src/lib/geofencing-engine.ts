import type { MerchantLocation, P2PTrader, LocationAlert, UserLocation } from '@/types/geofencing';

// Calculate distance between two points using Haversine formula
function calculateDistance(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLon / 2) *
    Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Mock merchant data (in production, this would come from an API)
export function getMerchants(userLocation: UserLocation, radius: number = 5): MerchantLocation[] {
  const mockMerchants: Omit<MerchantLocation, 'distance'>[] = [
    {
      id: 'm1',
      name: 'Crypto Coffee',
      address: '123 Blockchain Blvd, SF',
      latitude: userLocation.latitude + 0.01,
      longitude: userLocation.longitude + 0.01,
      acceptedTokens: ['ETH', 'USDC', 'USDT'],
      category: 'Food & Drink',
      rating: 4.8,
      verified: true,
    },
    {
      id: 'm2',
      name: 'Web3 Electronics',
      address: '456 DeFi Drive, SF',
      latitude: userLocation.latitude + 0.02,
      longitude: userLocation.longitude - 0.01,
      acceptedTokens: ['ETH', 'USDC', 'DAI', 'BTC'],
      category: 'Electronics',
      rating: 4.6,
      verified: true,
    },
    {
      id: 'm3',
      name: 'Base Builder Supplies',
      address: '789 Layer2 Lane, SF',
      latitude: userLocation.latitude - 0.01,
      longitude: userLocation.longitude + 0.02,
      acceptedTokens: ['ETH', 'USDC'],
      category: 'Hardware',
      rating: 4.9,
      verified: true,
    },
    {
      id: 'm4',
      name: 'NFT Art Gallery',
      address: '321 Token Trail, SF',
      latitude: userLocation.latitude + 0.03,
      longitude: userLocation.longitude + 0.01,
      acceptedTokens: ['ETH', 'WETH'],
      category: 'Art & Culture',
      rating: 4.7,
      verified: true,
    },
  ];
  
  return mockMerchants
    .map(merchant => ({
      ...merchant,
      distance: calculateDistance(
        userLocation.latitude,
        userLocation.longitude,
        merchant.latitude,
        merchant.longitude
      ),
    }))
    .filter(merchant => merchant.distance <= radius)
    .sort((a, b) => a.distance - b.distance);
}

// Mock P2P trader data
export function getNearbyTraders(userLocation: UserLocation, radius: number = 10): P2PTrader[] {
  const mockTraders: Omit<P2PTrader, 'distance'>[] = [
    {
      id: 't1',
      username: 'cryptowhale42',
      walletAddress: '0x1234...5678',
      latitude: userLocation.latitude + 0.015,
      longitude: userLocation.longitude - 0.01,
      rating: 4.9,
      completedTrades: 156,
      preferredTokens: ['USDC', 'USDT', 'DAI'],
      paymentMethods: ['Cash', 'Venmo', 'Bank Transfer'],
      online: true,
    },
    {
      id: 't2',
      username: 'defi_dave',
      walletAddress: '0xabcd...efgh',
      latitude: userLocation.latitude - 0.02,
      longitude: userLocation.longitude + 0.015,
      rating: 4.7,
      completedTrades: 89,
      preferredTokens: ['ETH', 'USDC'],
      paymentMethods: ['Cash', 'PayPal'],
      online: true,
    },
    {
      id: 't3',
      username: 'base_builder',
      walletAddress: '0x9876...4321',
      latitude: userLocation.latitude + 0.025,
      longitude: userLocation.longitude + 0.02,
      rating: 5.0,
      completedTrades: 234,
      preferredTokens: ['ETH', 'USDC', 'USDT', 'DAI'],
      paymentMethods: ['Cash', 'Zelle', 'Bank Transfer'],
      online: false,
    },
  ];
  
  return mockTraders
    .map(trader => ({
      ...trader,
      distance: calculateDistance(
        userLocation.latitude,
        userLocation.longitude,
        trader.latitude,
        trader.longitude
      ),
    }))
    .filter(trader => trader.distance <= radius)
    .sort((a, b) => a.distance - b.distance);
}

// Get user's location (browser geolocation)
export async function getUserLocation(): Promise<UserLocation | null> {
  if (!navigator.geolocation) {
    return null;
  }
  
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (position) => {
        resolve({
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: Date.now(),
        });
      },
      () => {
        resolve(null);
      }
    );
  });
}

// Check if user is within an alert zone
export function checkLocationAlerts(
  userLocation: UserLocation,
  alerts: LocationAlert[]
): LocationAlert[] {
  return alerts.filter(alert => {
    if (!alert.enabled) return false;
    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      alert.latitude,
      alert.longitude
    );
    return distance <= alert.radius;
  });
}

// Mock location alerts
export function getDefaultLocationAlerts(userLocation: UserLocation): LocationAlert[] {
  return [
    {
      id: 'alert-1',
      type: 'merchant',
      title: 'Crypto-Friendly Zone',
      message: '5+ merchants accepting crypto within 1km',
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      radius: 1,
      enabled: true,
    },
    {
      id: 'alert-2',
      type: 'trader',
      title: 'P2P Trading Hub',
      message: 'Multiple verified traders available nearby',
      latitude: userLocation.latitude + 0.01,
      longitude: userLocation.longitude + 0.01,
      radius: 2,
      enabled: true,
    },
  ];
}
