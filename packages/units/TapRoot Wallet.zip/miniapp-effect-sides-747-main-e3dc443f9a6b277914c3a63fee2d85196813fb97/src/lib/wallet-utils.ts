import type { Transaction, TransactionCategory, TrustScore, AddressCluster } from '@/types/wallet';

export function categorizeTransaction(tx: Transaction): TransactionCategory {
  const lowerTo = tx.to.toLowerCase();
  
  // DeFi protocols
  if (lowerTo.includes('uniswap') || lowerTo.includes('aave') || lowerTo.includes('compound')) {
    return 'defi';
  }
  
  // NFT marketplaces
  if (lowerTo.includes('opensea') || lowerTo.includes('blur') || lowerTo.includes('x2y2')) {
    return 'nft';
  }
  
  // Swap aggregators
  if (lowerTo.includes('swap') || lowerTo.includes('1inch') || lowerTo.includes('0x')) {
    return 'swap';
  }
  
  // Bridges
  if (lowerTo.includes('bridge') || lowerTo.includes('hop') || lowerTo.includes('across')) {
    return 'bridge';
  }
  
  // Social protocols
  if (lowerTo.includes('lens') || lowerTo.includes('farcaster') || lowerTo.includes('friend')) {
    return 'social';
  }
  
  // Default to transfer
  return 'transfer';
}

export function generateTransactionStory(tx: Transaction, labels: Map<string, string>): string {
  const fromLabel = labels.get(tx.from) || formatAddress(tx.from);
  const toLabel = labels.get(tx.to) || formatAddress(tx.to);
  const amount = parseFloat(tx.value).toFixed(4);
  const token = tx.token?.symbol || 'ETH';
  
  const stories: Record<TransactionCategory, string> = {
    defi: `You provided ${amount} ${token} to a DeFi protocol (${toLabel})`,
    nft: `You purchased an NFT from ${toLabel} for ${amount} ${token}`,
    transfer: `You sent ${amount} ${token} to ${toLabel}`,
    swap: `You swapped ${amount} ${token} using ${toLabel}`,
    bridge: `You bridged ${amount} ${token} via ${toLabel}`,
    social: `You interacted with ${toLabel} on a social protocol`,
    unknown: `You sent ${amount} ${token} to ${toLabel}`,
  };
  
  return stories[tx.category] || stories.unknown;
}

export function calculateTrustScore(
  address: string,
  transactions: Transaction[],
  currentTime: number
): TrustScore {
  const relevantTxs = transactions.filter(
    tx => tx.to === address || tx.from === address
  );
  
  const interactions = relevantTxs.length;
  const totalValue = relevantTxs.reduce((sum, tx) => sum + parseFloat(tx.value), 0);
  
  const firstTx = relevantTxs.reduce(
    (earliest, tx) => Math.min(earliest, tx.timestamp),
    currentTime
  );
  const lastTx = relevantTxs.reduce(
    (latest, tx) => Math.max(latest, tx.timestamp),
    0
  );
  
  // Calculate score based on: frequency, recency, total value
  const frequencyScore = Math.min(interactions / 10, 1) * 40;
  const recencyScore = Math.max(0, 1 - (currentTime - lastTx) / (365 * 24 * 60 * 60 * 1000)) * 30;
  const valueScore = Math.min(totalValue / 10, 1) * 30;
  
  const score = frequencyScore + recencyScore + valueScore;
  
  // Determine ring based on score
  let ring: 'inner' | 'mid' | 'outer' = 'outer';
  if (score >= 70) ring = 'inner';
  else if (score >= 40) ring = 'mid';
  
  return {
    address,
    score: Math.round(score),
    ring,
    interactions,
    totalValue: totalValue.toFixed(4),
    firstInteraction: firstTx,
    lastInteraction: lastTx,
  };
}

export function clusterAddresses(trustScores: TrustScore[]): AddressCluster[] {
  // Simple clustering by trust ring
  const clusters: AddressCluster[] = [];
  
  const innerAddresses = trustScores.filter(ts => ts.ring === 'inner');
  const midAddresses = trustScores.filter(ts => ts.ring === 'mid');
  const outerAddresses = trustScores.filter(ts => ts.ring === 'outer');
  
  if (innerAddresses.length > 0) {
    clusters.push({
      addresses: innerAddresses.map(ts => ts.address),
      clusterName: 'Core Circle',
      totalInteractions: innerAddresses.reduce((sum, ts) => sum + ts.interactions, 0),
      avgTrustScore: innerAddresses.reduce((sum, ts) => sum + ts.score, 0) / innerAddresses.length,
      category: 'Frequent & Trusted',
    });
  }
  
  if (midAddresses.length > 0) {
    clusters.push({
      addresses: midAddresses.map(ts => ts.address),
      clusterName: 'Regular Contacts',
      totalInteractions: midAddresses.reduce((sum, ts) => sum + ts.interactions, 0),
      avgTrustScore: midAddresses.reduce((sum, ts) => sum + ts.score, 0) / midAddresses.length,
      category: 'Occasional Interactions',
    });
  }
  
  if (outerAddresses.length > 0) {
    clusters.push({
      addresses: outerAddresses.map(ts => ts.address),
      clusterName: 'Acquaintances',
      totalInteractions: outerAddresses.reduce((sum, ts) => sum + ts.interactions, 0),
      avgTrustScore: outerAddresses.reduce((sum, ts) => sum + ts.score, 0) / outerAddresses.length,
      category: 'Few Interactions',
    });
  }
  
  return clusters;
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
}

export function getRelativeTime(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;
  
  const seconds = Math.floor(diff / 1000);
  const minutes = Math.floor(seconds / 60);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  
  if (days > 0) return `${days}d ago`;
  if (hours > 0) return `${hours}h ago`;
  if (minutes > 0) return `${minutes}m ago`;
  return 'just now';
}

export function getCategoryColor(category: TransactionCategory): string {
  const colors: Record<TransactionCategory, string> = {
    defi: 'bg-blue-100 text-blue-700',
    nft: 'bg-purple-100 text-purple-700',
    transfer: 'bg-green-100 text-green-700',
    swap: 'bg-yellow-100 text-yellow-700',
    bridge: 'bg-orange-100 text-orange-700',
    social: 'bg-pink-100 text-pink-700',
    unknown: 'bg-gray-100 text-gray-700',
  };
  
  return colors[category];
}

export function getRingColor(ring: 'inner' | 'mid' | 'outer'): string {
  const colors = {
    inner: 'bg-green-500',
    mid: 'bg-yellow-500',
    outer: 'bg-gray-400',
  };
  
  return colors[ring];
}
