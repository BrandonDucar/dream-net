export type AIInsight = {
  id: string;
  type: 'warning' | 'recommendation' | 'prediction' | 'opportunity';
  title: string;
  description: string;
  confidence: number;
  priority: 'high' | 'medium' | 'low';
  actionable: boolean;
  timestamp: number;
};

export type FraudDetection = {
  address: string;
  riskLevel: 'high' | 'medium' | 'low';
  reasons: string[];
  confidence: number;
};

export type AIQuery = {
  query: string;
  results: {
    type: 'transaction' | 'address' | 'insight';
    data: unknown;
    relevance: number;
  }[];
};

export type WalletHealthScore = {
  overall: number;
  diversification: number;
  security: number;
  activity: number;
  networkQuality: number;
  breakdown: {
    category: string;
    score: number;
    tips: string[];
  }[];
};

export type GasOptimization = {
  currentGasSpent: string;
  potentialSavings: string;
  recommendations: {
    title: string;
    description: string;
    estimatedSavings: string;
  }[];
};
