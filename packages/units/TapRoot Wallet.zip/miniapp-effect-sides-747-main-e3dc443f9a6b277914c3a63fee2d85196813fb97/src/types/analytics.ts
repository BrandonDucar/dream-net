export type PortfolioData = {
  totalValue: string;
  change24h: string;
  changePercent24h: number;
  assets: {
    token: string;
    amount: string;
    value: string;
    change24h: number;
    allocation: number;
  }[];
};

export type TaxSummary = {
  year: number;
  totalGains: string;
  totalLosses: string;
  netGainLoss: string;
  transactions: number;
  taxableEvents: number;
  categories: {
    category: string;
    gains: string;
    losses: string;
  }[];
};

export type SmartMoneyTracker = {
  address: string;
  label: string;
  category: 'whale' | 'smart' | 'institutional';
  recentActivity: string;
  profitLoss: string;
  copiedBy: number;
};

export type TransactionPattern = {
  pattern: string;
  frequency: number;
  averageValue: string;
  lastOccurrence: number;
  prediction: {
    nextOccurrence: number;
    confidence: number;
  };
};
