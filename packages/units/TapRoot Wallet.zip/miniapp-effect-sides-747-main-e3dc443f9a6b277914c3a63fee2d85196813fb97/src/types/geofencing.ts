export type MerchantLocation = {
  id: string;
  name: string;
  address: string;
  latitude: number;
  longitude: number;
  distance: number;
  acceptedTokens: string[];
  category: string;
  rating: number;
  verified: boolean;
};

export type P2PTrader = {
  id: string;
  username: string;
  walletAddress: string;
  distance: number;
  latitude: number;
  longitude: number;
  rating: number;
  completedTrades: number;
  preferredTokens: string[];
  paymentMethods: string[];
  online: boolean;
};

export type LocationAlert = {
  id: string;
  type: 'merchant' | 'trader' | 'event' | 'security';
  title: string;
  message: string;
  latitude: number;
  longitude: number;
  radius: number;
  enabled: boolean;
};

export type UserLocation = {
  latitude: number;
  longitude: number;
  accuracy: number;
  timestamp: number;
};
