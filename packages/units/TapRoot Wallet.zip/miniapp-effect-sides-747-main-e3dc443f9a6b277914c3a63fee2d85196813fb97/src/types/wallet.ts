export type TransactionCategory = 'defi' | 'nft' | 'transfer' | 'swap' | 'bridge' | 'social' | 'unknown';

export type Transaction = {
  id: string;
  hash: string;
  from: string;
  to: string;
  value: string;
  timestamp: number;
  category: TransactionCategory;
  status: 'success' | 'pending' | 'failed';
  gasUsed: string;
  chain: {
    name: string;
    id: number;
    color: string;
  };
  token?: {
    symbol: string;
    name: string;
  };
};

export type AddressLabel = {
  address: string;
  label: string;
  notes?: string;
  tags: string[];
  reminders?: string[];
  automations?: {
    type: 'alert' | 'auto-send' | 'notify';
    condition: string;
    action: string;
  }[];
};

export type TrustScore = {
  address: string;
  score: number;
  ring: 'inner' | 'mid' | 'outer';
  interactions: number;
  totalValue: string;
  firstInteraction: number;
  lastInteraction: number;
};

export type AddressCluster = {
  addresses: string[];
  clusterName: string;
  totalInteractions: number;
  avgTrustScore: number;
  category: string;
};
