'use client'
import { useState, useEffect } from 'react'
import { PetCreatorForm } from '@/components/pet-creator-form'
import { PetResults } from '@/components/pet-results'
import type { PetProfile } from '@/types/pet'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function Page(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [petProfile, setPetProfile] = useState<PetProfile | null>(null)
  const [isGenerating, setIsGenerating] = useState<boolean>(false)

  return (
    <main className="min-h-screen bg-gradient-to-br from-purple-400 via-pink-300 to-yellow-300 p-4 sm:p-8">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8 pt-12 sm:pt-8">
          <h1 className="text-4xl sm:text-6xl font-bold text-white mb-2 drop-shadow-lg animate-bounce-slow">
            DreamPet Creator
          </h1>
          <p className="text-xl sm:text-2xl text-white/90 font-semibold">
            $PET
          </p>
          <p className="text-sm sm:text-base text-white/80 mt-2">
            ✨ Design your perfect magical companion ✨
          </p>
        </div>

        {/* Form */}
        {!petProfile && (
          <PetCreatorForm
            onGenerate={setPetProfile}
            isGenerating={isGenerating}
            setIsGenerating={setIsGenerating}
          />
        )}

        {/* Results */}
        {petProfile && (
          <PetResults
            profile={petProfile}
            onCreateAnother={() => setPetProfile(null)}
          />
        )}
      </div>
    </main>
  )
}
