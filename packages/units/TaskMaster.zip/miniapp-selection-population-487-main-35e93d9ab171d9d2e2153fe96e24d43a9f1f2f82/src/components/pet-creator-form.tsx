'use client'

import { useState } from 'react'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Sparkles, Loader2 } from 'lucide-react'
import { openaiChatCompletion } from '@/openai-api'
import type { PetProfile, PetInput } from '@/types/pet'

interface PetCreatorFormProps {
  onGenerate: (profile: PetProfile) => void
  isGenerating: boolean
  setIsGenerating: (value: boolean) => void
}

const petTypes = [
  'Cute Fluffy Pet',
  'Magical Creature',
  'Robot Companion',
  'Dragonling',
  'Tiny Fairy Pet',
  'Cloud Pet',
  'Crystal Being',
  'Plant Companion',
  'Star Pet',
  'Ocean Spirit',
]

export function PetCreatorForm({ onGenerate, isGenerating, setIsGenerating }: PetCreatorFormProps): JSX.Element {
  const [petType, setPetType] = useState<string>('')
  const [personality, setPersonality] = useState<string>('')
  const [favoriteFood, setFavoriteFood] = useState<string>('')
  const [specialAbility, setSpecialAbility] = useState<string>('')

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>): Promise<void> => {
    e.preventDefault()
    
    if (!petType || !personality || !favoriteFood || !specialAbility) {
      alert('Please fill in all fields!')
      return
    }

    setIsGenerating(true)

    try {
      const prompt = `Create a magical pet profile based on these characteristics:
- Type: ${petType}
- Personality: ${personality}
- Favorite Food: ${favoriteFood}
- Special Ability: ${specialAbility}

Please respond with a JSON object (and ONLY JSON, no markdown formatting) with the following structure:
{
  "description": "A detailed, whimsical description of the pet (2-3 sentences)",
  "nameIdeas": ["name1", "name2", "name3", "name4", "name5"],
  "backstory": "A magical backstory explaining where this pet comes from and how it got its special ability (3-4 sentences)",
  "careInstructions": ["instruction1", "instruction2", "instruction3", "instruction4"],
  "funFacts": ["fact1", "fact2", "fact3", "fact4", "fact5"],
  "drawingPrompts": ["prompt1", "prompt2", "prompt3"]
}

Make it creative, whimsical, and fun! The pet should feel magical and unique.`

      const response = await openaiChatCompletion({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are a creative pet designer who creates magical, whimsical pets. Always respond with valid JSON only, no markdown formatting.',
          },
          {
            role: 'user',
            content: prompt,
          },
        ],
      })

      const content = response.choices[0].message.content
      const cleanedContent = content.replace(/```json\n?/g, '').replace(/```\n?/g, '').trim()
      const petData = JSON.parse(cleanedContent)

      const profile: PetProfile = {
        input: {
          type: petType,
          personality,
          favoriteFood,
          specialAbility,
        },
        description: petData.description,
        nameIdeas: petData.nameIdeas,
        backstory: petData.backstory,
        careInstructions: petData.careInstructions,
        funFacts: petData.funFacts,
        drawingPrompts: petData.drawingPrompts,
      }

      onGenerate(profile)
    } catch (error) {
      console.error('Error generating pet:', error)
      alert('Oops! Something went wrong. Please try again.')
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
      <CardHeader>
        <CardTitle className="text-2xl sm:text-3xl text-center bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
          Create Your DreamPet
        </CardTitle>
        <CardDescription className="text-center text-base">
          Fill in the details to bring your magical companion to life!
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Pet Type */}
          <div className="space-y-2">
            <Label htmlFor="petType" className="text-lg font-semibold text-gray-700">
              Type of Pet
            </Label>
            <Select value={petType} onValueChange={setPetType}>
              <SelectTrigger id="petType" className="w-full border-2 border-purple-200 focus:border-purple-400">
                <SelectValue placeholder="Choose your pet type..." />
              </SelectTrigger>
              <SelectContent>
                {petTypes.map((type) => (
                  <SelectItem key={type} value={type}>
                    {type}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Personality */}
          <div className="space-y-2">
            <Label htmlFor="personality" className="text-lg font-semibold text-gray-700">
              Personality
            </Label>
            <Input
              id="personality"
              type="text"
              placeholder="e.g., Playful and mischievous"
              value={personality}
              onChange={(e) => setPersonality(e.target.value)}
              className="border-2 border-pink-200 focus:border-pink-400"
            />
          </div>

          {/* Favorite Food */}
          <div className="space-y-2">
            <Label htmlFor="favoriteFood" className="text-lg font-semibold text-gray-700">
              Favorite Food
            </Label>
            <Input
              id="favoriteFood"
              type="text"
              placeholder="e.g., Rainbow cookies"
              value={favoriteFood}
              onChange={(e) => setFavoriteFood(e.target.value)}
              className="border-2 border-yellow-200 focus:border-yellow-400"
            />
          </div>

          {/* Special Ability */}
          <div className="space-y-2">
            <Label htmlFor="specialAbility" className="text-lg font-semibold text-gray-700">
              Special Ability
            </Label>
            <Input
              id="specialAbility"
              type="text"
              placeholder="e.g., Can create sparkles"
              value={specialAbility}
              onChange={(e) => setSpecialAbility(e.target.value)}
              className="border-2 border-blue-200 focus:border-blue-400"
            />
          </div>

          {/* Submit Button */}
          <Button
            type="submit"
            disabled={isGenerating}
            className="w-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white font-bold py-6 text-lg shadow-lg hover:shadow-xl transition-all"
          >
            {isGenerating ? (
              <>
                <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                Creating Your DreamPet...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-5 w-5" />
                Generate My Pet!
              </>
            )}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
