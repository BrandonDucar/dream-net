'use client'

import { Button } from '@/components/ui/button'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Separator } from '@/components/ui/separator'
import { ArrowLeft, Heart, Sparkles, BookOpen, Clipboard, Star, Palette } from 'lucide-react'
import type { PetProfile } from '@/types/pet'

interface PetResultsProps {
  profile: PetProfile
  onCreateAnother: () => void
}

export function PetResults({ profile, onCreateAnother }: PetResultsProps): JSX.Element {
  return (
    <div className="space-y-6 animate-fade-in">
      {/* Back Button */}
      <Button
        onClick={onCreateAnother}
        variant="outline"
        className="bg-white/90 hover:bg-white border-2 border-white shadow-lg"
      >
        <ArrowLeft className="mr-2 h-4 w-4" />
        Create Another Pet
      </Button>

      {/* Pet Type Badge */}
      <div className="text-center">
        <Badge className="text-lg px-6 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white border-0">
          {profile.input.type}
        </Badge>
      </div>

      {/* Description */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
          <CardTitle className="flex items-center gap-2 text-purple-700">
            <Heart className="h-6 w-6" />
            Your DreamPet
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-lg text-gray-700 leading-relaxed">{profile.description}</p>
          <div className="mt-4 grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="bg-purple-50 p-3 rounded-lg">
              <p className="text-xs text-purple-600 font-semibold mb-1">Personality</p>
              <p className="text-sm text-gray-700">{profile.input.personality}</p>
            </div>
            <div className="bg-pink-50 p-3 rounded-lg">
              <p className="text-xs text-pink-600 font-semibold mb-1">Favorite Food</p>
              <p className="text-sm text-gray-700">{profile.input.favoriteFood}</p>
            </div>
            <div className="bg-yellow-50 p-3 rounded-lg">
              <p className="text-xs text-yellow-600 font-semibold mb-1">Special Ability</p>
              <p className="text-sm text-gray-700">{profile.input.specialAbility}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Name Ideas */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-blue-100 to-cyan-100">
          <CardTitle className="flex items-center gap-2 text-blue-700">
            <Sparkles className="h-6 w-6" />
            Name Ideas
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-wrap gap-3">
            {profile.nameIdeas.map((name, index) => (
              <Badge
                key={index}
                variant="secondary"
                className="text-base px-4 py-2 bg-gradient-to-r from-blue-200 to-cyan-200 text-blue-800 border-0"
              >
                {name}
              </Badge>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Backstory */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-green-100 to-emerald-100">
          <CardTitle className="flex items-center gap-2 text-green-700">
            <BookOpen className="h-6 w-6" />
            Backstory
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-base text-gray-700 leading-relaxed">{profile.backstory}</p>
        </CardContent>
      </Card>

      {/* Care Instructions */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-orange-100 to-amber-100">
          <CardTitle className="flex items-center gap-2 text-orange-700">
            <Clipboard className="h-6 w-6" />
            Care Instructions
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <ul className="space-y-3">
            {profile.careInstructions.map((instruction, index) => (
              <li key={index} className="flex items-start gap-3">
                <span className="flex-shrink-0 w-6 h-6 rounded-full bg-gradient-to-br from-orange-400 to-amber-400 text-white text-xs flex items-center justify-center font-bold">
                  {index + 1}
                </span>
                <span className="text-base text-gray-700 flex-1">{instruction}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Fun Facts */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-rose-100 to-red-100">
          <CardTitle className="flex items-center gap-2 text-rose-700">
            <Star className="h-6 w-6" />
            Fun Facts
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <ul className="space-y-3">
            {profile.funFacts.map((fact, index) => (
              <li key={index} className="flex items-start gap-3">
                <Star className="flex-shrink-0 h-5 w-5 text-rose-500 mt-0.5" />
                <span className="text-base text-gray-700 flex-1">{fact}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      {/* Drawing Prompts */}
      <Card className="bg-white/95 backdrop-blur-sm shadow-2xl border-4 border-white">
        <CardHeader className="bg-gradient-to-r from-violet-100 to-purple-100">
          <CardTitle className="flex items-center gap-2 text-violet-700">
            <Palette className="h-6 w-6" />
            Drawing Prompts
          </CardTitle>
        </CardHeader>
        <CardContent className="pt-6">
          <p className="text-sm text-gray-600 mb-4 italic">
            Use these prompts to bring your DreamPet to life through art!
          </p>
          <Separator className="mb-4" />
          <div className="space-y-4">
            {profile.drawingPrompts.map((prompt, index) => (
              <div key={index} className="bg-gradient-to-r from-violet-50 to-purple-50 p-4 rounded-lg border-2 border-violet-200">
                <p className="text-xs text-violet-600 font-semibold mb-1">Prompt {index + 1}</p>
                <p className="text-base text-gray-700">{prompt}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
