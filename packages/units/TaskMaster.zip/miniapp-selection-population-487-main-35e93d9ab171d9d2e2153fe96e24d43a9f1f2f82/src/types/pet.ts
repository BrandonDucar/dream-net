export interface PetInput {
  type: string
  personality: string
  favoriteFood: string
  specialAbility: string
}

export interface PetProfile {
  input: PetInput
  description: string
  nameIdeas: string[]
  backstory: string
  careInstructions: string[]
  funFacts: string[]
  drawingPrompts: string[]
}
