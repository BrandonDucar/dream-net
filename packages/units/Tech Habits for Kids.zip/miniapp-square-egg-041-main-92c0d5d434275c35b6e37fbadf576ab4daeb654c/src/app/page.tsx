'use client'
import { useState, useEffect } from 'react'
import type { ReactNode } from 'react'
import { DailyLesson } from '@/components/daily-lesson'
import { ParentScripts } from '@/components/parent-scripts'
import { RewardBadges } from '@/components/reward-badges'
import { TechTimeTracker } from '@/components/tech-time-tracker'
import { InteractiveQuiz } from '@/components/interactive-quiz'
import { Button } from '@/components/ui/button'
import { Card } from '@/components/ui/card'
import { BookOpen, MessageCircle, Award, Clock, Brain, Home } from 'lucide-react'
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

type Section = 'home' | 'lessons' | 'scripts' | 'badges' | 'tracker' | 'quiz'

interface BadgeType {
  id: string
  name: string
  description: string
  emoji: string
  earned: boolean
}

export default function HealthyTechHabitsApp(): JSX.Element {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [currentSection, setCurrentSection] = useState<Section>('home')
  const [badges, setBadges] = useState<BadgeType[]>([])
  const [completedLessons, setCompletedLessons] = useState<number[]>([])
  const [quizScores, setQuizScores] = useState<number>(0)

  // Load saved data from localStorage
  useEffect(() => {
    const savedBadges = localStorage.getItem('healthyTechBadges')
    const savedLessons = localStorage.getItem('completedLessons')
    const savedScores = localStorage.getItem('quizScores')
    
    if (savedBadges) {
      setBadges(JSON.parse(savedBadges))
    } else {
      // Initialize badges
      const initialBadges: BadgeType[] = [
        { id: '1', name: 'First Lesson', description: 'Complete your first lesson', emoji: '🌟', earned: false },
        { id: '2', name: 'Break Time Hero', description: 'Take 3 screen breaks', emoji: '🦸', earned: false },
        { id: '3', name: 'Quiz Master', description: 'Complete 5 quizzes', emoji: '🧠', earned: false },
        { id: '4', name: 'Time Tracker', description: 'Use the timer 5 times', emoji: '⏰', earned: false },
        { id: '5', name: 'Parent Helper', description: 'Share with a parent', emoji: '💝', earned: false },
        { id: '6', name: 'Tech Balance', description: 'Complete 7 lessons', emoji: '⚖️', earned: false },
      ]
      setBadges(initialBadges)
    }
    
    if (savedLessons) {
      setCompletedLessons(JSON.parse(savedLessons))
    }
    
    if (savedScores) {
      setQuizScores(parseInt(savedScores))
    }
  }, [])

  // Save data to localStorage
  useEffect(() => {
    if (badges.length > 0) {
      localStorage.setItem('healthyTechBadges', JSON.stringify(badges))
    }
  }, [badges])

  useEffect(() => {
    localStorage.setItem('completedLessons', JSON.stringify(completedLessons))
  }, [completedLessons])

  useEffect(() => {
    localStorage.setItem('quizScores', quizScores.toString())
  }, [quizScores])

  const earnBadge = (badgeId: string): void => {
    setBadges(prevBadges =>
      prevBadges.map(badge =>
        badge.id === badgeId ? { ...badge, earned: true } : badge
      )
    )
  }

  const markLessonComplete = (lessonId: number): void => {
    if (!completedLessons.includes(lessonId)) {
      setCompletedLessons(prev => [...prev, lessonId])
      
      // Award badges based on lessons completed
      if (completedLessons.length === 0) {
        earnBadge('1')
      }
      if (completedLessons.length + 1 >= 7) {
        earnBadge('6')
      }
    }
  }

  const completeQuiz = (): void => {
    const newScore = quizScores + 1
    setQuizScores(newScore)
    
    if (newScore >= 5) {
      earnBadge('3')
    }
  }

  const renderSection = (): ReactNode => {
    switch (currentSection) {
      case 'lessons':
        return <DailyLesson onComplete={markLessonComplete} completedLessons={completedLessons} />
      case 'scripts':
        return <ParentScripts onShare={() => earnBadge('5')} />
      case 'badges':
        return <RewardBadges badges={badges} />
      case 'tracker':
        return <TechTimeTracker onTimerUse={() => earnBadge('4')} onBreakComplete={() => earnBadge('2')} />
      case 'quiz':
        return <InteractiveQuiz onComplete={completeQuiz} />
      default:
        return <HomeScreen setSection={setCurrentSection} badges={badges} />
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-purple-50 to-pink-50 pt-12 pb-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-black mb-2">
            🌈 Healthy Tech Habits
          </h1>
          <p className="text-lg text-black">Learn to use technology wisely!</p>
        </div>

        {/* Navigation */}
        {currentSection !== 'home' && (
          <div className="mb-6">
            <Button
              onClick={() => setCurrentSection('home')}
              variant="outline"
              size="lg"
              className="bg-white hover:bg-gray-50"
            >
              <Home className="mr-2 h-5 w-5" />
              Back to Home
            </Button>
          </div>
        )}

        {/* Main Content */}
        <div className="mb-8">
          {renderSection()}
        </div>

        {/* Footer for Home Screen */}
        {currentSection === 'home' && (
          <div className="text-center text-sm text-black mt-8 bg-white/50 rounded-lg p-4">
            <p className="font-semibold">👨‍👩‍👧‍👦 For Parents:</p>
            <p>This app teaches children ages 3-8 about healthy technology habits through fun, interactive lessons and activities.</p>
          </div>
        )}
      </div>
    </div>
  )
}

interface HomeScreenProps {
  setSection: (section: Section) => void
  badges: BadgeType[]
}

function HomeScreen({ setSection, badges }: HomeScreenProps): JSX.Element {
  const earnedBadgesCount = badges.filter(b => b.earned).length

  const menuItems: Array<{
    id: Section
    title: string
    description: string
    icon: typeof BookOpen
    color: string
  }> = [
    {
      id: 'lessons',
      title: 'Daily Lessons',
      description: 'Learn something new today!',
      icon: BookOpen,
      color: 'bg-blue-500 hover:bg-blue-600',
    },
    {
      id: 'scripts',
      title: 'Parent Talks',
      description: 'Conversation starters for families',
      icon: MessageCircle,
      color: 'bg-green-500 hover:bg-green-600',
    },
    {
      id: 'badges',
      title: 'My Badges',
      description: `You have ${earnedBadgesCount} badges!`,
      icon: Award,
      color: 'bg-yellow-500 hover:bg-yellow-600',
    },
    {
      id: 'tracker',
      title: 'Tech Timer',
      description: 'Track your screen time',
      icon: Clock,
      color: 'bg-purple-500 hover:bg-purple-600',
    },
    {
      id: 'quiz',
      title: 'Fun Quizzes',
      description: 'Test what you learned!',
      icon: Brain,
      color: 'bg-pink-500 hover:bg-pink-600',
    },
  ]

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {menuItems.map((item) => {
        const Icon = item.icon
        return (
          <Card
            key={item.id}
            className="p-6 hover:shadow-xl transition-shadow cursor-pointer bg-white border-4 border-black"
            onClick={() => setSection(item.id)}
          >
            <div className="flex items-start space-x-4">
              <div className={`${item.color} p-4 rounded-xl text-white`}>
                <Icon className="h-8 w-8" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-black mb-2">{item.title}</h3>
                <p className="text-black">{item.description}</p>
              </div>
            </div>
          </Card>
        )
      })}
    </div>
  )
}
