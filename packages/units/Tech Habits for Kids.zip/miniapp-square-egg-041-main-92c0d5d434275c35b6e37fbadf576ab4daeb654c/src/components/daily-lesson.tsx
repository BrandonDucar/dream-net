'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { CheckCircle2, Circle } from 'lucide-react'

interface Lesson {
  id: number
  title: string
  content: string
  tips: string[]
  emoji: string
  ageGroup: string
}

interface DailyLessonProps {
  onComplete: (lessonId: number) => void
  completedLessons: number[]
}

const lessons: Lesson[] = [
  {
    id: 1,
    title: 'Screen Time Breaks',
    emoji: '🏃‍♂️',
    ageGroup: '3-8 years',
    content: 'Our eyes and bodies need breaks from screens! Just like we need to stretch after sitting, we need to look away from screens and move around.',
    tips: [
      'Every 20 minutes, look at something far away for 20 seconds',
      'Stand up and do 5 jumping jacks',
      'Blink your eyes 10 times',
      'Give your eyes a rest by closing them for a moment',
    ],
  },
  {
    id: 2,
    title: 'No Screens Before Bed',
    emoji: '😴',
    ageGroup: '3-8 years',
    content: 'Screens make our brains think it\'s still daytime! To sleep well, we should stop using screens at least 1 hour before bedtime.',
    tips: [
      'Read a book instead of watching videos',
      'Draw or color pictures',
      'Talk with family about your day',
      'Listen to calm music or stories',
    ],
  },
  {
    id: 3,
    title: 'Real Play is Important',
    emoji: '🎨',
    ageGroup: '3-8 years',
    content: 'Playing with toys, drawing, running outside, and playing with friends helps us learn and grow! Screen time is fun, but real play is super important too.',
    tips: [
      'Play with building blocks or LEGO',
      'Go outside and explore nature',
      'Play pretend games with friends',
      'Do arts and crafts projects',
    ],
  },
  {
    id: 4,
    title: 'Asking Permission',
    emoji: '🙋',
    ageGroup: '3-8 years',
    content: 'It\'s good manners to ask a grown-up before using a device. They help us make good choices about what to watch and how long to play.',
    tips: [
      'Always ask before turning on a device',
      'Tell an adult what you want to watch',
      'Listen when it\'s time to stop',
      'Say thank you when screen time is over',
    ],
  },
  {
    id: 5,
    title: 'Good Posture Matters',
    emoji: '🪑',
    ageGroup: '3-8 years',
    content: 'How we sit when using screens is important! Sitting up straight helps our backs, necks, and eyes feel better.',
    tips: [
      'Sit up straight with feet on the floor',
      'Keep the screen at eye level',
      'Don\'t hold devices too close to your face',
      'Use a pillow for back support if needed',
    ],
  },
  {
    id: 6,
    title: 'Being Kind Online',
    emoji: '💝',
    ageGroup: '3-8 years',
    content: 'We should be kind to others online just like we are in person. If something makes you feel bad or confused, tell a grown-up right away!',
    tips: [
      'Be nice in messages and comments',
      'Don\'t share mean pictures or words',
      'Tell an adult if something seems wrong',
      'Remember: real friends are kind',
    ],
  },
  {
    id: 7,
    title: 'Balance is Best',
    emoji: '⚖️',
    ageGroup: '3-8 years',
    content: 'Having a good balance means doing lots of different activities! Some screen time is okay, but we also need time for playing, learning, eating, and sleeping.',
    tips: [
      'Do homework before screen time',
      'Eat meals without screens',
      'Spend time with family and pets',
      'Try new activities and hobbies',
    ],
  },
]

export function DailyLesson({ onComplete, completedLessons }: DailyLessonProps): JSX.Element {
  const [currentLessonIndex, setCurrentLessonIndex] = useState<number>(0)
  const currentLesson = lessons[currentLessonIndex]
  const progress = ((currentLessonIndex + 1) / lessons.length) * 100

  const handleComplete = (): void => {
    onComplete(currentLesson.id)
  }

  const handleNext = (): void => {
    if (currentLessonIndex < lessons.length - 1) {
      setCurrentLessonIndex(currentLessonIndex + 1)
    }
  }

  const handlePrevious = (): void => {
    if (currentLessonIndex > 0) {
      setCurrentLessonIndex(currentLessonIndex - 1)
    }
  }

  const isCompleted = completedLessons.includes(currentLesson.id)

  return (
    <div className="space-y-6">
      {/* Progress Bar */}
      <Card className="bg-white border-4 border-black">
        <CardContent className="pt-6">
          <div className="space-y-2">
            <div className="flex justify-between text-sm font-semibold text-black">
              <span>Lesson Progress</span>
              <span>{currentLessonIndex + 1} of {lessons.length}</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Lesson Content */}
      <Card className="bg-white border-4 border-black">
        <CardHeader className="bg-gradient-to-r from-blue-100 to-purple-100">
          <div className="flex items-center justify-between">
            <div>
              <CardTitle className="text-3xl font-bold text-black flex items-center gap-3">
                <span className="text-5xl">{currentLesson.emoji}</span>
                {currentLesson.title}
              </CardTitle>
              <p className="text-sm text-black mt-2">Ages: {currentLesson.ageGroup}</p>
            </div>
            {isCompleted && (
              <CheckCircle2 className="h-12 w-12 text-green-600" />
            )}
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          <div className="bg-yellow-50 border-4 border-yellow-300 rounded-lg p-6">
            <p className="text-xl leading-relaxed text-black">{currentLesson.content}</p>
          </div>

          <div>
            <h3 className="text-2xl font-bold text-black mb-4 flex items-center gap-2">
              <span>💡</span> Tips to Remember:
            </h3>
            <ul className="space-y-3">
              {currentLesson.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-3 bg-green-50 border-2 border-green-300 rounded-lg p-4">
                  <span className="text-2xl flex-shrink-0">✓</span>
                  <span className="text-lg text-black">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Complete Button */}
          {!isCompleted && (
            <Button
              onClick={handleComplete}
              size="lg"
              className="w-full bg-green-500 hover:bg-green-600 text-white text-xl py-6"
            >
              <CheckCircle2 className="mr-2 h-6 w-6" />
              Mark as Complete
            </Button>
          )}

          {isCompleted && (
            <div className="bg-green-100 border-4 border-green-500 rounded-lg p-4 text-center">
              <p className="text-xl font-bold text-black">🎉 Great job! You completed this lesson!</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex gap-4">
        <Button
          onClick={handlePrevious}
          disabled={currentLessonIndex === 0}
          size="lg"
          variant="outline"
          className="flex-1 border-4 border-black text-lg py-6"
        >
          ← Previous Lesson
        </Button>
        <Button
          onClick={handleNext}
          disabled={currentLessonIndex === lessons.length - 1}
          size="lg"
          variant="outline"
          className="flex-1 border-4 border-black text-lg py-6"
        >
          Next Lesson →
        </Button>
      </div>

      {/* Lesson List */}
      <Card className="bg-white border-4 border-black">
        <CardHeader>
          <CardTitle className="text-2xl text-black">All Lessons</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {lessons.map((lesson, index) => {
              const completed = completedLessons.includes(lesson.id)
              return (
                <button
                  key={lesson.id}
                  onClick={() => setCurrentLessonIndex(index)}
                  className={`flex items-center gap-3 p-4 rounded-lg border-2 transition-colors ${
                    currentLessonIndex === index
                      ? 'bg-blue-100 border-blue-500'
                      : 'bg-gray-50 border-gray-300 hover:bg-gray-100'
                  }`}
                >
                  {completed ? (
                    <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0" />
                  ) : (
                    <Circle className="h-6 w-6 text-gray-400 flex-shrink-0" />
                  )}
                  <span className="text-2xl flex-shrink-0">{lesson.emoji}</span>
                  <span className="text-left font-semibold text-black">{lesson.title}</span>
                </button>
              )
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
