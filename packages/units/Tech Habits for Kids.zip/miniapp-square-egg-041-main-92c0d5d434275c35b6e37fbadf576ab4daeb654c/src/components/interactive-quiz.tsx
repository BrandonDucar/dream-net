'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { CheckCircle2, XCircle, Sparkles } from 'lucide-react'

interface QuizQuestion {
  id: number
  question: string
  options: string[]
  correctAnswer: number
  explanation: string
  emoji: string
}

interface InteractiveQuizProps {
  onComplete: () => void
}

const quizzes: QuizQuestion[] = [
  {
    id: 1,
    emoji: '👀',
    question: 'How often should you take a break from screens?',
    options: [
      'Every 5 minutes',
      'Every 20-30 minutes',
      'Only when tired',
      'Never',
    ],
    correctAnswer: 1,
    explanation: 'Taking a break every 20-30 minutes helps your eyes rest and keeps your body moving!',
  },
  {
    id: 2,
    emoji: '😴',
    question: 'When should you stop using screens before bedtime?',
    options: [
      'Right before bed',
      '10 minutes before',
      'At least 1 hour before',
      'Anytime is fine',
    ],
    correctAnswer: 2,
    explanation: 'Stopping screens at least 1 hour before bed helps your brain know it\'s time to sleep!',
  },
  {
    id: 3,
    emoji: '🪑',
    question: 'What is the best way to sit when using a screen?',
    options: [
      'Lying down on the floor',
      'Sitting up straight with feet on floor',
      'Slouching in a chair',
      'Standing on one foot',
    ],
    correctAnswer: 1,
    explanation: 'Sitting up straight with your feet on the floor keeps your back and neck healthy!',
  },
  {
    id: 4,
    emoji: '🎮',
    question: 'What should you do before starting screen time?',
    options: [
      'Ask a grown-up for permission',
      'Hide from your parents',
      'Turn all lights off',
      'Skip homework',
    ],
    correctAnswer: 0,
    explanation: 'Always ask a grown-up first! They help you make good choices about screen time.',
  },
  {
    id: 5,
    emoji: '🏃',
    question: 'Besides screen time, what else is important?',
    options: [
      'Only video games',
      'Just watching videos',
      'Playing outside and with toys',
      'Staying inside all day',
    ],
    correctAnswer: 2,
    explanation: 'Playing outside and with toys helps your body grow strong and your imagination grow big!',
  },
  {
    id: 6,
    emoji: '💧',
    question: 'What should you do during your screen breaks?',
    options: [
      'Stare at a different screen',
      'Sit very still',
      'Move around and drink water',
      'Close your eyes and stay sitting',
    ],
    correctAnswer: 2,
    explanation: 'Moving around and drinking water during breaks helps your body feel great!',
  },
  {
    id: 7,
    emoji: '📱',
    question: 'How close should you hold a tablet or phone?',
    options: [
      'As close as possible',
      'At arm\'s length away',
      'Touching your nose',
      'On the floor',
    ],
    correctAnswer: 1,
    explanation: 'Holding devices at arm\'s length protects your eyes from strain!',
  },
  {
    id: 8,
    emoji: '🌟',
    question: 'What makes a balanced day?',
    options: [
      'Only screen time',
      'Screen time, play, learning, eating, sleeping',
      'Just sleeping',
      'Only eating',
    ],
    correctAnswer: 1,
    explanation: 'A balanced day has many activities - that\'s what keeps us happy and healthy!',
  },
]

export function InteractiveQuiz({ onComplete }: InteractiveQuizProps): JSX.Element {
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState<number>(0)
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null)
  const [showResult, setShowResult] = useState<boolean>(false)
  const [score, setScore] = useState<number>(0)
  const [quizComplete, setQuizComplete] = useState<boolean>(false)

  const currentQuestion = quizzes[currentQuestionIndex]
  const progress = ((currentQuestionIndex + 1) / quizzes.length) * 100

  const handleAnswerSelect = (answerIndex: number): void => {
    if (!showResult) {
      setSelectedAnswer(answerIndex)
      setShowResult(true)
      
      if (answerIndex === currentQuestion.correctAnswer) {
        setScore(score + 1)
      }
    }
  }

  const handleNext = (): void => {
    if (currentQuestionIndex < quizzes.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1)
      setSelectedAnswer(null)
      setShowResult(false)
    } else {
      setQuizComplete(true)
      onComplete()
    }
  }

  const handleRestart = (): void => {
    setCurrentQuestionIndex(0)
    setSelectedAnswer(null)
    setShowResult(false)
    setScore(0)
    setQuizComplete(false)
  }

  if (quizComplete) {
    const percentage = Math.round((score / quizzes.length) * 100)
    return (
      <div className="space-y-6">
        <Card className="bg-gradient-to-r from-yellow-100 to-orange-100 border-4 border-black">
          <CardContent className="pt-8">
            <div className="text-center space-y-6">
              <div className="text-8xl animate-bounce">
                {percentage >= 80 ? '🎉' : percentage >= 60 ? '⭐' : '🌟'}
              </div>
              <h2 className="text-4xl font-bold text-black">
                {percentage >= 80 ? 'Amazing!' : percentage >= 60 ? 'Great Job!' : 'Good Try!'}
              </h2>
              <div className="bg-white rounded-lg p-6 border-4 border-yellow-500">
                <p className="text-3xl font-bold text-black mb-2">
                  You got {score} out of {quizzes.length} correct!
                </p>
                <p className="text-xl text-black">
                  That's {percentage}%!
                </p>
              </div>
              <div className="space-y-3">
                <p className="text-xl text-black">
                  {percentage >= 80
                    ? 'You really know your healthy tech habits! Keep it up!'
                    : percentage >= 60
                    ? 'You\'re learning well! Keep practicing these healthy habits!'
                    : 'Keep learning and trying! You\'re doing great!'}
                </p>
              </div>
              <div className="flex gap-4 justify-center">
                <Button
                  onClick={handleRestart}
                  size="lg"
                  className="bg-purple-500 hover:bg-purple-600 text-xl px-8 py-6"
                >
                  <Sparkles className="mr-2 h-6 w-6" />
                  Try Again
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-pink-100 to-purple-100 border-4 border-black">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-black flex items-center gap-3">
            <span className="text-5xl">🧠</span>
            Fun Quiz Time!
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex justify-between text-sm font-semibold text-black">
              <span>Question {currentQuestionIndex + 1} of {quizzes.length}</span>
              <span>Score: {score}/{currentQuestionIndex + (showResult ? 1 : 0)}</span>
            </div>
            <Progress value={progress} className="h-3" />
          </div>
        </CardContent>
      </Card>

      {/* Question Card */}
      <Card className="bg-white border-4 border-black">
        <CardHeader className="bg-gradient-to-r from-blue-100 to-green-100">
          <div className="text-center">
            <div className="text-6xl mb-4">{currentQuestion.emoji}</div>
            <CardTitle className="text-2xl md:text-3xl text-black leading-relaxed">
              {currentQuestion.question}
            </CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="space-y-4">
            {/* Answer Options */}
            <div className="grid gap-4">
              {currentQuestion.options.map((option, index) => {
                const isSelected = selectedAnswer === index
                const isCorrect = index === currentQuestion.correctAnswer
                const showCorrect = showResult && isCorrect
                const showIncorrect = showResult && isSelected && !isCorrect

                return (
                  <button
                    key={index}
                    onClick={() => handleAnswerSelect(index)}
                    disabled={showResult}
                    className={`p-6 rounded-lg border-4 text-left text-lg transition-all ${
                      showCorrect
                        ? 'bg-green-100 border-green-500'
                        : showIncorrect
                        ? 'bg-red-100 border-red-500'
                        : isSelected
                        ? 'bg-blue-100 border-blue-500'
                        : 'bg-gray-50 border-gray-300 hover:border-gray-400 hover:bg-gray-100'
                    } ${showResult ? 'cursor-default' : 'cursor-pointer'}`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-black font-semibold flex-1">{option}</span>
                      {showCorrect && <CheckCircle2 className="h-8 w-8 text-green-600 flex-shrink-0 ml-4" />}
                      {showIncorrect && <XCircle className="h-8 w-8 text-red-600 flex-shrink-0 ml-4" />}
                    </div>
                  </button>
                )
              })}
            </div>

            {/* Explanation */}
            {showResult && (
              <div
                className={`p-6 rounded-lg border-4 ${
                  selectedAnswer === currentQuestion.correctAnswer
                    ? 'bg-green-50 border-green-500'
                    : 'bg-blue-50 border-blue-500'
                }`}
              >
                <div className="flex items-start gap-3">
                  <span className="text-3xl flex-shrink-0">
                    {selectedAnswer === currentQuestion.correctAnswer ? '🎉' : '💡'}
                  </span>
                  <div>
                    <h4 className="font-bold text-xl text-black mb-2">
                      {selectedAnswer === currentQuestion.correctAnswer
                        ? 'Correct! Great job!'
                        : 'Not quite, but that\'s okay!'}
                    </h4>
                    <p className="text-lg text-black">{currentQuestion.explanation}</p>
                  </div>
                </div>
              </div>
            )}

            {/* Next Button */}
            {showResult && (
              <Button
                onClick={handleNext}
                size="lg"
                className="w-full bg-purple-500 hover:bg-purple-600 text-xl py-6"
              >
                {currentQuestionIndex < quizzes.length - 1 ? 'Next Question →' : 'See Results →'}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tips */}
      <Card className="bg-yellow-50 border-4 border-yellow-400">
        <CardContent className="pt-6">
          <div className="text-center">
            <p className="text-lg text-black font-semibold">
              💪 Take your time and think about each answer!
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
