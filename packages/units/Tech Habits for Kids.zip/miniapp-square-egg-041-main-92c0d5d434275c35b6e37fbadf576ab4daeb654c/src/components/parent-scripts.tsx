'use client'

import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Share2, Copy, Check } from 'lucide-react'

interface Script {
  id: number
  topic: string
  ageGroup: string
  scenario: string
  script: string
  tips: string[]
  emoji: string
}

interface ParentScriptsProps {
  onShare: () => void
}

const scripts: Script[] = [
  {
    id: 1,
    topic: 'Setting Screen Time Limits',
    ageGroup: '3-5 years',
    emoji: '⏰',
    scenario: 'When your child asks for "just 5 more minutes"',
    script: '"I know this is fun! But our bodies need breaks from screens. Let\'s finish this show, then we can [alternative activity]. Your eyes will thank you!"',
    tips: [
      'Be consistent with time limits',
      'Give 5-minute warnings before screen time ends',
      'Offer exciting alternatives to make the transition easier',
      'Use a visual timer so kids can see time passing',
    ],
  },
  {
    id: 2,
    topic: 'Explaining Why Screens Affect Sleep',
    ageGroup: '4-6 years',
    emoji: '😴',
    scenario: 'When your child wants to watch videos before bed',
    script: '"Screens are like a bright sunshine for your brain! They tell your brain it\'s daytime, not bedtime. Let\'s give your brain the nighttime signal by reading books instead. What book should we read together?"',
    tips: [
      'Create a calming bedtime routine without screens',
      'Keep devices out of the bedroom',
      'Lead by example - parents should also avoid screens before bed',
      'Offer engaging alternatives like stories or quiet music',
    ],
  },
  {
    id: 3,
    topic: 'Encouraging Physical Play',
    ageGroup: '3-7 years',
    emoji: '🎈',
    scenario: 'When your child only wants screen time',
    script: '"Your body is like a superhero that needs training! Screens are fun, but your muscles, heart, and brain grow strongest when you run, jump, and play. Let\'s be superheroes outside for a bit!"',
    tips: [
      'Schedule outdoor time daily',
      'Join in the physical play yourself',
      'Make movement fun, not a chore',
      'Create screen-free zones like meal times and playrooms',
    ],
  },
  {
    id: 4,
    topic: 'Teaching Good Posture',
    ageGroup: '4-8 years',
    emoji: '🪑',
    scenario: 'When you notice slouching during screen time',
    script: '"Let\'s check our super sitting! Feet on the floor, back straight like a superhero, and screen at eye level. Good posture helps our bodies stay strong and healthy. Can you show me your best superhero sitting?"',
    tips: [
      'Model good posture yourself',
      'Set up ergonomic spaces for device use',
      'Do posture check-ins every 15 minutes',
      'Make it fun with "superhero posture" games',
    ],
  },
  {
    id: 5,
    topic: 'Discussing Content Choices',
    ageGroup: '5-8 years',
    emoji: '📺',
    scenario: 'When helping your child choose what to watch',
    script: '"Let\'s be smart choosers! Is this show teaching us something? Is it making us feel good? Will we be proud we watched it? Let\'s pick something that makes our brain and heart happy."',
    tips: [
      'Preview content before allowing access',
      'Watch together and discuss what you see',
      'Set clear rules about age-appropriate content',
      'Use parental controls and kid-friendly platforms',
    ],
  },
  {
    id: 6,
    topic: 'Balancing Screen Time with Other Activities',
    ageGroup: '3-8 years',
    emoji: '⚖️',
    scenario: 'When planning the day with your child',
    script: '"Let\'s make a fun day plan! We need time for playing, learning, eating, moving, and yes - some screen time too! What should we do first? Remember, the best days have lots of different activities!"',
    tips: [
      'Create visual schedules showing different activities',
      'Involve kids in planning their day',
      'Earn screen time through other activities',
      'Celebrate diverse activities, not just screen time',
    ],
  },
  {
    id: 7,
    topic: 'Handling Tantrum When Screen Time Ends',
    ageGroup: '3-6 years',
    emoji: '😢',
    scenario: 'When your child gets upset about ending screen time',
    script: '"I can see you\'re sad that screen time is over. It\'s okay to feel disappointed. Let\'s take some deep breaths together. What fun thing should we do next? You can choose!"',
    tips: [
      'Acknowledge their feelings without giving in',
      'Stay calm and consistent',
      'Redirect to a planned, exciting activity',
      'Don\'t use screen time as a punishment or reward for tantrums',
    ],
  },
  {
    id: 8,
    topic: 'Online Safety and Kindness',
    ageGroup: '5-8 years',
    emoji: '🛡️',
    scenario: 'When teaching about online interactions',
    script: '"When we use the internet, we need to be kind - just like we are with friends at school. If you see something that makes you feel uncomfortable, yucky, or confused, you should always tell me. I won\'t be mad - I\'m here to help keep you safe."',
    tips: [
      'Keep devices in common areas',
      'Know what apps and games your child uses',
      'Teach them not to share personal information',
      'Create an open, no-judgment environment for discussing online experiences',
    ],
  },
]

export function ParentScripts({ onShare }: ParentScriptsProps): JSX.Element {
  const [selectedScript, setSelectedScript] = useState<Script>(scripts[0])
  const [copied, setCopied] = useState<boolean>(false)

  const handleCopy = async (): Promise<void> => {
    const textToCopy = `${selectedScript.topic}\n\nScenario: ${selectedScript.scenario}\n\nWhat to say:\n"${selectedScript.script}"\n\nTips:\n${selectedScript.tips.map((tip, i) => `${i + 1}. ${tip}`).join('\n')}`
    
    try {
      await navigator.clipboard.writeText(textToCopy)
      setCopied(true)
      setTimeout(() => setCopied(false), 2000)
    } catch (err) {
      console.error('Failed to copy:', err)
    }
  }

  const handleShare = (): void => {
    handleCopy()
    onShare()
  }

  return (
    <div className="space-y-6">
      {/* Introduction */}
      <Card className="bg-gradient-to-r from-green-100 to-blue-100 border-4 border-black">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-black">👨‍👩‍👧‍👦 Parent Talking Scripts</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg text-black leading-relaxed">
            These conversation starters help you discuss healthy tech habits with your children in an age-appropriate, positive way. Choose a topic below to get started!
          </p>
        </CardContent>
      </Card>

      {/* Script Selection */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {scripts.map((script) => (
          <button
            key={script.id}
            onClick={() => setSelectedScript(script)}
            className={`text-left p-4 rounded-lg border-4 transition-all ${
              selectedScript.id === script.id
                ? 'bg-blue-100 border-blue-500 shadow-lg'
                : 'bg-white border-gray-300 hover:border-gray-400'
            }`}
          >
            <div className="flex items-start gap-3">
              <span className="text-4xl flex-shrink-0">{script.emoji}</span>
              <div className="flex-1">
                <h3 className="font-bold text-lg text-black mb-1">{script.topic}</h3>
                <Badge variant="secondary" className="text-xs">
                  Ages {script.ageGroup}
                </Badge>
              </div>
            </div>
          </button>
        ))}
      </div>

      {/* Selected Script Details */}
      <Card className="bg-white border-4 border-black">
        <CardHeader className="bg-gradient-to-r from-purple-100 to-pink-100">
          <div className="flex items-center justify-between flex-wrap gap-4">
            <div className="flex items-center gap-3">
              <span className="text-5xl">{selectedScript.emoji}</span>
              <div>
                <CardTitle className="text-2xl text-black">{selectedScript.topic}</CardTitle>
                <Badge className="mt-2">Ages {selectedScript.ageGroup}</Badge>
              </div>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleCopy}
                variant="outline"
                size="lg"
                className="border-2 border-black"
              >
                {copied ? (
                  <>
                    <Check className="mr-2 h-5 w-5" />
                    Copied!
                  </>
                ) : (
                  <>
                    <Copy className="mr-2 h-5 w-5" />
                    Copy
                  </>
                )}
              </Button>
              <Button
                onClick={handleShare}
                size="lg"
                className="bg-green-500 hover:bg-green-600"
              >
                <Share2 className="mr-2 h-5 w-5" />
                Share
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pt-6 space-y-6">
          {/* Scenario */}
          <div className="bg-yellow-50 border-4 border-yellow-300 rounded-lg p-6">
            <h3 className="font-bold text-xl text-black mb-3 flex items-center gap-2">
              <span>📍</span> When to Use This:
            </h3>
            <p className="text-lg text-black leading-relaxed">{selectedScript.scenario}</p>
          </div>

          {/* Script */}
          <div className="bg-blue-50 border-4 border-blue-300 rounded-lg p-6">
            <h3 className="font-bold text-xl text-black mb-3 flex items-center gap-2">
              <span>💬</span> What to Say:
            </h3>
            <p className="text-lg text-black italic leading-relaxed border-l-4 border-blue-500 pl-4">
              "{selectedScript.script}"
            </p>
          </div>

          {/* Tips */}
          <div className="bg-green-50 border-4 border-green-300 rounded-lg p-6">
            <h3 className="font-bold text-xl text-black mb-4 flex items-center gap-2">
              <span>💡</span> Helpful Tips:
            </h3>
            <ul className="space-y-3">
              {selectedScript.tips.map((tip, index) => (
                <li key={index} className="flex items-start gap-3">
                  <span className="font-bold text-green-600 text-lg flex-shrink-0">{index + 1}.</span>
                  <span className="text-lg text-black">{tip}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Additional Advice */}
          <div className="bg-purple-50 border-4 border-purple-300 rounded-lg p-6">
            <h3 className="font-bold text-xl text-black mb-3 flex items-center gap-2">
              <span>⭐</span> Remember:
            </h3>
            <ul className="space-y-2 text-lg text-black">
              <li>• Be consistent with rules and expectations</li>
              <li>• Model the behavior you want to see</li>
              <li>• Make it positive, not punitive</li>
              <li>• Adjust your approach based on your child's personality</li>
              <li>• Celebrate small wins and progress</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
