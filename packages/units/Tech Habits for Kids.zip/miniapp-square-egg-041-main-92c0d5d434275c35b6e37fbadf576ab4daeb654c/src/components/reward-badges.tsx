'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import { Lock, Sparkles } from 'lucide-react'

interface BadgeType {
  id: string
  name: string
  description: string
  emoji: string
  earned: boolean
}

interface RewardBadgesProps {
  badges: BadgeType[]
}

export function RewardBadges({ badges }: RewardBadgesProps): JSX.Element {
  const earnedCount = badges.filter(b => b.earned).length
  const totalCount = badges.length
  const progress = (earnedCount / totalCount) * 100

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-yellow-100 to-orange-100 border-4 border-black">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-black flex items-center gap-3">
            <span className="text-5xl">🏆</span>
            My Badge Collection
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <p className="text-xl font-semibold text-black">
                You've earned {earnedCount} out of {totalCount} badges!
              </p>
              <Badge className="text-lg px-4 py-2 bg-yellow-500">
                {Math.round(progress)}% Complete
              </Badge>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-6 border-2 border-black">
              <div
                className="bg-gradient-to-r from-yellow-400 to-orange-500 h-full rounded-full transition-all duration-500 flex items-center justify-center"
                style={{ width: `${progress}%` }}
              >
                {progress > 20 && (
                  <span className="text-sm font-bold text-white">{Math.round(progress)}%</span>
                )}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Badge Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {badges.map((badge) => (
          <Card
            key={badge.id}
            className={`border-4 transition-all ${
              badge.earned
                ? 'bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-500 shadow-xl'
                : 'bg-gray-50 border-gray-300 opacity-60'
            }`}
          >
            <CardContent className="pt-6">
              <div className="text-center space-y-4">
                {/* Badge Icon */}
                <div
                  className={`mx-auto w-24 h-24 rounded-full flex items-center justify-center text-6xl border-4 ${
                    badge.earned
                      ? 'bg-gradient-to-br from-yellow-200 to-orange-200 border-yellow-500 animate-pulse'
                      : 'bg-gray-200 border-gray-400'
                  }`}
                >
                  {badge.earned ? badge.emoji : <Lock className="h-10 w-10 text-gray-400" />}
                </div>

                {/* Badge Name */}
                <div>
                  <h3 className={`text-xl font-bold mb-2 ${badge.earned ? 'text-black' : 'text-gray-500'}`}>
                    {badge.name}
                  </h3>
                  <p className={`text-sm ${badge.earned ? 'text-black' : 'text-gray-400'}`}>
                    {badge.description}
                  </p>
                </div>

                {/* Earned Status */}
                {badge.earned ? (
                  <div className="bg-yellow-100 border-2 border-yellow-500 rounded-lg p-3">
                    <p className="text-sm font-bold text-black flex items-center justify-center gap-2">
                      <Sparkles className="h-4 w-4 text-yellow-600" />
                      Earned!
                      <Sparkles className="h-4 w-4 text-yellow-600" />
                    </p>
                  </div>
                ) : (
                  <div className="bg-gray-100 border-2 border-gray-300 rounded-lg p-3">
                    <p className="text-sm font-semibold text-gray-500">Keep going to unlock!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Encouragement Message */}
      <Card className="bg-gradient-to-r from-purple-100 to-pink-100 border-4 border-black">
        <CardContent className="pt-6">
          <div className="text-center space-y-3">
            <p className="text-2xl font-bold text-black">
              {earnedCount === totalCount ? (
                <>🎊 Wow! You earned ALL the badges! You're a Healthy Tech Habits Champion! 🎊</>
              ) : earnedCount >= totalCount / 2 ? (
                <>🌟 Great job! You're more than halfway there! Keep it up! 🌟</>
              ) : earnedCount > 0 ? (
                <>⭐ Nice work! You're making great progress! ⭐</>
              ) : (
                <>🚀 Start your journey and earn your first badge! 🚀</>
              )}
            </p>
            {earnedCount < totalCount && (
              <div className="bg-white rounded-lg p-4 border-2 border-purple-300">
                <p className="text-lg text-black font-semibold mb-2">How to earn more badges:</p>
                <ul className="text-left text-black space-y-2">
                  <li>✅ Complete daily lessons</li>
                  <li>⏰ Use the tech timer regularly</li>
                  <li>🧠 Take fun quizzes</li>
                  <li>💬 Share with your parents</li>
                  <li>🏃 Take screen time breaks</li>
                </ul>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
