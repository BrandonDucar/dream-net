'use client'

import { useState, useEffect, useRef } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Progress } from '@/components/ui/progress'
import { Play, Pause, RotateCcw, Clock, AlertCircle } from 'lucide-react'

interface TechTimeTrackerProps {
  onTimerUse: () => void
  onBreakComplete: () => void
}

interface TimeSession {
  duration: number
  timestamp: number
}

export function TechTimeTracker({ onTimerUse, onBreakComplete }: TechTimeTrackerProps): JSX.Element {
  const [selectedMinutes, setSelectedMinutes] = useState<number>(15)
  const [timeLeft, setTimeLeft] = useState<number>(0)
  const [isRunning, setIsRunning] = useState<boolean>(false)
  const [isPaused, setIsPaused] = useState<boolean>(false)
  const [totalTimeToday, setTotalTimeToday] = useState<number>(0)
  const [timerCount, setTimerCount] = useState<number>(0)
  const [breakCount, setBreakCount] = useState<number>(0)
  const [showBreakReminder, setShowBreakReminder] = useState<boolean>(false)
  const intervalRef = useRef<NodeJS.Timeout | null>(null)

  // Load saved data
  useEffect(() => {
    const savedSessions = localStorage.getItem('techTimeSessions')
    const savedTimerCount = localStorage.getItem('timerUsageCount')
    const savedBreakCount = localStorage.getItem('breakCount')
    
    if (savedSessions) {
      const sessions: TimeSession[] = JSON.parse(savedSessions)
      const today = new Date().setHours(0, 0, 0, 0)
      const todaySessions = sessions.filter(s => new Date(s.timestamp).setHours(0, 0, 0, 0) === today)
      const total = todaySessions.reduce((sum, session) => sum + session.duration, 0)
      setTotalTimeToday(total)
    }
    
    if (savedTimerCount) {
      setTimerCount(parseInt(savedTimerCount))
    }
    
    if (savedBreakCount) {
      setBreakCount(parseInt(savedBreakCount))
    }
  }, [])

  // Timer logic
  useEffect(() => {
    if (isRunning && !isPaused && timeLeft > 0) {
      intervalRef.current = setInterval(() => {
        setTimeLeft(prev => {
          if (prev <= 1) {
            handleTimerComplete()
            return 0
          }
          return prev - 1
        })
      }, 1000)
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isRunning, isPaused, timeLeft])

  const handleStart = (): void => {
    if (!isRunning) {
      setTimeLeft(selectedMinutes * 60)
      setIsRunning(true)
      setIsPaused(false)
      
      // Track timer usage
      const newCount = timerCount + 1
      setTimerCount(newCount)
      localStorage.setItem('timerUsageCount', newCount.toString())
      
      if (newCount >= 5) {
        onTimerUse()
      }
    }
  }

  const handlePause = (): void => {
    setIsPaused(!isPaused)
  }

  const handleReset = (): void => {
    setIsRunning(false)
    setIsPaused(false)
    setTimeLeft(0)
  }

  const handleTimerComplete = (): void => {
    setIsRunning(false)
    setIsPaused(false)
    
    // Save session
    const sessions: TimeSession[] = JSON.parse(localStorage.getItem('techTimeSessions') || '[]')
    sessions.push({
      duration: selectedMinutes,
      timestamp: Date.now(),
    })
    localStorage.setItem('techTimeSessions', JSON.stringify(sessions))
    
    // Update total time
    setTotalTimeToday(prev => prev + selectedMinutes)
    
    // Show break reminder
    setShowBreakReminder(true)
    
    // Play completion sound (optional)
    if (typeof Audio !== 'undefined') {
      const audio = new Audio('data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIGmm98OShUA0PULF')
      audio.play().catch(() => {})
    }
  }

  const handleBreakComplete = (): void => {
    setShowBreakReminder(false)
    const newCount = breakCount + 1
    setBreakCount(newCount)
    localStorage.setItem('breakCount', newCount.toString())
    
    if (newCount >= 3) {
      onBreakComplete()
    }
  }

  const formatTime = (seconds: number): string => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const progress = isRunning ? ((selectedMinutes * 60 - timeLeft) / (selectedMinutes * 60)) * 100 : 0
  const totalHours = Math.floor(totalTimeToday / 60)
  const totalMins = totalTimeToday % 60

  const timePresets = [5, 10, 15, 20, 30, 45, 60]

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-100 to-blue-100 border-4 border-black">
        <CardHeader>
          <CardTitle className="text-3xl font-bold text-black flex items-center gap-3">
            <span className="text-5xl">⏰</span>
            Tech Time Tracker
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-lg text-black">
            Set a timer to help you keep track of your screen time. Remember to take breaks!
          </p>
        </CardContent>
      </Card>

      {/* Break Reminder Modal */}
      {showBreakReminder && (
        <Card className="bg-gradient-to-r from-green-100 to-emerald-100 border-4 border-green-500 animate-pulse">
          <CardContent className="pt-6">
            <div className="text-center space-y-4">
              <div className="text-6xl">🎉</div>
              <h3 className="text-2xl font-bold text-black">Time for a Break!</h3>
              <p className="text-lg text-black">
                Great job using your timer! Now it's time to give your eyes and body a rest.
              </p>
              <div className="bg-white rounded-lg p-4 border-2 border-green-500">
                <p className="font-bold text-black mb-2">Break Time Activities:</p>
                <ul className="text-left text-black space-y-1">
                  <li>👀 Look out the window for 20 seconds</li>
                  <li>🤸 Do 10 jumping jacks</li>
                  <li>💧 Get a drink of water</li>
                  <li>🧘 Stretch your arms and legs</li>
                </ul>
              </div>
              <Button
                onClick={handleBreakComplete}
                size="lg"
                className="bg-green-500 hover:bg-green-600 text-xl py-6"
              >
                I Took a Break! ✓
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Timer Display */}
      <Card className="bg-white border-4 border-black">
        <CardContent className="pt-6">
          <div className="text-center space-y-6">
            {/* Time Display */}
            <div className="relative">
              <div className="mx-auto w-64 h-64 rounded-full bg-gradient-to-br from-purple-200 to-blue-200 flex items-center justify-center border-8 border-purple-500">
                <div className="text-center">
                  <Clock className="h-12 w-12 mx-auto mb-4 text-purple-700" />
                  <div className="text-5xl font-bold text-black">
                    {isRunning ? formatTime(timeLeft) : `${selectedMinutes}:00`}
                  </div>
                  <div className="text-sm text-black mt-2">
                    {isRunning ? (isPaused ? 'Paused' : 'Running') : 'Ready'}
                  </div>
                </div>
              </div>
              {isRunning && (
                <div className="mt-4">
                  <Progress value={progress} className="h-4" />
                </div>
              )}
            </div>

            {/* Time Selection */}
            {!isRunning && (
              <div>
                <p className="text-lg font-semibold text-black mb-4">Choose your screen time:</p>
                <div className="grid grid-cols-3 md:grid-cols-4 gap-3">
                  {timePresets.map((minutes) => (
                    <Button
                      key={minutes}
                      onClick={() => setSelectedMinutes(minutes)}
                      variant={selectedMinutes === minutes ? 'default' : 'outline'}
                      size="lg"
                      className={`text-lg py-6 ${
                        selectedMinutes === minutes
                          ? 'bg-purple-500 hover:bg-purple-600'
                          : 'border-2 border-black'
                      }`}
                    >
                      {minutes} min
                    </Button>
                  ))}
                </div>
              </div>
            )}

            {/* Control Buttons */}
            <div className="flex gap-4 justify-center">
              {!isRunning ? (
                <Button
                  onClick={handleStart}
                  size="lg"
                  className="bg-green-500 hover:bg-green-600 text-xl px-8 py-6"
                >
                  <Play className="mr-2 h-6 w-6" />
                  Start Timer
                </Button>
              ) : (
                <>
                  <Button
                    onClick={handlePause}
                    size="lg"
                    variant="outline"
                    className="border-4 border-black text-xl px-8 py-6"
                  >
                    <Pause className="mr-2 h-6 w-6" />
                    {isPaused ? 'Resume' : 'Pause'}
                  </Button>
                  <Button
                    onClick={handleReset}
                    size="lg"
                    variant="outline"
                    className="border-4 border-black text-xl px-8 py-6"
                  >
                    <RotateCcw className="mr-2 h-6 w-6" />
                    Reset
                  </Button>
                </>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Today's Summary */}
      <Card className="bg-gradient-to-r from-blue-100 to-cyan-100 border-4 border-black">
        <CardHeader>
          <CardTitle className="text-2xl text-black flex items-center gap-2">
            <span>📊</span> Today's Screen Time
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-white rounded-lg p-4 border-2 border-blue-500 text-center">
              <div className="text-3xl font-bold text-black">
                {totalHours}h {totalMins}m
              </div>
              <div className="text-sm text-black mt-1">Total Time</div>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-purple-500 text-center">
              <div className="text-3xl font-bold text-black">{timerCount}</div>
              <div className="text-sm text-black mt-1">Times Used</div>
            </div>
            <div className="bg-white rounded-lg p-4 border-2 border-green-500 text-center">
              <div className="text-3xl font-bold text-black">{breakCount}</div>
              <div className="text-sm text-black mt-1">Breaks Taken</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Tips */}
      <Card className="bg-yellow-50 border-4 border-yellow-400">
        <CardContent className="pt-6">
          <div className="flex items-start gap-4">
            <AlertCircle className="h-8 w-8 text-yellow-600 flex-shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-xl text-black mb-2">Healthy Screen Time Tips:</h3>
              <ul className="space-y-2 text-black">
                <li>• Take a 5-minute break every 20-30 minutes</li>
                <li>• Look at something far away to rest your eyes</li>
                <li>• Stand up and move your body during breaks</li>
                <li>• Drink water and stay hydrated</li>
                <li>• Remember: Balance is important!</li>
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
