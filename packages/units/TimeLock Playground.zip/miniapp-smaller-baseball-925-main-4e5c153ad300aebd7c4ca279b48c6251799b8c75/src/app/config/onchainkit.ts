export const ONCHAINKIT_API_KEY = 'af1b55a2-1be2-4cad-bf91-ca7ab6e1dd05';
export const ONCHAINKIT_PROJECT_ID = '95f58f80-0e6e-4f44-850d-b13a7b4e5bbf';
