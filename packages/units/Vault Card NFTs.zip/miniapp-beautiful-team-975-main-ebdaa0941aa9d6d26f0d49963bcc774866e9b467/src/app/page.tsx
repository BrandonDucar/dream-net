'use client'
import { useState, useEffect } from 'react';
import { usePrivy } from '@privy-io/react-auth';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { VaultCardDisplay } from '@/components/vault-card-display';
import { CreateCardDialog, type CardCreationData } from '@/components/create-card-dialog';
import { CardDetailsDialog } from '@/components/card-details-dialog';
import { TransactionHistory } from '@/components/transaction-history';
import { AnalyticsDashboard } from '@/components/analytics-dashboard';
import { mockVaultCards } from '@/lib/mock-data';
import { mockTransactions } from '@/lib/mock-transactions';
import type { VaultCard } from '@/types/vault-card';
import type { Transaction } from '@/types/transaction';
import { Wallet, Sparkles, Shield, Zap, TrendingUp, Users, BadgeCheck, BarChart3, Clock } from 'lucide-react';
import { toast } from 'sonner';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const { ready, authenticated, login, user } = usePrivy();
  const [vaultCards, setVaultCards] = useState<VaultCard[]>(mockVaultCards);
  const [transactions, setTransactions] = useState<Transaction[]>(mockTransactions);
  const [selectedCard, setSelectedCard] = useState<VaultCard | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [activeView, setActiveView] = useState<'cards' | 'analytics' | 'history'>('cards');

  const handleCreateCard = (cardData: CardCreationData) => {
    const newCard: VaultCard = {
      id: String(vaultCards.length + 1),
      name: cardData.name,
      tokenId: 1000 + vaultCards.length + 1,
      vaultAddress: `0x${Math.random().toString(16).substring(2, 42)}`,
      balance: cardData.initialBalance,
      cardDesign: cardData.cardDesign,
      rules: {
        dailyLimit: cardData.rules.dailyLimit,
        weeklyLimit: cardData.rules.weeklyLimit,
        monthlyLimit: cardData.rules.monthlyLimit,
        requiresApproval: cardData.rules.requiresApproval,
        minApprovers: 1,
      },
      autoFeatures: {
        autoTopUp: {
          enabled: cardData.autoFeatures.autoTopUp,
          threshold: '20.00',
          amount: '50.00',
        },
        autoLock: {
          enabled: cardData.autoFeatures.autoLock,
          conditions: ['Custom conditions'],
        },
        autoStream: {
          enabled: cardData.autoFeatures.autoStream,
        },
        autoAllocate: {
          enabled: cardData.autoFeatures.autoAllocate,
          allocations: [
            { percentage: 50, destination: 'Primary', label: 'Primary' },
            { percentage: 50, destination: 'Reserve', label: 'Reserve' },
          ],
        },
        autoTax: {
          enabled: cardData.autoFeatures.autoTax,
          rate: 10,
        },
      },
      createdAt: new Date(),
      owner: user?.wallet?.address || '0x000...',
    };

    setVaultCards([...vaultCards, newCard]);
    toast.success('Vault Card minted successfully! 🎉');
  };

  const handleCardClick = (card: VaultCard) => {
    setSelectedCard(card);
    setDetailsOpen(true);
  };

  const handleSpend = (cardId: string, amount: string, recipient: string, category: string, description: string) => {
    // Create new transaction
    const newTransaction: Transaction = {
      id: `tx${transactions.length + 1}`,
      cardId,
      type: 'spend',
      amount,
      description,
      category,
      recipient,
      status: vaultCards.find(c => c.id === cardId)?.rules.requiresApproval ? 'requires_approval' : 'completed',
      timestamp: new Date(),
      hash: `0x${Math.random().toString(16).substring(2, 42)}`,
      metadata: {
        approved: !vaultCards.find(c => c.id === cardId)?.rules.requiresApproval,
      },
    };

    // Update card balance
    setVaultCards(cards =>
      cards.map(card => {
        if (card.id === cardId && newTransaction.status === 'completed') {
          return {
            ...card,
            balance: (parseFloat(card.balance) - parseFloat(amount)).toFixed(2),
            lastUsed: new Date(),
          };
        }
        return card;
      })
    );

    // Add transaction
    setTransactions([newTransaction, ...transactions]);
  };

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-pulse text-lg">Loading Base Vault Cards...</div>
      </div>
    );
  }

  if (!authenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
        {/* Hero Section */}
        <div className="container mx-auto px-4 py-16">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-medium mb-4">
              <BadgeCheck className="w-4 h-4" />
              Built on Base
            </div>
            
            <h1 className="text-6xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              BASE VAULT CARDS
            </h1>
            
            <p className="text-2xl text-gray-600 max-w-2xl mx-auto">
              Mint cards tied to real onchain vaults. Not debit. Not credit. Something new.
            </p>

            <div className="flex justify-center gap-4 pt-4">
              <Button size="lg" onClick={login} className="text-lg px-8">
                <Wallet className="w-5 h-5 mr-2" />
                Connect Wallet
              </Button>
            </div>

            {/* Feature Grid */}
            <div className="grid md:grid-cols-3 gap-6 pt-12">
              <Card className="p-6 text-left hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Each Card is an NFT</h3>
                <p className="text-gray-600 text-sm">
                  Tied to a segregated smart vault on Base. Full onchain ownership and control.
                </p>
              </Card>

              <Card className="p-6 text-left hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center mb-4">
                  <Sparkles className="w-6 h-6 text-purple-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Programmable Rules</h3>
                <p className="text-gray-600 text-sm">
                  Spendable only within the rules you set. Daily limits, approvals, and more.
                </p>
              </Card>

              <Card className="p-6 text-left hover:shadow-lg transition-shadow">
                <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-green-600" />
                </div>
                <h3 className="font-semibold text-lg mb-2">Auto Features</h3>
                <p className="text-gray-600 text-sm">
                  Auto-top up, auto-lock, auto-stream, auto-allocate, auto-tax withholding.
                </p>
              </Card>
            </div>
          </div>
        </div>

        {/* Use Cases Section */}
        <div className="bg-white py-16">
          <div className="container mx-auto px-4">
            <div className="max-w-4xl mx-auto">
              <h2 className="text-3xl font-bold text-center mb-12">Perfect For</h2>
              
              <div className="grid md:grid-cols-2 gap-6">
                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <Users className="w-5 h-5 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Parents</h3>
                      <p className="text-gray-600 text-sm">
                        Give kids controlled spending power with automatic limits and approval requirements
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-5 h-5 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Side Businesses</h3>
                      <p className="text-gray-600 text-sm">
                        Separate business expenses with auto-tax withholding and category controls
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                      <Wallet className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">Personal Budgeting</h3>
                      <p className="text-gray-600 text-sm">
                        Auto-allocate income across savings, spending, and investments
                      </p>
                    </div>
                  </div>
                </Card>

                <Card className="p-6 hover:shadow-lg transition-shadow">
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                      <Shield className="w-5 h-5 text-orange-600" />
                    </div>
                    <div>
                      <h3 className="font-semibold mb-2">DAOs</h3>
                      <p className="text-gray-600 text-sm">
                        Treasury management with multi-sig approvals and automatic distributions
                      </p>
                    </div>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </div>

        {/* CTA Section */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 py-16">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold text-white mb-4">
              Nobody has this yet.
            </h2>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Be among the first to mint programmable vault cards on Base
            </p>
            <Button size="lg" variant="secondary" onClick={login} className="text-lg px-8">
              <Wallet className="w-5 h-5 mr-2" />
              Get Started
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                BASE VAULT CARDS
              </h1>
              <p className="text-sm text-gray-600">
                {user?.wallet?.address ? (
                  <span className="font-mono">
                    {user.wallet.address.slice(0, 6)}...{user.wallet.address.slice(-4)}
                  </span>
                ) : (
                  'Connected'
                )}
              </p>
            </div>
            <CreateCardDialog onCreateCard={handleCreateCard} />
          </div>

          {/* Navigation Tabs */}
          <div className="flex gap-2">
            <Button
              variant={activeView === 'cards' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('cards')}
              className="gap-2"
            >
              <Wallet className="w-4 h-4" />
              Cards
            </Button>
            <Button
              variant={activeView === 'analytics' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('analytics')}
              className="gap-2"
            >
              <BarChart3 className="w-4 h-4" />
              Analytics
            </Button>
            <Button
              variant={activeView === 'history' ? 'default' : 'ghost'}
              size="sm"
              onClick={() => setActiveView('history')}
              className="gap-2"
            >
              <Clock className="w-4 h-4" />
              History
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-8">
        {activeView === 'cards' && (
          <>
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">Your Vault Cards</h2>
              <p className="text-gray-600">
                {vaultCards.length} card{vaultCards.length !== 1 ? 's' : ''} minted
              </p>
            </div>

            {vaultCards.length === 0 ? (
              <Card className="p-12 text-center">
                <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
                  <Wallet className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-semibold mb-2">No vault cards yet</h3>
                <p className="text-gray-600 mb-6">
                  Create your first vault card to get started
                </p>
                <CreateCardDialog onCreateCard={handleCreateCard} />
              </Card>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {vaultCards.map((card) => (
                  <VaultCardDisplay
                    key={card.id}
                    card={card}
                    onClick={() => handleCardClick(card)}
                  />
                ))}
              </div>
            )}
          </>
        )}

        {activeView === 'analytics' && (
          <>
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">Analytics Dashboard</h2>
              <p className="text-gray-600">
                Insights into your spending patterns and card usage
              </p>
            </div>
            <AnalyticsDashboard cards={vaultCards} transactions={transactions} />
          </>
        )}

        {activeView === 'history' && (
          <>
            <div className="mb-8">
              <h2 className="text-2xl font-bold mb-2">Transaction History</h2>
              <p className="text-gray-600">
                {transactions.length} total transactions across all cards
              </p>
            </div>
            <TransactionHistory transactions={transactions} />
          </>
        )}
      </div>

      <CardDetailsDialog
        card={selectedCard}
        open={detailsOpen}
        onOpenChange={setDetailsOpen}
        onSpend={handleSpend}
      />
    </div>
  );
}
