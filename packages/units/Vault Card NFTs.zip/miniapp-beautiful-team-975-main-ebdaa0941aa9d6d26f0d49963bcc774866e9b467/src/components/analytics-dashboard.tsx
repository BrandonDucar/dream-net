'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import type { Transaction } from '@/types/transaction';
import type { VaultCard } from '@/types/vault-card';
import { 
  TrendingUp, 
  TrendingDown, 
  DollarSign, 
  Activity,
  PieChart as PieChartIcon,
  BarChart3
} from 'lucide-react';
import { BarChart, Bar, PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { format, subDays, startOfDay } from 'date-fns';

interface AnalyticsDashboardProps {
  cards: VaultCard[];
  transactions: Transaction[];
}

const COLORS = ['#3b82f6', '#8b5cf6', '#10b981', '#f59e0b', '#ef4444', '#06b6d4'];

export function AnalyticsDashboard({ cards, transactions }: AnalyticsDashboardProps) {
  // Calculate total balance across all cards
  const totalBalance = cards.reduce((sum, card) => sum + parseFloat(card.balance), 0);

  // Calculate spending analytics
  const spendTransactions = transactions.filter(tx => tx.type === 'spend' && tx.status === 'completed');
  const totalSpent = spendTransactions.reduce((sum, tx) => sum + parseFloat(tx.amount), 0);

  // Category breakdown
  const categoryData = spendTransactions.reduce((acc, tx) => {
    const category = tx.category || 'Uncategorized';
    if (!acc[category]) {
      acc[category] = { category, amount: 0, count: 0 };
    }
    acc[category].amount += parseFloat(tx.amount);
    acc[category].count += 1;
    return acc;
  }, {} as Record<string, { category: string; amount: number; count: number }>);

  const categoryBreakdown = Object.values(categoryData).map(item => ({
    ...item,
    percentage: totalSpent > 0 ? (item.amount / totalSpent) * 100 : 0,
  }));

  // Daily spending trend (last 7 days)
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const date = startOfDay(subDays(new Date(), 6 - i));
    return {
      date: format(date, 'MMM dd'),
      timestamp: date.getTime(),
      amount: 0,
    };
  });

  spendTransactions.forEach(tx => {
    const txDate = startOfDay(tx.timestamp).getTime();
    const dayEntry = last7Days.find(d => d.timestamp === txDate);
    if (dayEntry) {
      dayEntry.amount += parseFloat(tx.amount);
    }
  });

  // Card distribution
  const cardBalances = cards.map(card => ({
    name: card.name,
    balance: parseFloat(card.balance),
    percentage: totalBalance > 0 ? (parseFloat(card.balance) / totalBalance) * 100 : 0,
  }));

  // Transaction type breakdown
  const transactionTypes = transactions.reduce((acc, tx) => {
    if (!acc[tx.type]) {
      acc[tx.type] = 0;
    }
    acc[tx.type] += 1;
    return acc;
  }, {} as Record<string, number>);

  const typeBreakdown = Object.entries(transactionTypes).map(([type, count]) => ({
    type: type.charAt(0).toUpperCase() + type.slice(1),
    count,
  }));

  // Recent activity stats
  const last24hTransactions = transactions.filter(tx => 
    tx.timestamp.getTime() > Date.now() - 24 * 60 * 60 * 1000
  );

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Balance</p>
                <p className="text-2xl font-bold">${totalBalance.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center">
                <DollarSign className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Total Spent</p>
                <p className="text-2xl font-bold">${totalSpent.toFixed(2)}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-red-100 flex items-center justify-center">
                <TrendingDown className="w-6 h-6 text-red-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">Active Cards</p>
                <p className="text-2xl font-bold">{cards.length}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-purple-100 flex items-center justify-center">
                <PieChartIcon className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600 mb-1">24h Transactions</p>
                <p className="text-2xl font-bold">{last24hTransactions.length}</p>
              </div>
              <div className="w-12 h-12 rounded-full bg-green-100 flex items-center justify-center">
                <Activity className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="spending" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="spending">Spending Trend</TabsTrigger>
          <TabsTrigger value="categories">Categories</TabsTrigger>
          <TabsTrigger value="cards">Card Distribution</TabsTrigger>
        </TabsList>

        <TabsContent value="spending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <BarChart3 className="w-5 h-5" />
                Daily Spending (Last 7 Days)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={last7Days}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip 
                    formatter={(value: number) => `$${value.toFixed(2)}`}
                    labelStyle={{ color: '#000' }}
                  />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="amount" 
                    stroke="#3b82f6" 
                    strokeWidth={2}
                    name="Spending"
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="categories" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Category Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={categoryBreakdown}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={(entry) => `${entry.category}: $${entry.amount.toFixed(0)}`}
                      outerRadius={80}
                      fill="#8884d8"
                      dataKey="amount"
                    >
                      {categoryBreakdown.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip 
                      formatter={(value: number) => `$${value.toFixed(2)}`}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Categories</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {categoryBreakdown
                    .sort((a, b) => b.amount - a.amount)
                    .slice(0, 5)
                    .map((category, index) => (
                      <div key={category.category}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">{category.category}</span>
                          <span className="text-sm font-bold">${category.amount.toFixed(2)}</span>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="h-2 rounded-full"
                            style={{
                              width: `${category.percentage}%`,
                              backgroundColor: COLORS[index % COLORS.length],
                            }}
                          />
                        </div>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-xs text-gray-500">{category.count} transactions</span>
                          <span className="text-xs text-gray-500">{category.percentage.toFixed(1)}%</span>
                        </div>
                      </div>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="cards" className="space-y-4">
          <div className="grid md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Balance Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={cardBalances}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip 
                      formatter={(value: number) => `$${value.toFixed(2)}`}
                      labelStyle={{ color: '#000' }}
                    />
                    <Legend />
                    <Bar dataKey="balance" fill="#8b5cf6" name="Balance" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Card Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {cardBalances.map((card, index) => (
                    <div key={card.name} className="p-4 rounded-lg border bg-white">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold">{card.name}</span>
                        <span className="text-lg font-bold">${card.balance.toFixed(2)}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className="h-2 rounded-full"
                          style={{
                            width: `${card.percentage}%`,
                            backgroundColor: COLORS[index % COLORS.length],
                          }}
                        />
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        {card.percentage.toFixed(1)}% of total balance
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
