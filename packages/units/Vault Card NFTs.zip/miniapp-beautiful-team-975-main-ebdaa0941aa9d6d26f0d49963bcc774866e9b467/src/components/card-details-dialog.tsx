'use client'

import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { SpendCardDialog } from '@/components/spend-card-dialog';
import type { VaultCard } from '@/types/vault-card';
import { Wallet, Lock, TrendingUp, Zap, ArrowUpDown, Calculator, Shield, Clock } from 'lucide-react';

interface CardDetailsDialogProps {
  card: VaultCard | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSpend?: (cardId: string, amount: string, recipient: string, category: string, description: string) => void;
}

const cardDesigns = {
  'gradient-blue': 'bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700',
  'gradient-purple': 'bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600',
  'gradient-green': 'bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600',
  'gradient-orange': 'bg-gradient-to-br from-orange-500 via-amber-600 to-yellow-600',
};

export function CardDetailsDialog({ card, open, onOpenChange, onSpend }: CardDetailsDialogProps) {
  if (!card) return null;

  const handleSpend = (amount: string, recipient: string, category: string, description: string) => {
    if (onSpend) {
      onSpend(card.id, amount, recipient, category, description);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <div>
              <DialogTitle>Vault Card Details</DialogTitle>
              <DialogDescription>
                NFT #{card.tokenId} • {card.vaultAddress}
              </DialogDescription>
            </div>
            <SpendCardDialog card={card} onSpend={handleSpend} />
          </div>
        </DialogHeader>

        <div className="space-y-6">
          {/* Card Preview */}
          <Card className="overflow-hidden">
            <div className={`${cardDesigns[card.cardDesign]} p-8 text-white relative`}>
              <div className="absolute top-4 right-4 text-xs font-mono opacity-70">
                #{card.tokenId}
              </div>
              
              <div className="flex flex-col gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Wallet className="w-5 h-5" />
                    <span className="text-sm font-medium opacity-90">Vault Card</span>
                  </div>
                  <h3 className="text-2xl font-bold mb-1">{card.name}</h3>
                </div>

                <div>
                  <div className="text-4xl font-bold mb-2">${card.balance}</div>
                  <div className="text-sm font-mono opacity-70">
                    {card.vaultAddress}
                  </div>
                </div>
              </div>
            </div>
          </Card>

          {/* Spending Rules */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-3">
              <Shield className="w-4 h-4" />
              Spending Rules
            </h3>
            <Card className="p-4">
              <div className="grid gap-3">
                {card.rules.dailyLimit && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Daily Limit</span>
                    <Badge variant="secondary">${card.rules.dailyLimit}</Badge>
                  </div>
                )}
                {card.rules.weeklyLimit && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Weekly Limit</span>
                    <Badge variant="secondary">${card.rules.weeklyLimit}</Badge>
                  </div>
                )}
                {card.rules.monthlyLimit && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Monthly Limit</span>
                    <Badge variant="secondary">${card.rules.monthlyLimit}</Badge>
                  </div>
                )}
                {card.rules.requiresApproval && (
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Approval Required</span>
                    <Badge>Yes ({card.rules.minApprovers || 1} approver{(card.rules.minApprovers || 1) > 1 ? 's' : ''})</Badge>
                  </div>
                )}
                {card.rules.allowedCategories && card.rules.allowedCategories.length > 0 && (
                  <div>
                    <span className="text-sm text-gray-600 block mb-2">Allowed Categories</span>
                    <div className="flex flex-wrap gap-1">
                      {card.rules.allowedCategories.map((cat) => (
                        <Badge key={cat} variant="outline" className="text-xs">
                          {cat}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </Card>
          </div>

          {/* Auto Features */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-3">
              <Zap className="w-4 h-4" />
              Auto Features
            </h3>
            <div className="grid gap-3">
              {card.autoFeatures.autoTopUp.enabled && (
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-blue-100 flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium mb-1">Auto Top-up</div>
                      <div className="text-sm text-gray-600">
                        When balance drops below ${card.autoFeatures.autoTopUp.threshold || '0'}, 
                        automatically add ${card.autoFeatures.autoTopUp.amount || '0'}
                      </div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </Card>
              )}

              {card.autoFeatures.autoLock.enabled && (
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center flex-shrink-0">
                      <Lock className="w-4 h-4 text-orange-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium mb-1">Auto Lock</div>
                      <div className="text-sm text-gray-600">
                        {card.autoFeatures.autoLock.conditions?.join(', ') || 'Custom conditions'}
                      </div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </Card>
              )}

              {card.autoFeatures.autoStream.enabled && (
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-purple-100 flex items-center justify-center flex-shrink-0">
                      <ArrowUpDown className="w-4 h-4 text-purple-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium mb-1">Auto Stream</div>
                      <div className="text-sm text-gray-600">
                        Streaming to {card.autoFeatures.autoStream.recipients?.length || 0} recipient(s)
                      </div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </Card>
              )}

              {card.autoFeatures.autoAllocate.enabled && (
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-indigo-100 flex items-center justify-center flex-shrink-0">
                      <TrendingUp className="w-4 h-4 text-indigo-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium mb-1">Auto Allocate</div>
                      <div className="text-sm text-gray-600 space-y-1">
                        {card.autoFeatures.autoAllocate.allocations?.map((alloc, idx) => (
                          <div key={idx} className="flex justify-between">
                            <span>{alloc.label}</span>
                            <span className="font-medium">{alloc.percentage}%</span>
                          </div>
                        ))}
                      </div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </Card>
              )}

              {card.autoFeatures.autoTax.enabled && (
                <Card className="p-4">
                  <div className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-full bg-emerald-100 flex items-center justify-center flex-shrink-0">
                      <Calculator className="w-4 h-4 text-emerald-600" />
                    </div>
                    <div className="flex-1">
                      <div className="font-medium mb-1">Auto Tax Withholding</div>
                      <div className="text-sm text-gray-600">
                        {card.autoFeatures.autoTax.rate}% automatically set aside
                      </div>
                    </div>
                    <Badge className="bg-green-500">Active</Badge>
                  </div>
                </Card>
              )}
            </div>
          </div>

          {/* Metadata */}
          <div>
            <h3 className="font-semibold flex items-center gap-2 mb-3">
              <Clock className="w-4 h-4" />
              Card Info
            </h3>
            <Card className="p-4">
              <div className="grid gap-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Created</span>
                  <span className="font-medium">{card.createdAt.toLocaleDateString()}</span>
                </div>
                {card.lastUsed && (
                  <div className="flex justify-between">
                    <span className="text-gray-600">Last Used</span>
                    <span className="font-medium">{card.lastUsed.toLocaleDateString()}</span>
                  </div>
                )}
                <Separator />
                <div className="flex justify-between">
                  <span className="text-gray-600">Owner</span>
                  <span className="font-mono text-xs">{card.owner}</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
