'use client'

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import { Plus, Sparkles } from 'lucide-react';
import { toast } from 'sonner';

interface CreateCardDialogProps {
  onCreateCard: (cardData: CardCreationData) => void;
}

export interface CardCreationData {
  name: string;
  initialBalance: string;
  cardDesign: 'gradient-blue' | 'gradient-purple' | 'gradient-green' | 'gradient-orange';
  useCase: string;
  rules: {
    dailyLimit?: string;
    weeklyLimit?: string;
    monthlyLimit?: string;
    requiresApproval: boolean;
  };
  autoFeatures: {
    autoTopUp: boolean;
    autoLock: boolean;
    autoStream: boolean;
    autoAllocate: boolean;
    autoTax: boolean;
  };
}

export function CreateCardDialog({ onCreateCard }: CreateCardDialogProps) {
  const [open, setOpen] = useState(false);
  const [cardData, setCardData] = useState<CardCreationData>({
    name: '',
    initialBalance: '0',
    cardDesign: 'gradient-blue',
    useCase: 'budget',
    rules: {
      requiresApproval: false,
    },
    autoFeatures: {
      autoTopUp: false,
      autoLock: false,
      autoStream: false,
      autoAllocate: false,
      autoTax: false,
    },
  });

  const handleCreate = () => {
    if (!cardData.name) {
      toast.error('Please enter a card name');
      return;
    }
    onCreateCard(cardData);
    setOpen(false);
    toast.success('Vault Card created successfully! 🎉');
  };

  const cardDesignPreviews = {
    'gradient-blue': 'bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700',
    'gradient-purple': 'bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600',
    'gradient-green': 'bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600',
    'gradient-orange': 'bg-gradient-to-br from-orange-500 via-amber-600 to-yellow-600',
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="lg" className="gap-2">
          <Plus className="w-5 h-5" />
          Create Vault Card
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5" />
            Create New Vault Card
          </DialogTitle>
          <DialogDescription>
            Mint a new NFT card tied to a segregated smart vault on Base
          </DialogDescription>
        </DialogHeader>

        <Tabs defaultValue="basics" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="basics">Basics</TabsTrigger>
            <TabsTrigger value="rules">Rules</TabsTrigger>
            <TabsTrigger value="auto">Auto Features</TabsTrigger>
          </TabsList>

          <TabsContent value="basics" className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Card Name</Label>
              <Input
                id="name"
                placeholder="e.g., Kid's Allowance, Marketing Budget"
                value={cardData.name}
                onChange={(e) => setCardData({ ...cardData, name: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="balance">Initial Balance (USD)</Label>
              <Input
                id="balance"
                type="number"
                placeholder="0.00"
                value={cardData.initialBalance}
                onChange={(e) => setCardData({ ...cardData, initialBalance: e.target.value })}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="useCase">Use Case</Label>
              <Select
                value={cardData.useCase}
                onValueChange={(value) => setCardData({ ...cardData, useCase: value })}
              >
                <SelectTrigger id="useCase">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="parent">Parent Control</SelectItem>
                  <SelectItem value="business">Side Business</SelectItem>
                  <SelectItem value="allowance">Allowance System</SelectItem>
                  <SelectItem value="budget">Personal Budget</SelectItem>
                  <SelectItem value="dao">DAO Treasury</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Card Design</Label>
              <div className="grid grid-cols-2 gap-3">
                {(Object.keys(cardDesignPreviews) as Array<keyof typeof cardDesignPreviews>).map((design) => (
                  <Card
                    key={design}
                    className={`h-24 cursor-pointer transition-all ${
                      cardData.cardDesign === design ? 'ring-2 ring-blue-500' : ''
                    }`}
                    onClick={() => setCardData({ ...cardData, cardDesign: design })}
                  >
                    <div className={`${cardDesignPreviews[design]} h-full rounded-md`} />
                  </Card>
                ))}
              </div>
            </div>
          </TabsContent>

          <TabsContent value="rules" className="space-y-4">
            <div className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="dailyLimit">Daily Spending Limit (USD)</Label>
                <Input
                  id="dailyLimit"
                  type="number"
                  placeholder="No limit"
                  value={cardData.rules.dailyLimit || ''}
                  onChange={(e) => setCardData({
                    ...cardData,
                    rules: { ...cardData.rules, dailyLimit: e.target.value }
                  })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="weeklyLimit">Weekly Spending Limit (USD)</Label>
                <Input
                  id="weeklyLimit"
                  type="number"
                  placeholder="No limit"
                  value={cardData.rules.weeklyLimit || ''}
                  onChange={(e) => setCardData({
                    ...cardData,
                    rules: { ...cardData.rules, weeklyLimit: e.target.value }
                  })}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="monthlyLimit">Monthly Spending Limit (USD)</Label>
                <Input
                  id="monthlyLimit"
                  type="number"
                  placeholder="No limit"
                  value={cardData.rules.monthlyLimit || ''}
                  onChange={(e) => setCardData({
                    ...cardData,
                    rules: { ...cardData.rules, monthlyLimit: e.target.value }
                  })}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Require Approval</Label>
                  <p className="text-sm text-gray-500">Transactions need owner approval</p>
                </div>
                <Switch
                  checked={cardData.rules.requiresApproval}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    rules: { ...cardData.rules, requiresApproval: checked }
                  })}
                />
              </div>
            </div>
          </TabsContent>

          <TabsContent value="auto" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Auto Top-up</Label>
                  <p className="text-sm text-gray-500">Automatically refill when balance is low</p>
                </div>
                <Switch
                  checked={cardData.autoFeatures.autoTopUp}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    autoFeatures: { ...cardData.autoFeatures, autoTopUp: checked }
                  })}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Auto Lock</Label>
                  <p className="text-sm text-gray-500">Lock based on time/location conditions</p>
                </div>
                <Switch
                  checked={cardData.autoFeatures.autoLock}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    autoFeatures: { ...cardData.autoFeatures, autoLock: checked }
                  })}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Auto Stream</Label>
                  <p className="text-sm text-gray-500">Continuous payment streams to recipients</p>
                </div>
                <Switch
                  checked={cardData.autoFeatures.autoStream}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    autoFeatures: { ...cardData.autoFeatures, autoStream: checked }
                  })}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Auto Allocate</Label>
                  <p className="text-sm text-gray-500">Split funds across multiple destinations</p>
                </div>
                <Switch
                  checked={cardData.autoFeatures.autoAllocate}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    autoFeatures: { ...cardData.autoFeatures, autoAllocate: checked }
                  })}
                />
              </div>

              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label>Auto Tax Withholding</Label>
                  <p className="text-sm text-gray-500">Automatically set aside tax percentage</p>
                </div>
                <Switch
                  checked={cardData.autoFeatures.autoTax}
                  onCheckedChange={(checked) => setCardData({
                    ...cardData,
                    autoFeatures: { ...cardData.autoFeatures, autoTax: checked }
                  })}
                />
              </div>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4">
          <Button variant="outline" onClick={() => setOpen(false)}>
            Cancel
          </Button>
          <Button onClick={handleCreate}>
            Mint Card
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
