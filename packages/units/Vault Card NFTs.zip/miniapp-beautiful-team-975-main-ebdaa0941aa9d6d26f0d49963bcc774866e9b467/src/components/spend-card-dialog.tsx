'use client'

import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import type { VaultCard } from '@/types/vault-card';
import { CreditCard, AlertCircle, CheckCircle2 } from 'lucide-react';
import { toast } from 'sonner';

interface SpendCardDialogProps {
  card: VaultCard;
  onSpend: (amount: string, recipient: string, category: string, description: string) => void;
}

const categories = [
  'Gaming',
  'Education',
  'Entertainment',
  'Food & Dining',
  'Shopping',
  'Transportation',
  'Utilities',
  'Healthcare',
  'Travel',
  'Other',
];

export function SpendCardDialog({ card, onSpend }: SpendCardDialogProps) {
  const [open, setOpen] = useState(false);
  const [amount, setAmount] = useState('');
  const [recipient, setRecipient] = useState('');
  const [category, setCategory] = useState('');
  const [description, setDescription] = useState('');
  const [step, setStep] = useState<'form' | 'confirm' | 'processing'>('form');

  const balance = parseFloat(card.balance);
  const spendAmount = parseFloat(amount) || 0;
  const dailyLimit = card.rules.dailyLimit ? parseFloat(card.rules.dailyLimit) : Infinity;

  const canSpend = spendAmount > 0 && spendAmount <= balance && recipient && category && description;
  const exceedsDailyLimit = spendAmount > dailyLimit;

  const handleSpend = () => {
    if (!canSpend) {
      toast.error('Please fill in all fields correctly');
      return;
    }

    if (exceedsDailyLimit && !card.rules.requiresApproval) {
      toast.warning('Amount exceeds daily limit');
      return;
    }

    setStep('processing');

    // Simulate processing
    setTimeout(() => {
      onSpend(amount, recipient, category, description);
      toast.success(
        card.rules.requiresApproval 
          ? 'Transaction submitted for approval'
          : 'Transaction completed successfully! 🎉'
      );
      setOpen(false);
      // Reset form
      setAmount('');
      setRecipient('');
      setCategory('');
      setDescription('');
      setStep('form');
    }, 1500);
  };

  const handleConfirm = () => {
    setStep('confirm');
  };

  const handleBack = () => {
    setStep('form');
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="default" className="gap-2">
          <CreditCard className="w-4 h-4" />
          Spend from Card
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CreditCard className="w-5 h-5" />
            Spend from {card.name}
          </DialogTitle>
          <DialogDescription>
            Current balance: ${card.balance}
          </DialogDescription>
        </DialogHeader>

        {step === 'form' && (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="amount">Amount (USD)</Label>
              <Input
                id="amount"
                type="number"
                placeholder="0.00"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                step="0.01"
                min="0"
                max={card.balance}
              />
              {spendAmount > balance && (
                <p className="text-sm text-red-600">Insufficient balance</p>
              )}
              {exceedsDailyLimit && (
                <div className="flex items-start gap-2 text-sm text-orange-600">
                  <AlertCircle className="w-4 h-4 mt-0.5" />
                  <span>
                    Exceeds daily limit of ${dailyLimit}
                    {card.rules.requiresApproval && ' - will require approval'}
                  </span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              <Label htmlFor="recipient">Recipient Address</Label>
              <Input
                id="recipient"
                placeholder="0x..."
                value={recipient}
                onChange={(e) => setRecipient(e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select value={category} onValueChange={setCategory}>
                <SelectTrigger id="category">
                  <SelectValue placeholder="Select category" />
                </SelectTrigger>
                <SelectContent>
                  {categories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                placeholder="What is this payment for?"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                rows={3}
              />
            </div>

            {card.rules.allowedCategories && card.rules.allowedCategories.length > 0 && (
              <div className="p-3 bg-blue-50 rounded-lg">
                <p className="text-sm font-medium mb-2">Allowed Categories:</p>
                <div className="flex flex-wrap gap-2">
                  {card.rules.allowedCategories.map((cat) => (
                    <Badge key={cat} variant="secondary">
                      {cat}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={() => setOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleConfirm} disabled={!canSpend}>
                Review Transaction
              </Button>
            </div>
          </div>
        )}

        {step === 'confirm' && (
          <div className="space-y-4">
            <div className="p-4 bg-gray-50 rounded-lg space-y-3">
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Amount:</span>
                <span className="font-bold">${amount}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Recipient:</span>
                <span className="font-mono text-sm">
                  {recipient.slice(0, 6)}...{recipient.slice(-4)}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Category:</span>
                <Badge variant="secondary">{category}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-sm text-gray-600">Description:</span>
                <span className="text-sm text-right max-w-[200px]">{description}</span>
              </div>
              <div className="pt-2 border-t">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-600">New Balance:</span>
                  <span className="font-bold">${(balance - spendAmount).toFixed(2)}</span>
                </div>
              </div>
            </div>

            {card.rules.requiresApproval && (
              <div className="flex items-start gap-2 p-3 bg-yellow-50 rounded-lg">
                <AlertCircle className="w-5 h-5 text-yellow-600 mt-0.5" />
                <div className="text-sm">
                  <p className="font-medium text-yellow-900">Approval Required</p>
                  <p className="text-yellow-700">
                    This transaction will be submitted for approval before processing
                  </p>
                </div>
              </div>
            )}

            <div className="flex justify-end gap-2 pt-4">
              <Button variant="outline" onClick={handleBack}>
                Back
              </Button>
              <Button onClick={handleSpend}>
                Confirm & Send
              </Button>
            </div>
          </div>
        )}

        {step === 'processing' && (
          <div className="py-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-blue-100 flex items-center justify-center mx-auto animate-pulse">
              <CreditCard className="w-8 h-8 text-blue-600" />
            </div>
            <div>
              <h3 className="font-semibold text-lg mb-1">Processing Transaction</h3>
              <p className="text-sm text-gray-600">
                {card.rules.requiresApproval 
                  ? 'Submitting for approval...'
                  : 'Confirming on Base network...'}
              </p>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
