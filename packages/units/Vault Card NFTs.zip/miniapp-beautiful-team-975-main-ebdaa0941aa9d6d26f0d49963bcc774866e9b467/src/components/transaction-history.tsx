'use client'

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import type { Transaction } from '@/types/transaction';
import { 
  ArrowUpRight, 
  ArrowDownLeft, 
  Clock, 
  CheckCircle2, 
  XCircle, 
  AlertCircle,
  Sparkles,
  TrendingUp,
  DollarSign
} from 'lucide-react';
import { format } from 'date-fns';

interface TransactionHistoryProps {
  transactions: Transaction[];
  maxHeight?: string;
}

const transactionIcons = {
  spend: ArrowUpRight,
  topup: ArrowDownLeft,
  allocation: Sparkles,
  tax: TrendingUp,
  stream: DollarSign,
  refund: ArrowDownLeft,
};

const transactionColors = {
  spend: 'text-red-500',
  topup: 'text-green-500',
  allocation: 'text-blue-500',
  tax: 'text-orange-500',
  stream: 'text-purple-500',
  refund: 'text-green-500',
};

const statusConfig = {
  completed: {
    icon: CheckCircle2,
    color: 'text-green-500',
    badge: 'bg-green-100 text-green-700',
    label: 'Completed',
  },
  pending: {
    icon: Clock,
    color: 'text-yellow-500',
    badge: 'bg-yellow-100 text-yellow-700',
    label: 'Pending',
  },
  failed: {
    icon: XCircle,
    color: 'text-red-500',
    badge: 'bg-red-100 text-red-700',
    label: 'Failed',
  },
  requires_approval: {
    icon: AlertCircle,
    color: 'text-blue-500',
    badge: 'bg-blue-100 text-blue-700',
    label: 'Needs Approval',
  },
};

export function TransactionHistory({ transactions, maxHeight = '600px' }: TransactionHistoryProps) {
  if (transactions.length === 0) {
    return (
      <Card>
        <CardContent className="p-12 text-center">
          <div className="w-16 h-16 rounded-full bg-gray-100 flex items-center justify-center mx-auto mb-4">
            <Clock className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold mb-2">No transactions yet</h3>
          <p className="text-gray-600 text-sm">
            Transactions will appear here once you start using your vault card
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Transaction History</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="pr-4" style={{ maxHeight }}>
          <div className="space-y-3">
            {transactions.map((transaction) => {
              const TypeIcon = transactionIcons[transaction.type];
              const StatusIcon = statusConfig[transaction.status].icon;
              
              return (
                <div
                  key={transaction.id}
                  className="flex items-start gap-4 p-4 rounded-lg border bg-white hover:bg-gray-50 transition-colors"
                >
                  <div className={`w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 ${transactionColors[transaction.type]}`}>
                    <TypeIcon className="w-5 h-5" />
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2 mb-1">
                      <div className="flex-1">
                        <h4 className="font-semibold text-sm mb-1">
                          {transaction.description}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-gray-500">
                          <span>{format(transaction.timestamp, 'MMM d, yyyy h:mm a')}</span>
                          {transaction.category && (
                            <>
                              <span>•</span>
                              <span>{transaction.category}</span>
                            </>
                          )}
                        </div>
                      </div>
                      <div className="text-right flex-shrink-0">
                        <div className={`text-lg font-bold ${transaction.type === 'topup' || transaction.type === 'refund' ? 'text-green-600' : 'text-gray-900'}`}>
                          {transaction.type === 'topup' || transaction.type === 'refund' ? '+' : '-'}${transaction.amount}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 mt-2">
                      <Badge 
                        variant="secondary" 
                        className={`text-xs ${statusConfig[transaction.status].badge}`}
                      >
                        <StatusIcon className="w-3 h-3 mr-1" />
                        {statusConfig[transaction.status].label}
                      </Badge>

                      {transaction.hash && (
                        <span className="text-xs font-mono text-gray-400">
                          {transaction.hash.slice(0, 10)}...
                        </span>
                      )}
                    </div>

                    {transaction.metadata?.merchant && (
                      <div className="text-xs text-gray-500 mt-1">
                        Merchant: {transaction.metadata.merchant}
                      </div>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
