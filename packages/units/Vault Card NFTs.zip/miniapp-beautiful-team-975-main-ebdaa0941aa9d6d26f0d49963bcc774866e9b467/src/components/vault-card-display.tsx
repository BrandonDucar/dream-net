'use client'

import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import type { VaultCard } from '@/types/vault-card';
import { Wallet, Lock, TrendingUp, Zap } from 'lucide-react';

interface VaultCardDisplayProps {
  card: VaultCard;
  onClick?: () => void;
}

const cardDesigns = {
  'gradient-blue': 'bg-gradient-to-br from-blue-500 via-blue-600 to-indigo-700',
  'gradient-purple': 'bg-gradient-to-br from-purple-500 via-purple-600 to-pink-600',
  'gradient-green': 'bg-gradient-to-br from-emerald-500 via-green-600 to-teal-600',
  'gradient-orange': 'bg-gradient-to-br from-orange-500 via-amber-600 to-yellow-600',
};

export function VaultCardDisplay({ card, onClick }: VaultCardDisplayProps) {
  const activeAutoFeatures = [
    card.autoFeatures.autoTopUp.enabled && 'Top-up',
    card.autoFeatures.autoLock.enabled && 'Lock',
    card.autoFeatures.autoStream.enabled && 'Stream',
    card.autoFeatures.autoAllocate.enabled && 'Allocate',
    card.autoFeatures.autoTax.enabled && 'Tax',
  ].filter(Boolean);

  return (
    <Card 
      className="overflow-hidden cursor-pointer transition-all hover:scale-105 hover:shadow-xl"
      onClick={onClick}
    >
      <div className={`${cardDesigns[card.cardDesign]} p-6 text-white relative h-48`}>
        <div className="absolute top-4 right-4 text-xs font-mono opacity-70">
          #{card.tokenId}
        </div>
        
        <div className="flex flex-col h-full justify-between">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <Wallet className="w-5 h-5" />
              <span className="text-sm font-medium opacity-90">Vault Card</span>
            </div>
            <h3 className="text-xl font-bold mb-1">{card.name}</h3>
          </div>

          <div>
            <div className="text-3xl font-bold mb-1">${card.balance}</div>
            <div className="text-xs font-mono opacity-70">
              {card.vaultAddress.slice(0, 6)}...{card.vaultAddress.slice(-4)}
            </div>
          </div>
        </div>

        <div className="absolute bottom-4 right-4 flex gap-1">
          {card.autoFeatures.autoTopUp.enabled && (
            <div className="w-2 h-2 rounded-full bg-white opacity-80" title="Auto Top-up" />
          )}
          {card.autoFeatures.autoLock.enabled && (
            <div className="w-2 h-2 rounded-full bg-white opacity-80" title="Auto Lock" />
          )}
          {card.autoFeatures.autoStream.enabled && (
            <div className="w-2 h-2 rounded-full bg-white opacity-80" title="Auto Stream" />
          )}
          {card.autoFeatures.autoAllocate.enabled && (
            <div className="w-2 h-2 rounded-full bg-white opacity-80" title="Auto Allocate" />
          )}
        </div>
      </div>

      <div className="p-4 bg-white">
        <div className="flex flex-wrap gap-2 mb-3">
          {activeAutoFeatures.slice(0, 3).map((feature) => (
            <Badge key={feature} variant="secondary" className="text-xs">
              {feature}
            </Badge>
          ))}
          {activeAutoFeatures.length > 3 && (
            <Badge variant="secondary" className="text-xs">
              +{activeAutoFeatures.length - 3} more
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
          {card.rules.dailyLimit && (
            <div className="flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              <span>Daily: ${card.rules.dailyLimit}</span>
            </div>
          )}
          {card.rules.requiresApproval && (
            <div className="flex items-center gap-1">
              <Lock className="w-3 h-3" />
              <span>Approval req.</span>
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
