import type { VaultCard } from '@/types/vault-card';

export const mockVaultCards: VaultCard[] = [
  {
    id: '1',
    name: "Kid's Allowance Card",
    tokenId: 1001,
    vaultAddress: '0x742d35Cc6634C0532925a3b844Bc9e7595f0bEb1',
    balance: '50.00',
    cardDesign: 'gradient-blue',
    rules: {
      dailyLimit: '10.00',
      weeklyLimit: '50.00',
      allowedCategories: ['Gaming', 'Education', 'Entertainment'],
      requiresApproval: true,
      minApprovers: 1,
    },
    autoFeatures: {
      autoTopUp: {
        enabled: true,
        threshold: '20.00',
        amount: '50.00',
      },
      autoLock: {
        enabled: true,
        conditions: ['After 10 PM', 'Location: Outside home radius'],
      },
      autoStream: {
        enabled: false,
      },
      autoAllocate: {
        enabled: true,
        allocations: [
          { percentage: 20, destination: 'Savings', label: 'Auto-save' },
          { percentage: 80, destination: 'Spending', label: 'Available' },
        ],
      },
      autoTax: {
        enabled: false,
      },
    },
    createdAt: new Date('2024-01-15'),
    lastUsed: new Date('2024-03-20'),
    owner: '0x123...',
  },
  {
    id: '2',
    name: 'Marketing Budget',
    tokenId: 1002,
    vaultAddress: '0x8B3a3E4F2e5d9C7a6B1F3E2D4C5B6A7E8F9D0C1B',
    balance: '5000.00',
    cardDesign: 'gradient-purple',
    rules: {
      monthlyLimit: '10000.00',
      allowedCategories: ['Advertising', 'Social Media', 'Content Creation'],
      requiresApproval: true,
      minApprovers: 2,
    },
    autoFeatures: {
      autoTopUp: {
        enabled: true,
        threshold: '1000.00',
        amount: '5000.00',
      },
      autoLock: {
        enabled: false,
      },
      autoStream: {
        enabled: true,
        recipients: [
          { address: '0xABC...', rate: '100.00' },
        ],
      },
      autoAllocate: {
        enabled: true,
        allocations: [
          { percentage: 40, destination: 'Social Ads', label: 'Social' },
          { percentage: 30, destination: 'Content', label: 'Content' },
          { percentage: 30, destination: 'Reserve', label: 'Reserve' },
        ],
      },
      autoTax: {
        enabled: true,
        rate: 10,
        destination: '0xTax...',
      },
    },
    createdAt: new Date('2024-02-01'),
    lastUsed: new Date('2024-03-22'),
    owner: '0x456...',
  },
];
