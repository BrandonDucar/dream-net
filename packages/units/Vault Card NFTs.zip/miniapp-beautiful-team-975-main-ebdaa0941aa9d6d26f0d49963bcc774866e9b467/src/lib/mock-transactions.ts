import type { Transaction } from '@/types/transaction';

export const mockTransactions: Transaction[] = [
  {
    id: 'tx1',
    cardId: '1',
    type: 'spend',
    amount: '15.99',
    description: 'Steam Game Purchase',
    category: 'Gaming',
    recipient: '0xSteam...',
    status: 'completed',
    timestamp: new Date('2024-03-22T14:30:00'),
    hash: '0x1a2b3c4d5e6f...',
    metadata: {
      merchant: 'Steam Store',
      approved: true,
    },
  },
  {
    id: 'tx2',
    cardId: '1',
    type: 'topup',
    amount: '50.00',
    description: 'Auto Top-up',
    status: 'completed',
    timestamp: new Date('2024-03-21T08:15:00'),
    hash: '0x2b3c4d5e6f7g...',
  },
  {
    id: 'tx3',
    cardId: '1',
    type: 'spend',
    amount: '8.50',
    description: 'In-app Purchase',
    category: 'Gaming',
    recipient: '0xGameApp...',
    status: 'completed',
    timestamp: new Date('2024-03-20T16:45:00'),
    hash: '0x3c4d5e6f7g8h...',
    metadata: {
      merchant: 'Mobile Game',
      approved: true,
    },
  },
  {
    id: 'tx4',
    cardId: '1',
    type: 'allocation',
    amount: '10.00',
    description: 'Auto-save Allocation',
    category: 'Savings',
    status: 'completed',
    timestamp: new Date('2024-03-20T00:00:00'),
    hash: '0x4d5e6f7g8h9i...',
  },
  {
    id: 'tx5',
    cardId: '1',
    type: 'spend',
    amount: '25.00',
    description: 'Online Course',
    category: 'Education',
    recipient: '0xUdemy...',
    status: 'pending',
    timestamp: new Date('2024-03-22T18:00:00'),
    metadata: {
      merchant: 'Udemy',
      approved: false,
    },
  },
  {
    id: 'tx6',
    cardId: '2',
    type: 'spend',
    amount: '500.00',
    description: 'Facebook Ads Campaign',
    category: 'Advertising',
    recipient: '0xMeta...',
    status: 'completed',
    timestamp: new Date('2024-03-22T10:00:00'),
    hash: '0x5e6f7g8h9i0j...',
    metadata: {
      merchant: 'Meta Ads',
      approved: true,
      approvers: ['0x123...', '0x456...'],
    },
  },
  {
    id: 'tx7',
    cardId: '2',
    type: 'stream',
    amount: '100.00',
    description: 'Content Creator Payment',
    category: 'Content Creation',
    recipient: '0xCreator...',
    status: 'completed',
    timestamp: new Date('2024-03-22T09:00:00'),
    hash: '0x6f7g8h9i0j1k...',
  },
  {
    id: 'tx8',
    cardId: '2',
    type: 'tax',
    amount: '150.00',
    description: 'Auto Tax Withholding',
    status: 'completed',
    timestamp: new Date('2024-03-21T00:00:00'),
    hash: '0x7g8h9i0j1k2l...',
  },
  {
    id: 'tx9',
    cardId: '2',
    type: 'spend',
    amount: '350.00',
    description: 'Instagram Promotion',
    category: 'Social Media',
    recipient: '0xInsta...',
    status: 'completed',
    timestamp: new Date('2024-03-19T14:30:00'),
    hash: '0x8h9i0j1k2l3m...',
    metadata: {
      merchant: 'Instagram Ads',
      approved: true,
      approvers: ['0x123...', '0x456...'],
    },
  },
  {
    id: 'tx10',
    cardId: '2',
    type: 'allocation',
    amount: '1000.00',
    description: 'Budget Allocation',
    status: 'completed',
    timestamp: new Date('2024-03-18T00:00:00'),
    hash: '0x9i0j1k2l3m4n...',
  },
];

export function getTransactionsByCardId(cardId: string): Transaction[] {
  return mockTransactions.filter(tx => tx.cardId === cardId);
}

export function getRecentTransactions(limit: number = 10): Transaction[] {
  return [...mockTransactions]
    .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
    .slice(0, limit);
}
