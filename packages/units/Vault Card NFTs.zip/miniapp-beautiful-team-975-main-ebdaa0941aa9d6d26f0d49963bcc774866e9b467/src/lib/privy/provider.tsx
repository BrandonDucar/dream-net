'use client'

import { PrivyProvider, type PrivyProviderProps } from '@privy-io/react-auth';
import type { ReactNode } from 'react';

const PRIVY_APP_ID = "cm5yjbh8z01lv6heoze3v3ep5";
const CLIENT_ID = "client-WY5fRbUUsnYnSBnU7hp47apYGAdUgABi38uhK4PxBYLpx";

interface PrivyWrapperProps extends Omit<PrivyProviderProps, 'appId' | 'clientId'> {
  children: ReactNode;
}

const PrivyWrapper: React.FC<PrivyWrapperProps> = ({ children, ...props }) => {
  return (
    <PrivyProvider 
      appId={PRIVY_APP_ID} 
      clientId={CLIENT_ID}
      config={{
        loginMethods: ['email', 'wallet'],
        appearance: {
          theme: 'light',
          accentColor: '#0052FF',
          showWalletLoginFirst: true,
        },
        embeddedWallets: {
          createOnLogin: 'users-without-wallets',
        },
        defaultChain: {
          id: 8453,
          name: 'Base',
          network: 'base-mainnet',
          nativeCurrency: {
            name: 'Ethereum',
            symbol: 'ETH',
            decimals: 18
          },
          rpcUrls: {
            default: {
              http: ['https://mainnet.base.org']
            },
            public: {
              http: ['https://mainnet.base.org']
            }
          }
        },
        supportedChains: [
          {
            id: 8453,
            name: 'Base',
            network: 'base-mainnet',
            nativeCurrency: {
              name: 'Ethereum',
              symbol: 'ETH',
              decimals: 18
            },
            rpcUrls: {
              default: {
                http: ['https://mainnet.base.org']
              },
              public: {
                http: ['https://mainnet.base.org']
              }
            }
          }
        ]
      }}
      {...props}
    >
      {children}
    </PrivyProvider>
  );
};

export { PrivyWrapper };
