export interface Transaction {
  id: string;
  cardId: string;
  type: 'spend' | 'topup' | 'allocation' | 'tax' | 'stream' | 'refund';
  amount: string;
  description: string;
  category?: string;
  recipient?: string;
  status: 'completed' | 'pending' | 'failed' | 'requires_approval';
  timestamp: Date;
  hash?: string;
  metadata?: {
    location?: string;
    merchant?: string;
    approved?: boolean;
    approvers?: string[];
  };
}

export interface SpendingAnalytics {
  totalSpent: string;
  transactionCount: number;
  avgTransactionSize: string;
  categoryBreakdown: Array<{
    category: string;
    amount: string;
    percentage: number;
    count: number;
  }>;
  dailySpending: Array<{
    date: string;
    amount: string;
  }>;
  weeklyTrend: number;
  monthlyTrend: number;
}
