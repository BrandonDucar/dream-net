export interface VaultCard {
  id: string;
  name: string;
  tokenId: number;
  vaultAddress: string;
  balance: string;
  cardDesign: 'gradient-blue' | 'gradient-purple' | 'gradient-green' | 'gradient-orange';
  rules: SpendingRules;
  autoFeatures: AutoFeatures;
  createdAt: Date;
  lastUsed?: Date;
  owner: string;
}

export interface SpendingRules {
  dailyLimit?: string;
  weeklyLimit?: string;
  monthlyLimit?: string;
  allowedCategories?: string[];
  blockedCategories?: string[];
  allowedAddresses?: string[];
  requiresApproval?: boolean;
  minApprovers?: number;
}

export interface AutoFeatures {
  autoTopUp: {
    enabled: boolean;
    threshold?: string;
    amount?: string;
    sourceVault?: string;
  };
  autoLock: {
    enabled: boolean;
    conditions?: string[];
  };
  autoStream: {
    enabled: boolean;
    recipients?: Array<{ address: string; rate: string }>;
  };
  autoAllocate: {
    enabled: boolean;
    allocations?: Array<{ percentage: number; destination: string; label: string }>;
  };
  autoTax: {
    enabled: boolean;
    rate?: number;
    destination?: string;
  };
}

export type CardUseCase = 'parent' | 'business' | 'allowance' | 'budget' | 'dao';
