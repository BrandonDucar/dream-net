'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { ScoreHistoryEntry, MetricBreakdown } from '@/types/score-engine';
import { getHistory, clearHistory } from '@/lib/storage';

export default function AdminHistoryPage() {
  const [history, setHistory] = useState<ScoreHistoryEntry[]>([]);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [password, setPassword] = useState<string>('');
  const [selectedEntry, setSelectedEntry] = useState<ScoreHistoryEntry | null>(null);
  const [searchTerm, setSearchTerm] = useState<string>('');

  useEffect(() => {
    if (isUnlocked) {
      setHistory(getHistory());
    }
  }, [isUnlocked]);

  const handleUnlock = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsUnlocked(true);
    } else {
      alert('Incorrect password');
    }
  };

  const handleClearHistory = (): void => {
    if (confirm('Are you sure you want to clear all history? This cannot be undone.')) {
      clearHistory();
      setHistory([]);
    }
  };

  const filteredHistory = history.filter((entry: ScoreHistoryEntry) =>
    entry.wallet_address.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-800 w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-white">Admin Access</CardTitle>
            <CardDescription className="text-gray-400">
              Enter password to access admin panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUnlock} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                  placeholder="admin123"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Unlock
              </Button>
              <div className="text-center">
                <a href="/" className="text-sm text-gray-500 hover:text-gray-300">
                  Back to Home
                </a>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Scoring History
            </h1>
            <p className="text-gray-400">View past wallet scoring events</p>
          </div>
          <div className="flex gap-2">
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/metrics">Metrics</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/rules">Rules</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/">Home</a>
            </Button>
            <Button
              variant="destructive"
              onClick={handleClearHistory}
              disabled={history.length === 0}
            >
              Clear History
            </Button>
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800 mb-6">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <Label htmlFor="search" className="text-gray-300 mb-2 block">
                  Search by Wallet Address
                </Label>
                <Input
                  id="search"
                  type="text"
                  placeholder="0x..."
                  value={searchTerm}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setSearchTerm(e.target.value)}
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <div className="text-gray-400 mt-8">
                {filteredHistory.length} {filteredHistory.length === 1 ? 'entry' : 'entries'}
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="pt-6">
            {filteredHistory.length === 0 ? (
              <div className="text-center py-12 text-gray-500">
                {searchTerm ? 'No matching entries found' : 'No scoring history yet'}
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="border-gray-800">
                    <TableHead className="text-gray-400">Wallet Address</TableHead>
                    <TableHead className="text-gray-400">Rule</TableHead>
                    <TableHead className="text-gray-400">Score</TableHead>
                    <TableHead className="text-gray-400">Normalized</TableHead>
                    <TableHead className="text-gray-400">Date</TableHead>
                    <TableHead className="text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredHistory.map((entry: ScoreHistoryEntry) => (
                    <TableRow key={entry.id} className="border-gray-800">
                      <TableCell className="text-white font-mono text-sm">
                        {entry.wallet_address.slice(0, 10)}...
                      </TableCell>
                      <TableCell className="text-gray-400 font-mono text-sm">
                        {entry.rule_slug}
                      </TableCell>
                      <TableCell className="text-gray-400">
                        {entry.total_score.toFixed(1)}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline" className="border-gray-700 text-gray-300">
                          {entry.normalized_score.toFixed(1)}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-gray-400 text-sm">
                        {new Date(entry.created_at).toLocaleString()}
                      </TableCell>
                      <TableCell>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => setSelectedEntry(entry)}
                          className="border-gray-700 text-gray-300"
                        >
                          View Details
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>

      {selectedEntry && (
        <Dialog open={true} onOpenChange={() => setSelectedEntry(null)}>
          <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle className="text-white">Scoring Details</DialogTitle>
              <DialogDescription className="text-gray-400">
                {selectedEntry.wallet_address}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-6">
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Total Score</div>
                  <div className="text-2xl font-bold text-white">
                    {selectedEntry.total_score.toFixed(1)}
                  </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Normalized</div>
                  <div className="text-2xl font-bold text-green-400">
                    {selectedEntry.normalized_score.toFixed(1)}
                  </div>
                </div>
                <div className="bg-gray-800 rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-1">Rule</div>
                  <div className="text-sm font-mono text-white mt-2">
                    {selectedEntry.rule_slug}
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-lg font-semibold mb-3 text-white">Metric Breakdown</h3>
                <div className="space-y-3">
                  {selectedEntry.metric_breakdown.map((breakdown: MetricBreakdown) => (
                    <div
                      key={breakdown.metric_id}
                      className="bg-gray-800 rounded-lg p-4"
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-white font-medium">
                          {breakdown.metric_label}
                        </div>
                        <div className="text-gray-300 font-mono text-sm">
                          {breakdown.points_awarded.toFixed(1)} / {breakdown.max_points}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <Progress
                          value={(breakdown.points_awarded / breakdown.max_points) * 100}
                          className="flex-1 h-2"
                        />
                        <div className="text-xs text-gray-400">
                          {((breakdown.points_awarded / breakdown.max_points) * 100).toFixed(0)}%
                        </div>
                      </div>
                      <div className="text-xs text-gray-500 mt-2">
                        Raw Value: {breakdown.raw_value !== null ? String(breakdown.raw_value) : 'N/A'}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {selectedEntry.suggestions.length > 0 && (
                <div>
                  <h3 className="text-lg font-semibold mb-3 text-white">Suggestions</h3>
                  <div className="space-y-2">
                    {selectedEntry.suggestions.map((suggestion, index: number) => (
                      <div
                        key={index}
                        className="bg-gray-800 rounded-lg p-3 border border-gray-700"
                      >
                        <div className="flex items-start justify-between mb-1">
                          <div className="font-medium text-white text-sm">
                            {suggestion.title}
                          </div>
                          <Badge
                            variant={
                              suggestion.impact === 'high'
                                ? 'destructive'
                                : suggestion.impact === 'medium'
                                ? 'default'
                                : 'secondary'
                            }
                            className="ml-2 text-xs"
                          >
                            {suggestion.impact}
                          </Badge>
                        </div>
                        <p className="text-gray-400 text-xs">{suggestion.description}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="text-xs text-gray-500">
                Scored at: {new Date(selectedEntry.created_at).toLocaleString()}
              </div>

              <div className="flex justify-end pt-4">
                <Button
                  variant="outline"
                  onClick={() => setSelectedEntry(null)}
                  className="border-gray-700 text-gray-300"
                >
                  Close
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
