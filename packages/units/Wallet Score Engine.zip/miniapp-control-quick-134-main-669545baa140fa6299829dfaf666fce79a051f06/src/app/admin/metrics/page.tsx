'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import type { ScoreMetric, MetricType, MetricCategory } from '@/types/score-engine';
import { getMetrics, saveMetrics } from '@/lib/storage';

export default function AdminMetricsPage() {
  const [metrics, setMetrics] = useState<ScoreMetric[]>([]);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [password, setPassword] = useState<string>('');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingMetric, setEditingMetric] = useState<ScoreMetric | null>(null);

  useEffect(() => {
    if (isUnlocked) {
      setMetrics(getMetrics());
    }
  }, [isUnlocked]);

  const handleUnlock = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsUnlocked(true);
    } else {
      alert('Incorrect password');
    }
  };

  const handleCreateNew = (): void => {
    const newMetric: ScoreMetric = {
      id: `metric_${Date.now()}`,
      key: '',
      label: '',
      category: 'custom',
      description: '',
      weight: 1,
      max_points: 10,
      type: 'numeric_range',
      config: {
        min_value: 0,
        max_value: 100,
      },
      enabled: true,
    };
    setEditingMetric(newMetric);
    setIsEditing(true);
  };

  const handleEdit = (metric: ScoreMetric): void => {
    setEditingMetric({ ...metric });
    setIsEditing(true);
  };

  const handleDuplicate = (metric: ScoreMetric): void => {
    const duplicated: ScoreMetric = {
      ...metric,
      id: `metric_${Date.now()}`,
      key: `${metric.key}_copy`,
      label: `${metric.label} (Copy)`,
    };
    setEditingMetric(duplicated);
    setIsEditing(true);
  };

  const handleToggleEnabled = (id: string): void => {
    const updated = metrics.map((m: ScoreMetric) =>
      m.id === id ? { ...m, enabled: !m.enabled } : m
    );
    setMetrics(updated);
    saveMetrics(updated);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this metric?')) {
      const updated = metrics.filter((m: ScoreMetric) => m.id !== id);
      setMetrics(updated);
      saveMetrics(updated);
    }
  };

  const handleSaveMetric = (metric: ScoreMetric): void => {
    const existing = metrics.find((m: ScoreMetric) => m.id === metric.id);
    let updated: ScoreMetric[];

    if (existing) {
      updated = metrics.map((m: ScoreMetric) => (m.id === metric.id ? metric : m));
    } else {
      updated = [...metrics, metric];
    }

    setMetrics(updated);
    saveMetrics(updated);
    setIsEditing(false);
    setEditingMetric(null);
  };

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-800 w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-white">Admin Access</CardTitle>
            <CardDescription className="text-gray-400">
              Enter password to access admin panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUnlock} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                  placeholder="admin123"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Unlock
              </Button>
              <div className="text-center">
                <a href="/" className="text-sm text-gray-500 hover:text-gray-300">
                  Back to Home
                </a>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Metrics Management
            </h1>
            <p className="text-gray-400">Configure scoring metrics</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleCreateNew} className="bg-green-600 hover:bg-green-700">
              + New Metric
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/rules">Rules</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/history">History</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/">Home</a>
            </Button>
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="pt-6">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-800">
                  <TableHead className="text-gray-400">Label</TableHead>
                  <TableHead className="text-gray-400">Key</TableHead>
                  <TableHead className="text-gray-400">Category</TableHead>
                  <TableHead className="text-gray-400">Type</TableHead>
                  <TableHead className="text-gray-400">Weight</TableHead>
                  <TableHead className="text-gray-400">Max Points</TableHead>
                  <TableHead className="text-gray-400">Enabled</TableHead>
                  <TableHead className="text-gray-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {metrics.map((metric: ScoreMetric) => (
                  <TableRow key={metric.id} className="border-gray-800">
                    <TableCell className="text-white font-medium">{metric.label}</TableCell>
                    <TableCell className="text-gray-400 font-mono text-sm">{metric.key}</TableCell>
                    <TableCell>
                      <Badge variant="outline" className="capitalize border-gray-700 text-gray-300">
                        {metric.category}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-400 text-sm">{metric.type}</TableCell>
                    <TableCell className="text-gray-400">{metric.weight}</TableCell>
                    <TableCell className="text-gray-400">{metric.max_points}</TableCell>
                    <TableCell>
                      <Switch
                        checked={metric.enabled}
                        onCheckedChange={() => handleToggleEnabled(metric.id)}
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(metric)}
                          className="border-gray-700 text-gray-300"
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDuplicate(metric)}
                          className="border-gray-700 text-gray-300"
                        >
                          Duplicate
                        </Button>
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(metric.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {isEditing && editingMetric && (
        <MetricEditor
          metric={editingMetric}
          onSave={handleSaveMetric}
          onCancel={() => {
            setIsEditing(false);
            setEditingMetric(null);
          }}
        />
      )}
    </div>
  );
}

interface MetricEditorProps {
  metric: ScoreMetric;
  onSave: (metric: ScoreMetric) => void;
  onCancel: () => void;
}

function MetricEditor({ metric, onSave, onCancel }: MetricEditorProps) {
  const [formData, setFormData] = useState<ScoreMetric>(metric);

  const handleChange = (field: keyof ScoreMetric, value: string | number | boolean): void => {
    setFormData((prev: ScoreMetric) => ({ ...prev, [field]: value }));
  };

  const handleConfigChange = (field: string, value: string | number): void => {
    setFormData((prev: ScoreMetric) => ({
      ...prev,
      config: { ...prev.config, [field]: value },
    }));
  };

  const handleTypeChange = (type: MetricType): void => {
    let newConfig;

    if (type === 'numeric_range') {
      newConfig = { min_value: 0, max_value: 100 };
    } else if (type === 'boolean') {
      newConfig = { true_points: 10, false_points: 0 };
    } else {
      newConfig = { points_per_item: 1, max_items: 10 };
    }

    setFormData((prev: ScoreMetric) => ({ ...prev, type, config: newConfig }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">
            {metric.key ? 'Edit Metric' : 'New Metric'}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure metric properties and scoring logic
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="key" className="text-gray-300">Key</Label>
              <Input
                id="key"
                type="text"
                value={formData.key}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('key', e.target.value)}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="label" className="text-gray-300">Label</Label>
              <Input
                id="label"
                type="text"
                value={formData.label}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('label', e.target.value)}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description</Label>
            <Textarea
              id="description"
              value={formData.description || ''}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('description', e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category" className="text-gray-300">Category</Label>
              <Select
                value={formData.category}
                onValueChange={(value: string) => handleChange('category', value as MetricCategory)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="liquidity" className="text-white">Liquidity</SelectItem>
                  <SelectItem value="activity" className="text-white">Activity</SelectItem>
                  <SelectItem value="loyalty" className="text-white">Loyalty</SelectItem>
                  <SelectItem value="risk" className="text-white">Risk</SelectItem>
                  <SelectItem value="custom" className="text-white">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="type" className="text-gray-300">Type</Label>
              <Select
                value={formData.type}
                onValueChange={(value: string) => handleTypeChange(value as MetricType)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="numeric_range" className="text-white">Numeric Range</SelectItem>
                  <SelectItem value="boolean" className="text-white">Boolean</SelectItem>
                  <SelectItem value="list_count" className="text-white">List Count</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="weight" className="text-gray-300">Weight</Label>
              <Input
                id="weight"
                type="number"
                step="0.1"
                value={formData.weight}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('weight', parseFloat(e.target.value))}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_points" className="text-gray-300">Max Points</Label>
              <Input
                id="max_points"
                type="number"
                value={formData.max_points}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('max_points', parseFloat(e.target.value))}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>

          <div className="border border-gray-700 rounded-lg p-4 space-y-4">
            <h3 className="font-semibold text-white">Type Configuration</h3>

            {formData.type === 'numeric_range' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="min_value" className="text-gray-300">Min Value</Label>
                  <Input
                    id="min_value"
                    type="number"
                    value={(formData.config as { min_value?: number }).min_value || 0}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('min_value', parseFloat(e.target.value))}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_value" className="text-gray-300">Max Value</Label>
                  <Input
                    id="max_value"
                    type="number"
                    value={(formData.config as { max_value?: number }).max_value || 100}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('max_value', parseFloat(e.target.value))}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>
            )}

            {formData.type === 'boolean' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="true_points" className="text-gray-300">True Points</Label>
                  <Input
                    id="true_points"
                    type="number"
                    value={(formData.config as { true_points?: number }).true_points || 0}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('true_points', parseFloat(e.target.value))}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="false_points" className="text-gray-300">False Points</Label>
                  <Input
                    id="false_points"
                    type="number"
                    value={(formData.config as { false_points?: number }).false_points || 0}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('false_points', parseFloat(e.target.value))}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>
            )}

            {formData.type === 'list_count' && (
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="points_per_item" className="text-gray-300">Points Per Item</Label>
                  <Input
                    id="points_per_item"
                    type="number"
                    value={(formData.config as { points_per_item?: number }).points_per_item || 1}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('points_per_item', parseFloat(e.target.value))}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="max_items" className="text-gray-300">Max Items (optional)</Label>
                  <Input
                    id="max_items"
                    type="number"
                    value={(formData.config as { max_items?: number }).max_items || ''}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleConfigChange('max_items', e.target.value ? parseFloat(e.target.value) : 0)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>
              </div>
            )}
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel} className="border-gray-700 text-gray-300">
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              Save Metric
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
