'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import type { ScoreRule, ScoreMetric, RuleStatus } from '@/types/score-engine';
import { getRules, saveRules, getMetrics } from '@/lib/storage';

export default function AdminRulesPage() {
  const [rules, setRules] = useState<ScoreRule[]>([]);
  const [metrics, setMetrics] = useState<ScoreMetric[]>([]);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(false);
  const [password, setPassword] = useState<string>('');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [editingRule, setEditingRule] = useState<ScoreRule | null>(null);

  useEffect(() => {
    if (isUnlocked) {
      setRules(getRules());
      setMetrics(getMetrics());
    }
  }, [isUnlocked]);

  const handleUnlock = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    if (password === 'admin123') {
      setIsUnlocked(true);
    } else {
      alert('Incorrect password');
    }
  };

  const handleCreateNew = (): void => {
    const newRule: ScoreRule = {
      id: `rule_${Date.now()}`,
      name: '',
      slug: '',
      description: '',
      status: 'draft',
      max_score: 100,
      metric_ids: [],
    };
    setEditingRule(newRule);
    setIsEditing(true);
  };

  const handleEdit = (rule: ScoreRule): void => {
    setEditingRule({ ...rule });
    setIsEditing(true);
  };

  const handleDuplicate = (rule: ScoreRule): void => {
    const duplicated: ScoreRule = {
      ...rule,
      id: `rule_${Date.now()}`,
      slug: `${rule.slug}_copy`,
      name: `${rule.name} (Copy)`,
      status: 'draft',
    };
    setEditingRule(duplicated);
    setIsEditing(true);
  };

  const handleSetActive = (id: string): void => {
    const updated = rules.map((r: ScoreRule) =>
      r.id === id ? { ...r, status: 'active' as RuleStatus } : r
    );
    setRules(updated);
    saveRules(updated);
  };

  const handleDelete = (id: string): void => {
    if (confirm('Are you sure you want to delete this rule?')) {
      const updated = rules.filter((r: ScoreRule) => r.id !== id);
      setRules(updated);
      saveRules(updated);
    }
  };

  const handleSaveRule = (rule: ScoreRule): void => {
    const existing = rules.find((r: ScoreRule) => r.id === rule.id);
    let updated: ScoreRule[];

    if (existing) {
      updated = rules.map((r: ScoreRule) => (r.id === rule.id ? rule : r));
    } else {
      updated = [...rules, rule];
    }

    setRules(updated);
    saveRules(updated);
    setIsEditing(false);
    setEditingRule(null);
  };

  if (!isUnlocked) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white flex items-center justify-center">
        <Card className="bg-gray-900 border-gray-800 w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-white">Admin Access</CardTitle>
            <CardDescription className="text-gray-400">
              Enter password to access admin panel
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleUnlock} className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="password" className="text-gray-300">Password</Label>
                <Input
                  id="password"
                  type="password"
                  value={password}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setPassword(e.target.value)}
                  placeholder="admin123"
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>
              <Button type="submit" className="w-full bg-blue-600 hover:bg-blue-700">
                Unlock
              </Button>
              <div className="text-center">
                <a href="/" className="text-sm text-gray-500 hover:text-gray-300">
                  Back to Home
                </a>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
              Rules Management
            </h1>
            <p className="text-gray-400">Configure scoring rules</p>
          </div>
          <div className="flex gap-2">
            <Button onClick={handleCreateNew} className="bg-green-600 hover:bg-green-700">
              + New Rule
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/metrics">Metrics</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/admin/history">History</a>
            </Button>
            <Button variant="outline" asChild className="border-gray-700 text-gray-300">
              <a href="/">Home</a>
            </Button>
          </div>
        </div>

        <Card className="bg-gray-900 border-gray-800">
          <CardContent className="pt-6">
            <Table>
              <TableHeader>
                <TableRow className="border-gray-800">
                  <TableHead className="text-gray-400">Name</TableHead>
                  <TableHead className="text-gray-400">Slug</TableHead>
                  <TableHead className="text-gray-400">Status</TableHead>
                  <TableHead className="text-gray-400">Metrics</TableHead>
                  <TableHead className="text-gray-400">Max Score</TableHead>
                  <TableHead className="text-gray-400">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rules.map((rule: ScoreRule) => (
                  <TableRow key={rule.id} className="border-gray-800">
                    <TableCell className="text-white font-medium">{rule.name}</TableCell>
                    <TableCell className="text-gray-400 font-mono text-sm">{rule.slug}</TableCell>
                    <TableCell>
                      <Badge
                        variant={rule.status === 'active' ? 'default' : 'secondary'}
                        className="capitalize"
                      >
                        {rule.status}
                      </Badge>
                    </TableCell>
                    <TableCell className="text-gray-400">{rule.metric_ids.length}</TableCell>
                    <TableCell className="text-gray-400">{rule.max_score}</TableCell>
                    <TableCell>
                      <div className="flex gap-2">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleEdit(rule)}
                          className="border-gray-700 text-gray-300"
                        >
                          Edit
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => handleDuplicate(rule)}
                          className="border-gray-700 text-gray-300"
                        >
                          Duplicate
                        </Button>
                        {rule.status !== 'active' && (
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => handleSetActive(rule.id)}
                            className="border-green-700 text-green-400"
                          >
                            Set Active
                          </Button>
                        )}
                        <Button
                          size="sm"
                          variant="destructive"
                          onClick={() => handleDelete(rule.id)}
                        >
                          Delete
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>

      {isEditing && editingRule && (
        <RuleEditor
          rule={editingRule}
          metrics={metrics}
          onSave={handleSaveRule}
          onCancel={() => {
            setIsEditing(false);
            setEditingRule(null);
          }}
        />
      )}
    </div>
  );
}

interface RuleEditorProps {
  rule: ScoreRule;
  metrics: ScoreMetric[];
  onSave: (rule: ScoreRule) => void;
  onCancel: () => void;
}

function RuleEditor({ rule, metrics, onSave, onCancel }: RuleEditorProps) {
  const [formData, setFormData] = useState<ScoreRule>(rule);

  const handleChange = (field: keyof ScoreRule, value: string | number | string[]): void => {
    setFormData((prev: ScoreRule) => ({ ...prev, [field]: value }));
  };

  const handleMetricToggle = (metricId: string): void => {
    const currentIds = formData.metric_ids;
    const newIds = currentIds.includes(metricId)
      ? currentIds.filter((id: string) => id !== metricId)
      : [...currentIds, metricId];
    setFormData((prev: ScoreRule) => ({ ...prev, metric_ids: newIds }));
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <Dialog open={true} onOpenChange={onCancel}>
      <DialogContent className="bg-gray-900 border-gray-800 text-white max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-white">
            {rule.name ? 'Edit Rule' : 'New Rule'}
          </DialogTitle>
          <DialogDescription className="text-gray-400">
            Configure rule properties and select metrics
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-gray-300">Name</Label>
              <Input
                id="name"
                type="text"
                value={formData.name}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('name', e.target.value)}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="slug" className="text-gray-300">Slug</Label>
              <Input
                id="slug"
                type="text"
                value={formData.slug}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('slug', e.target.value)}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="description" className="text-gray-300">Description</Label>
            <Textarea
              id="description"
              value={formData.description || ''}
              onChange={(e: React.ChangeEvent<HTMLTextAreaElement>) => handleChange('description', e.target.value)}
              className="bg-gray-800 border-gray-700 text-white"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="status" className="text-gray-300">Status</Label>
              <Select
                value={formData.status}
                onValueChange={(value: string) => handleChange('status', value as RuleStatus)}
              >
                <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-gray-800 border-gray-700">
                  <SelectItem value="draft" className="text-white">Draft</SelectItem>
                  <SelectItem value="active" className="text-white">Active</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="max_score" className="text-gray-300">Max Score</Label>
              <Input
                id="max_score"
                type="number"
                value={formData.max_score}
                onChange={(e: React.ChangeEvent<HTMLInputElement>) => handleChange('max_score', parseFloat(e.target.value))}
                required
                className="bg-gray-800 border-gray-700 text-white"
              />
            </div>
          </div>

          <div className="border border-gray-700 rounded-lg p-4 space-y-3">
            <h3 className="font-semibold text-white">Select Metrics</h3>
            <div className="text-sm text-gray-400 mb-2">
              {formData.metric_ids.length} metrics selected
            </div>
            <div className="space-y-2 max-h-64 overflow-y-auto">
              {metrics.map((metric: ScoreMetric) => (
                <label
                  key={metric.id}
                  className="flex items-start space-x-3 p-3 rounded-lg bg-gray-800 hover:bg-gray-750 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={formData.metric_ids.includes(metric.id)}
                    onChange={() => handleMetricToggle(metric.id)}
                    className="mt-1 w-4 h-4 rounded border-gray-700"
                  />
                  <div className="flex-1">
                    <div className="text-white font-medium">{metric.label}</div>
                    <div className="text-sm text-gray-400">
                      {metric.key} • {metric.category} • {metric.max_points} pts
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onCancel} className="border-gray-700 text-gray-300">
              Cancel
            </Button>
            <Button type="submit" className="bg-blue-600 hover:bg-blue-700">
              Save Rule
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
