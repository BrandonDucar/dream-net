'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import type { CreditScore, RiskAssessment } from '@/types/score-engine';
import { getSnapshotsByWallet, getBadges, getWalletBadgesByAddress } from '@/lib/storage';
import { getTrendEmoji } from '@/lib/trend-engine';
import { getRiskLevelColor, getRiskLevelLabel } from '@/lib/risk-engine';
import { getBadgeTierColor } from '@/lib/badge-engine';

export default function AnalyticsPage() {
  const [walletAddress, setWalletAddress] = useState('');
  const [creditScore, setCreditScore] = useState<CreditScore | null>(null);
  const [riskAssessment, setRiskAssessment] = useState<RiskAssessment | null>(null);
  const [loading, setLoading] = useState(false);

  const loadAnalytics = async () => {
    if (!walletAddress) return;

    setLoading(true);
    try {
      // Get latest score with analytics
      const response = await fetch('/api/wallet-score', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          rule_slug: 'base-wallet-core',
          wallet_context: {
            wallet_address: walletAddress,
            numeric_signals: {
              lp_amount: 5000,
              trade_count_30d: 50,
              hold_time_days: 180,
              liquidation_count: 0,
              successful_repayments: 10,
              total_borrows: 10,
              leverage_ratio: 2,
            },
            flags: {
              in_high_trust_pack: true,
            },
          },
        }),
      });

      const result = await response.json();
      setCreditScore(result.credit_score || null);
      setRiskAssessment(result.risk_assessment || null);
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const snapshots = walletAddress ? getSnapshotsByWallet(walletAddress) : [];
  const badges = getBadges();
  const earnedBadges = walletAddress ? getWalletBadgesByAddress(walletAddress) : [];
  const earnedBadgeIds = new Set(earnedBadges.map((eb) => eb.badge_id));

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-4 pt-16 md:pt-8">
      <div className="container mx-auto max-w-7xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Advanced Analytics</h1>
          <p className="text-gray-400">
            Deep dive into credit scoring, risk assessment, and performance metrics
          </p>
        </div>

        {/* Wallet Input */}
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Wallet Address</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              <Input
                value={walletAddress}
                onChange={(e) => setWalletAddress(e.target.value)}
                placeholder="0x..."
                className="flex-1 bg-gray-900 border-gray-700 text-white"
              />
              <Button onClick={loadAnalytics} disabled={loading || !walletAddress}>
                {loading ? 'Loading...' : 'Analyze'}
              </Button>
            </div>
          </CardContent>
        </Card>

        {walletAddress && (
          <>
            {/* Credit Score (FICO Style) */}
            {creditScore && (
              <Card className="mb-6 bg-gradient-to-br from-blue-900 to-blue-800 border-blue-700">
                <CardHeader>
                  <CardTitle>Credit Score (FICO-Style)</CardTitle>
                  <CardDescription className="text-blue-200">
                    DeFi credit rating from 300-850
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    {/* Score Display */}
                    <div className="text-center">
                      <div className="text-6xl font-bold mb-2">{creditScore.credit_score}</div>
                      <Badge
                        variant="secondary"
                        className="text-lg px-4 py-1"
                        style={{
                          backgroundColor:
                            creditScore.credit_tier === 'excellent'
                              ? '#10b981'
                              : creditScore.credit_tier === 'very_good'
                              ? '#22c55e'
                              : creditScore.credit_tier === 'good'
                              ? '#84cc16'
                              : creditScore.credit_tier === 'fair'
                              ? '#f59e0b'
                              : '#ef4444',
                        }}
                      >
                        {creditScore.credit_tier.toUpperCase()}
                      </Badge>
                      <div className="mt-4 space-y-2">
                        <div className="text-sm text-blue-200">
                          Lending Capacity: ${creditScore.lending_capacity.toLocaleString()}
                        </div>
                        <div className="text-sm text-blue-200">
                          Interest Tier: {creditScore.interest_tier}
                        </div>
                      </div>
                    </div>

                    {/* Factors Breakdown */}
                    <div className="space-y-3">
                      {Object.entries(creditScore.factors).map(([factor, value]) => (
                        <div key={factor}>
                          <div className="flex justify-between text-sm mb-1">
                            <span className="capitalize">
                              {factor.replace('_', ' ')}
                            </span>
                            <span>{value}%</span>
                          </div>
                          <Progress value={value} className="h-2" />
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Risk Assessment */}
            {riskAssessment && (
              <Card className="mb-6 bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Risk Assessment</CardTitle>
                  <CardDescription>
                    Comprehensive risk analysis and alerts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                    <Card
                      className="border-2"
                      style={{
                        borderColor: getRiskLevelColor(riskAssessment.overall_risk),
                        backgroundColor: `${getRiskLevelColor(riskAssessment.overall_risk)}20`,
                      }}
                    >
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold">
                          {getRiskLevelLabel(riskAssessment.overall_risk)}
                        </div>
                        <div className="text-sm text-gray-400 mt-2">Overall Risk Level</div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold">{riskAssessment.risk_score}/100</div>
                        <div className="text-sm text-gray-400 mt-2">Risk Score</div>
                      </CardContent>
                    </Card>

                    <Card className="bg-gray-700 border-gray-600">
                      <CardContent className="pt-6 text-center">
                        <div className="text-3xl font-bold">
                          {riskAssessment.risk_factors.length}
                        </div>
                        <div className="text-sm text-gray-400 mt-2">Risk Factors</div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Risk Factors */}
                  {riskAssessment.risk_factors.length > 0 && (
                    <div className="space-y-3">
                      <h3 className="font-semibold mb-2">Risk Factors</h3>
                      {riskAssessment.risk_factors.map((factor, index) => (
                        <Card
                          key={index}
                          className="bg-gray-700 border-l-4"
                          style={{ borderLeftColor: getRiskLevelColor(factor.severity) }}
                        >
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between mb-2">
                              <h4 className="font-medium">{factor.factor}</h4>
                              <Badge
                                variant="secondary"
                                style={{ backgroundColor: getRiskLevelColor(factor.severity) }}
                              >
                                {factor.severity}
                              </Badge>
                            </div>
                            <p className="text-sm text-gray-300 mb-2">{factor.description}</p>
                            {factor.remediation && (
                              <p className="text-sm text-blue-300">💡 {factor.remediation}</p>
                            )}
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}

                  {/* Alerts */}
                  {riskAssessment.alerts.length > 0 && (
                    <div className="mt-6 space-y-2">
                      <h3 className="font-semibold mb-2">Active Alerts</h3>
                      {riskAssessment.alerts.map((alert) => (
                        <Card
                          key={alert.id}
                          className="bg-red-900 border-red-700"
                        >
                          <CardContent className="pt-4">
                            <div className="flex items-start justify-between">
                              <div>
                                <h4 className="font-medium">{alert.title}</h4>
                                <p className="text-sm text-red-200">{alert.message}</p>
                              </div>
                              <Badge variant="destructive">{alert.severity}</Badge>
                            </div>
                          </CardContent>
                        </Card>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Score History */}
            {snapshots.length > 0 && (
              <Card className="mb-6 bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Score History</CardTitle>
                  <CardDescription>{snapshots.length} scores recorded</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {snapshots.slice(0, 20).map((snapshot, index) => (
                      <div
                        key={index}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                      >
                        <div>
                          <div className="font-medium">
                            Score: {snapshot.normalized_score.toFixed(1)}
                          </div>
                          <div className="text-sm text-gray-400">
                            {new Date(snapshot.timestamp).toLocaleString()}
                          </div>
                        </div>
                        {index < snapshots.length - 1 && (
                          <Badge variant="secondary">
                            {getTrendEmoji(
                              snapshot.normalized_score > snapshots[index + 1].normalized_score
                                ? 'up'
                                : snapshot.normalized_score < snapshots[index + 1].normalized_score
                                ? 'down'
                                : 'stable'
                            )}
                          </Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Badges */}
            <Card className="bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Badges & Achievements</CardTitle>
                <CardDescription>
                  {earnedBadges.length} of {badges.length} unlocked
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
                  {badges.map((badge) => {
                    const isEarned = earnedBadgeIds.has(badge.id);
                    return (
                      <Card
                        key={badge.id}
                        className={`text-center ${
                          isEarned ? 'bg-gradient-to-br from-yellow-900 to-yellow-800 border-yellow-700' : 'bg-gray-700 border-gray-600 opacity-50'
                        }`}
                      >
                        <CardContent className="pt-6">
                          <div className="text-4xl mb-2">{badge.icon}</div>
                          <div className="text-sm font-medium mb-1">{badge.name}</div>
                          <Badge
                            variant="secondary"
                            style={{ backgroundColor: getBadgeTierColor(badge.tier) }}
                            className="text-xs"
                          >
                            {badge.tier}
                          </Badge>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>
    </div>
  );
}
