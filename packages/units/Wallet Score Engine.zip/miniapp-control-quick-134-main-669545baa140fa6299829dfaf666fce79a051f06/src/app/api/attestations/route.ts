import { NextRequest, NextResponse } from 'next/server';
import type { Attestation } from '@/types/score-engine';
import { getAttestationsByWallet, addAttestation } from '@/lib/storage';
import { simulateAttestationVerification, getAttestationPoints, type AttestationProviderKey, ATTESTATION_PROVIDERS } from '@/lib/attestation-engine';

// GET /api/attestations?wallet=0x...
export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const wallet = searchParams.get('wallet');

  if (!wallet) {
    return NextResponse.json(
      { error: 'Wallet address required' },
      { status: 400 }
    );
  }

  const attestations = getAttestationsByWallet(wallet);
  return NextResponse.json({ attestations });
}

// POST /api/attestations
export async function POST(request: NextRequest) {
  try {
    const body: { wallet_address: string; type: string } = await request.json();
    const { wallet_address, type } = body;

    if (!wallet_address || !type) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Check if type is valid
    if (!(type in ATTESTATION_PROVIDERS)) {
      return NextResponse.json(
        { error: 'Invalid attestation type' },
        { status: 400 }
      );
    }

    // Simulate verification (in real app, would integrate with OAuth/APIs)
    const attestationData = simulateAttestationVerification(type as AttestationProviderKey);
    
    const attestation: Attestation = {
      id: `att_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      wallet_address,
      ...attestationData,
    };

    addAttestation(attestation);

    return NextResponse.json({ attestation }, { status: 201 });
  } catch (error) {
    console.error('Attestation error:', error);
    return NextResponse.json(
      { error: 'Failed to create attestation' },
      { status: 500 }
    );
  }
}
