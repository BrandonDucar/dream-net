import { NextRequest, NextResponse } from 'next/server';
import type { SimulationRequest } from '@/types/score-engine';
import { simulateScoreChanges } from '@/lib/simulation-engine';
import { getMetrics, getRuleBySlug } from '@/lib/storage';

export async function POST(request: NextRequest) {
  try {
    const body: SimulationRequest = await request.json();
    const { rule_slug, wallet_address, changes } = body;

    if (!wallet_address || !rule_slug || !changes) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    const rule = getRuleBySlug(rule_slug);
    if (!rule) {
      return NextResponse.json(
        { error: 'Scoring rule not found' },
        { status: 404 }
      );
    }

    const metrics = getMetrics();

    // Build current context (simplified - in real app would fetch from wallet)
    const currentContext = {
      wallet_address,
      numeric_signals: {},
      flags: {},
    };

    const simulation = simulateScoreChanges(body, rule, metrics, currentContext);

    return NextResponse.json(simulation);
  } catch (error) {
    console.error('Simulation error:', error);
    return NextResponse.json(
      { error: 'Failed to simulate score changes' },
      { status: 500 }
    );
  }
}
