import { NextRequest, NextResponse } from 'next/server';
import type { WalletContext, ScoreResult } from '@/types/score-engine';
import { getRuleBySlug, getMetrics } from '@/lib/storage';
import { computeWalletScore } from '@/lib/scoring-engine';

export async function POST(request: NextRequest): Promise<NextResponse> {
  try {
    const body = await request.json();
    const { rule_slug, wallet_context } = body as {
      rule_slug: string;
      wallet_context: WalletContext;
    };

    if (!rule_slug || !wallet_context) {
      return NextResponse.json(
        { error: 'Missing required fields: rule_slug, wallet_context' },
        { status: 400 }
      );
    }

    const rule = getRuleBySlug(rule_slug);
    if (!rule) {
      return NextResponse.json(
        { error: `Rule not found: ${rule_slug}` },
        { status: 404 }
      );
    }

    if (rule.status !== 'active') {
      return NextResponse.json(
        { error: `Rule is not active: ${rule_slug}` },
        { status: 400 }
      );
    }

    const metrics = getMetrics();
    const result: ScoreResult = computeWalletScore(rule, metrics, wallet_context);

    return NextResponse.json(result, { status: 200 });
  } catch (error) {
    console.error('Error computing wallet score:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
