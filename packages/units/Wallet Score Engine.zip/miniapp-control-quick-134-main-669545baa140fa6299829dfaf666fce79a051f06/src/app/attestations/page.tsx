'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { Attestation } from '@/types/score-engine';
import { ATTESTATION_PROVIDERS } from '@/lib/attestation-engine';

export default function AttestationsPage() {
  const [walletAddress, setWalletAddress] = useState('');
  const [attestations, setAttestations] = useState<Attestation[]>([]);
  const [loading, setLoading] = useState(false);
  const [verifying, setVerifying] = useState<string | null>(null);
  const [message, setMessage] = useState('');

  const loadAttestations = async (wallet: string) => {
    setLoading(true);
    try {
      const response = await fetch(`/api/attestations?wallet=${wallet}`);
      const data = await response.json();
      setAttestations(data.attestations || []);
    } catch (error) {
      console.error('Failed to load attestations:', error);
    } finally {
      setLoading(false);
    }
  };

  const verifyAttestation = async (type: string) => {
    if (!walletAddress) {
      setMessage('Please enter a wallet address first');
      return;
    }

    setVerifying(type);
    setMessage('');

    try {
      const response = await fetch('/api/attestations', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet_address: walletAddress,
          type,
        }),
      });

      if (response.ok) {
        setMessage(`✅ ${type} verified successfully!`);
        loadAttestations(walletAddress);
      } else {
        setMessage(`❌ Failed to verify ${type}`);
      }
    } catch (error) {
      console.error('Verification error:', error);
      setMessage('❌ Verification failed');
    } finally {
      setVerifying(null);
    }
  };

  useEffect(() => {
    if (walletAddress && walletAddress.length > 10) {
      loadAttestations(walletAddress);
    }
  }, [walletAddress]);

  const verifiedTypes = new Set(
    attestations.filter((a) => a.status === 'verified').map((a) => a.type)
  );

  const totalPoints = attestations
    .filter((a) => a.status === 'verified')
    .reduce((sum, a) => sum + a.points, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-4 pt-16 md:pt-8">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Identity Attestations</h1>
          <p className="text-gray-400">
            Verify your identity across multiple platforms to boost your reputation score
          </p>
        </div>

        {/* Wallet Input */}
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Your Wallet</CardTitle>
            <CardDescription>Enter your wallet address to manage attestations</CardDescription>
          </CardHeader>
          <CardContent>
            <Input
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              placeholder="0x..."
              className="bg-gray-900 border-gray-700 text-white"
            />
          </CardContent>
        </Card>

        {message && (
          <Alert className="mb-6 bg-gray-800 border-gray-700">
            <AlertDescription>{message}</AlertDescription>
          </Alert>
        )}

        {walletAddress && (
          <>
            {/* Stats */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <Card className="bg-gradient-to-br from-blue-900 to-blue-800 border-blue-700">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold">{attestations.filter((a) => a.status === 'verified').length}</div>
                  <div className="text-sm text-blue-200">Verified Attestations</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-900 to-green-800 border-green-700">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold">{totalPoints}</div>
                  <div className="text-sm text-green-200">Total Points</div>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-purple-900 to-purple-800 border-purple-700">
                <CardContent className="pt-6">
                  <div className="text-3xl font-bold">{new Set(attestations.map((a) => a.type)).size}</div>
                  <div className="text-sm text-purple-200">Unique Providers</div>
                </CardContent>
              </Card>
            </div>

            {/* Available Attestations */}
            <Card className="mb-6 bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Available Attestations</CardTitle>
                <CardDescription>Click to verify your identity with each provider</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {Object.entries(ATTESTATION_PROVIDERS).map(([key, provider]) => {
                    const isVerified = verifiedTypes.has(key);
                    const isVerifying = verifying === key;

                    return (
                      <Card
                        key={key}
                        className={`${
                          isVerified
                            ? 'bg-green-900 border-green-700'
                            : 'bg-gray-700 border-gray-600'
                        } hover:border-gray-500 transition-colors`}
                      >
                        <CardContent className="pt-6">
                          <div className="flex items-center justify-between mb-4">
                            <span className="text-3xl">{provider.icon}</span>
                            <Badge variant={isVerified ? 'default' : 'secondary'}>
                              {provider.points} pts
                            </Badge>
                          </div>
                          <h3 className="font-semibold mb-2">{provider.name}</h3>
                          <Button
                            onClick={() => verifyAttestation(key)}
                            disabled={isVerified || isVerifying || loading}
                            size="sm"
                            className={`w-full ${
                              isVerified
                                ? 'bg-green-600 hover:bg-green-700'
                                : 'bg-blue-600 hover:bg-blue-700'
                            }`}
                          >
                            {isVerifying
                              ? 'Verifying...'
                              : isVerified
                              ? '✓ Verified'
                              : 'Verify'}
                          </Button>
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </CardContent>
            </Card>

            {/* Attestation History */}
            {attestations.length > 0 && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Your Attestations</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {attestations.map((attestation) => (
                      <div
                        key={attestation.id}
                        className="flex items-center justify-between p-3 bg-gray-700 rounded-lg"
                      >
                        <div className="flex items-center gap-3">
                          <Badge
                            variant={
                              attestation.status === 'verified' ? 'default' : 'secondary'
                            }
                          >
                            {attestation.status}
                          </Badge>
                          <span className="font-medium">{attestation.provider}</span>
                        </div>
                        <div className="text-sm text-gray-400">
                          +{attestation.points} points
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Info Card */}
        {!walletAddress && (
          <Card className="bg-gray-800 border-gray-700">
            <CardHeader>
              <CardTitle>🎯 Why Verify Your Identity?</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-gray-300">
              <p>• <strong>Boost Your Score:</strong> Each verification adds points to your reputation</p>
              <p>• <strong>Unlock Features:</strong> Access premium scoring tiers and benefits</p>
              <p>• <strong>Build Trust:</strong> Demonstrate authenticity across multiple platforms</p>
              <p>• <strong>Earn Badges:</strong> Unlock special achievements for identity verification</p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}
