'use client'
import { useState, useEffect } from 'react';
import Link from 'next/link';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import type { ScoreRule, ScoreResult, MetricBreakdown } from '@/types/score-engine';
import { getActiveRules, getMetrics, addHistoryEntry, getBadges, getWalletBadgesByAddress } from '@/lib/storage';
import { computeWalletScore } from '@/lib/scoring-engine';
import { getRiskLevelColor, getRiskLevelLabel } from '@/lib/risk-engine';
import { getTrendEmoji } from '@/lib/trend-engine';
import { Navigation } from '@/components/navigation';
import { sdk } from "@farcaster/miniapp-sdk";
import { useAddMiniApp } from "@/hooks/useAddMiniApp";
import { useQuickAuth } from "@/hooks/useQuickAuth";
import { useIsInFarcaster } from "@/hooks/useIsInFarcaster";

export default function HomePage() {
    const { addMiniApp } = useAddMiniApp();
    const isInFarcaster = useIsInFarcaster()
    useQuickAuth(isInFarcaster)
    useEffect(() => {
      const tryAddMiniApp = async () => {
        try {
          await addMiniApp()
        } catch (error) {
          console.error('Failed to add mini app:', error)
        }

      }

    

      tryAddMiniApp()
    }, [addMiniApp])
    useEffect(() => {
      const initializeFarcaster = async () => {
        try {
          await new Promise(resolve => setTimeout(resolve, 100))
          
          if (document.readyState !== 'complete') {
            await new Promise<void>(resolve => {
              if (document.readyState === 'complete') {
                resolve()
              } else {
                window.addEventListener('load', () => resolve(), { once: true })
              }

            })
          }

    

          await sdk.actions.ready()
          console.log('Farcaster SDK initialized successfully - app fully loaded')
        } catch (error) {
          console.error('Failed to initialize Farcaster SDK:', error)
          
          setTimeout(async () => {
            try {
              await sdk.actions.ready()
              console.log('Farcaster SDK initialized on retry')
            } catch (retryError) {
              console.error('Farcaster SDK retry failed:', retryError)
            }

          }, 1000)
        }

      }

    

      initializeFarcaster()
    }, [])
  const [walletAddress, setWalletAddress] = useState<string>('');
  const [selectedRuleSlug, setSelectedRuleSlug] = useState<string>('');
  const [activeRules, setActiveRules] = useState<ScoreRule[]>([]);
  const [scoreResult, setScoreResult] = useState<ScoreResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  // Simulated signals for demo
  const [lpAmount, setLpAmount] = useState<string>('5000');
  const [tradeCount, setTradeCount] = useState<string>('45');
  const [holdTime, setHoldTime] = useState<string>('180');
  const [inHighTrustPack, setInHighTrustPack] = useState<boolean>(false);

  useEffect(() => {
    const rules = getActiveRules();
    setActiveRules(rules);
    if (rules.length > 0 && !selectedRuleSlug) {
      setSelectedRuleSlug(rules[0].slug);
    }
  }, [selectedRuleSlug]);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>): void => {
    e.preventDefault();
    setIsLoading(true);

    try {
      const rule = activeRules.find((r: ScoreRule) => r.slug === selectedRuleSlug);
      if (!rule) {
        alert('Please select a valid scoring rule');
        setIsLoading(false);
        return;
      }

      const metrics = getMetrics();

      const context = {
        wallet_address: walletAddress,
        numeric_signals: {
          lp_amount: parseFloat(lpAmount) || 0,
          trade_count_30d: parseFloat(tradeCount) || 0,
          hold_time_days: parseFloat(holdTime) || 0,
        },
        flags: {
          in_high_trust_pack: inHighTrustPack,
        },
      };

      const result = computeWalletScore(rule, metrics, context);
      setScoreResult(result);

      // Save to history
      addHistoryEntry({
        id: `${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
        wallet_address: result.wallet_address,
        rule_slug: result.rule_slug,
        total_score: result.total_score,
        normalized_score: result.normalized_score,
        metric_breakdown: result.metric_breakdown,
        suggestions: result.suggestions,
        created_at: new Date().toISOString(),
      });
    } catch (error) {
      console.error('Scoring error:', error);
      alert('Error computing score. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getScoreColor = (score: number): string => {
    if (score >= 80) return 'text-green-400';
    if (score >= 60) return 'text-yellow-400';
    if (score >= 40) return 'text-orange-400';
    return 'text-red-400';
  };

  const groupedBreakdowns = scoreResult?.metric_breakdown.reduce((acc: Record<string, MetricBreakdown[]>, breakdown: MetricBreakdown) => {
    const metric = getMetrics().find((m) => m.id === breakdown.metric_id);
    const category = metric?.category || 'custom';
    if (!acc[category]) {
      acc[category] = [];
    }
    acc[category].push(breakdown);
    return acc;
  }, {});

  const allBadges = getBadges();
  const earnedBadges = scoreResult ? getWalletBadgesByAddress(scoreResult.wallet_address) : [];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-950 via-gray-900 to-gray-950 text-white">
      <div className="container mx-auto px-4 py-12 max-w-6xl">
        <div className="text-center mb-8">
          <h1 className="text-5xl font-bold mb-4 bg-gradient-to-r from-blue-400 to-purple-400 bg-clip-text text-transparent">
            🏆 Wallet Score Engine
          </h1>
          <p className="text-gray-400 text-lg mb-4">
            Advanced reputation scoring with credit analysis, risk assessment & badges
          </p>
          <div className="flex justify-center gap-4 text-sm text-gray-500">
            <span>✅ Identity Attestations</span>
            <span>📊 FICO-Style Credit (300-850)</span>
            <span>🛡️ Risk Analysis</span>
            <span>🎖️ Achievement Badges</span>
          </div>
        </div>

        <Navigation />

        <Card className="bg-gray-900 border-gray-800 mb-8">
          <CardHeader>
            <CardTitle className="text-white">Score Your Wallet</CardTitle>
            <CardDescription className="text-gray-400">
              Enter wallet details and select a scoring profile
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="wallet" className="text-gray-300">Wallet Address</Label>
                <Input
                  id="wallet"
                  type="text"
                  placeholder="0x..."
                  value={walletAddress}
                  onChange={(e: React.ChangeEvent<HTMLInputElement>) => setWalletAddress(e.target.value)}
                  required
                  className="bg-gray-800 border-gray-700 text-white"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="rule" className="text-gray-300">Scoring Profile</Label>
                <Select value={selectedRuleSlug} onValueChange={setSelectedRuleSlug}>
                  <SelectTrigger className="bg-gray-800 border-gray-700 text-white">
                    <SelectValue placeholder="Select a rule" />
                  </SelectTrigger>
                  <SelectContent className="bg-gray-800 border-gray-700">
                    {activeRules.map((rule: ScoreRule) => (
                      <SelectItem key={rule.id} value={rule.slug} className="text-white">
                        {rule.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <Separator className="bg-gray-700" />

              <div className="text-sm text-gray-400 mb-2">
                Demo Signals (customize for testing)
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="lp" className="text-gray-300">LP Amount (USD)</Label>
                  <Input
                    id="lp"
                    type="number"
                    value={lpAmount}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setLpAmount(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="trades" className="text-gray-300">Trade Count (30d)</Label>
                  <Input
                    id="trades"
                    type="number"
                    value={tradeCount}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setTradeCount(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="hold" className="text-gray-300">Hold Time (Days)</Label>
                  <Input
                    id="hold"
                    type="number"
                    value={holdTime}
                    onChange={(e: React.ChangeEvent<HTMLInputElement>) => setHoldTime(e.target.value)}
                    className="bg-gray-800 border-gray-700 text-white"
                  />
                </div>

                <div className="space-y-2 flex items-end">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={inHighTrustPack}
                      onChange={(e: React.ChangeEvent<HTMLInputElement>) => setInHighTrustPack(e.target.checked)}
                      className="w-4 h-4 rounded border-gray-700 bg-gray-800"
                    />
                    <span className="text-gray-300 text-sm">In High-Trust Pack</span>
                  </label>
                </div>
              </div>

              <Button
                type="submit"
                disabled={isLoading || !walletAddress || !selectedRuleSlug}
                className="w-full bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600"
              >
                {isLoading ? 'Computing...' : 'Score Wallet'}
              </Button>
            </form>
          </CardContent>
        </Card>

        {scoreResult && (
          <div className="space-y-6">
            <Card className="bg-gradient-to-br from-gray-900 to-gray-800 border-gray-700">
              <CardHeader className="text-center pb-2">
                <CardTitle className="text-gray-400 text-sm uppercase tracking-wide">
                  Wallet Score
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center">
                <div className={`text-7xl font-bold mb-2 ${getScoreColor(scoreResult.normalized_score)}`}>
                  {scoreResult.normalized_score.toFixed(1)}
                </div>
                <div className="text-gray-500 text-sm">
                  out of 100
                </div>
                <Progress
                  value={scoreResult.normalized_score}
                  className="mt-4 h-2"
                />
              </CardContent>
            </Card>

            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle className="text-white">Score Breakdown</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {groupedBreakdowns && Object.entries(groupedBreakdowns).map(([category, breakdowns]) => (
                  <div key={category}>
                    <h3 className="text-lg font-semibold mb-3 capitalize text-blue-400">
                      {category}
                    </h3>
                    <div className="space-y-3">
                      {(breakdowns as MetricBreakdown[]).map((breakdown: MetricBreakdown) => (
                        <div key={breakdown.metric_id} className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="text-gray-300 font-medium">{breakdown.metric_label}</div>
                            <div className="text-sm text-gray-500">
                              Value: {breakdown.raw_value !== null ? String(breakdown.raw_value) : 'N/A'}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-white font-semibold">
                              {breakdown.points_awarded.toFixed(1)} / {breakdown.max_points}
                            </div>
                            <Progress
                              value={(breakdown.points_awarded / breakdown.max_points) * 100}
                              className="w-32 h-1.5 mt-1"
                            />
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>

            {/* Credit Score */}
            {scoreResult.credit_score && (
              <Card className="bg-gradient-to-br from-blue-900 to-blue-800 border-blue-700">
                <CardHeader>
                  <CardTitle className="text-white">DeFi Credit Score</CardTitle>
                  <CardDescription className="text-blue-200">FICO-Style (300-850)</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-5xl font-bold">{scoreResult.credit_score.credit_score}</div>
                      <Badge variant="secondary" className="mt-2" style={{
                        backgroundColor: scoreResult.credit_score.credit_tier === 'excellent' ? '#10b981' :
                                        scoreResult.credit_score.credit_tier === 'very_good' ? '#22c55e' :
                                        scoreResult.credit_score.credit_tier === 'good' ? '#84cc16' :
                                        scoreResult.credit_score.credit_tier === 'fair' ? '#f59e0b' : '#ef4444'
                      }}>
                        {scoreResult.credit_score.credit_tier.toUpperCase()}
                      </Badge>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-blue-200 mb-1">Lending Capacity</div>
                      <div className="text-2xl font-bold">${scoreResult.credit_score.lending_capacity.toLocaleString()}</div>
                      <div className="text-xs text-blue-300 mt-2">{scoreResult.credit_score.interest_tier} rates</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Risk Assessment */}
            {scoreResult.risk_assessment && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Risk Assessment</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <div className="text-2xl font-bold" style={{ color: getRiskLevelColor(scoreResult.risk_assessment.overall_risk) }}>
                        {getRiskLevelLabel(scoreResult.risk_assessment.overall_risk)}
                      </div>
                      <div className="text-sm text-gray-400">Risk Score: {scoreResult.risk_assessment.risk_score}/100</div>
                    </div>
                    {scoreResult.risk_assessment.alerts.length > 0 && (
                      <Badge variant="destructive">{scoreResult.risk_assessment.alerts.length} Alerts</Badge>
                    )}
                  </div>
                  {scoreResult.risk_assessment.risk_factors.length > 0 && (
                    <div className="space-y-2">
                      {scoreResult.risk_assessment.risk_factors.slice(0, 3).map((factor, i) => (
                        <div key={i} className="text-sm p-2 bg-gray-800 rounded border-l-2" style={{ borderLeftColor: getRiskLevelColor(factor.severity) }}>
                          {factor.factor}: {factor.description}
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            )}

            {/* Trend */}
            {scoreResult.trend && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Score Trend (30 days)</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-4">
                    <div className="text-4xl">{getTrendEmoji(scoreResult.trend.direction)}</div>
                    <div>
                      <div className="text-2xl font-bold">
                        {scoreResult.trend.change_points > 0 ? '+' : ''}{scoreResult.trend.change_points}
                      </div>
                      <div className="text-sm text-gray-400">
                        {scoreResult.trend.change_percentage > 0 ? '+' : ''}{scoreResult.trend.change_percentage.toFixed(1)}%
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Badges */}
            {scoreResult.badges_earned && scoreResult.badges_earned.length > 0 && (
              <Card className="bg-gradient-to-br from-yellow-900 to-yellow-800 border-yellow-700">
                <CardHeader>
                  <CardTitle className="text-white">Badges Earned 🎖️</CardTitle>
                  <CardDescription className="text-yellow-200">{scoreResult.badges_earned.length} achievements unlocked</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex flex-wrap gap-3">
                    {scoreResult.badges_earned.slice(0, 5).map((badgeId) => {
                      const badge = allBadges.find((b) => b.id === badgeId);
                      if (!badge) return null;
                      return (
                        <div key={badgeId} className="flex items-center gap-2 bg-yellow-950 px-3 py-2 rounded-lg">
                          <span className="text-2xl">{badge.icon}</span>
                          <span className="text-sm font-medium">{badge.name}</span>
                        </div>
                      );
                    })}
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Attestations */}
            {scoreResult.attestation_count !== undefined && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">Identity Verification</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <div className="text-3xl font-bold text-green-400">{scoreResult.attestation_count}</div>
                      <div className="text-sm text-gray-400">Verified attestations</div>
                    </div>
                    <Link href="/attestations">
                      <Button variant="outline">Add More ✅</Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            )}

            {scoreResult.suggestions.length > 0 && (
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle className="text-white">AI-Powered Suggestions</CardTitle>
                  <CardDescription className="text-gray-400">Personalized recommendations to improve your score</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                  {scoreResult.suggestions.map((suggestion, index: number) => (
                    <div
                      key={index}
                      className="p-4 rounded-lg bg-gray-800 border border-gray-700"
                    >
                      <div className="flex items-start justify-between mb-2">
                        <h4 className="font-semibold text-white">{suggestion.title}</h4>
                        <Badge
                          variant={suggestion.impact === 'high' ? 'destructive' : suggestion.impact === 'medium' ? 'default' : 'secondary'}
                          className="ml-2"
                        >
                          {suggestion.impact}
                        </Badge>
                      </div>
                      <p className="text-gray-400 text-sm mb-2">{suggestion.description}</p>
                      {suggestion.estimated_points && (
                        <div className="text-xs text-green-400">Potential: +{suggestion.estimated_points} points</div>
                      )}
                      {suggestion.actionable_steps && suggestion.actionable_steps.length > 0 && (
                        <ul className="mt-2 space-y-1 text-xs text-gray-500">
                          {suggestion.actionable_steps.map((step, i) => (
                            <li key={i}>• {step}</li>
                          ))}
                        </ul>
                      )}
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </div>
        )}

        {/* Feature Cards */}
        {!scoreResult && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-8">
            <Link href="/attestations">
              <Card className="bg-gray-900 border-gray-800 hover:border-blue-600 transition-colors cursor-pointer">
                <CardHeader>
                  <CardTitle className="text-white text-center">✅ Attestations</CardTitle>
                  <CardDescription className="text-center">Verify your identity across platforms</CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/analytics">
              <Card className="bg-gray-900 border-gray-800 hover:border-purple-600 transition-colors cursor-pointer">
                <CardHeader>
                  <CardTitle className="text-white text-center">📊 Analytics</CardTitle>
                  <CardDescription className="text-center">View detailed credit & risk data</CardDescription>
                </CardHeader>
              </Card>
            </Link>
            <Link href="/simulate">
              <Card className="bg-gray-900 border-gray-800 hover:border-green-600 transition-colors cursor-pointer">
                <CardHeader>
                  <CardTitle className="text-white text-center">🔮 Simulate</CardTitle>
                  <CardDescription className="text-center">Test what-if scenarios</CardDescription>
                </CardHeader>
              </Card>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
