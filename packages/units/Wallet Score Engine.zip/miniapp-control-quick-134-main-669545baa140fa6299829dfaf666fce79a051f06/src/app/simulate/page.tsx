'use client';

import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import type { SimulationResult } from '@/types/score-engine';
import { getMetrics } from '@/lib/storage';

export default function SimulatePage() {
  const [walletAddress, setWalletAddress] = useState('');
  const [changes, setChanges] = useState<Record<string, string>>({});
  const [simulation, setSimulation] = useState<SimulationResult | null>(null);
  const [loading, setLoading] = useState(false);

  const metrics = getMetrics();

  const runSimulation = async () => {
    if (!walletAddress) return;

    setLoading(true);
    try {
      const changesArray = Object.entries(changes)
        .filter(([_, value]) => value !== '')
        .map(([metric_key, value]) => ({
          metric_key,
          new_value: isNaN(Number(value)) ? (value === 'true') : Number(value),
        }));

      const response = await fetch('/api/simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          wallet_address: walletAddress,
          rule_slug: 'base-wallet-core',
          changes: changesArray,
        }),
      });

      const result = await response.json();
      setSimulation(result);
    } catch (error) {
      console.error('Simulation failed:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white p-4 pt-16 md:pt-8">
      <div className="container mx-auto max-w-6xl">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2">Score Simulator</h1>
          <p className="text-gray-400">
            See how changes to your metrics would impact your score
          </p>
        </div>

        {/* Wallet Input */}
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>Wallet Address</CardTitle>
          </CardHeader>
          <CardContent>
            <Input
              value={walletAddress}
              onChange={(e) => setWalletAddress(e.target.value)}
              placeholder="0x..."
              className="bg-gray-900 border-gray-700 text-white"
            />
          </CardContent>
        </Card>

        {/* Metric Changes */}
        <Card className="mb-6 bg-gray-800 border-gray-700">
          <CardHeader>
            <CardTitle>What-If Scenarios</CardTitle>
            <CardDescription>
              Enter new values to see projected impact
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics.map((metric) => (
                <div key={metric.id}>
                  <Label htmlFor={metric.key} className="text-white">
                    {metric.label}
                    <span className="text-gray-400 text-sm ml-2">({metric.category})</span>
                  </Label>
                  <div className="flex gap-2 mt-1">
                    <Input
                      id={metric.key}
                      type={metric.type === 'boolean' ? 'text' : 'number'}
                      value={changes[metric.key] || ''}
                      onChange={(e) =>
                        setChanges({ ...changes, [metric.key]: e.target.value })
                      }
                      placeholder={
                        metric.type === 'boolean' ? 'true/false' : 'New value...'
                      }
                      className="flex-1 bg-gray-900 border-gray-700 text-white"
                    />
                    {changes[metric.key] && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          const newChanges = { ...changes };
                          delete newChanges[metric.key];
                          setChanges(newChanges);
                        }}
                      >
                        Clear
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>

            <Button
              onClick={runSimulation}
              disabled={loading || !walletAddress || Object.keys(changes).length === 0}
              className="w-full mt-6"
            >
              {loading ? 'Simulating...' : 'Run Simulation'}
            </Button>
          </CardContent>
        </Card>

        {/* Simulation Results */}
        {simulation && (
          <>
            {/* Score Change Overview */}
            <Card className="mb-6 bg-gradient-to-br from-purple-900 to-purple-800 border-purple-700">
              <CardHeader>
                <CardTitle>Projected Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <div className="text-sm text-purple-200 mb-1">Current Score</div>
                    <div className="text-4xl font-bold">{simulation.current_score.toFixed(1)}</div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm text-purple-200 mb-1">Projected Score</div>
                    <div className="text-4xl font-bold text-green-400">
                      {simulation.projected_score.toFixed(1)}
                    </div>
                  </div>

                  <div className="text-center">
                    <div className="text-sm text-purple-200 mb-1">Change</div>
                    <div
                      className={`text-4xl font-bold ${
                        simulation.score_change > 0
                          ? 'text-green-400'
                          : simulation.score_change < 0
                          ? 'text-red-400'
                          : 'text-gray-400'
                      }`}
                    >
                      {simulation.score_change > 0 ? '+' : ''}
                      {simulation.score_change.toFixed(1)}
                      <span className="text-xl ml-2">
                        ({simulation.percentage_change.toFixed(1)}%)
                      </span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Affected Metrics */}
            <Card className="mb-6 bg-gray-800 border-gray-700">
              <CardHeader>
                <CardTitle>Affected Metrics</CardTitle>
                <CardDescription>How your changes impact each metric</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {simulation.affected_metrics.map((affected, index) => (
                    <div key={index} className="p-4 bg-gray-700 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <h4 className="font-medium">{affected.metric_label}</h4>
                        <Badge
                          variant={
                            affected.points_change > 0
                              ? 'default'
                              : affected.points_change < 0
                              ? 'destructive'
                              : 'secondary'
                          }
                        >
                          {affected.points_change > 0 ? '+' : ''}
                          {affected.points_change.toFixed(1)} pts
                        </Badge>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-300">
                        <span>Current: {affected.current_points.toFixed(1)}</span>
                        <span>→</span>
                        <span>Projected: {affected.projected_points.toFixed(1)}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* New Suggestions */}
            {simulation.new_suggestions.length > 0 && (
              <Card className="bg-gray-800 border-gray-700">
                <CardHeader>
                  <CardTitle>Updated Suggestions</CardTitle>
                  <CardDescription>
                    Based on your projected state
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {simulation.new_suggestions.map((suggestion, index) => (
                      <Card
                        key={index}
                        className={`${
                          suggestion.impact === 'high'
                            ? 'bg-red-900 border-red-700'
                            : suggestion.impact === 'medium'
                            ? 'bg-yellow-900 border-yellow-700'
                            : 'bg-blue-900 border-blue-700'
                        }`}
                      >
                        <CardContent className="pt-4">
                          <div className="flex items-start justify-between mb-2">
                            <h4 className="font-medium">{suggestion.title}</h4>
                            <Badge variant="secondary">{suggestion.impact}</Badge>
                          </div>
                          <p className="text-sm text-gray-200 mb-2">{suggestion.description}</p>
                          {suggestion.estimated_points && (
                            <div className="text-sm text-green-300">
                              Potential gain: +{suggestion.estimated_points} points
                            </div>
                          )}
                          {suggestion.actionable_steps && suggestion.actionable_steps.length > 0 && (
                            <ul className="mt-2 space-y-1 text-sm text-gray-300">
                              {suggestion.actionable_steps.map((step, idx) => (
                                <li key={idx}>• {step}</li>
                              ))}
                            </ul>
                          )}
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </>
        )}

        {/* Info */}
        {!simulation && (
          <Alert className="bg-gray-800 border-gray-700">
            <AlertDescription>
              💡 <strong>Pro Tip:</strong> Enter new values for any metrics you want to change,
              then run the simulation to see how they would affect your score. This helps you
              identify the most impactful improvements.
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  );
}
