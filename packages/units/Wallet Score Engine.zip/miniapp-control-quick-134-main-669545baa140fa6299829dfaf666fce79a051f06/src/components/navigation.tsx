'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export function Navigation() {
  const pathname = usePathname();

  const navItems = [
    { href: '/', label: 'Score Wallet', icon: '🎯' },
    { href: '/attestations', label: 'Attestations', icon: '✅', badge: 'Identity' },
    { href: '/analytics', label: 'Analytics', icon: '📊', badge: 'Advanced' },
    { href: '/simulate', label: 'Simulate', icon: '🔮', badge: 'What-If' },
    { href: '/admin/metrics', label: 'Metrics', icon: '⚙️', badge: 'Admin' },
    { href: '/admin/rules', label: 'Rules', icon: '📋', badge: 'Admin' },
    { href: '/admin/history', label: 'History', icon: '📜', badge: 'Admin' },
  ];

  return (
    <Card className="bg-gray-800 border-gray-700 p-4 mb-6">
      <div className="flex flex-wrap gap-2">
        {navItems.map((item) => (
          <Link key={item.href} href={item.href}>
            <div
              className={`px-4 py-2 rounded-lg transition-all ${
                pathname === item.href
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-700 text-gray-300 hover:bg-gray-600'
              }`}
            >
              <span className="mr-2">{item.icon}</span>
              <span className="font-medium">{item.label}</span>
              {item.badge && (
                <Badge variant="secondary" className="ml-2 text-xs">
                  {item.badge}
                </Badge>
              )}
            </div>
          </Link>
        ))}
      </div>
    </Card>
  );
}
