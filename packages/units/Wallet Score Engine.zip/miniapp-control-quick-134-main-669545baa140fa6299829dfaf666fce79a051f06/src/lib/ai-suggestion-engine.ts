import type {
  Suggestion,
  MetricBreakdown,
  ScoreMetric,
  SuggestionImpact,
  WalletContext,
} from '@/types/score-engine';

// Enhanced AI-powered suggestion generation
export function generateAISuggestions(
  breakdowns: MetricBreakdown[],
  metrics: ScoreMetric[],
  context: WalletContext,
  currentScore: number
): Suggestion[] {
  const suggestions: Suggestion[] = [];

  // Analyze each metric for improvement opportunities
  for (const breakdown of breakdowns) {
    const deficit = breakdown.max_points - breakdown.points_awarded;
    const percentageOfMax = (breakdown.points_awarded / breakdown.max_points) * 100;

    // Skip metrics that are performing well (>80%)
    if (percentageOfMax > 80) {
      continue;
    }

    const metric = metrics.find((m: ScoreMetric) => m.id === breakdown.metric_id);
    if (!metric) continue;

    // Calculate estimated impact
    const estimated_points = Math.round(deficit);

    // Determine impact level
    let impact: SuggestionImpact;
    if (deficit >= breakdown.max_points * 0.7) {
      impact = 'high';
    } else if (deficit >= breakdown.max_points * 0.4) {
      impact = 'medium';
    } else {
      impact = 'low';
    }

    // Generate category-specific, personalized suggestions
    const suggestion = generatePersonalizedSuggestion(
      metric,
      breakdown,
      context,
      estimated_points,
      impact
    );

    if (suggestion) {
      suggestions.push(suggestion);
    }
  }

  // Add strategic suggestions based on overall score
  if (currentScore < 50) {
    suggestions.push({
      title: 'Quick Wins Strategy',
      description: 'Focus on the highest-impact metrics first to rapidly improve your score',
      impact: 'high',
      actionable_steps: [
        'Complete identity attestations (fast and high value)',
        'Increase your LP amount to reach the optimal range',
        'Participate in at least 10 trades this month',
      ],
      time_estimate: '1-2 weeks',
      priority: 5,
    });
  }

  if (currentScore >= 50 && currentScore < 75) {
    suggestions.push({
      title: 'Consistency Optimization',
      description: 'Maintain regular activity to build long-term reputation',
      impact: 'medium',
      actionable_steps: [
        'Set up recurring trades or LP contributions',
        'Diversify across multiple protocols',
        'Engage with governance when available',
      ],
      time_estimate: '2-4 weeks',
      priority: 3,
    });
  }

  if (currentScore >= 75) {
    suggestions.push({
      title: 'Elite Status Path',
      description: 'Fine-tune remaining metrics to achieve elite status',
      impact: 'medium',
      actionable_steps: [
        'Complete all available attestations',
        'Maintain perfect consistency for 30+ days',
        'Achieve 90%+ in all category scores',
      ],
      time_estimate: '1 month+',
      priority: 2,
    });
  }

  // Sort by priority (high impact first, then by estimated points)
  const impactOrder: Record<SuggestionImpact, number> = { high: 3, medium: 2, low: 1 };
  suggestions.sort((a: Suggestion, b: Suggestion) => {
    const impactDiff = impactOrder[b.impact] - impactOrder[a.impact];
    if (impactDiff !== 0) return impactDiff;
    
    const pointsA = a.estimated_points || 0;
    const pointsB = b.estimated_points || 0;
    return pointsB - pointsA;
  });

  // Limit to top 8 suggestions
  return suggestions.slice(0, 8);
}

function generatePersonalizedSuggestion(
  metric: ScoreMetric,
  breakdown: MetricBreakdown,
  context: WalletContext,
  estimated_points: number,
  impact: SuggestionImpact
): Suggestion | null {
  const rawValue = breakdown.raw_value;
  const actionable_steps: string[] = [];
  let time_estimate = '1-2 weeks';

  switch (metric.category) {
    case 'liquidity':
      if (metric.key === 'lp_amount') {
        const currentAmount = typeof rawValue === 'number' ? rawValue : 0;
        const config = metric.config as { min_value: number; max_value: number };
        const targetAmount = Math.round(config.max_value * 0.8); // aim for 80% of max
        const needToAdd = Math.max(0, targetAmount - currentAmount);

        actionable_steps.push(
          `Add $${needToAdd.toLocaleString()} to liquidity pools`,
          'Focus on stable pairs (USDC/ETH) for lower risk',
          'Monitor impermanent loss using pool analytics'
        );
        time_estimate = 'Immediate';

        return {
          title: `Increase Liquidity Provision (+${estimated_points} pts)`,
          description: `Boost your LP amount from $${currentAmount.toLocaleString()} to $${targetAmount.toLocaleString()} to maximize this metric.`,
          impact,
          estimated_points,
          actionable_steps,
          time_estimate,
          priority: impact === 'high' ? 5 : impact === 'medium' ? 3 : 1,
        };
      }
      break;

    case 'activity':
      if (metric.key === 'trade_count_30d') {
        const currentTrades = typeof rawValue === 'number' ? rawValue : 0;
        const config = metric.config as { min_value: number; max_value: number };
        const targetTrades = Math.round(config.max_value * 0.7);
        const needToTrade = Math.max(0, targetTrades - currentTrades);

        actionable_steps.push(
          `Execute ${needToTrade} more trades this month`,
          'Use limit orders to optimize gas fees',
          'Start with smaller amounts to build history safely'
        );
        time_estimate = '2-4 weeks';

        return {
          title: `Increase Trading Activity (+${estimated_points} pts)`,
          description: `Complete ${needToTrade} more trades to reach the optimal activity level.`,
          impact,
          estimated_points,
          actionable_steps,
          time_estimate,
          priority: impact === 'high' ? 4 : impact === 'medium' ? 2 : 1,
        };
      }
      break;

    case 'loyalty':
      if (metric.key === 'hold_time_days') {
        const currentDays = typeof rawValue === 'number' ? rawValue : 0;
        const config = metric.config as { min_value: number; max_value: number };
        const targetDays = Math.round(config.max_value * 0.5);

        actionable_steps.push(
          'Hold assets for longer periods (3-6 months recommended)',
          'Set up automated strategies to avoid manual trading temptation',
          'Focus on long-term value rather than short-term gains'
        );
        time_estimate = `${Math.max(30, targetDays - currentDays)} days`;

        return {
          title: `Extend Holding Period (+${estimated_points} pts)`,
          description: `Increase average holding time to ${targetDays} days to demonstrate loyalty.`,
          impact,
          estimated_points,
          actionable_steps,
          time_estimate,
          priority: impact === 'high' ? 3 : impact === 'medium' ? 2 : 1,
        };
      }

      if (metric.key === 'in_high_trust_pack' && rawValue === false) {
        actionable_steps.push(
          'Apply for high-trust community membership',
          'Complete required attestations and verifications',
          'Maintain good standing in DreamNet ecosystem'
        );
        time_estimate = '3-7 days';

        return {
          title: `Join High-Trust Pack (+${estimated_points} pts)`,
          description: 'Gain membership in the verified high-trust community for instant score boost.',
          impact: 'high',
          estimated_points,
          actionable_steps,
          time_estimate,
          priority: 5,
        };
      }

      if (metric.key === 'attestation_score') {
        const currentScore = typeof rawValue === 'number' ? rawValue : 0;
        const config = metric.config as { min_value: number; max_value: number };
        const targetScore = Math.round(config.max_value * 0.6);
        const attestationsNeeded = Math.ceil((targetScore - currentScore) / 10); // ~10 points per attestation

        actionable_steps.push(
          `Complete ${attestationsNeeded} more identity attestations`,
          'Start with easy ones: Farcaster, Twitter, Email',
          'High-value attestations: Proof of Humanity, Worldcoin'
        );
        time_estimate = '1-3 days';

        return {
          title: `Verify Your Identity (+${estimated_points} pts)`,
          description: `Complete ${attestationsNeeded} more attestations to boost your trust score significantly.`,
          impact: 'high',
          estimated_points,
          actionable_steps,
          time_estimate,
          priority: 5,
        };
      }
      break;

    case 'risk':
      actionable_steps.push(
        'Reduce exposure to high-risk protocols',
        'Maintain healthy collateral ratios',
        'Avoid liquidation by monitoring positions regularly'
      );
      time_estimate = 'Ongoing';

      return {
        title: `Reduce Risk Exposure (+${estimated_points} pts)`,
        description: 'Lower your risk profile by following best practices and maintaining safe positions.',
        impact,
        estimated_points,
        actionable_steps,
        time_estimate,
        priority: impact === 'high' ? 4 : 2,
      };
  }

  return null;
}
