import type { Attestation, AttestationStatus } from '@/types/score-engine';

// Attestation providers and their point values (Gitcoin Passport style)
export const ATTESTATION_PROVIDERS = {
  github: { name: 'GitHub', points: 15, icon: '🐙' },
  twitter: { name: 'Twitter/X', points: 10, icon: '🐦' },
  farcaster: { name: 'Farcaster', points: 20, icon: '💜' },
  ens: { name: 'ENS Domain', points: 12, icon: '🌐' },
  email: { name: 'Email', points: 5, icon: '📧' },
  phone: { name: 'Phone', points: 8, icon: '📱' },
  linkedin: { name: 'LinkedIn', points: 12, icon: '💼' },
  discord: { name: 'Discord', points: 8, icon: '💬' },
  telegram: { name: 'Telegram', points: 8, icon: '✈️' },
  proof_of_humanity: { name: 'Proof of Humanity', points: 50, icon: '👤' },
  worldcoin: { name: 'Worldcoin', points: 40, icon: '🌍' },
  brightid: { name: 'BrightID', points: 30, icon: '🔆' },
  nft_holder: { name: 'NFT Holder', points: 15, icon: '🖼️' },
  token_holder: { name: 'Token Holder', points: 10, icon: '🪙' },
  governance: { name: 'Governance Participant', points: 25, icon: '🗳️' },
} as const;

export type AttestationProviderKey = keyof typeof ATTESTATION_PROVIDERS;

export function getAttestationPoints(type: string): number {
  if (type in ATTESTATION_PROVIDERS) {
    return ATTESTATION_PROVIDERS[type as AttestationProviderKey].points;
  }
  return 5; // default
}

export function calculateAttestationScore(attestations: Attestation[]): {
  total_points: number;
  verified_count: number;
  diversity_bonus: number;
  final_score: number;
} {
  const verifiedAttestations = attestations.filter(
    (a: Attestation) => a.status === 'verified'
  );

  const total_points = verifiedAttestations.reduce(
    (sum: number, a: Attestation) => sum + a.points,
    0
  );

  const verified_count = verifiedAttestations.length;

  // Diversity bonus: reward having attestations from different categories
  const uniqueTypes = new Set(verifiedAttestations.map((a: Attestation) => a.type));
  const diversity_bonus = Math.min(uniqueTypes.size * 3, 30); // max 30 points

  const final_score = total_points + diversity_bonus;

  return {
    total_points,
    verified_count,
    diversity_bonus,
    final_score,
  };
}

export function createAttestationMetric() {
  return {
    id: 'metric_attestations',
    key: 'attestation_score',
    label: 'Identity Attestations',
    category: 'loyalty' as const,
    description: 'Verified identity proofs from multiple sources',
    weight: 1.5,
    max_points: 100,
    type: 'numeric_range' as const,
    config: {
      min_value: 0,
      max_value: 150,
    },
    enabled: true,
  };
}

// Simulate attestation verification (in real app, would integrate with OAuth/APIs)
export function simulateAttestationVerification(
  type: AttestationProviderKey
): Omit<Attestation, 'id' | 'wallet_address'> {
  const provider = ATTESTATION_PROVIDERS[type];
  const now = new Date().toISOString();

  return {
    type,
    provider: provider.name,
    value: `${type}_verified_${Date.now()}`,
    status: 'verified',
    points: provider.points,
    verified_at: now,
    expires_at: type === 'proof_of_humanity' ? 
      new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString() : 
      undefined,
    metadata: {
      verification_method: 'oauth',
      confidence: 0.95,
    },
  };
}
