import type { Badge, WalletBadge, BadgeTier } from '@/types/score-engine';

// Predefined badges/achievements
export const SEED_BADGES: Badge[] = [
  {
    id: 'badge_newcomer',
    key: 'newcomer',
    name: 'Newcomer',
    description: 'Complete your first wallet score',
    tier: 'bronze',
    icon: '🌱',
    points: 5,
    criteria: {
      type: 'score_count',
      value: 1,
      description: 'Get your wallet scored at least once',
    },
    enabled: true,
  },
  {
    id: 'badge_rising_star',
    key: 'rising_star',
    name: 'Rising Star',
    description: 'Achieve a score above 50',
    tier: 'silver',
    icon: '⭐',
    points: 10,
    criteria: {
      type: 'score_threshold',
      value: 50,
      description: 'Reach a normalized score of 50 or higher',
    },
    enabled: true,
  },
  {
    id: 'badge_high_performer',
    key: 'high_performer',
    name: 'High Performer',
    description: 'Achieve a score above 75',
    tier: 'gold',
    icon: '🏆',
    points: 25,
    criteria: {
      type: 'score_threshold',
      value: 75,
      description: 'Reach a normalized score of 75 or higher',
    },
    enabled: true,
  },
  {
    id: 'badge_elite',
    key: 'elite',
    name: 'Elite',
    description: 'Achieve a score above 90',
    tier: 'platinum',
    icon: '💎',
    points: 50,
    criteria: {
      type: 'score_threshold',
      value: 90,
      description: 'Reach a normalized score of 90 or higher',
    },
    enabled: true,
  },
  {
    id: 'badge_perfect',
    key: 'perfect',
    name: 'Perfect Score',
    description: 'Achieve a perfect 100 score',
    tier: 'diamond',
    icon: '👑',
    points: 100,
    criteria: {
      type: 'score_threshold',
      value: 100,
      description: 'Reach a perfect normalized score of 100',
    },
    enabled: true,
  },
  {
    id: 'badge_identity_verified',
    key: 'identity_verified',
    name: 'Identity Verified',
    description: 'Verify at least 5 attestations',
    tier: 'silver',
    icon: '✅',
    points: 15,
    criteria: {
      type: 'attestation_count',
      value: 5,
      description: 'Complete 5 or more identity attestations',
    },
    enabled: true,
  },
  {
    id: 'badge_trusted_identity',
    key: 'trusted_identity',
    name: 'Trusted Identity',
    description: 'Verify at least 10 attestations',
    tier: 'gold',
    icon: '🛡️',
    points: 30,
    criteria: {
      type: 'attestation_count',
      value: 10,
      description: 'Complete 10 or more identity attestations',
    },
    enabled: true,
  },
  {
    id: 'badge_consistency',
    key: 'consistency',
    name: 'Consistency King',
    description: 'Maintain a score above 70 for 30 days',
    tier: 'gold',
    icon: '📈',
    points: 35,
    criteria: {
      type: 'consistency_streak',
      value: 30,
      description: 'Keep your score above 70 for 30 consecutive days',
    },
    enabled: true,
  },
  {
    id: 'badge_improver',
    key: 'improver',
    name: 'Fast Improver',
    description: 'Improve your score by 20+ points in 7 days',
    tier: 'silver',
    icon: '🚀',
    points: 20,
    criteria: {
      type: 'score_improvement',
      value: 20,
      description: 'Increase your score by at least 20 points within a week',
    },
    enabled: true,
  },
  {
    id: 'badge_diversified',
    key: 'diversified',
    name: 'Diversified',
    description: 'Score 50+ in all categories',
    tier: 'platinum',
    icon: '🌈',
    points: 40,
    criteria: {
      type: 'category_balance',
      value: 50,
      description: 'Achieve at least 50% in every scoring category',
    },
    enabled: true,
  },
];

// Check which badges a wallet has earned
export function checkBadgesEarned(
  score: number,
  attestationCount: number,
  previousScores: number[],
  categoryPercentages: Record<string, number>
): string[] {
  const earnedBadgeIds: string[] = [];

  for (const badge of SEED_BADGES) {
    if (!badge.enabled) continue;

    let earned = false;

    switch (badge.criteria.type) {
      case 'score_threshold':
        earned = score >= badge.criteria.value;
        break;

      case 'attestation_count':
        earned = attestationCount >= badge.criteria.value;
        break;

      case 'score_count':
        earned = previousScores.length >= badge.criteria.value;
        break;

      case 'score_improvement':
        if (previousScores.length >= 2) {
          const oldScore = previousScores[previousScores.length - 2];
          const improvement = score - oldScore;
          earned = improvement >= badge.criteria.value;
        }
        break;

      case 'category_balance':
        const allCategories = Object.values(categoryPercentages);
        if (allCategories.length > 0) {
          const minCategoryScore = Math.min(...allCategories);
          earned = minCategoryScore >= badge.criteria.value;
        }
        break;

      // 'consistency_streak' would require time-series data, skip for now
    }

    if (earned) {
      earnedBadgeIds.push(badge.id);
    }
  }

  return earnedBadgeIds;
}

// Get badge tier color
export function getBadgeTierColor(tier: BadgeTier): string {
  const colors: Record<BadgeTier, string> = {
    bronze: '#CD7F32',
    silver: '#C0C0C0',
    gold: '#FFD700',
    platinum: '#E5E4E2',
    diamond: '#B9F2FF',
  };
  return colors[tier];
}

// Calculate total badge points
export function calculateBadgeBonus(badgeIds: string[]): number {
  return badgeIds.reduce((total: number, badgeId: string) => {
    const badge = SEED_BADGES.find((b: Badge) => b.id === badgeId);
    return total + (badge?.points || 0);
  }, 0);
}
