import type { CreditScore, WalletContext } from '@/types/score-engine';

// FICO-style credit score (300-850) for DeFi
export function calculateCreditScore(
  context: WalletContext,
  normalizedScore: number
): CreditScore {
  const signals = context.numeric_signals || {};
  const flags = context.flags || {};
  const onChain = context.on_chain_data || {};

  // Factor 1: Payment History (35% weight) - Based on liquidations and repayments
  const liquidationCount = signals.liquidation_count || 0;
  const repaymentSuccess = signals.successful_repayments || 0;
  const totalBorrows = signals.total_borrows || 1;
  
  const repaymentRate = totalBorrows > 0 ? repaymentSuccess / totalBorrows : 1;
  const liquidationPenalty = Math.max(0, 100 - (liquidationCount * 20));
  const payment_history = Math.min(100, (repaymentRate * 70 + liquidationPenalty * 0.3));

  // Factor 2: Liquidation History (10% weight)
  const daysWithoutLiquidation = signals.days_without_liquidation || 365;
  const liquidation_history = Math.min(100, (daysWithoutLiquidation / 365) * 100);

  // Factor 3: Credit Utilization (30% weight) - How much of available credit is used
  const totalBorrowed = signals.total_borrowed || 0;
  const totalCollateral = signals.total_collateral || 1;
  const utilizationRatio = totalCollateral > 0 ? totalBorrowed / totalCollateral : 0;
  
  // Optimal utilization: 10-30%, penalize >70%
  let credit_utilization: number;
  if (utilizationRatio < 0.1) {
    credit_utilization = 70 + (utilizationRatio * 300); // 0-10% = 70-100
  } else if (utilizationRatio <= 0.3) {
    credit_utilization = 100; // optimal range
  } else if (utilizationRatio <= 0.7) {
    credit_utilization = 100 - ((utilizationRatio - 0.3) * 125); // 30-70% = 100-50
  } else {
    credit_utilization = Math.max(0, 50 - ((utilizationRatio - 0.7) * 100)); // >70% = 50-0
  }

  // Factor 4: Account Age (15% weight) - Length of credit history
  const firstTxDate = onChain.first_transaction_date;
  let account_age = 50; // default
  
  if (firstTxDate) {
    const daysSinceFirst = (Date.now() - new Date(firstTxDate).getTime()) / (1000 * 60 * 60 * 24);
    account_age = Math.min(100, (daysSinceFirst / 730) * 100); // 2 years = 100%
  }

  // Factor 5: Credit Mix (10% weight) - Diversity of protocols and activities
  const uniqueProtocols = onChain.unique_protocols || 0;
  const hasLending = flags.has_lending_activity || false;
  const hasTrading = flags.has_trading_activity || false;
  const hasStaking = flags.has_staking_activity || false;
  
  const activityDiversity = [hasLending, hasTrading, hasStaking].filter(Boolean).length;
  const credit_mix = Math.min(100, (uniqueProtocols * 10) + (activityDiversity * 20));

  // Calculate weighted credit score (300-850 scale)
  const factors = {
    payment_history: payment_history * 0.35,
    liquidation_history: liquidation_history * 0.10,
    credit_utilization: credit_utilization * 0.30,
    account_age: account_age * 0.15,
    credit_mix: credit_mix * 0.10,
  };

  const totalFactorScore = Object.values(factors).reduce((sum: number, val: number) => sum + val, 0);
  
  // Map 0-100 to 300-850
  const credit_score = Math.round(300 + (totalFactorScore / 100) * 550);

  // Determine credit tier
  let credit_tier: CreditScore['credit_tier'];
  if (credit_score >= 750) credit_tier = 'excellent';
  else if (credit_score >= 700) credit_tier = 'very_good';
  else if (credit_score >= 650) credit_tier = 'good';
  else if (credit_score >= 600) credit_tier = 'fair';
  else credit_tier = 'poor';

  // Calculate lending capacity (based on credit score and collateral)
  const baseCapacity = totalCollateral * 0.7; // standard 70% LTV
  let capacityMultiplier = 1.0;
  
  if (credit_score >= 750) capacityMultiplier = 1.5; // 105% LTV for excellent
  else if (credit_score >= 700) capacityMultiplier = 1.3; // 91% LTV
  else if (credit_score >= 650) capacityMultiplier = 1.1; // 77% LTV
  else if (credit_score < 600) capacityMultiplier = 0.7; // 49% LTV for poor
  
  const lending_capacity = Math.round(baseCapacity * capacityMultiplier);

  // Interest tier
  let interest_tier: CreditScore['interest_tier'];
  if (credit_score >= 720) interest_tier = 'premium';
  else if (credit_score >= 650) interest_tier = 'standard';
  else interest_tier = 'subprime';

  return {
    wallet_address: context.wallet_address,
    credit_score,
    credit_tier,
    factors: {
      payment_history: Math.round(payment_history),
      liquidation_history: Math.round(liquidation_history),
      credit_utilization: Math.round(credit_utilization),
      account_age: Math.round(account_age),
      credit_mix: Math.round(credit_mix),
    },
    lending_capacity,
    interest_tier,
  };
}

// Get credit score insights
export function getCreditScoreInsights(creditScore: CreditScore): string[] {
  const insights: string[] = [];
  const factors = creditScore.factors;

  if (factors.payment_history < 70) {
    insights.push('💡 Improve payment history by avoiding liquidations and completing repayments on time');
  }

  if (factors.credit_utilization > 70 || factors.credit_utilization < 10) {
    insights.push('💡 Optimize credit utilization between 10-30% for best results');
  }

  if (factors.account_age < 50) {
    insights.push('💡 Build credit history by maintaining consistent on-chain activity over time');
  }

  if (factors.credit_mix < 50) {
    insights.push('💡 Diversify your DeFi activities across lending, trading, and staking');
  }

  if (creditScore.credit_score >= 750) {
    insights.push('🎉 Excellent credit score! You qualify for premium rates and higher lending limits');
  }

  return insights;
}
