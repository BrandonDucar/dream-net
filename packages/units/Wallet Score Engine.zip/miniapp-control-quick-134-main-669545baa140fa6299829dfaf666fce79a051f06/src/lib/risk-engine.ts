import type { RiskAssessment, RiskLevel, WalletContext } from '@/types/score-engine';

export function assessRisk(context: WalletContext, score: number): RiskAssessment {
  const signals = context.numeric_signals || {};
  const flags = context.flags || {};
  const riskFactors: RiskAssessment['risk_factors'] = [];
  const alerts: RiskAssessment['alerts'] = [];

  // Factor 1: Liquidation risk
  const liquidationCount = signals.liquidation_count || 0;
  if (liquidationCount > 0) {
    const severity: RiskLevel = liquidationCount >= 5 ? 'critical' : 
                                  liquidationCount >= 3 ? 'high' :
                                  liquidationCount >= 1 ? 'medium' : 'low';
    riskFactors.push({
      factor: 'Liquidation History',
      severity,
      description: `${liquidationCount} liquidation(s) detected`,
      remediation: 'Maintain healthier collateral ratios and monitor positions regularly',
    });
  }

  // Factor 2: High leverage
  const leverageRatio = signals.leverage_ratio || 0;
  if (leverageRatio > 3) {
    const severity: RiskLevel = leverageRatio >= 10 ? 'critical' :
                                  leverageRatio >= 5 ? 'high' : 'medium';
    riskFactors.push({
      factor: 'High Leverage',
      severity,
      description: `Leverage ratio of ${leverageRatio.toFixed(1)}x detected`,
      remediation: 'Consider reducing leverage to decrease liquidation risk',
    });
    
    if (leverageRatio >= 5) {
      alerts.push({
        id: `alert_${Date.now()}_leverage`,
        title: 'High Leverage Warning',
        message: `Your leverage ratio of ${leverageRatio.toFixed(1)}x is dangerously high`,
        severity,
        created_at: new Date().toISOString(),
      });
    }
  }

  // Factor 3: Concentration risk
  const topHoldingPercentage = signals.top_holding_percentage || 0;
  if (topHoldingPercentage > 50) {
    const severity: RiskLevel = topHoldingPercentage >= 90 ? 'high' :
                                  topHoldingPercentage >= 70 ? 'medium' : 'low';
    riskFactors.push({
      factor: 'Portfolio Concentration',
      severity,
      description: `${topHoldingPercentage.toFixed(0)}% of portfolio in single asset`,
      remediation: 'Diversify holdings to reduce concentration risk',
    });
  }

  // Factor 4: Smart contract risk exposure
  const uniqueProtocols = context.on_chain_data?.unique_protocols || 0;
  const unauditedProtocols = signals.unaudited_protocol_count || 0;
  
  if (unauditedProtocols > 0) {
    const severity: RiskLevel = unauditedProtocols >= 5 ? 'high' :
                                  unauditedProtocols >= 3 ? 'medium' : 'low';
    riskFactors.push({
      factor: 'Unaudited Contracts',
      severity,
      description: `Exposure to ${unauditedProtocols} unaudited protocol(s)`,
      remediation: 'Use audited protocols whenever possible',
    });
  }

  // Factor 5: Recent suspicious activity
  if (flags.suspicious_activity) {
    riskFactors.push({
      factor: 'Suspicious Activity',
      severity: 'high',
      description: 'Patterns consistent with wash trading or manipulation detected',
      remediation: 'Review recent transactions for legitimacy',
    });
    
    alerts.push({
      id: `alert_${Date.now()}_suspicious`,
      title: 'Suspicious Activity Detected',
      message: 'Unusual transaction patterns have been identified',
      severity: 'high',
      created_at: new Date().toISOString(),
    });
  }

  // Factor 6: Low activity periods (indicates stale positions)
  const daysSinceLastTx = signals.days_since_last_transaction || 0;
  if (daysSinceLastTx > 90) {
    riskFactors.push({
      factor: 'Stale Positions',
      severity: 'low',
      description: `No activity for ${daysSinceLastTx} days`,
      remediation: 'Review and rebalance positions regularly',
    });
  }

  // Factor 7: New wallet risk
  const accountAgeDays = signals.account_age_days || 0;
  if (accountAgeDays < 30) {
    riskFactors.push({
      factor: 'New Account',
      severity: 'medium',
      description: `Account is only ${accountAgeDays} days old`,
      remediation: 'Build transaction history to establish credibility',
    });
  }

  // Calculate overall risk score (0-100, higher is riskier)
  let risk_score = 0;
  
  // Base risk from factors
  const severityWeights: Record<RiskLevel, number> = {
    minimal: 5,
    low: 10,
    medium: 20,
    high: 35,
    critical: 50,
  };
  
  for (const factor of riskFactors) {
    risk_score += severityWeights[factor.severity];
  }

  // Adjust based on score (high score = lower risk)
  const scoreAdjustment = ((100 - score) / 100) * 20; // up to 20 points
  risk_score += scoreAdjustment;

  // Cap at 100
  risk_score = Math.min(100, risk_score);

  // Determine overall risk level
  let overall_risk: RiskLevel;
  if (risk_score >= 70) overall_risk = 'critical';
  else if (risk_score >= 50) overall_risk = 'high';
  else if (risk_score >= 30) overall_risk = 'medium';
  else if (risk_score >= 15) overall_risk = 'low';
  else overall_risk = 'minimal';

  // If no risk factors, set minimal
  if (riskFactors.length === 0) {
    overall_risk = 'minimal';
    risk_score = Math.min(risk_score, 10);
  }

  return {
    overall_risk,
    risk_score: Math.round(risk_score),
    risk_factors: riskFactors,
    alerts,
  };
}

export function getRiskLevelColor(level: RiskLevel): string {
  const colors: Record<RiskLevel, string> = {
    minimal: '#10b981', // green
    low: '#84cc16', // lime
    medium: '#f59e0b', // amber
    high: '#ef4444', // red
    critical: '#991b1b', // dark red
  };
  return colors[level];
}

export function getRiskLevelLabel(level: RiskLevel): string {
  const labels: Record<RiskLevel, string> = {
    minimal: 'Minimal Risk',
    low: 'Low Risk',
    medium: 'Medium Risk',
    high: 'High Risk',
    critical: 'Critical Risk',
  };
  return labels[level];
}
