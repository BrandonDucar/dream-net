import type {
  ScoreMetric,
  ScoreRule,
  WalletContext,
  ScoreResult,
  MetricBreakdown,
  Suggestion,
  NumericRangeConfig,
  BooleanConfig,
  ListCountConfig,
  SuggestionImpact,
} from '@/types/score-engine';
import { calculateCreditScore } from './credit-score-engine';
import { assessRisk } from './risk-engine';
import { calculateTrend } from './trend-engine';
import { generateAISuggestions } from './ai-suggestion-engine';
import { checkBadgesEarned, calculateBadgeBonus } from './badge-engine';
import { calculateAttestationScore } from './attestation-engine';
import { getSnapshotsByWallet, getAttestationsByWallet, addSnapshot, awardBadge, getWalletBadgesByAddress } from './storage';

function isNumericRangeConfig(config: unknown): config is NumericRangeConfig {
  return (
    typeof config === 'object' &&
    config !== null &&
    'min_value' in config &&
    'max_value' in config
  );
}

function isBooleanConfig(config: unknown): config is BooleanConfig {
  return (
    typeof config === 'object' &&
    config !== null &&
    'true_points' in config &&
    'false_points' in config
  );
}

function isListCountConfig(config: unknown): config is ListCountConfig {
  return (
    typeof config === 'object' &&
    config !== null &&
    'points_per_item' in config
  );
}

function computeMetricPoints(
  metric: ScoreMetric,
  context: WalletContext
): { points: number; rawValue: number | boolean | null } {
  const { type, key, config, max_points } = metric;

  if (type === 'numeric_range' && isNumericRangeConfig(config)) {
    const value = context.numeric_signals?.[key] ?? null;
    if (value === null) {
      return { points: 0, rawValue: null };
    }

    const { min_value, max_value } = config;

    if (value <= min_value) {
      return { points: 0, rawValue: value };
    }

    if (value >= max_value) {
      return { points: max_points, rawValue: value };
    }

    // Linear interpolation
    const ratio = (value - min_value) / (max_value - min_value);
    const points = ratio * max_points;

    return { points, rawValue: value };
  }

  if (type === 'boolean' && isBooleanConfig(config)) {
    const value = context.flags?.[key] ?? false;
    const points = value ? config.true_points : config.false_points;

    return { points, rawValue: value };
  }

  if (type === 'list_count' && isListCountConfig(config)) {
    const count = context.numeric_signals?.[key] ?? 0;
    const { points_per_item, max_items } = config;

    let points = count * points_per_item;

    if (max_items !== undefined && count > max_items) {
      points = max_items * points_per_item;
    }

    points = Math.min(points, max_points);

    return { points, rawValue: count };
  }

  return { points: 0, rawValue: null };
}

function generateSuggestions(
  breakdowns: MetricBreakdown[],
  metrics: ScoreMetric[]
): Suggestion[] {
  const suggestions: Suggestion[] = [];

  for (const breakdown of breakdowns) {
    const deficit = breakdown.max_points - breakdown.points_awarded;

    // Only suggest if there's a significant gap
    if (deficit < breakdown.max_points * 0.3) {
      continue;
    }

    const metric = metrics.find((m: ScoreMetric) => m.id === breakdown.metric_id);
    if (!metric) continue;

    let description = '';
    let impact: SuggestionImpact = 'low';

    // Determine impact based on deficit
    if (deficit >= breakdown.max_points * 0.7) {
      impact = 'high';
    } else if (deficit >= breakdown.max_points * 0.5) {
      impact = 'medium';
    }

    // Generate category-specific guidance
    switch (metric.category) {
      case 'liquidity':
        description = 'Consider adding or increasing liquidity provision to boost your score.';
        break;
      case 'activity':
        description = 'Increase your on-chain activity and trading frequency.';
        break;
      case 'loyalty':
        description = 'Hold assets longer and engage more consistently with the ecosystem.';
        break;
      case 'risk':
        description = 'Reduce risky behaviors and improve your trust signals.';
        break;
      default:
        description = 'Improve this metric to increase your overall score.';
    }

    suggestions.push({
      title: `Improve ${breakdown.metric_label}`,
      description,
      impact,
    });
  }

  // Sort by impact and limit to 5
  const impactOrder: Record<SuggestionImpact, number> = { high: 3, medium: 2, low: 1 };
  suggestions.sort((a: Suggestion, b: Suggestion) => impactOrder[b.impact] - impactOrder[a.impact]);

  return suggestions.slice(0, 5);
}

export function computeWalletScore(
  rule: ScoreRule,
  metrics: ScoreMetric[],
  context: WalletContext,
  options: { includeAdvanced?: boolean; saveSnapshot?: boolean } = {}
): ScoreResult {
  const { includeAdvanced = true, saveSnapshot = true } = options;
  
  const breakdowns: MetricBreakdown[] = [];
  let rawTotal = 0;

  // Compute attestation score if applicable
  const attestations = context.attestations || getAttestationsByWallet(context.wallet_address);
  const attestationData = calculateAttestationScore(attestations);
  
  // Add attestation score to context for metric calculation
  if (attestationData.final_score > 0 && !context.numeric_signals?.attestation_score) {
    context.numeric_signals = {
      ...(context.numeric_signals || {}),
      attestation_score: attestationData.final_score,
    };
  }

  // Compute points for each metric
  for (const metricId of rule.metric_ids) {
    const metric = metrics.find((m: ScoreMetric) => m.id === metricId);

    if (!metric || !metric.enabled) {
      continue;
    }

    const { points, rawValue } = computeMetricPoints(metric, context);

    // Apply weight
    const weightedPoints = points * metric.weight;
    rawTotal += weightedPoints;

    breakdowns.push({
      metric_id: metric.id,
      metric_key: metric.key,
      metric_label: metric.label,
      raw_value: rawValue,
      points_awarded: weightedPoints,
      max_points: metric.max_points * metric.weight,
    });
  }

  // Clamp to max_score
  const totalScore = Math.min(rawTotal, rule.max_score);
  const normalizedScore = (totalScore / rule.max_score) * 100;

  // Generate AI-powered suggestions
  const suggestions = includeAdvanced
    ? generateAISuggestions(breakdowns, metrics, context, normalizedScore)
    : generateSuggestions(breakdowns, metrics);

  // Build base result
  const result: ScoreResult = {
    wallet_address: context.wallet_address,
    rule_slug: rule.slug,
    total_score: Math.round(totalScore * 100) / 100,
    max_score: rule.max_score,
    normalized_score: Math.round(normalizedScore * 100) / 100,
    metric_breakdown: breakdowns,
    suggestions,
    attestation_count: attestations.filter((a) => a.status === 'verified').length,
  };

  // Add advanced analytics if requested
  if (includeAdvanced) {
    // Credit score
    result.credit_score = calculateCreditScore(context, normalizedScore);

    // Risk assessment
    result.risk_assessment = assessRisk(context, normalizedScore);

    // Trend analysis
    const snapshots = getSnapshotsByWallet(context.wallet_address, rule.slug);
    if (snapshots.length >= 2) {
      result.trend = calculateTrend(snapshots, 30);
    }

    // Badge checking
    const previousScores = snapshots.map((s) => s.normalized_score);
    const categoryPercentages: Record<string, number> = {};
    
    // Calculate category percentages
    const categoryTotals: Record<string, { points: number; maxPoints: number }> = {};
    for (const breakdown of breakdowns) {
      const metric = metrics.find((m: ScoreMetric) => m.id === breakdown.metric_id);
      if (!metric) continue;
      
      if (!categoryTotals[metric.category]) {
        categoryTotals[metric.category] = { points: 0, maxPoints: 0 };
      }
      
      categoryTotals[metric.category].points += breakdown.points_awarded;
      categoryTotals[metric.category].maxPoints += breakdown.max_points;
    }
    
    for (const category in categoryTotals) {
      const { points, maxPoints } = categoryTotals[category];
      categoryPercentages[category] = maxPoints > 0 ? (points / maxPoints) * 100 : 0;
    }

    const earnedBadgeIds = checkBadgesEarned(
      normalizedScore,
      result.attestation_count || 0,
      previousScores,
      categoryPercentages
    );

    // Award new badges
    const existingBadges = getWalletBadgesByAddress(context.wallet_address);
    const existingBadgeIds = existingBadges.map((wb) => wb.badge_id);
    
    for (const badgeId of earnedBadgeIds) {
      if (!existingBadgeIds.includes(badgeId)) {
        awardBadge(context.wallet_address, badgeId);
      }
    }

    result.badges_earned = earnedBadgeIds;

    // Add badge bonus to score (optional enhancement)
    const badgeBonus = calculateBadgeBonus(earnedBadgeIds);
    if (badgeBonus > 0) {
      result.total_score = Math.round((result.total_score + badgeBonus * 0.1) * 100) / 100; // 10% weight
    }
  }

  // Save snapshot for trend analysis
  if (saveSnapshot) {
    addSnapshot({
      wallet_address: context.wallet_address,
      rule_slug: rule.slug,
      score: result.total_score,
      normalized_score: result.normalized_score,
      timestamp: new Date().toISOString(),
    });
  }

  return result;
}
