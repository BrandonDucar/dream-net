import type {
  SimulationRequest,
  SimulationResult,
  WalletContext,
  ScoreRule,
  ScoreMetric,
} from '@/types/score-engine';
import { computeWalletScore } from './scoring-engine';
import { generateAISuggestions } from './ai-suggestion-engine';

// "What-if" simulation tool
export function simulateScoreChanges(
  request: SimulationRequest,
  rule: ScoreRule,
  metrics: ScoreMetric[],
  currentContext: WalletContext
): SimulationResult {
  // Calculate current score
  const currentResult = computeWalletScore(rule, metrics, currentContext);
  const current_score = currentResult.normalized_score;

  // Create modified context with changes
  const modifiedContext: WalletContext = {
    ...currentContext,
    numeric_signals: { ...(currentContext.numeric_signals || {}) },
    flags: { ...(currentContext.flags || {}) },
  };

  // Apply changes
  for (const change of request.changes) {
    const { metric_key, new_value } = change;

    if (typeof new_value === 'boolean') {
      if (!modifiedContext.flags) modifiedContext.flags = {};
      modifiedContext.flags[metric_key] = new_value;
    } else {
      if (!modifiedContext.numeric_signals) modifiedContext.numeric_signals = {};
      modifiedContext.numeric_signals[metric_key] = new_value;
    }
  }

  // Calculate projected score
  const projectedResult = computeWalletScore(rule, metrics, modifiedContext);
  const projected_score = projectedResult.normalized_score;

  // Calculate differences
  const score_change = projected_score - current_score;
  const percentage_change = current_score !== 0 ? (score_change / current_score) * 100 : 0;

  // Identify affected metrics
  const affected_metrics = [];

  for (const change of request.changes) {
    const { metric_key } = change;
    const metric = metrics.find((m: ScoreMetric) => m.key === metric_key);
    if (!metric) continue;

    const currentBreakdown = currentResult.metric_breakdown.find(
      (mb) => mb.metric_key === metric_key
    );
    const projectedBreakdown = projectedResult.metric_breakdown.find(
      (mb) => mb.metric_key === metric_key
    );

    if (currentBreakdown && projectedBreakdown) {
      const current_points = currentBreakdown.points_awarded;
      const projected_points = projectedBreakdown.points_awarded;
      const points_change = projected_points - current_points;

      affected_metrics.push({
        metric_key,
        metric_label: metric.label,
        current_points: Math.round(current_points * 100) / 100,
        projected_points: Math.round(projected_points * 100) / 100,
        points_change: Math.round(points_change * 100) / 100,
      });
    }
  }

  // Generate new suggestions based on projected state
  const new_suggestions = generateAISuggestions(
    projectedResult.metric_breakdown,
    metrics,
    modifiedContext,
    projected_score
  );

  return {
    current_score: Math.round(current_score * 100) / 100,
    projected_score: Math.round(projected_score * 100) / 100,
    score_change: Math.round(score_change * 100) / 100,
    percentage_change: Math.round(percentage_change * 100) / 100,
    affected_metrics,
    new_suggestions,
  };
}

// Suggest optimal changes to maximize score
export function suggestOptimalChanges(
  rule: ScoreRule,
  metrics: ScoreMetric[],
  context: WalletContext
): Array<{ metric_key: string; metric_label: string; suggested_value: number | boolean; potential_gain: number }> {
  const currentResult = computeWalletScore(rule, metrics, context);
  const suggestions: Array<{
    metric_key: string;
    metric_label: string;
    suggested_value: number | boolean;
    potential_gain: number;
  }> = [];

  for (const breakdown of currentResult.metric_breakdown) {
    const deficit = breakdown.max_points - breakdown.points_awarded;

    // Only suggest if there's potential for improvement
    if (deficit < 1) continue;

    const metric = metrics.find((m: ScoreMetric) => m.id === breakdown.metric_id);
    if (!metric) continue;

    let suggested_value: number | boolean;
    let potential_gain = deficit;

    // Determine optimal value based on metric type
    if (metric.type === 'numeric_range') {
      const config = metric.config as { min_value: number; max_value: number };
      // Suggest max value for maximum points
      suggested_value = config.max_value;
    } else if (metric.type === 'boolean') {
      const config = metric.config as { true_points: number; false_points: number };
      // Suggest true if it gives more points
      suggested_value = config.true_points > config.false_points;
    } else {
      // list_count - suggest max_items or a reasonable high value
      const config = metric.config as { points_per_item: number; max_items?: number };
      suggested_value = config.max_items || 10;
    }

    suggestions.push({
      metric_key: metric.key,
      metric_label: metric.label,
      suggested_value,
      potential_gain: Math.round(potential_gain * 100) / 100,
    });
  }

  // Sort by potential gain (highest first)
  suggestions.sort((a, b) => b.potential_gain - a.potential_gain);

  return suggestions.slice(0, 5); // Top 5 opportunities
}
