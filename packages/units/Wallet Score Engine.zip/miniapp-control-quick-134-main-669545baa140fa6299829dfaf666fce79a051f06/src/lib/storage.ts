import type { ScoreMetric, ScoreRule, ScoreHistoryEntry, Attestation, Badge, WalletBadge, ScoreSnapshot, Webhook } from '@/types/score-engine';
import { SEED_BADGES } from './badge-engine';
import { createAttestationMetric } from './attestation-engine';

const STORAGE_KEYS = {
  METRICS: 'wallet_score_metrics',
  RULES: 'wallet_score_rules',
  HISTORY: 'wallet_score_history',
  ATTESTATIONS: 'wallet_score_attestations',
  BADGES: 'wallet_score_badges',
  WALLET_BADGES: 'wallet_score_wallet_badges',
  SNAPSHOTS: 'wallet_score_snapshots',
  WEBHOOKS: 'wallet_score_webhooks',
} as const;

// Seed data
const SEED_METRICS: ScoreMetric[] = [
  {
    id: 'metric_1',
    key: 'lp_amount',
    label: 'LP Amount',
    category: 'liquidity',
    description: 'Total liquidity provided in USD',
    weight: 1,
    max_points: 30,
    type: 'numeric_range',
    config: {
      min_value: 0,
      max_value: 10000,
    },
    enabled: true,
  },
  {
    id: 'metric_2',
    key: 'trade_count_30d',
    label: 'Trade Count (30d)',
    category: 'activity',
    description: 'Number of trades in the last 30 days',
    weight: 1,
    max_points: 25,
    type: 'numeric_range',
    config: {
      min_value: 0,
      max_value: 100,
    },
    enabled: true,
  },
  {
    id: 'metric_3',
    key: 'hold_time_days',
    label: 'Hold Time (Days)',
    category: 'loyalty',
    description: 'Average holding time for assets',
    weight: 1,
    max_points: 25,
    type: 'numeric_range',
    config: {
      min_value: 0,
      max_value: 365,
    },
    enabled: true,
  },
  {
    id: 'metric_4',
    key: 'in_high_trust_pack',
    label: 'In High-Trust Pack',
    category: 'loyalty',
    description: 'Member of verified high-trust community',
    weight: 1,
    max_points: 20,
    type: 'boolean',
    config: {
      true_points: 20,
      false_points: 0,
    },
    enabled: true,
  },
  createAttestationMetric(),
];

const SEED_RULES: ScoreRule[] = [
  {
    id: 'rule_1',
    name: 'Base Wallet Core Score',
    slug: 'base-wallet-core',
    description: 'Core scoring model for Base wallet evaluation',
    status: 'active',
    max_score: 100,
    metric_ids: ['metric_1', 'metric_2', 'metric_3', 'metric_4', 'metric_attestations'],
  },
];

// In-memory fallback
let metricsCache: ScoreMetric[] | null = null;
let rulesCache: ScoreRule[] | null = null;
let historyCache: ScoreHistoryEntry[] | null = null;
let attestationsCache: Attestation[] | null = null;
let badgesCache: Badge[] | null = null;
let walletBadgesCache: WalletBadge[] | null = null;
let snapshotsCache: ScoreSnapshot[] | null = null;
let webhooksCache: Webhook[] | null = null;

// Check if localStorage is available
function isLocalStorageAvailable(): boolean {
  try {
    if (typeof window === 'undefined') return false;
    const test = '__test__';
    localStorage.setItem(test, test);
    localStorage.removeItem(test);
    return true;
  } catch {
    return false;
  }
}

// Metrics
export function getMetrics(): ScoreMetric[] {
  if (!isLocalStorageAvailable()) {
    if (metricsCache === null) {
      metricsCache = [...SEED_METRICS];
    }
    return metricsCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.METRICS);
  if (!stored) {
    const metrics = [...SEED_METRICS];
    localStorage.setItem(STORAGE_KEYS.METRICS, JSON.stringify(metrics));
    return metrics;
  }

  return JSON.parse(stored) as ScoreMetric[];
}

export function saveMetrics(metrics: ScoreMetric[]): void {
  if (!isLocalStorageAvailable()) {
    metricsCache = metrics;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.METRICS, JSON.stringify(metrics));
}

export function getMetricById(id: string): ScoreMetric | undefined {
  return getMetrics().find((m: ScoreMetric) => m.id === id);
}

// Rules
export function getRules(): ScoreRule[] {
  if (!isLocalStorageAvailable()) {
    if (rulesCache === null) {
      rulesCache = [...SEED_RULES];
    }
    return rulesCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.RULES);
  if (!stored) {
    const rules = [...SEED_RULES];
    localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
    return rules;
  }

  return JSON.parse(stored) as ScoreRule[];
}

export function saveRules(rules: ScoreRule[]): void {
  if (!isLocalStorageAvailable()) {
    rulesCache = rules;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.RULES, JSON.stringify(rules));
}

export function getRuleBySlug(slug: string): ScoreRule | undefined {
  return getRules().find((r: ScoreRule) => r.slug === slug);
}

export function getActiveRules(): ScoreRule[] {
  return getRules().filter((r: ScoreRule) => r.status === 'active');
}

// History
export function getHistory(): ScoreHistoryEntry[] {
  if (!isLocalStorageAvailable()) {
    if (historyCache === null) {
      historyCache = [];
    }
    return historyCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.HISTORY);
  if (!stored) {
    return [];
  }

  return JSON.parse(stored) as ScoreHistoryEntry[];
}

export function saveHistory(history: ScoreHistoryEntry[]): void {
  if (!isLocalStorageAvailable()) {
    historyCache = history;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.HISTORY, JSON.stringify(history));
}

export function addHistoryEntry(entry: ScoreHistoryEntry): void {
  const history = getHistory();
  history.unshift(entry);
  
  // Keep only the last 100 entries
  if (history.length > 100) {
    history.splice(100);
  }
  
  saveHistory(history);
}

export function clearHistory(): void {
  if (!isLocalStorageAvailable()) {
    historyCache = [];
    return;
  }

  localStorage.removeItem(STORAGE_KEYS.HISTORY);
}

// Attestations
export function getAttestations(): Attestation[] {
  if (!isLocalStorageAvailable()) {
    if (attestationsCache === null) {
      attestationsCache = [];
    }
    return attestationsCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.ATTESTATIONS);
  if (!stored) {
    return [];
  }

  return JSON.parse(stored) as Attestation[];
}

export function saveAttestations(attestations: Attestation[]): void {
  if (!isLocalStorageAvailable()) {
    attestationsCache = attestations;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.ATTESTATIONS, JSON.stringify(attestations));
}

export function getAttestationsByWallet(wallet: string): Attestation[] {
  return getAttestations().filter((a: Attestation) => a.wallet_address.toLowerCase() === wallet.toLowerCase());
}

export function addAttestation(attestation: Attestation): void {
  const attestations = getAttestations();
  attestations.push(attestation);
  saveAttestations(attestations);
}

// Badges
export function getBadges(): Badge[] {
  if (!isLocalStorageAvailable()) {
    if (badgesCache === null) {
      badgesCache = [...SEED_BADGES];
    }
    return badgesCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.BADGES);
  if (!stored) {
    const badges = [...SEED_BADGES];
    localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(badges));
    return badges;
  }

  return JSON.parse(stored) as Badge[];
}

export function saveBadges(badges: Badge[]): void {
  if (!isLocalStorageAvailable()) {
    badgesCache = badges;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.BADGES, JSON.stringify(badges));
}

// Wallet Badges
export function getWalletBadges(): WalletBadge[] {
  if (!isLocalStorageAvailable()) {
    if (walletBadgesCache === null) {
      walletBadgesCache = [];
    }
    return walletBadgesCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.WALLET_BADGES);
  if (!stored) {
    return [];
  }

  return JSON.parse(stored) as WalletBadge[];
}

export function saveWalletBadges(walletBadges: WalletBadge[]): void {
  if (!isLocalStorageAvailable()) {
    walletBadgesCache = walletBadges;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.WALLET_BADGES, JSON.stringify(walletBadges));
}

export function getWalletBadgesByAddress(wallet: string): WalletBadge[] {
  return getWalletBadges().filter((wb: WalletBadge) => wb.wallet_address.toLowerCase() === wallet.toLowerCase());
}

export function awardBadge(wallet: string, badgeId: string): void {
  const walletBadges = getWalletBadges();
  
  // Check if already earned
  const existing = walletBadges.find(
    (wb: WalletBadge) => wb.wallet_address.toLowerCase() === wallet.toLowerCase() && wb.badge_id === badgeId
  );
  
  if (existing) return;
  
  walletBadges.push({
    badge_id: badgeId,
    wallet_address: wallet,
    earned_at: new Date().toISOString(),
  });
  
  saveWalletBadges(walletBadges);
}

// Score Snapshots
export function getSnapshots(): ScoreSnapshot[] {
  if (!isLocalStorageAvailable()) {
    if (snapshotsCache === null) {
      snapshotsCache = [];
    }
    return snapshotsCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.SNAPSHOTS);
  if (!stored) {
    return [];
  }

  return JSON.parse(stored) as ScoreSnapshot[];
}

export function saveSnapshots(snapshots: ScoreSnapshot[]): void {
  if (!isLocalStorageAvailable()) {
    snapshotsCache = snapshots;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.SNAPSHOTS, JSON.stringify(snapshots));
}

export function getSnapshotsByWallet(wallet: string, ruleSlug?: string): ScoreSnapshot[] {
  let snapshots = getSnapshots().filter(
    (s: ScoreSnapshot) => s.wallet_address.toLowerCase() === wallet.toLowerCase()
  );
  
  if (ruleSlug) {
    snapshots = snapshots.filter((s: ScoreSnapshot) => s.rule_slug === ruleSlug);
  }
  
  return snapshots.sort((a: ScoreSnapshot, b: ScoreSnapshot) => 
    new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );
}

export function addSnapshot(snapshot: ScoreSnapshot): void {
  const snapshots = getSnapshots();
  snapshots.push(snapshot);
  
  // Keep only last 1000 snapshots
  if (snapshots.length > 1000) {
    snapshots.splice(0, snapshots.length - 1000);
  }
  
  saveSnapshots(snapshots);
}

// Webhooks
export function getWebhooks(): Webhook[] {
  if (!isLocalStorageAvailable()) {
    if (webhooksCache === null) {
      webhooksCache = [];
    }
    return webhooksCache;
  }

  const stored = localStorage.getItem(STORAGE_KEYS.WEBHOOKS);
  if (!stored) {
    return [];
  }

  return JSON.parse(stored) as Webhook[];
}

export function saveWebhooks(webhooks: Webhook[]): void {
  if (!isLocalStorageAvailable()) {
    webhooksCache = webhooks;
    return;
  }

  localStorage.setItem(STORAGE_KEYS.WEBHOOKS, JSON.stringify(webhooks));
}

export function addWebhook(webhook: Webhook): void {
  const webhooks = getWebhooks();
  webhooks.push(webhook);
  saveWebhooks(webhooks);
}

export function updateWebhook(id: string, updates: Partial<Webhook>): void {
  const webhooks = getWebhooks();
  const index = webhooks.findIndex((w: Webhook) => w.id === id);
  
  if (index !== -1) {
    webhooks[index] = { ...webhooks[index], ...updates };
    saveWebhooks(webhooks);
  }
}

export function deleteWebhook(id: string): void {
  const webhooks = getWebhooks().filter((w: Webhook) => w.id !== id);
  saveWebhooks(webhooks);
}
