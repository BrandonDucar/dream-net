import type { ScoreTrend, ScoreSnapshot, TrendDirection } from '@/types/score-engine';

export function calculateTrend(
  snapshots: ScoreSnapshot[],
  periodDays: number = 30
): ScoreTrend | null {
  if (snapshots.length < 2) {
    return null;
  }

  // Sort by timestamp (newest first)
  const sorted = [...snapshots].sort(
    (a: ScoreSnapshot, b: ScoreSnapshot) =>
      new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const now = Date.now();
  const periodMs = periodDays * 24 * 60 * 60 * 1000;
  const cutoffTime = now - periodMs;

  // Filter snapshots within the period
  const recentSnapshots = sorted.filter(
    (s: ScoreSnapshot) => new Date(s.timestamp).getTime() >= cutoffTime
  );

  if (recentSnapshots.length < 2) {
    return null;
  }

  const latestScore = recentSnapshots[0].normalized_score;
  const oldestScore = recentSnapshots[recentSnapshots.length - 1].normalized_score;

  const change_points = latestScore - oldestScore;
  const change_percentage = oldestScore !== 0 ? (change_points / oldestScore) * 100 : 0;

  let direction: TrendDirection;
  if (Math.abs(change_points) < 2) {
    direction = 'stable';
  } else if (change_points > 0) {
    direction = 'up';
  } else {
    direction = 'down';
  }

  return {
    direction,
    change_percentage: Math.round(change_percentage * 100) / 100,
    change_points: Math.round(change_points * 100) / 100,
    period_days: periodDays,
  };
}

export function getTrendEmoji(direction: TrendDirection): string {
  const emojis: Record<TrendDirection, string> = {
    up: '📈',
    down: '📉',
    stable: '➡️',
  };
  return emojis[direction];
}

export function getTrendColor(direction: TrendDirection): string {
  const colors: Record<TrendDirection, string> = {
    up: '#10b981', // green
    down: '#ef4444', // red
    stable: '#6b7280', // gray
  };
  return colors[direction];
}

// Generate score snapshots from history (helper for trend analysis)
export function generateSnapshotsFromHistory(
  entries: Array<{ wallet_address: string; rule_slug: string; total_score: number; normalized_score: number; created_at: string }>
): ScoreSnapshot[] {
  return entries.map((entry) => ({
    wallet_address: entry.wallet_address,
    rule_slug: entry.rule_slug,
    score: entry.total_score,
    normalized_score: entry.normalized_score,
    timestamp: entry.created_at,
  }));
}
