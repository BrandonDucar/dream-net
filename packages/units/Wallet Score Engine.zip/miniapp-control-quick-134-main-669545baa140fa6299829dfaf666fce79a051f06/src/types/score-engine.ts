export type MetricCategory = "liquidity" | "activity" | "loyalty" | "risk" | "custom";

export type MetricType = "numeric_range" | "boolean" | "list_count";

export type RuleStatus = "draft" | "active";

export type SuggestionImpact = "low" | "medium" | "high";

export type RiskLevel = "minimal" | "low" | "medium" | "high" | "critical";

export type AttestationStatus = "pending" | "verified" | "expired" | "revoked";

export type BadgeTier = "bronze" | "silver" | "gold" | "platinum" | "diamond";

export type TrendDirection = "up" | "down" | "stable";

export interface NumericRangeConfig {
  min_value: number;
  max_value: number;
}

export interface BooleanConfig {
  true_points: number;
  false_points: number;
}

export interface ListCountConfig {
  points_per_item: number;
  max_items?: number;
}

export type MetricConfig = NumericRangeConfig | BooleanConfig | ListCountConfig;

export interface ScoreMetric {
  id: string;
  key: string;
  label: string;
  category: MetricCategory;
  description?: string;
  weight: number;
  max_points: number;
  type: MetricType;
  config: MetricConfig;
  enabled: boolean;
}

export interface ScoreRule {
  id: string;
  name: string;
  slug: string;
  description?: string;
  status: RuleStatus;
  max_score: number;
  metric_ids: string[];
}

// NEW: Attestation system (Gitcoin Passport style)
export interface Attestation {
  id: string;
  wallet_address: string;
  type: string; // e.g., "github", "twitter", "ens", "farcaster", "email"
  provider: string;
  value: string; // the verified value (username, address, etc.)
  status: AttestationStatus;
  points: number; // contribution to score
  verified_at: string;
  expires_at?: string;
  metadata?: Record<string, unknown>;
}

// NEW: Badge/Achievement system
export interface Badge {
  id: string;
  key: string;
  name: string;
  description: string;
  tier: BadgeTier;
  icon: string; // emoji or icon name
  points: number;
  criteria: {
    type: string; // e.g., "score_threshold", "attestation_count", "activity_streak"
    value: number;
    description: string;
  };
  enabled: boolean;
}

export interface WalletBadge {
  badge_id: string;
  wallet_address: string;
  earned_at: string;
  metadata?: Record<string, unknown>;
}

// NEW: Time-series data point
export interface ScoreSnapshot {
  wallet_address: string;
  rule_slug: string;
  score: number;
  normalized_score: number;
  timestamp: string;
}

// NEW: Trend analysis
export interface ScoreTrend {
  direction: TrendDirection;
  change_percentage: number;
  change_points: number;
  period_days: number;
}

// NEW: Peer comparison
export interface PeerComparison {
  wallet_address: string;
  score: number;
  percentile: number; // 0-100
  rank: number;
  total_wallets: number;
  category_percentiles: Record<MetricCategory, number>;
}

// NEW: Risk assessment
export interface RiskAssessment {
  overall_risk: RiskLevel;
  risk_score: number; // 0-100, higher is riskier
  risk_factors: {
    factor: string;
    severity: RiskLevel;
    description: string;
    remediation?: string;
  }[];
  alerts: {
    id: string;
    title: string;
    message: string;
    severity: RiskLevel;
    created_at: string;
  }[];
}

// NEW: Credit score (300-850 FICO style)
export interface CreditScore {
  wallet_address: string;
  credit_score: number; // 300-850
  credit_tier: "poor" | "fair" | "good" | "very_good" | "excellent";
  factors: {
    payment_history: number; // 0-100
    liquidation_history: number; // 0-100
    credit_utilization: number; // 0-100
    account_age: number; // 0-100
    credit_mix: number; // 0-100
  };
  lending_capacity: number; // suggested max borrow in USD
  interest_tier: "premium" | "standard" | "subprime";
}

// Enhanced WalletContext
export interface WalletContext {
  wallet_address: string;
  numeric_signals?: Record<string, number>;
  flags?: Record<string, boolean>;
  tags?: string[];
  attestations?: Attestation[];
  on_chain_data?: {
    total_volume?: number;
    unique_protocols?: number;
    first_transaction_date?: string;
    last_transaction_date?: string;
    nft_count?: number;
    token_holdings?: number;
  };
}

export interface MetricBreakdown {
  metric_id: string;
  metric_key: string;
  metric_label: string;
  raw_value: number | boolean | null;
  points_awarded: number;
  max_points: number;
}

// Enhanced Suggestion with AI-powered insights
export interface Suggestion {
  title: string;
  description: string;
  impact: SuggestionImpact;
  estimated_points?: number;
  actionable_steps?: string[];
  time_estimate?: string; // e.g., "2-3 days", "1 week"
  priority?: number; // 1-5
}

// Enhanced ScoreResult
export interface ScoreResult {
  wallet_address: string;
  rule_slug: string;
  total_score: number;
  max_score: number;
  normalized_score: number;
  metric_breakdown: MetricBreakdown[];
  suggestions: Suggestion[];
  credit_score?: CreditScore;
  risk_assessment?: RiskAssessment;
  trend?: ScoreTrend;
  peer_comparison?: PeerComparison;
  badges_earned?: string[]; // badge IDs
  attestation_count?: number;
}

export interface ScoreHistoryEntry {
  id: string;
  wallet_address: string;
  rule_slug: string;
  total_score: number;
  normalized_score: number;
  metric_breakdown: MetricBreakdown[];
  suggestions: Suggestion[];
  created_at: string;
}

// NEW: Webhook configuration
export interface Webhook {
  id: string;
  url: string;
  events: WebhookEvent[];
  secret?: string;
  enabled: boolean;
  created_at: string;
  last_triggered?: string;
}

export type WebhookEvent =
  | "score.calculated"
  | "score.changed"
  | "badge.earned"
  | "attestation.verified"
  | "risk.alert"
  | "threshold.crossed";

export interface WebhookPayload {
  event: WebhookEvent;
  timestamp: string;
  data: {
    wallet_address: string;
    [key: string]: unknown;
  };
}

// NEW: Simulation request
export interface SimulationRequest {
  wallet_address: string;
  rule_slug: string;
  changes: {
    metric_key: string;
    new_value: number | boolean;
  }[];
}

export interface SimulationResult {
  current_score: number;
  projected_score: number;
  score_change: number;
  percentage_change: number;
  affected_metrics: {
    metric_key: string;
    metric_label: string;
    current_points: number;
    projected_points: number;
    points_change: number;
  }[];
  new_suggestions: Suggestion[];
}

// NEW: Analytics data
export interface WalletAnalytics {
  wallet_address: string;
  total_scores: number;
  average_score: number;
  best_score: number;
  worst_score: number;
  score_volatility: number;
  improvement_rate: number; // points per day
  active_days: number;
  badges_earned: number;
  attestations_verified: number;
  category_strengths: {
    category: MetricCategory;
    average_points: number;
    max_points: number;
    percentage: number;
  }[];
  recent_activity: {
    date: string;
    score: number;
    event: string;
  }[];
}
